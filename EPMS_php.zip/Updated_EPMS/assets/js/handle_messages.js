// This script handles displaying error/success messages
document.addEventListener('DOMContentLoaded', function() {
    // Check for messages in URL parameters (can be set by PHP with header redirects)
    const urlParams = new URLSearchParams(window.location.search);
    const errorMsg = urlParams.get('error');
    const successMsg = urlParams.get('success');
    
    const messageContainer = document.getElementById('message-container');
    
    if (errorMsg) {
        displayMessage(errorMsg, 'danger');
    } else if (successMsg) {
        displayMessage(successMsg, 'success');
    }
    
    // Function to display messages
    function displayMessage(message, type) {
        messageContainer.innerHTML = `
            <div class="alert alert-${type}">
                ${message}
            </div>
        `;
        
        // Auto-hide the message after 5 seconds
        setTimeout(() => {
            messageContainer.innerHTML = '';
        }, 5000);
    }
});

document.addEventListener('DOMContentLoaded', function() {
    const adminForm = document.getElementById('adminForm');
    
    if (adminForm) {
        adminForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(this);
            
            // Disable submit button during submission
            const submitButton = this.querySelector('button[type="submit"]');
            submitButton.disabled = true;
            submitButton.textContent = 'Processing...';
            
            // Send request to server
            fetch('admin/create_admin.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log("Response received:", response);
                return response.json();
            })
            .then(data => {
                console.log("Data received:", data);
                // Re-enable submit button
                submitButton.disabled = false;
                submitButton.textContent = 'Create Admin Account';
                
                if (data.status === 'success') {
                    // Show success message
                    alert(data.message);
                    
                    // Reset form on success
                    adminForm.reset();
                    
                    // Redirect to admin list or dashboard if needed
                    // window.location.href = 'admin/dashboard.php';
                } else {
                    // Show error message
                    alert(data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                submitButton.disabled = false;
                submitButton.textContent = 'Create Admin Account';
                alert('An error occurred. Please try again.');
            });
        });
    }
    
    // Password confirmation validation
    const passwordField = document.getElementById('password');
    const confirmPasswordField = document.getElementById('confirm_password');
    
    if (confirmPasswordField) {
        confirmPasswordField.addEventListener('input', function() {
            if (this.value === passwordField.value) {
                this.setCustomValidity('');
            } else {
                this.setCustomValidity('Passwords do not match');
            }
        });
    }
});