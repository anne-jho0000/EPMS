-- Create database
CREATE DATABASE IF NOT EXISTS epms_system;
USE epms_system;

-- Employees table
CREATE TABLE IF NOT EXISTS employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(20) NOT NULL UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('employee', 'manager', 'admin') NOT NULL DEFAULT 'employee',
    department VARCHAR(50),
    position VARCHAR(50),
    hire_date DATE,
    status ENUM('active', 'inactive', 'suspended') NOT NULL DEFAULT 'active',
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Login logs table
CREATE TABLE IF NOT EXISTS login_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(20) NOT NULL,
    success BOOLEAN NOT NULL DEFAULT 0,
    ip_address VARCHAR(45) NOT NULL,
    attempt_time DATETIME NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);

-- Password reset table
CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id VARCHAR(20) NOT NULL,
    token VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at DATETIME NOT NULL,
    used BOOLEAN NOT NULL DEFAULT 0,
    FOREIGN KEY (employee_id) REFERENCES employees(employee_id)
);

-- Insert sample employee data (password is 'password123' hashed)
INSERT INTO employees (employee_id, name, email, password, role, department, position, hire_date)
VALUES 
('EMP001', 'John Smith', 'john.smith@example.com', '$2y$10$KvGmQH8mzZ3ZtvU4TUkhvu4uK7yOEgFg.2HzmpJ9zxcTlPV5YtXD2', 'employee', 'Marketing', 'Marketing Specialist', '2022-01-15'),
('EMP002', 'Jane Doe', 'jane.doe@example.com', '$2y$10$KvGmQH8mzZ3ZtvU4TUkhvu4uK7yOEgFg.2HzmpJ9zxcTlPV5YtXD2', 'manager', 'Human Resources', 'HR Manager', '2021-06-10'),
('ADMIN01', 'Admin User', 'admin@example.com', '$2y$10$KvGmQH8mzZ3ZtvU4TUkhvu4uK7yOEgFg.2HzmpJ9zxcTlPV5YtXD2', 'admin', 'IT', 'System Administrator', '2020-11-05');


-- Create admin_users table if it doesn't exist
CREATE TABLE IF NOT EXISTS `admin_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` varchar(50) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `admin_role` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_login` datetime DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_id` (`admin_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;