<?php
// Start session
session_start();

// Database connection
function connectDB() {
    $host = "localhost";
    $dbname = "epms_db";
    $username = "db_username";
    $password = "db_password";
    
    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        // Set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch(PDOException $e) {
        die("Connection failed: " . $e->getMessage());
    }
}

// Function to validate employee login
function validateLogin($employee_id, $password) {
    $conn = connectDB();
    
    try {
        // Prepare SQL statement to prevent SQL injection
        $stmt = $conn->prepare("SELECT * FROM employees WHERE employee_id = :employee_id LIMIT 1");
        $stmt->bindParam(':employee_id', $employee_id);
        $stmt->execute();
        
        // Check if employee exists
        if ($stmt->rowCount() > 0) {
            $employee = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Verify password
            if (password_verify($password, $employee['password'])) {
                return [
                    'success' => true,
                    'employee' => $employee
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'Invalid password'
                ];
            }
        } else {
            return [
                'success' => false,
                'message' => 'Employee ID not found'
            ];
        }
    } catch(PDOException $e) {
        return [
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ];
    }
}

// Function to log login attempts
function logLoginAttempt($employee_id, $success, $ip_address) {
    $conn = connectDB();
    
    try {
        $stmt = $conn->prepare("INSERT INTO login_logs (employee_id, success, ip_address, attempt_time) 
                               VALUES (:employee_id, :success, :ip_address, NOW())");
        $stmt->bindParam(':employee_id', $employee_id);
        $stmt->bindParam(':success', $success, PDO::PARAM_BOOL);
        $stmt->bindParam(':ip_address', $ip_address);
        $stmt->execute();
    } catch(PDOException $e) {
        // Just log errors, don't stop the login process
        error_log("Failed to log login attempt: " . $e->getMessage());
    }
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize input
    $employee_id = filter_input(INPUT_POST, 'employee_id', FILTER_SANITIZE_STRING);
    $password = $_POST['password']; // No sanitizing for password as it could alter it
    
    // IP address for logging
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    // Validate credentials
    if (empty($employee_id) || empty($password)) {
        $_SESSION['login_error'] = "Employee ID and password are required";
        header("Location: employee_login.html");
        exit();
    }
    
    // Attempt login
    $result = validateLogin($employee_id, $password);
    
    // Log the attempt
    logLoginAttempt($employee_id, $result['success'], $ip_address);
    
    if ($result['success']) {
        // Set session variables
        $_SESSION['logged_in'] = true;
        $_SESSION['employee_id'] = $employee_id;
        $_SESSION['employee_name'] = $result['employee']['name'];
        $_SESSION['role'] = $result['employee']['role'];
        
        // Redirect to dashboard
        header("Location: employee_dashboard.php");
        exit();
    } else {
        // Set error message and redirect back to login
        $_SESSION['login_error'] = $result['message'];
        header("Location: employee_login.html");
        exit();
    }
} else {
    // If not a POST request, redirect to login page
    header("Location: employee_login.html");
    exit();
}
?>