<?php
// Start session
session_start();

// Database connection parameters
$db_host = "localhost";
$db_user = "epms_admin";
$db_pass = "your_secure_password";
$db_name = "epms_database";

// Initialize variables
$error_message = "";
$login_successful = false;

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $admin_id = trim($_POST["admin_id"]);
    $password = $_POST["password"];
    
    // Basic validation
    if (empty($admin_id) || empty($password)) {
        $error_message = "Both Admin ID and Password are required";
    } else {
        // Connect to database
        $conn = new mysqli($db_host, $db_user, $db_pass, $db_name);
        
        // Check connection
        if ($conn->connect_error) {
            $error_message = "Database connection failed: " . $conn->connect_error;
        } else {
            // Prepare SQL statement to prevent SQL injection
            $stmt = $conn->prepare("SELECT admin_id, password, name FROM administrators WHERE admin_id = ?");
            $stmt->bind_param("s", $admin_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows == 1) {
                $row = $result->fetch_assoc();
                
                // Verify password (using password_verify for hashed passwords)
                if (password_verify($password, $row["password"])) {
                    // Login successful
                    $_SESSION["admin_id"] = $row["admin_id"];
                    $_SESSION["admin_name"] = $row["name"];
                    $_SESSION["is_logged_in"] = true;
                    
                    // Redirect to dashboard
                    header("Location: admin_dashboard.php");
                    exit();
                } else {
                    $error_message = "Invalid password";
                }
            } else {
                $error_message = "Admin ID not found";
            }
            
            $stmt->close();
            $conn->close();
        }
    }
}

// Handle forgot password request
if (isset($_GET["action"]) && $_GET["action"] == "forgot_password") {
    // Redirect to password reset page
    header("Location: admin_password_reset.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EPMS Admin Portal</title>
    <style>
        /* Reset styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        /* Body styles from your CSS */
        body {
            background-color: #1e2633;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        /* Login container styles from your CSS */
        .login-container {
            background-color: #0e1521;
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(255, 216, 77, 0.2);
            width: 100%;
            max-width: 900px;
            overflow: hidden;
            display: flex;
            position: relative;
        }

        .login-container::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(255, 216, 77, 0.4);
            pointer-events: none;
        }

        /* Left panel for login form */
        .login-form-panel {
            flex: 1;
            padding: 40px;
            color: #ffffff;
        }

        .logo {
            margin-bottom: 30px;
            text-align: center;
        }

        .login-form-panel h1 {
            margin-bottom: 20px;
            font-size: 32px;
        }

        .login-form-panel p {
            color: #a0a0a0;
            margin-bottom: 40px;
        }

        .form-group {
            margin-bottom: 25px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 12px 15px;
            background-color: #243142;
            border: none;
            border-radius: 6px;
            color: #ffffff;
            font-size: 16px;
        }

        .forgot-password {
            text-align: right;
            margin-bottom: 25px;
        }

        .forgot-password a {
            color: #ffd84d;
            text-decoration: none;
        }

        .login-btn {
            width: 100%;
            padding: 14px;
            background-color: #ffd84d;
            color: #0e1521;
            border: none;
            border-radius: 6px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .login-btn:hover {
            background-color: #ffcc00;
        }

        /* Right panel for info */
        .info-panel {
            flex: 1;
            background-color: #ffd84d;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .info-panel h1 {
            font-size: 36px;
            margin-bottom: 20px;
            color: #0e1521;
        }

        .info-panel p {
            font-size: 16px;
            color: #333;
            margin-bottom: 40px;
            line-height: 1.5;
        }

        .sign-up-btn {
            align-self: flex-end;
            padding: 10px 20px;
            background-color: #0e1521;
            color: #ffffff;
            border: none;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
        }

        .info-icon {
            align-self: flex-end;
            margin-top: auto;
        }

        /* Error message styling */
        .error-message {
            background-color: rgba(255, 77, 77, 0.2);
            border-left: 4px solid #ff4d4d;
            padding: 10px;
            margin-bottom: 20px;
            color: #ff9999;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .login-container {
                flex-direction: column;
            }
            
            .info-panel {
                order: -1;
            }
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="login-form-panel">
            <div class="logo">
                <img src="images/epms_logo.png" alt="EPMS Logo" width="80">
            </div>
            <h1>Admin Login</h1>
            <p>Access administrative controls and system management</p>
            
            <?php if (!empty($error_message)): ?>
            <div class="error-message">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="admin-id">Admin ID</label>
                    <input type="text" id="admin-id" name="admin_id" placeholder="Enter your admin ID" value="<?php echo isset($_POST['admin_id']) ? htmlspecialchars($_POST['admin_id']) : ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password">
                </div>
                
                <div class="forgot-password">
                    <a href="?action=forgot_password">Forgot Password?</a>
                </div>
                
                <button type="submit" class="login-btn">Login</button>
            </form>
        </div>
        
        <div class="info-panel">
            <h1>ADMIN PORTAL</h1>
            <p>Welcome to the administrative portal. Manage employee accounts, process payments, configure system settings, and oversee all aspects of the Employment Payment Management System.</p>
            
            <a href="admin_signup.php" class="sign-up-btn">Sign Up Admin</a>
            
            <div class="info-icon">
                <img src="images/admin_icon.png" alt="Admin" width="40">
            </div>
        </div>
    </div>
</body>
</html>