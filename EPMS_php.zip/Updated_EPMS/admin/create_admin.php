<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Database connection
include 'config.php'; // This should have your database connection

// Start session if not already started
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Log function to track what's happening
function log_debug($message) {
    error_log(date('[Y-m-d H:i:s] ') . $message . "\n", 3, 'admin_create_debug.log');
}

log_debug("Script started");

// Function to validate input data
function validate_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    log_debug("Form submitted with data: " . print_r($_POST, true));
    
    // Get form data and validate
    $admin_id = validate_input($_POST['admin_id']);
    $full_name = validate_input($_POST['full_name']);
    $email = validate_input($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $admin_role = validate_input($_POST['admin_role']);
    
    // Validation
    $errors = [];
    
    // Check if fields are empty
    if (empty($admin_id)) $errors[] = "Admin ID is required";
    if (empty($full_name)) $errors[] = "Full Name is required";
    if (empty($email)) $errors[] = "Email address is required";
    if (empty($password)) $errors[] = "Password is required";
    if (empty($admin_role)) $errors[] = "Admin Role is required";
    
    // Validate email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) && !empty($email)) {
        $errors[] = "Invalid email format";
    }
    
    // Check if passwords match
    if ($password !== $confirm_password) {
        $errors[] = "Passwords do not match";
    }
    
    // If no validation errors, proceed
    if (empty($errors)) {
        // Hash password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        // Check if admin exists (by admin_id or email)
        $check_sql = "SELECT * FROM admin_users WHERE admin_id = ? OR email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("ss", $admin_id, $email);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        log_debug("Checking if admin exists with ID: $admin_id or email: $email");
        
        if ($result->num_rows > 0) {
            // Admin exists, update information
            $admin_data = $result->fetch_assoc();
            
            // If updating based on admin_id but email exists for another admin
            if ($admin_data['admin_id'] != $admin_id && $admin_data['email'] == $email) {
                $response = [
                    "status" => "error",
                    "message" => "Email already exists for another admin."
                ];
            } else {
                // Update admin information
                $update_sql = "UPDATE admin_users SET full_name = ?, email = ?, password = ?, admin_role = ? WHERE admin_id = ?";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->bind_param("sssss", $full_name, $email, $hashed_password, $admin_role, $admin_id);
                log_debug("Query execution result: " . ($insert_stmt->affected_rows ?? $update_stmt->affected_rows ?? 'unknown'));

                if ($update_stmt->execute()) {
                    $response = [
                        "status" => "success",
                        "message" => "Admin account updated successfully."
                    ];
                } else {
                    $response = [
                        "status" => "error",
                        "message" => "Error updating account: " . $conn->error
                    ];
                }
                $update_stmt->close();
            }
        } else {
            // Create new admin
            $insert_sql = "INSERT INTO admin_users (admin_id, full_name, email, password, admin_role, created_at) 
                          VALUES (?, ?, ?, ?, ?, NOW())";
            $insert_stmt = $conn->prepare($insert_sql);
            $insert_stmt->bind_param("sssss", $admin_id, $full_name, $email, $hashed_password, $admin_role);
            
            if ($insert_stmt->execute()) {
                $response = [
                    "status" => "success",
                    "message" => "Admin account created successfully."
                ];
            } else {
                $response = [
                    "status" => "error",
                    "message" => "Error creating account: " . $conn->error
                ];
            }
            $insert_stmt->close();
        }
        
        $check_stmt->close();
    } else {
        // Return validation errors
        $response = [
            "status" => "error",
            "message" => "Validation errors: " . implode(", ", $errors)
        ];
    }
    log_debug("Sending response: " . json_encode($response));

    // Return JSON response for AJAX requests
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
}
?>