<?php
// Start session
session_start();

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "epms_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$admin_id = $password = "";
$admin_id_err = $password_err = $login_err = "";
$signup_modal = false;

// Process login form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["login"])) {
        // Validate admin ID
        if (empty(trim($_POST["admin_id"]))) {
            $admin_id_err = "Please enter your Admin ID.";
        } else {
            $admin_id = trim($_POST["admin_id"]);
        }
        
        // Validate password
        if (empty(trim($_POST["password"]))) {
            $password_err = "Please enter your password.";
        } else {
            $password = trim($_POST["password"]);
        }
        
        // Authenticate user
        if (empty($admin_id_err) && empty($password_err)) {
            $sql = "SELECT id, admin_id, password FROM admins WHERE admin_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $param_admin_id);
            $param_admin_id = $admin_id;
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows == 1) {
                $stmt->bind_result($id, $admin_id, $hashed_password);
                if ($stmt->fetch()) {
                    if (password_verify($password, $hashed_password)) {
                        // Start a new session
                        session_start();
                        
                        // Store data in session variables
                        $_SESSION["loggedin"] = true;
                        $_SESSION["id"] = $id;
                        $_SESSION["admin_id"] = $admin_id;
                        
                        // Redirect to admin dashboard
                        header("location: dashboard.php");
                        exit;
                    } else {
                        $login_err = "Invalid Admin ID or password.";
                    }
                }
            } else {
                $login_err = "Invalid Admin ID or password.";
            }
            $stmt->close();
        }
    } elseif (isset($_POST["signup"])) {
        // Process signup logic here
        // This would handle admin registration - for example purpose only
        // In a real system, admin creation might need additional security or approval
        $signup_modal = true;
    }
}

// Close connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EPMS Admin Portal</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            background-color: #1e2633;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background-color: #0e1521;
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(255, 216, 77, 0.2);
            width: 100%;
            max-width: 900px;
            overflow: hidden;
            display: flex;
            position: relative;
        }
        
        .left-panel {
            width: 40%;
            background-color: #0e1521;
            padding: 40px;
            color: white;
            display: flex;
            flex-direction: column;
        }
        
        .right-panel {
            flex: 1;
            background: linear-gradient(135deg, #ffd84d 0%, #ffc107 100%);
            color: #333;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            clip-path: polygon(10% 0, 100% 0, 100% 100%, 0 100%);
        }
        
        .logo {
            margin-bottom: 40px;
        }
        
        .login-title {
            font-size: 32px;
            font-weight: bold;
            margin-bottom: 15px;
        }
        
        .login-subtitle {
            color: #adb5bd;
            margin-bottom: 50px;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        .form-group input {
            width: 100%;
            padding: 15px;
            background-color: #2a3042;
            border: none;
            border-radius: 8px;
            color: white;
            font-size: 16px;
        }
        
        .form-group input::placeholder {
            color: #6c757d;
        }
        
        .form-group input:focus {
            outline: none;
            background-color: #323a4e;
        }
        
        .forgot-password {
            text-align: right;
            margin-top: 10px;
        }
        
        .forgot-password a {
            color: #fcd535;
            text-decoration: none;
            font-size: 14px;
        }
        
        .login-btn {
            width: 100%;
            padding: 15px;
            background-color: #fcd535;
            border: none;
            border-radius: 8px;
            color: #000;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
            transition: all 0.3s;
        }
        
        .login-btn:hover {
            background-color: #ffda58;
        }
        
        .portal-title {
            font-size: 42px;
            font-weight: bold;
            position: relative;
            left: 60px;
            margin-bottom: 20px;
            color: #1c2231;
        }
        
        .portal-description {
            font-size: 16px;
            line-height: 1.6;
            color: #1c2231;
            position: relative;
            left: 30px;
            margin-bottom: 40px;
        }
        
        .portal-image {
            position: absolute;
            bottom: 30px;
            right: 30px;
            max-width: 80px;
            
        }
        
        .error-text {
            color: #ff3e3e;
            font-size: 14px;
            margin-top: 5px;
        }
        
        /* Sign Up Button in Corner */
        .signup-btn-corner {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #1c2231;
            color: #fcd535;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            z-index: 10;
            transition: all 0.3s ease;
        }
        
        .signup-btn-corner:hover {
            background-color: #2a3042;
            transform: scale(1.05);
            box-shadow: 0 0 10px rgba(28, 34, 49, 0.5);
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 100;
            justify-content: center;
            align-items: center;
        }
        
        .modal-active {
            display: flex;
            animation: fadeIn 0.3s ease;
        }
        
        .modal-content {
            background-color: #032331;
            width: 500px;
            border-radius: 10px;
            padding: 30px;
            position: relative;
            box-shadow: 0 0 30px rgba(0, 255, 255, 0.3);
            overflow: hidden;
        }
        
        .modal-content::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            box-shadow: inset 0 0 15px rgba(0, 255, 255, 0.5);
            pointer-events: none;
            border-radius: 10px;
            z-index: 1;
        }
        
        .close-modal {
            position: absolute;
            top: 15px;
            right: 15px;
            font-size: 24px;
            cursor: pointer;
            color: #fcd535;
            z-index: 2;
        }
        
        .modal-title {
            text-align: center;
            color: #00e6ff;
            font-size: 24px;
            margin-bottom: 20px;
        }
        
        .modal-form-group {
            margin-bottom: 20px;
            position: relative;
            z-index: 2;
        }
        
        .modal-form-group input {
            width: 100%;
            padding: 12px;
            background-color: transparent;
            border: none;
            border-bottom: 1px solid #00c3d9;
            color: white;
            outline: none;
            font-size: 16px;
        }
        
        .modal-form-group input:focus {
            border-bottom: 2px solid #00e6ff;
        }
        
        .modal-btn {
            width: 100%;
            padding: 14px;
            background: linear-gradient(to right, #00a2b8, #00e6ff);
            border: none;
            border-radius: 50px;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 20px;
            transition: all 0.3s ease;
            z-index: 2;
            position: relative;
        }
        
        .modal-btn:hover {
            background: linear-gradient(to right, #00c3d9, #00f2ff);
            box-shadow: 0 0 15px rgba(0, 230, 255, 0.5);
        }
        
        .modal-divider {
            display: flex;
            align-items: center;
            margin: 20px 0;
            color: #6c757d;
        }
        
        .modal-divider::before,
        .modal-divider::after {
            content: "";
            flex: 1;
            border-bottom: 1px solid #6c757d;
        }
        
        .modal-divider::before {
            margin-right: 10px;
        }
        
        .modal-divider::after {
            margin-left: 10px;
        }
        
        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }
        
        @keyframes slideIn {
            from {
                transform: translateY(-50px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }
        
        .icon {
            position: absolute;
            right: 10px;
            top: 40px;
            color: #00c3d9;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="left-panel">
            <div class="logo">
                <img src="..\assets\images\logo2.png" alt="EPMS Logo" height="50">
            </div>
            
            <h1 class="login-title">Admin Login</h1>
            <p class="login-subtitle">Access administrative controls and system management</p>
            
            <?php if (!empty($login_err)): ?>
                <div class="error-text"><?php echo $login_err; ?></div>
            <?php endif; ?>
            
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label for="admin_id">Admin ID</label>
                    <input type="text" id="admin_id" name="admin_id" placeholder="Enter your admin ID" value="<?php echo $admin_id; ?>">
                    <?php if (!empty($admin_id_err)): ?>
                        <span class="error-text"><?php echo $admin_id_err; ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="Enter your password">
                    <?php if (!empty($password_err)): ?>
                        <span class="error-text"><?php echo $password_err; ?></span>
                    <?php endif; ?>
                </div>
                
                <div class="forgot-password">
                    <a href="#">Forgot Password?</a>
                </div>
                
                <button type="submit" name="login" class="login-btn">Login</button>
            </form>
        </div>
        
        <div class="right-panel">
            <button id="signupBtn" class="signup-btn-corner">Sign Up Admin</button>
            
            <h1 class="portal-title">ADMIN PORTAL</h1>
            <p class="portal-description">
                Welcome to the administrative portal. Manage employee accounts, process payments, configure 
                system settings, and oversee all aspects of the Employment Payment Management System.
            </p>
            
            <img src="..\assets\images\admin.jpg" alt="Admin" class="portal-image">
        </div>
    </div>
    
    <!-- Sign Up Modal -->
    <div id="signupModal" class="modal">
        <div class="modal-content">
            <span class="close-modal" id="closeModal">&times;</span>
            
            <h2 class="modal-title">Sign Up New Admin</h2>
            
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="modal-form-group">
                    <input type="text" name="new_admin_id" placeholder="Admin ID">
                    <span class="icon">👤</span>
                </div>
                
                <div class="modal-form-group">
                    <input type="text" name="full_name" placeholder="Full Name">
                    <span class="icon">📝</span>
                </div>
                
                <div class="modal-form-group">
                    <input type="email" name="email" placeholder="Email Address">
                    <span class="icon">✉</span>
                </div>
                
                <div class="modal-form-group">
                    <input type="password" name="new_password" placeholder="Password">
                    <span class="icon">🔒</span>
                </div>
                
                <div class="modal-form-group">
                    <input type="password" name="confirm_password" placeholder="Confirm Password">
                    <span class="icon">🔒</span>
                </div>
                
                <div class="modal-divider">Admin Role</div>
                
                <div class="modal-form-group">
                    <select name="admin_role" style="width: 100%; padding: 12px; background-color: #0a3241; border: 1px solid #00c3d9; color: white; border-radius: 5px;">
                        <option value="">Select Admin Role</option>
                        <option value="system_admin">System Admin</option>
                        <option value="hr_admin">HR Admin</option>
                        <option value="finance_admin">Finance Admin</option>
                    </select>
                </div>
                
                <button type="submit" name="signup" class="modal-btn">Create Admin Account</button>
            </form>
        </div>
    </div>
    
    <script>
        // Get modal elements
        const modal = document.getElementById("signupModal");
        const btnSignup = document.getElementById("signupBtn");
        const closeBtn = document.getElementById("closeModal");
        
        // Open modal when signup button is clicked
        btnSignup.addEventListener("click", function() {
            modal.classList.add("modal-active");
            document.querySelector(".modal-content").style.animation = "slideIn 0.3s ease forwards";
        });
        
        // Close modal when X is clicked
        closeBtn.addEventListener("click", function() {
            modal.classList.remove("modal-active");
        });
        
        // Close modal when clicking outside of it
        window.addEventListener("click", function(event) {
            if (event.target === modal) {
                modal.classList.remove("modal-active");
            }
        });
        
        // Show modal if signup was attempted
        <?php if ($signup_modal): ?>
        window.addEventListener("load", function() {
            modal.classList.add("modal-active");
            document.querySelector(".modal-content").style.animation = "slideIn 0.3s ease forwards";
        });
        <?php endif; ?>
    </script>
</body>
</html>