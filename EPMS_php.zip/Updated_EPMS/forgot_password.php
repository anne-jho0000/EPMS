<?php
// Include the database configuration and functions
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Initialize variables
$email = '';
$message = '';
$error = '';
$success = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get email from form
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    
    // Validate email
    if (empty($email)) {
        $error = 'Please enter your email address.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } else {
        // Connect to database
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
        
        // Check connection
        if ($conn->connect_error) {
            $error = 'Database connection failed. Please try again later.';
        } else {
            // Prepare statement to find employee by email
            $stmt = $conn->prepare("SELECT employee_id, first_name FROM employees WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                // No user found with this email
                $error = 'No account found with this email address.';
            } else {
                // User found, generate reset token
                $row = $result->fetch_assoc();
                $employee_id = $row['employee_id'];
                $first_name = $row['first_name'];
                
                // Generate a unique token
                $token = bin2hex(random_bytes(32));
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                // Store token in database
                $stmt = $conn->prepare("DELETE FROM password_resets WHERE employee_id = ?");
                $stmt->bind_param("s", $employee_id);
                $stmt->execute();
                
                $stmt = $conn->prepare("INSERT INTO password_resets (employee_id, token, expires) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $employee_id, $token, $expires);
                $stmt->execute();
                
                // Send email with reset link
                $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/epms/reset_password.php?token=" . $token;
                $subject = "EPMS Password Reset";
                $email_body = "Hello $first_name,\n\n";
                $email_body .= "You have requested a password reset for your EPMS account.\n\n";
                $email_body .= "Please click the link below to reset your password:\n";
                $email_body .= "$reset_link\n\n";
                $email_body .= "This link will expire in 1 hour.\n\n";
                $email_body .= "If you did not request this reset, please ignore this email.\n\n";
                $email_body .= "Regards,\nEPMS Team";
                
                $headers = "From: noreply@epms.example.com\r\n";
                
                if (mail($email, $subject, $email_body, $headers)) {
                    $success = true;
                    $message = "A password reset link has been sent to your email address. Please check your inbox.";
                    $email = ''; // Clear email field
                } else {
                    $error = "Failed to send email. Please try again later.";
                }
            }
            
            $stmt->close();
            $conn->close();
        }
    }
}

// Include header
include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - EPMS</title>
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="assets/js/handle_messages.js" defer></script>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <div class="logo-container">
                <img src="assets/images/epms-logo.png" alt="EPMS Logo" class="logo">
            </div>
            <h1>Forgot Password</h1>
            
            <?php if ($success): ?>
                <div class="message success" id="success-message">
                    <?php echo $message; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="message error" id="error-message">
                    <?php echo $error; ?>
                </div>
            <?php endif; ?>
            
            <p class="instruction">Enter your email address below to receive a password reset link.</p>
            
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" placeholder="Enter your email" required>
                </div>
                
                <div class="form-actions">
                    <button type="submit" class="btn primary-btn">Send Reset Link</button>
                    <a href="index.html" class="btn secondary-btn">Back to Login</a>
                </div>
            </form>
            
            <div class="help-text">
                <p>Need assistance? <a href="contact_admin.php">Contact Admin</a></p>
            </div>
        </div>
    </div>
</body>
</html>