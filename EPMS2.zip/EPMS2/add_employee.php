<?php
// Include database connection
require_once 'database.php';

// Initialize variables and arrays
$firstName = $lastName = $email = $phone = $hireDate = $jobTitle = $department = $password = "";
// Remove username from initialization or set it to empty string
// $username = "";
$errors = [];
$successMessage = "";

// Helper Functions
function validatePassword($password) {
    $errors = [];
    if (strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters long";
    }
    if (!preg_match("/[A-Z]/", $password)) {
        $errors[] = "Password must contain at least one uppercase letter";
    }
    if (!preg_match("/[a-z]/", $password)) {
        $errors[] = "Password must contain at least one lowercase letter";
    }
    if (!preg_match("/[0-9]/", $password)) {
        $errors[] = "Password must contain at least one number";
    }
    if (!preg_match("/[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?]/", $password)) {
        $errors[] = "Password must contain at least one special character";
    }
    return $errors;
}

function getDepartments() {
    return [
        "Administration",
        "Finance",
        "Human Resources",
        "Information Technology",
        "Marketing",
        "Operations",
        "Research and Development",
        "Sales"
    ];
}

// Form Processing
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize form data
    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $hireDate = trim($_POST['hire_date']);
    $jobTitle = trim($_POST['job_title']);
    $department = trim($_POST['department']);
    // Remove this line since username field is removed from the form
    // $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    // Validate required fields
    if (empty($firstName)) $errors[] = "First name is required";
    if (empty($lastName)) $errors[] = "Last name is required";
    if (empty($email)) $errors[] = "Email is required";
    if (empty($phone)) $errors[] = "Phone is required";
    if (empty($hireDate)) $errors[] = "Hire date is required";
    if (empty($jobTitle)) $errors[] = "Job title is required";
    if (empty($department)) $errors[] = "Department is required";
    // Remove or comment out username validation
    // if (empty($username)) $errors[] = "Username is required";

    // Remove or comment out username duplicate check
    /*
    if (!empty($username)) {
        $checkDuplicate = "SELECT COUNT(*) as count FROM employees WHERE username = ?";
        $stmt = mysqli_prepare($conn, $checkDuplicate);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_assoc($result);
            if ($row['count'] > 0) {
                $errors[] = "Username '" . htmlspecialchars($username) . "' already exists. Please choose a different username.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    */

    // Validate password
    $passwordValidationErrors = validatePassword($password);
    if (!empty($passwordValidationErrors)) {
        $errors = array_merge($errors, $passwordValidationErrors);
    }

    // Database insertion if no errors
    if (empty($errors)) {
        // First check if email already exists
        $checkEmail = "SELECT COUNT(*) as count FROM employees WHERE email = ?";
        $stmt = mysqli_prepare($conn, $checkEmail);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_assoc($result);
            if ($row['count'] > 0) {
                $errors[] = "Email address already exists. Please use a different email.";
            }
            mysqli_stmt_close($stmt);
        }

        if (empty($errors)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            // Generate username from email (before the @ symbol)
            $username = strtolower(explode('@', $email)[0]);
            $baseUsername = $username;
            $counter = 1;
            
            // Check if username exists and append number if it does
            do {
                $checkUsername = "SELECT COUNT(*) as count FROM employees WHERE username = ?";
                $stmt = mysqli_prepare($conn, $checkUsername);
                mysqli_stmt_bind_param($stmt, "s", $username);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $row = mysqli_fetch_assoc($result);
                
                if ($row['count'] > 0) {
                    $username = $baseUsername . $counter;
                    $counter++;
                } else {
                    break;
                }
            } while (true);
            
            $insertQuery = "INSERT INTO employees (first_name, last_name, email, phone, hire_date, job_title, department, password, username, created_at) 
                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())";
            
            $stmt = mysqli_prepare($conn, $insertQuery);
            
            if ($stmt) {
                mysqli_stmt_bind_param(
                    $stmt, 
                    "sssssssss",
                    $firstName, 
                    $lastName, 
                    $email, 
                    $phone, 
                    $hireDate, 
                    $jobTitle, 
                    $department, 
                    $hashedPassword,
                    $username
                );
        
                if (mysqli_stmt_execute($stmt)) {
                    $employeeId = mysqli_insert_id($conn);
                    $successMessage = "Employee added successfully! Employee ID: " . $employeeId;
                    
                    // Log admin activity
                    if (function_exists('logAdminActivity') && isset($_SESSION['admin_id'])) {
                        $activityDescription = "Added new employee: $firstName $lastName (ID: $employeeId)";
                        logAdminActivity($_SESSION['admin_id'], 'New Employee Added', $activityDescription);
                    }
                    
                    // Clear form fields
                    $firstName = $lastName = $email = $phone = $hireDate = $jobTitle = $department = $password = "";
                } else {
                    $errors[] = "Error adding employee: " . mysqli_stmt_error($stmt);
                }
                mysqli_stmt_close($stmt);
            } else {
                $errors[] = "Error preparing statement: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Employee - EPMS</title>
    <style>
        :root {
            --primary-color: #ffde59; /* Yellow from logo */
            --secondary-color: #5e5e5e; /* Dark gray from logo */
            --lighter-gray: #f0f0f0;
            --white: #ffffff;
            --error: #d32f2f;
            --success: #388e3c;
        }
        
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: var(--lighter-gray);
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            position: relative;
        }
        
        .back-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .back-button:hover {
            background-color: var(--primary-color);
            color: var(--secondary-color);
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-top: 20px;
        }
        
        .logo {
            max-width: 150px;
            height: auto;
            margin-bottom: 15px;
        }
        
        h1 {
            color: var(--secondary-color);
            margin-top: 0;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            color: var(--secondary-color);
            font-weight: bold;
        }
        
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }
        
        .required:after {
            content: " *";
            color: var(--error);
        }
        
        .btn-submit {
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn-submit:hover {
            background-color: var(--primary-color);
            color: var(--secondary-color);
        }
        
        .error-message {
            color: var(--error);
            padding: 10px;
            background-color: rgba(211, 47, 47, 0.1);
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .success-message {
            color: var(--success);
            padding: 10px;
            background-color: rgba(56, 142, 60, 0.1);
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="adminHome.php" class="back-button">Back to Admin Home</a>
        
        <div class="header">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
            <h1>Add New Employee</h1>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="error-message">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($successMessage)): ?>
            <div class="success-message">
                <?php echo htmlspecialchars($successMessage); ?>
            </div>
        <?php endif; ?>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <!-- Personal Information -->
            <div class="form-group">
                <label for="first_name" class="required">First Name</label>
                <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($firstName); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="last_name" class="required">Last Name</label>
                <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($lastName); ?>" required>
            </div>
            
            <!-- Contact Information -->
            <div class="form-group">
                <label for="email" class="required">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>">
            </div>
            
            <!-- Employment Information -->
            <div class="form-group">
                <label for="hire_date" class="required">Hire Date</label>
                <input type="date" id="hire_date" name="hire_date" value="<?php echo htmlspecialchars($hireDate); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="job_title" class="required">Job Title</label>
                <input type="text" id="job_title" name="job_title" value="<?php echo htmlspecialchars($jobTitle); ?>" required>
            </div>
            
            <div class="form-group">
                <label for="department" class="required">Department</label>
                <select id="department" name="department" required>
                    <option value="">-- Select Department --</option>
                    <?php foreach (getDepartments() as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept); ?>" 
                                <?php echo $department === $dept ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Login Credentials -->
            <!-- Remove the username field section -->
            <!--
            <div class="form-group">
                <label for="username" class="required">Username</label>
                <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
                <small class="form-text text-muted">This will be used for login purposes.</small>
            </div>
            -->

            <div class="form-group">
                <label for="password" class="required">Password</label>
                <input type="password" id="password" name="password" required>
                <small class="form-text text-muted">Password must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.</small>
            </div>

            <!-- Submit Button -->
            <div class="form-group">
                <button type="submit" class="btn-submit">Add Employee</button>
            </div>
        </form>
    </div>
</body>
</html>