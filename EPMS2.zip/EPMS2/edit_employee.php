<?php
// Include database connection
require_once 'database.php';

// Check if employee ID is provided
if (!isset($_GET['id'])) {
    echo "No employee ID provided.";
    exit();
}

$emp_id = mysqli_real_escape_string($conn, $_GET['id']);

// Fetch employee details with benefits
$sql = "SELECT e.*, eb.* 
        FROM employees e
        LEFT JOIN employee_benefits eb ON e.emp_id = eb.emp_id
        WHERE e.emp_id = '$emp_id'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 0) {
    echo "Employee not found.";
    exit();
}

$employee = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect employee details
    $first_name = mysqli_real_escape_string($conn, $_POST['first_name']);
    $last_name = mysqli_real_escape_string($conn, $_POST['last_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $hire_date = mysqli_real_escape_string($conn, $_POST['hire_date']);
    $job_title = mysqli_real_escape_string($conn, $_POST['job_title']);
    $department = mysqli_real_escape_string($conn, $_POST['department']);
    $salary = mysqli_real_escape_string($conn, $_POST['salary']);

    // Collect benefits details
    $sss_number = mysqli_real_escape_string($conn, $_POST['sss_number']);
    $sss_contribution = mysqli_real_escape_string($conn, $_POST['sss_contribution']);
    $pagibig_number = mysqli_real_escape_string($conn, $_POST['pagibig_number']);
    $pagibig_contribution = mysqli_real_escape_string($conn, $_POST['pagibig_contribution']);
    $philhealth_number = mysqli_real_escape_string($conn, $_POST['philhealth_number']);
    $philhealth_contribution = mysqli_real_escape_string($conn, $_POST['philhealth_contribution']);
    $tin_number = mysqli_real_escape_string($conn, $_POST['tin_number']);
    $tax_contribution = mysqli_real_escape_string($conn, $_POST['tax_contribution']);

    // Start transaction
    mysqli_begin_transaction($conn);

    try {
        // Update employees table
        $update_employee_sql = "UPDATE employees SET 
            first_name = '$first_name', 
            last_name = '$last_name', 
            email = '$email', 
            phone = '$phone', 
            hire_date = '$hire_date', 
            job_title = '$job_title', 
            department = '$department', 
            salary = '$salary' 
        WHERE emp_id = '$emp_id'";

        // Update or insert employee benefits
        $update_benefits_sql = "INSERT INTO employee_benefits 
            (emp_id, sss_number, sss_contribution, 
            pagibig_number, pagibig_contribution, 
            philhealth_number, philhealth_contribution, 
            tin_number, tax_contribution) 
        VALUES 
            ('$emp_id', '$sss_number', '$sss_contribution', 
            '$pagibig_number', '$pagibig_contribution', 
            '$philhealth_number', '$philhealth_contribution', 
            '$tin_number', '$tax_contribution')
        ON DUPLICATE KEY UPDATE 
            sss_number = '$sss_number', 
            sss_contribution = '$sss_contribution', 
            pagibig_number = '$pagibig_number', 
            pagibig_contribution = '$pagibig_contribution', 
            philhealth_number = '$philhealth_number', 
            philhealth_contribution = '$philhealth_contribution', 
            tin_number = '$tin_number', 
            tax_contribution = '$tax_contribution'";

        // Execute queries
        if (mysqli_query($conn, $update_employee_sql) && 
            mysqli_query($conn, $update_benefits_sql)) {
            // Commit transaction
            mysqli_commit($conn);
            header("Location: employee_details.php");
            exit();
        } else {
            throw new Exception("Error updating records");
        }
    } catch (Exception $e) {
        // Rollback transaction
        mysqli_rollback($conn);
        $error = "Error updating record: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Employee - EPMS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            display: flex;
        }
        .sidebar {
            width: 200px;
            background-color: #333;
            color: white;
            padding: 20px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
        }
        .sidebar a {
            color: #ffd700;
            text-decoration: none;
            display: block;
            margin-bottom: 10px;
        }
        .main-content {
            margin-left: 240px;
            width: calc(100% - 240px);
            padding: 20px;
        }
        .form-section {
            background-color: white;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        .form-group input, 
        .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .form-actions {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        .btn {
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .btn-save {
            background-color: #4CAF50;
            color: white;
        }
        .btn-cancel {
            background-color: #f44336;
            color: white;
        }
        h2 {
            border-bottom: 2px solid #ffd700;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>EPMS</h2>
        <a href="adminHome.php">Admin Home</a>
        <a href="#">Employee Details</a>
        <a href="add_employee.php">Add New Employee</a>
    </div>
    
    <div class="main-content">
        <h1>Edit Employee</h1>
        <?php if (isset($error)) echo "<p style='color: red;'>$error</p>"; ?>
        <form method="POST" action="">
            <div class="form-section">
                <h2>Personal Information</h2>
                <div class="form-group">
                    <label>First Name</label>
                    <input type="text" name="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" name="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" value="<?php echo htmlspecialchars($employee['email']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Hire Date</label>
                    <input type="date" name="hire_date" value="<?php echo htmlspecialchars($employee['hire_date']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Job Title</label>
                    <input type="text" name="job_title" value="<?php echo htmlspecialchars($employee['job_title']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Department</label>
                    <select name="department" required>
                        <option value="Research and Development" <?php echo ($employee['department'] == 'Research and Development') ? 'selected' : ''; ?>>Research and Development</option>
                        <option value="Human Resources" <?php echo ($employee['department'] == 'Human Resources') ? 'selected' : ''; ?>>Human Resources</option>
                        <option value="Finance" <?php echo ($employee['department'] == 'Finance') ? 'selected' : ''; ?>>Finance</option>
                        <option value="Marketing" <?php echo ($employee['department'] == 'Marketing') ? 'selected' : ''; ?>>Marketing</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Salary</label>
                    <input type="number" name="salary" value="<?php echo htmlspecialchars($employee['salary']); ?>" required>
                </div>
            </div>

            <div class="form-section">
                <h2>Benefits Information</h2>
                <div class="form-group">
                    <label>SSS Number</label>
                    <input type="text" name="sss_number" value="<?php echo htmlspecialchars($employee['sss_number'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>SSS Contribution</label>
                    <input type="number" step="0.01" name="sss_contribution" value="<?php echo htmlspecialchars($employee['sss_contribution'] ?? '0.00'); ?>">
                </div>
                <div class="form-group">
                    <label>Pagibig Number</label>
                    <input type="text" name="pagibig_number" value="<?php echo htmlspecialchars($employee['pagibig_number'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Pagibig Contribution</label>
                    <input type="number" step="0.01" name="pagibig_contribution" value="<?php echo htmlspecialchars($employee['pagibig_contribution'] ?? '0.00'); ?>">
                </div>
                <div class="form-group">
                    <label>PhilHealth Number</label>
                    <input type="text" name="philhealth_number" value="<?php echo htmlspecialchars($employee['philhealth_number'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>PhilHealth Contribution</label>
                    <input type="number" step="0.01" name="philhealth_contribution" value="<?php echo htmlspecialchars($employee['philhealth_contribution'] ?? '0.00'); ?>">
                </div>
                <div class="form-group">
                    <label>TIN Number</label>
                    <input type="text" name="tin_number" value="<?php echo htmlspecialchars($employee['tin_number'] ?? ''); ?>">
                </div>
                <div class="form-group">
                    <label>Tax Contribution</label>
                    <input type="number" step="0.01" name="tax_contribution" value="<?php echo htmlspecialchars($employee['tax_contribution'] ?? '0.00'); ?>">
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" class="btn btn-save">Save Changes</button>
                <button type="button" class="btn btn-cancel" onclick="window.location.href='employee_details.php'">Cancel</button>
            </div>
        </form>
    </div>
</body>
</html>