<?php
// Start session
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}

// Include database connection
require_once 'database.php';

$success_message = '';
$error_message = '';

// Handle response submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['respond'])) {
    $request_id = mysqli_real_escape_string($conn, $_POST['request_id']);
    $response = mysqli_real_escape_string($conn, $_POST['response']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    
    // Update request with response
    $sql = "UPDATE employee_requests SET 
            response = ?, 
            status = ?, 
            response_date = NOW() 
            WHERE request_id = ?";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssi", $response, $status, $request_id);
    
    if (mysqli_stmt_execute($stmt)) {
        $success_message = "Response submitted successfully!";
    } else {
        $error_message = "Error: " . mysqli_error($conn);
    }
    
    mysqli_stmt_close($stmt);
}

// Get all employee requests including contact form submissions
$sql = "SELECT r.*, 
        CASE 
            WHEN r.emp_id = 0 THEN 'Contact Form' 
            ELSE CONCAT(e.first_name, ' ', e.last_name) 
        END as employee_name
        FROM employee_requests r
        LEFT JOIN employees e ON r.emp_id = e.emp_id
        ORDER BY r.request_date DESC";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Employee Requests - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #333;
            --accent-color: #444;
            --success-color: #4CAF50;
            --danger-color: #f44336;
            --warning-color: #ff9800;
            --text-light: #fff;
            --text-dark: #333;
            --light-bg: #f5f5f5;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }
        
        .header {
            background-color: var(--secondary-color);
            color: var(--text-light);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .header h2 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
        }
        
        .logo {
            width: 80px;
            height: auto;
        }
        
        .admin-badge {
            background-color: var(--primary-color);
            color: var(--secondary-color);
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 10px;
            margin-left: 10px;
            font-weight: bold;
            vertical-align: middle;
        }
        
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .page-title {
            margin-bottom: 30px;
            text-align: center;
            color: var(--secondary-color);
        }
        
        .back-btn {
            background-color: var(--success-color);
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            display: inline-block;
            font-weight: bold;
            margin-bottom: 20px;
        }
        
        .back-btn:hover {
            opacity: 0.9;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #dff0d8;
            color: #3c763d;
            border: 1px solid #d6e9c6;
        }
        
        .alert-danger {
            background-color: #f2dede;
            color: #a94442;
            border: 1px solid #ebccd1;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        
        th {
            background-color: var(--primary-color);
            color: var(--text-dark);
            font-weight: bold;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tr:hover {
            background-color: #f1f1f1;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
        }
        
        .status-pending {
            background-color: var(--warning-color);
            color: white;
        }
        
        .status-approved {
            background-color: var(--success-color);
            color: white;
        }
        
        .status-rejected {
            background-color: var(--danger-color);
            color: white;
        }
        
        .request-details {
            margin-top: 10px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 4px;
            display: none;
        }
        
        .request-response {
            margin-top: 10px;
            padding: 10px;
            background-color: #e9f7ef;
            border-radius: 4px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: opacity 0.3s;
            font-size: 16px;
        }
        
        .btn:hover {
            opacity: 0.9;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: var(--text-dark);
        }
        
        .btn-secondary {
            background-color: var(--secondary-color);
            color: var(--text-light);
        }
        
        .btn-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .btn-danger {
            background-color: var(--danger-color);
            color: white;
        }
        
        .response-form {
            margin-top: 15px;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 4px;
            display: none;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Manage Employee Requests <span class="admin-badge">Admin Only</span></h2>
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
        </div>
    </div>

    <div class="container">
        <a href="adminHome.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Admin Dashboard
        </a>
        
        <h1 class="page-title">Employee Requests Management</h1>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (mysqli_num_rows($result) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>From</th>
                        <th>Type</th>
                        <th>Subject</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo $row['request_id']; ?></td>
                            <td><?php echo $row['employee_name']; ?></td>
                            <td><?php echo $row['request_type']; ?></td>
                            <td><?php echo $row['subject']; ?></td>
                            <td><?php echo date('M d, Y', strtotime($row['request_date'])); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo strtolower($row['status']); ?>">
                                    <?php echo $row['status']; ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-secondary view-details" data-id="<?php echo $row['request_id']; ?>">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                
                                <div id="details-<?php echo $row['request_id']; ?>" class="request-details">
                                    <p><strong>Description:</strong> <?php echo nl2br($row['description']); ?></p>
                                    
                                    <?php if (!empty($row['response'])): ?>
                                        <div class="request-response">
                                            <p><strong>Response:</strong> <?php echo nl2br($row['response']); ?></p>
                                            <p><small>Responded on: <?php echo date('M d, Y H:i', strtotime($row['response_date'])); ?></small></p>
                                        </div>
                                    <?php else: ?>
                                        <button class="btn btn-primary respond-btn" data-id="<?php echo $row['request_id']; ?>">
                                            <i class="fas fa-reply"></i> Respond
                                        </button>
                                        
                                        <div id="response-form-<?php echo $row['request_id']; ?>" class="response-form">
                                            <form method="POST" action="">
                                                <input type="hidden" name="request_id" value="<?php echo $row['request_id']; ?>">
                                                
                                                <div class="form-group">
                                                    <label for="response-<?php echo $row['request_id']; ?>">Your Response:</label>
                                                    <textarea id="response-<?php echo $row['request_id']; ?>" name="response" class="form-control" required></textarea>
                                                </div>
                                                
                                                <div class="form-group">
                                                    <label for="status-<?php echo $row['request_id']; ?>">Status:</label>
                                                    <select id="status-<?php echo $row['request_id']; ?>" name="status" class="form-control" required>
                                                        <option value="Pending">Pending</option>
                                                        <option value="Approved">Approved</option>
                                                        <option value="Rejected">Rejected</option>
                                                    </select>
                                                </div>
                                                
                                                <div style="text-align: right;">
                                                    <button type="button" class="btn btn-secondary cancel-btn" data-id="<?php echo $row['request_id']; ?>">
                                                        Cancel
                                                    </button>
                                                    <button type="submit" name="respond" class="btn btn-success">
                                                        Submit Response
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No employee requests found.</p>
        <?php endif; ?>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle request details
        const viewButtons = document.querySelectorAll('.view-details');
        
        viewButtons.forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.getAttribute('data-id');
                const detailsDiv = document.getElementById('details-' + requestId);
                
                if (detailsDiv.style.display === 'block') {
                    detailsDiv.style.display = 'none';
                    this.innerHTML = '<i class="fas fa-eye"></i> View';
                } else {
                    detailsDiv.style.display = 'block';
                    this.innerHTML = '<i class="fas fa-eye-slash"></i> Hide';
                }
            });
        });
        
        // Toggle response form
        const respondButtons = document.querySelectorAll('.respond-btn');
        
        respondButtons.forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.getAttribute('data-id');
                const responseForm = document.getElementById('response-form-' + requestId);
                
                responseForm.style.display = 'block';
                this.style.display = 'none';
            });
        });
        
        // Cancel response
        const cancelButtons = document.querySelectorAll('.cancel-btn');
        
        cancelButtons.forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.getAttribute('data-id');
                const responseForm = document.getElementById('response-form-' + requestId);
                const respondBtn = document.querySelector('.respond-btn[data-id="' + requestId + '"]');
                
                responseForm.style.display = 'none';
                respondBtn.style.display = 'inline-block';
            });
        });
    });
    </script>
</body>
</html>

<?php
// Close connection
mysqli_close($conn);
?>