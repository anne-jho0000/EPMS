<?php
// Start session for user authentication
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in
    header("Location: adminLogin.php");
    exit();
}

// Include database connection and admin functions
require_once 'database.php';
require_once 'admin_functions.php';

// Get current page from query string
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$perPage = 10; // Number of activities per page

// Get admin activities with pagination
$activitiesData = getAllAdminActivities($page, $perPage);
$activities = $activitiesData['activities'];
$totalPages = $activitiesData['totalPages'];

// Format activity types for display
function formatActivityType($type) {
    return ucwords(str_replace('_', ' ', $type));
}

// Format timestamps for display
function formatTimestamp($timestamp) {
    $date = new DateTime($timestamp);
    return $date->format('M j, Y g:i A');
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Activities - EPMS</title>
    <style>
        :root {
            --primary-color: #ffde59; /* Yellow from logo */
            --secondary-color: #5e5e5e; /* Dark gray from logo */
            --lighter-gray: #f0f0f0;
            --white: #ffffff;
            --error: #d32f2f;
            --success: #388e3c;
        }
        
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--lighter-gray);
            display: flex;
        }
        
        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 20px;
        }
        
        .logo-container {
            text-align: center;
            padding: 0 20px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .logo {
            max-width: 100px;
            height: auto;
        }
        
        .system-name {
            font-size: 16px;
            font-weight: bold;
            color: var(--primary-color);
            margin-top: 10px;
            text-align: center;
        }
        
        .admin-profile {
            text-align: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .admin-profile-btn {
            background-color: var(--primary-color);
            color: #333;
            border: none;
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
            cursor: pointer;
            margin-bottom: 10px;
        }
        
        .admin-name {
            font-weight: bold;
            font-size: 18px;
            margin: 10px 0 5px;
        }
        
        .admin-role {
            font-size: 14px;
            color: #ccc;
        }
        
        .nav-menu {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }
        
        .nav-item {
            padding: 10px 20px;
            display: flex;
            align-items: center;
            transition: background-color 0.3s;
        }
        
        .nav-item:hover {
            background-color: rgba(255, 255, 255, 0.1);
        }
        
        .nav-item.active {
            background-color: rgba(255, 255, 255, 0.2);
            border-left: 4px solid var(--primary-color);
        }
        
        .nav-item a {
            color: white;
            text-decoration: none;
            font-size: 16px;
            display: flex;
            align-items: center;
            width: 100%;
        }
        
        .nav-icon {
            margin-right: 10px;
            font-size: 20px;
            width: 24px;
            text-align: center;
        }
        
        .content {
            margin-left: 250px;
            padding: 20px;
            width: calc(100% - 250px);
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            background-color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }
        
        h1 {
            margin: 0;
            color: var(--secondary-color);
        }
        
        .back-btn {
            background-color: var(--secondary-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            transition: background-color 0.3s;
        }
        
        .back-btn:hover {
            background-color: var(--primary-color);
            color: var(--secondary-color);
        }
        
        .card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        
        .activity-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .activity-item {
            padding: 15px;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: flex-start;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #f0f0f0;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            flex-shrink: 0;
            font-size: 18px;
        }
        
        .activity-icon.add {
            background-color: #e3f2fd;
            color: #1976d2;
        }
        
        .activity-icon.edit {
            background-color: #e8f5e9;
            color: #388e3c;
        }
        
        .activity-icon.delete {
            background-color: #ffebee;
            color: #d32f2f;
        }
        
        .activity-icon.login {
            background-color: #fff8e1;
            color: #ffa000;
        }
        
        .activity-content {
            flex-grow: 1;
        }
        
        .activity-title {
            font-weight: 500;
            margin-bottom: 5px;
            font-size: 16px;
        }
        
        .activity-meta {
            display: flex;
            justify-content: space-between;
            color: #757575;
            font-size: 14px;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        
        .pagination a, .pagination span {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 5px;
            border-radius: 4px;
            text-decoration: none;
            color: var(--secondary-color);
            background-color: white;
            border: 1px solid #ddd;
        }
        
        .pagination a:hover {
            background-color: var(--primary-color);
            color: var(--secondary-color);
        }
        
        .pagination .active {
            background-color: var(--secondary-color);
            color: white;
            border-color: var(--secondary-color);
        }
        
        .no-activities {
            padding: 30px;
            text-align: center;
            color: #757575;
            font-style: italic;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
            <div class="system-name">Employment Payment Management System</div>
        </div>
        
        <div class="admin-profile">
            <button class="admin-profile-btn">Admin Profile</button>
            <div class="admin-name"><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin User'); ?></div>
            <div class="admin-role"><?php echo htmlspecialchars($_SESSION['admin_role'] ?? 'administrator'); ?></div>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="adminHome.php">
                    <span class="nav-icon">🏠</span> Admin Home
                </a>
            </li>
            <li class="nav-item">
                <a href="employee_details.php">
                    <span class="nav-icon">👥</span> Employee Details
                </a>
            </li>
            <li class="nav-item">
                <a href="attendance.php">
                    <span class="nav-icon">📋</span> Attendance
                </a>
            </li>
            <li class="nav-item active">
                <a href="admin_activities.php">
                    <span class="nav-icon">📊</span> Admin Activities
                </a>
            </li>
            <!-- Add more menu items as needed -->
        </ul>
    </div>
    
    <div class="content">
        <div class="header">
            <h1>Admin Activities</h1>
            <a href="adminHome.php" class="back-btn">Back to Dashboard</a>
        </div>
        
        <div class="card">
            <?php if (empty($activities)): ?>
                <div class="no-activities">No activities found.</div>
            <?php else: ?>
                <ul class="activity-list">
                    <?php foreach ($activities as $activity): ?>
                        <li class="activity-item">
                            <?php 
                            $iconClass = 'activity-icon';
                            if (strpos($activity['activity_type'], 'add') !== false) {
                                $iconClass .= ' add';
                                $icon = '➕';
                            } elseif (strpos($activity['activity_type'], 'edit') !== false || strpos($activity['activity_type'], 'update') !== false) {
                                $iconClass .= ' edit';
                                $icon = '✏️';
                            } elseif (strpos($activity['activity_type'], 'delete') !== false) {
                                $iconClass .= ' delete';
                                $icon = '🗑️';
                            } elseif (strpos($activity['activity_type'], 'login') !== false) {
                                $iconClass .= ' login';
                                $icon = '🔑';
                            } else {
                                $icon = '📋';
                            }
                            ?>
                            <div class="<?php echo $iconClass; ?>"><?php echo $icon; ?></div>
                            <div class="activity-content">
                                <div class="activity-title"><?php echo htmlspecialchars($activity['description']); ?></div>
                                <div class="activity-meta">
                                    <span>By: <?php echo htmlspecialchars($activity['admin_name']); ?></span>
                                    <span><?php echo formatTimestamp($activity['created_at']); ?></span>
                                </div>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <div class="pagination">
                        <?php if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?>">Previous</a>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <?php if ($i == $page): ?>
                                <span class="active"><?php echo $i; ?></span>
                            <?php else: ?>
                                <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                        
                        <?php if ($page < $totalPages): ?>
                            <a href="?page=<?php echo $page + 1; ?>">Next</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>