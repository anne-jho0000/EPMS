<?php
// Start session for user authentication
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in
    header("Location: adminLogin.php");
    exit();
}

// Include database connection and admin functions
require_once 'database.php';
require_once 'admin_functions.php';

// Initialize admin activity system
initAdminActivitySystem();

// Fetch admin information
$admin_id = $_SESSION['admin_id'];
$query = "SELECT * FROM admins WHERE admin_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "s", $admin_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$admin = mysqli_fetch_assoc($result);

// Get all admin activities
// Try to use stored procedure first
$all_activities = getAllAdminActivities();

// If stored procedure fails, fall back to direct query
if ($all_activities === false) {
    $query = "SELECT * FROM (
        SELECT 'New Employee Added' as activity_type, CONCAT(first_name, ' ', last_name) as full_name, department, created_at, NULL as request_type, NULL as details, 'employee' as source
        FROM employees
        WHERE created_at IS NOT NULL
        
        UNION ALL
        
        SELECT 'Salary Processed' as activity_type, NULL as full_name, NULL as department, processed_date as created_at, NULL as request_type, CONCAT('Month: ', month) as details, 'salary' as source
        FROM salary_payments
        WHERE processed_date IS NOT NULL
        
        UNION ALL
        
        SELECT 'Employee Request' as activity_type, NULL as full_name, NULL as department, created_at, request_type, subject as details, 'request' as source
        FROM employee_requests
        WHERE created_at IS NOT NULL
        
        UNION ALL
        
        SELECT action_type as activity_type, admin_name as full_name, NULL as department, action_time as created_at, NULL as request_type, action_details as details, 'admin' as source
        FROM admin_activity_log
        WHERE action_time IS NOT NULL
    ) AS activities 
    ORDER BY created_at DESC";

    $all_activities_result = mysqli_query($conn, $query);
    if (!$all_activities_result) {
        error_log("All activities query failed: " . mysqli_error($conn));
        $all_activities_result = false;
    } else {
        $all_activities = array();
        while ($row = mysqli_fetch_assoc($all_activities_result)) {
            $all_activities[] = $row;
        }
    }
}

// Helper function to format time elapsed
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Activities - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding-top: 20px;
        }
        
        .logo-container {
            text-align: center;
            padding: 10px;
            margin-bottom: 20px;
        }
        
        .logo-img {
            width: 100px;
            height: 100px;
            object-fit: contain;
        }
        
        .system-name {
            text-align: center;
            font-size: 14px;
            margin-top: 15px;
            color: #f0c14b;
        }
        
        .admin-profile {
            text-align: center;
            padding: 20px 0;
            border-top: 1px solid #444;
            border-bottom: 1px solid #444;
            margin: 20px 0;
        }
        
        .profile-img {
            display: inline-block;
            padding: 8px 15px;
            background-color: #f0c14b;
            border-radius: 20px;
            font-weight: bold;
            color: #333;
        }
        
        .admin-name {
            margin-top: 10px;
            font-weight: bold;
        }
        
        .admin-role {
            font-size: 12px;
            color: #ccc;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-item {
            padding: 15px 20px;
            transition: all 0.3s;
        }
        
        .nav-item:hover, .nav-item.active {
            background-color: #444;
            border-left: 4px solid #f0c14b;
        }
        
        .nav-item i {
            margin-right: 10px;
            color: #f0c14b;
        }
        
        .nav-link {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .content {
            flex: 1;
            background-color: #f5f5f5;
        }
        
        .header {
            background-color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .page-title {
            font-size: 24px;
            color: #333;
        }
        
        .back-btn {
            background-color: #f0c14b;
            color: #333;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
            text-decoration: none;
        }
        
        .back-btn i {
            margin-right: 5px;
        }
        
        .activities-content {
            padding: 20px;
        }
        
        .activities-container {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .activities-header {
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
        }
        
        .activities-title {
            font-size: 20px;
            color: #333;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            background-color: rgba(240, 193, 75, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #f0c14b;
            margin-right: 15px;
        }
        
        .activity-details {
            flex: 1;
        }
        
        .activity-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .activity-description {
            color: #777;
            font-size: 14px;
        }
        
        .activity-time {
            color: #999;
            font-size: 12px;
            text-align: right;
            min-width: 100px;
        }
        
        .activity-date {
            font-weight: bold;
            padding: 10px 0;
            color: #555;
            background-color: #f9f9f9;
            margin: 15px 0;
            padding-left: 10px;
            border-left: 3px solid #f0c14b;
        }
        
        .filter-container {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .filter-select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            flex: 1;
        }
        
        .filter-btn {
            background-color: #f0c14b;
            color: #333;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        
        .pagination a {
            color: #333;
            padding: 8px 12px;
            text-decoration: none;
            border: 1px solid #ddd;
            margin: 0 5px;
        }
        
        .pagination a.active {
            background-color: #f0c14b;
            color: white;
            border-color: #f0c14b;
        }
        
        .pagination a:hover:not(.active) {
            background-color: #f5f5f5;
        }
    </style>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const filterBtn = document.getElementById('filter-activities');
            const activityTypeSelect = document.getElementById('activity-type');
            const activityDateSelect = document.getElementById('activity-date');
            
            filterBtn.addEventListener('click', function() {
                const selectedType = activityTypeSelect.value;
                const selectedDate = activityDateSelect.value;
                const activities = document.querySelectorAll('.activity-item');
                
                activities.forEach(function(activity) {
                    let showActivity = true;
                    
                    // Filter by type
                    if (selectedType && activity.dataset.type !== selectedType) {
                        showActivity = false;
                    }
                    
                    // Filter by date
                    if (selectedDate && showActivity) {
                        const activityDate = new Date(activity.dataset.date);
                        const today = new Date();
                        today.setHours(0, 0, 0, 0);
                        
                        switch(selectedDate) {
                            case 'today':
                                showActivity = activityDate.toDateString() === today.toDateString();
                                break;
                            case 'yesterday':
                                const yesterday = new Date(today);
                                yesterday.setDate(yesterday.getDate() - 1);
                                showActivity = activityDate.toDateString() === yesterday.toDateString();
                                break;
                            case 'week':
                                const weekAgo = new Date(today);
                                weekAgo.setDate(weekAgo.getDate() - 7);
                                showActivity = activityDate >= weekAgo;
                                break;
                            case 'month':
                                const monthAgo = new Date(today);
                                monthAgo.setMonth(monthAgo.getMonth() - 1);
                                showActivity = activityDate >= monthAgo;
                                break;
                        }
                    }
                    
                    activity.style.display = showActivity ? '' : 'none';
                });
                
                // Update date headers visibility
                const dateHeaders = document.querySelectorAll('.activity-date');
                dateHeaders.forEach(function(header) {
                    const nextActivities = getNextSiblings(header, '.activity-item');
                    const hasVisibleActivities = nextActivities.some(activity => activity.style.display !== 'none');
                    header.style.display = hasVisibleActivities ? '' : 'none';
                });
            });
            
            // Helper function to get next siblings matching a selector
            function getNextSiblings(elem, selector) {
                const siblings = [];
                let nextSibling = elem.nextElementSibling;
                
                while (nextSibling) {
                    if (nextSibling.matches('.activity-date')) break;
                    if (nextSibling.matches(selector)) {
                        siblings.push(nextSibling);
                    }
                    nextSibling = nextSibling.nextElementSibling;
                }
                
                return siblings;
            }
        });
    </script>
</head>
<body>
    <div class="sidebar">
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img">
            <div class="system-name">
                Employment Payment<br>Management System<br>EPMS
            </div>
        </div>
        
        <div class="admin-profile">
            <button class="profile-img">Admin Profile</button>
            <div class="admin-name"><?php echo htmlspecialchars(isset($admin) && isset($admin['full_name']) ? $admin['full_name'] : 'Admin User'); ?></div>
            <div class="admin-role"><?php echo htmlspecialchars(isset($admin) && isset($admin['role']) ? $admin['role'] : 'Admin'); ?></div>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item">
                <a href="adminHome.php" class="nav-link">
                    <i class="fas fa-home"></i> Admin Home
                </a>
            </li>
            <li class="nav-item">
                <a href="employee_details.php" class="nav-link">
                    <i class="fas fa-users"></i> Employee Details
                </a>
            </li>
            <li class="nav-item">
                <a href="view_attendance.php" class="nav-link">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
            </li>
            <li class="nav-item">
                <a href="salary_calculation.php" class="nav-link">
                    <i class="fas fa-calculator"></i> Salary Calculation
                </a>
            </li>
            <li class="nav-item">
                <a href="admin_requests.php" class="nav-link">
                    <i class="fas fa-bell"></i> Employee Requests
                </a>
            </li>
            <li class="nav-item">
                <a href="index.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>
    
    <div class="content">
        <div class="header">
            <h1 class="page-title">Admin Activities</h1>
            <a href="adminHome.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <div class="activities-content">
            <div class="activities-container">
                <div class="activities-header">
                    <h2 class="activities-title">All System Activities</h2>
                    
                    <div class="filter-container">
                        <select class="filter-select" id="activity-type">
                            <option value="">All Activity Types</option>
                            <option value="New Employee Added">New Employee Added</option>
                            <option value="Salary Processed">Salary Processed</option>
                            <option value="Employee Request">Employee Request</option>
                            <option value="Leave Request">Leave Request</option>
                            <option value="Profile Updated">Profile Updated</option>
                        </select>
                        
                        <select class="filter-select" id="activity-date">
                            <option value="">All Dates</option>
                            <option value="today">Today</option>
                            <option value="yesterday">Yesterday</option>
                            <option value="week">This Week</option>
                            <option value="month">This Month</option>
                        </select>
                        
                        <button class="filter-btn" id="filter-activities">Filter</button>
                    </div>
                </div>
                
                <?php 
                $current_date = '';
                $items_per_page = 10;
                $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                $start_index = ($current_page - 1) * $items_per_page;
                
                if ($all_activities && is_array($all_activities) && count($all_activities) > 0) {
                    // Get total number of activities
                    $total_activities = count($all_activities);
                    $total_pages = ceil($total_activities / $items_per_page);
                    
                    // Slice the array for pagination
                    $paginated_activities = array_slice($all_activities, $start_index, $items_per_page);
                    
                    foreach ($paginated_activities as $activity) {
                        $icon_class = "";
                        
                        // Get the date part for grouping
                        $activity_date = isset($activity['created_at']) ? date('Y-m-d', strtotime($activity['created_at'])) : date('Y-m-d');
                        
                        // If date changes, display a new date header
                        if ($activity_date != $current_date) {
                            $current_date = $activity_date;
                            echo '<div class="activity-date">' . date('F j, Y', strtotime($activity_date)) . '</div>';
                        }
                        
                        // Safely handle time formatting
                        if (isset($activity['created_at']) && !empty($activity['created_at'])) {
                            $time_ago = time_elapsed_string($activity['created_at']);
                            $time_formatted = date('h:i A', strtotime($activity['created_at']));
                        } else {
                            $time_ago = "unknown time";
                            $time_formatted = "unknown time";
                        }
                        
                        // Safely handle activity type and description
                        $activity_type = isset($activity['activity_type']) ? $activity['activity_type'] : 'Unknown Activity';
                        $full_name = isset($activity['full_name']) ? htmlspecialchars($activity['full_name']) : 'Unknown User';
                        $details = isset($activity['details']) ? htmlspecialchars($activity['details']) : '';
                        $department = isset($activity['department']) ? htmlspecialchars($activity['department']) : '';
                        
                        // Set icon and description based on activity type
                        switch ($activity_type) {
                            case 'New Employee Added':
                                $icon_class = "fas fa-user-plus";
                                $description = "$full_name was added to " . ($department ? "the $department department" : "the system");
                                break;
                            case 'Salary Processed':
                                $icon_class = "fas fa-money-check-alt";
                                $description = "Salary processed: $details";
                                break;
                            case 'Employee Request':
                                $icon_class = "fas fa-file-alt";
                                $description = "$full_name submitted a request: $details";
                                break;
                            case 'Leave Request':
                                $icon_class = "fas fa-calendar-alt";
                                $description = "$full_name submitted a leave request";
                                break;
                            default:
                                $icon_class = "fas fa-cog";
                                $description = "$full_name performed an action: $details";
                        }
                ?>
                <div class="activity-item" data-type="<?php echo htmlspecialchars($activity_type); ?>" data-date="<?php echo $activity_date; ?>">
                    <div class="activity-icon">
                        <i class="<?php echo $icon_class; ?>"></i>
                    </div>
                    <div class="activity-details">
                        <div class="activity-title"><?php echo htmlspecialchars($activity_type); ?></div>
                        <div class="activity-description"><?php echo $description; ?></div>
                    </div>
                    <div class="activity-time">
                        <div><?php echo $time_formatted; ?></div>
                        <div><?php echo $time_ago; ?></div>
                    </div>
                </div>
                <?php
                    }
                    
                    // Display pagination
                    if ($total_pages > 1) {
                        echo '<div class="pagination">';
                        if ($current_page > 1) {
                            echo '<a href="?page=1">&laquo;</a>';
                        }
                        for ($i = 1; $i <= $total_pages; $i++) {
                            echo '<a href="?page=' . $i . '"' . ($current_page == $i ? ' class="active"' : '') . '>' . $i . '</a>';
                        }
                        if ($current_page < $total_pages) {
                            echo '<a href="?page=' . $total_pages . '">&raquo;</a>';
                        }
                        echo '</div>';
                    }
                } else {
                    echo '<div class="no-activities">No activities found</div>';
                }
                ?>
                
                <div class="pagination">
                    <a href="#">&laquo;</a>
                    <a href="#" class="active">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a>
                    <a href="#">&raquo;</a>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        // Filter activities based on selected criteria
        document.getElementById('filter-activities').addEventListener('click', function() {
            const typeFilter = document.getElementById('activity-type').value;
            const dateFilter = document.getElementById('activity-date').value;
            
            const activities = document.querySelectorAll('.activity-item');
            const today = new Date().toISOString().split('T')[0];
            const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
            
            // Get the start of the week (Sunday)
            const startOfWeek = new Date();
            startOfWeek.setDate(startOfWeek.getDate() - startOfWeek.getDay());
            const weekStart = startOfWeek.toISOString().split('T')[0];
            
            // Get the start of the month
            const startOfMonth = new Date();
            startOfMonth.setDate(1);
            const monthStart = startOfMonth.toISOString().split('T')[0];
            
            activities.forEach(activity => {
                const activityType = activity.getAttribute('data-type');
                const activityDate = activity.getAttribute('data-date');
                
                let showByType = true;
                let showByDate = true;
                
                // Check type filter
                if (typeFilter && activityType !== typeFilter) {
                    showByType = false;
                }
                
                // Check date filter
                if (dateFilter) {
                    switch(dateFilter) {
                        case 'today':
                            showByDate = (activityDate === today);
                            break;
                        case 'yesterday':
                            showByDate = (activityDate === yesterday);
                            break;
                        case 'week':
                            showByDate = (activityDate >= weekStart);
                            break;
                        case 'month':
                            showByDate = (activityDate >= monthStart);
                            break;
                    }
                }
                
                // Show or hide based on filters
                if (showByType && showByDate) {
                    activity.style.display = 'flex';
                } else {
                    activity.style.display = 'none';
                }
            });
            
            // Hide date headers that don't have visible activities
            const dateHeaders = document.querySelectorAll('.activity-date');
            dateHeaders.forEach(header => {
                const nextEl = header.nextElementSibling;
                let hasVisibleActivity = false;
                
                // Check if any following activities until the next date header are visible
                let current = nextEl;
                while (current && !current.classList.contains('activity-date')) {
                    if (current.classList.contains('activity-item') && current.style.display !== 'none') {
                        hasVisibleActivity = true;
                        break;
                    }
                    current = current.nextElementSibling;
                }
                
                header.style.display = hasVisibleActivity ? 'block' : 'none';
            });
        });
    </script>
</body>
</html>