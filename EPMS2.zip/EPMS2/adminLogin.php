<?php
// Start session
session_start();

// Include database connection and admin functions
require_once 'database.php';
require_once 'admin_functions.php';

/**
 * Sanitize and validate input data
 * 
 * @param string $data Input data to sanitize
 * @return string Sanitized data
 */
function validateInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Initialize variables
$admin_id = $password = "";
$login_err = "";

// Process form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    // Get and validate form data
    $adminId = validateInput($_POST["admin_id"]);
    $password = validateInput($_POST["password"]);
    
    // Prepare SQL statement to prevent SQL injection
    $query = "SELECT id, admin_id, password, full_name FROM admins WHERE admin_id = '$adminId'";
    $result = mysqli_query($conn, $query);
    
    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        
        // Verify password (using password_verify if passwords are hashed)
        if (password_verify($password, $row["password"])) {
            // Password is correct, start a new session
            $_SESSION["loggedin"] = true;
            $_SESSION["id"] = $row["id"];
            $_SESSION["admin_id"] = $row["admin_id"];
            $_SESSION["admin_name"] = $row["full_name"];
            
            // Update last login time using stored procedure
            updateAdminLastLogin($row["id"]);
            
            // Log the login activity using stored procedure
            logAdminActivity($row["id"], $row["full_name"], "Login", "Admin logged in successfully");
            
            // Redirect to admin home page
            header("location: adminHome.php");
            exit;
        } else {
            // Password is not valid
            $login_err = "Invalid admin ID or password.";
            
            // Optionally log failed login attempts
            if (isset($row["id"]) && isset($row["full_name"])) {
                logAdminActivity($row["id"], $row["full_name"], "Failed Login", "Invalid password attempt");
            }
        }
    } else {
        // Admin ID doesn't exist
        $login_err = "Invalid admin ID or password.";
    }
}

// Process admin registration when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["register_admin"])) {
    // Get and sanitize form data
    $fullName = validateInput($_POST["full_name"]);
    $email = validateInput($_POST["email"]);
    $phone = validateInput($_POST["phone"]);
    $adminId = validateInput($_POST["admin_id"]);
    $password = $_POST["password"];
    $confirmPassword = $_POST["confirm_password"];
    $role = validateInput($_POST["role"]);
    
    $errors = [];
    
    // Validate inputs
    if (empty($fullName) || strlen($fullName) < 3) {
        $errors[] = "Full name is required and must be at least 3 characters.";
    }
    
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Valid email is required.";
    }
    
    if (empty($adminId) || strlen($adminId) < 5) {
        $errors[] = "Admin ID is required and must be at least 5 characters.";
    }
    
    if (empty($password) || strlen($password) < 8) {
        $errors[] = "Password must be at least 8 characters.";
    }
    
    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }
    
    if (empty($role)) {
        $errors[] = "Admin role is required.";
    }
    
    $check_query = "SELECT admin_id FROM admins WHERE admin_id = ? OR email = ?";
    $stmt = $conn->prepare($check_query);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("ss", $adminId, $email);
    $stmt->execute();
    $check_result = $stmt->get_result();
    
    if ($check_result === false) {
        $errors[] = "Database error: " . $conn->error;
    } else {
        if ($check_result->num_rows > 0) {
            $errors[] = "Admin ID or email already exists.";
        }
    }

    // If no errors, insert the new admin
    if (empty($errors)) {
        // Hash the password
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Current timestamp
        $created_at = date('Y-m-d H:i:s');
        
        // Prepare and execute the insert statement
        $insert_query = "INSERT INTO admins (full_name, email, phone, admin_id, password, role, created_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($insert_query);
if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("sssssss", $fullName, $email, $phone, $adminId, $hashedPassword, $role, $created_at);

if ($stmt->execute()) {
    $success_message = "New admin registered successfully!";
} else {
    $errors[] = "Registration failed: " . $stmt->error;
}
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - Employment Payment Management System</title>
    <style>
         * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        body {
            background-color: #1e2633;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background-color: #0e1521;
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(255, 216, 77, 0.2);
            width: 100%;
            max-width: 900px;
            overflow: hidden;
            display: flex;
            position: relative;
        }
        
        .login-section {
            width: 40%;
            background-color: #0e1521;
            padding: 40px;
            color: white;
            display: flex;
            flex-direction: column;
        }
        
        .info-section {
            flex: 1;
            background: linear-gradient(135deg, #ffd84d 0%, #ffc107 100%);
            color: #333;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            clip-path: polygon(10% 0, 100% 0, 100% 100%, 0 100%);
        }
        
        .logo {
            max-width: 150px;
            margin-bottom: 30px;
        }
        
        h1 {
            font-size: 32px;
            margin-bottom: 20px;
        }
        
        .subtitle {
            margin-bottom: 40px;
            opacity: 0.8;
            font-size: 11px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 4px;
            background-color: #2a314a;
            color: white;
            font-size: 16px;
        }
        
        .error-message {
            color: #ff6b6b;
            margin-bottom: 20px;
        }
        
        .btn {
            background-color: #ffd633;
            color: #1a1f2e;
            border: none;
            padding: 12px;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        
        .forgot-password {
            text-align: right;
            margin: 10px 0 20px;
        }
        
        .forgot-password a {
            color: #ffd633;
            text-decoration: none;
        }

        .portal-title {
            font-size: 42px;
            font-weight: bold;
            position: relative;
            left: 60px;
            margin-bottom: 20px;
            color: #1c2231;
        }
        
        .portal-description {
            font-size: 16px;
            line-height: 1.6;
            color: #1c2231;
            position: relative;
            left: 30px;
            margin-bottom: 40px;
        }
    
        
        .signup-btn-corner {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #1c2231;
            color: #fcd535;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            z-index: 10;
            transition: all 0.3s ease;
        }
        .signup-btn-corner:hover {
            background-color: #2a3042;
            transform: scale(1.05);
            box-shadow: 0 0 10px rgba(28, 34, 49, 0.5);
        }

         /* Add home button styles */
         .home-btn {
            display: inline-block;
            padding: 12px 40px;
            bottom: 10px;
            background: linear-gradient(to right, #f0c14b, #daa520);
            border: none;
            border-radius: 25px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s;
        }

        .home-btn:hover {
           
            transform: translateY(-3px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }

        
        /* Modal styles */
        .modal {
            position: fixed;
            top: 5%; /* Start higher from the top */
            left: 50%;
            transform: translateX(-50%);
            display: none;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.7);
            z-index: 100;
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            position: relative;
            max-height: 80vh; /* 80% of viewport height */
            overflow-y: auto; /* Enable vertical scrolling */
            padding-bottom: 70px; /* Add some space at bottom */
            background-color: #1a1f2e;
            margin: 5% auto;
            padding: 30px;
            border-radius: 8px;
            width: 80%;
            max-width: 600px;
            color: white;
           
        }

        .close {
            color: #ffd633;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover {
            color: white;
        }

        .error-container {
            background-color: rgba(255, 0, 0, 0.1);
            border-left: 4px solid #ff6b6b;
            padding: 10px;
            margin-bottom: 20px;
        }

        .error {
            color: #ff6b6b;
            margin: 5px 0;
        }

        .success-message {
            background-color: rgba(0, 255, 0, 0.1);
            border-left: 4px solid #4CAF50;
            padding: 10px;
            margin-bottom: 20px;
            color: #4CAF50;
        }

        /* Form styles */
        .btn-primary {
            
            bottom: 20px;
            margin-top: 20px;
            background-color: #ffd633;
            color: #1a1f2e;
        }

        .form-group small {
            display: block;
            margin-top: 5px;
            color: #aaa;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-section">
            <img src="images/logo2.png" alt="System Logo" class="logo">
            
            <h1>Admin Login</h1>
            <p class="subtitle">Access administrative controls and system management</p>
            
            <?php if (isset($login_err)) { ?>
                <div class="error-message"><?php echo $login_err; ?></div>
            <?php } ?>
            
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label>Admin ID</label>
                    <input type="text" name="admin_id" class="form-control" placeholder="Enter your admin ID" required>
                </div>
                
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
                
                <div class="forgot-password">
                    <a href="forgot_password.php">Forgot Password?</a>
                </div>
                
                <button type="submit" class="btn" name="login">Login</button>
            </form>
        </div>
        

        <div class="info-section">
            <button id="signupBtn" class="signup-btn-corner">Sign Up Admin</button>
            
            <h1 class="portal-title">ADMIN PORTAL</h1>
            <p class="portal-description">
                Welcome to the administrative portal. Manage employee accounts, process payments, configure 
                system settings, and oversee all aspects of the Employment Payment Management System.
            </p>

            <a href="index.php" class="home-btn">Home</a>
            
        </div>
       
    </div>
    
   
    <!-- Sign Up Modal -->
    <div id="signupModal" class="modal">
        <div class="modal-content">
            <span class="close">&times;</span>
            <h2>Register New Admin</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="error-container">
                    <?php foreach ($errors as $error): ?>
                        <p class="error"><?php echo $error; ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if (isset($success_message)): ?>
                <div class="success-message">
                    <?php echo $success_message; ?>
                </div>
            <?php endif; ?>
            
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" class="form-control">
                </div>
                
                <div class="form-group">
                    <label for="admin_id">Admin ID</label>
                    <input type="text" id="admin_id" name="admin_id" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                    <small>Must be at least 8 characters long</small>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="role">Admin Role</label>
                    <select id="role" name="role" class="form-control" required>
                        <option value="">Select Role</option>
                        <option value="super_admin">Super Admin</option>
                        <option value="manager">Manager</option>
                        <option value="payroll_admin">Payroll Admin</option>
                        <option value="hr_admin">HR Admin</option>
                    </select>
                </div>
                
                <button type="submit" name="register_admin" class="btn btn-primary">Register Admin</button>
            </form>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
    // Get the modal
    var modal = document.getElementById('signupModal');
    
    // Get the button that opens the modal (by class since it has the same ID as the modal)
    var btn = document.querySelector('.signup-btn-corner');
    
    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName('close')[0];
    
    // When the user clicks the button, open the modal
    btn.onclick = function(e) {
        e.preventDefault();
        modal.style.display = 'block';
    }
    
    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
        modal.style.display = 'none';
    }
    
    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
        if (!modal.contains(event.target) && event.target != btn) {
            modal.style.display = 'none';
        }
    }

        
    <?php if (!empty($errors) || isset($success_message)): ?>
        modal.style.display = 'block';
    <?php endif; ?>

    });
    </script>
</body>
</html>