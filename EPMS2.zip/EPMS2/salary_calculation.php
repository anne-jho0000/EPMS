<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is an admin
if (!isset($_SESSION['admin_id'])) {
    // Redirect non-admin users to login page
    header('Location: adminLogin.php?error=unauthorized');
    exit;
}

require_once 'database.php';

class SalaryCalculator {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function calculateMonthlySalary($employee_id, $month, $year) {
        $conn = $this->db->getConnection();
        
        // Calculate total working hours
        $stmt = $conn->prepare("
            SELECT 
                emp_id as employee_id, 
                COUNT(DISTINCT DATE(check_in)) as working_days,
                SUM(TIMESTAMPDIFF(HOUR, check_in, check_out)) as total_hours
            FROM attendance
            WHERE 
                emp_id = ? AND 
                YEAR(check_in) = ? AND 
                MONTH(check_in) = ? AND 
                check_out IS NOT NULL
            GROUP BY emp_id
        ");
        
        $stmt->bind_param("sii", $employee_id, $year, $month);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $attendance = $result->fetch_assoc();
            
            // Fetch employee base salary
            $stmt = $conn->prepare("SELECT base_salary, hourly_rate FROM employees WHERE emp_id = ?");
            $stmt->bind_param("s", $employee_id);
            $stmt->execute();
            $employeeResult = $stmt->get_result();
            $employee = $employeeResult->fetch_assoc();
            
            if (!$employee) {
                throw new Exception("Employee not found");
            }
            
            // Calculate salary
            $working_days = $attendance['working_days'];
            $total_hours = $attendance['total_hours'];
            $base_salary = $employee['base_salary'];
            $hourly_rate = $employee['hourly_rate'];
            
            $total_salary = $base_salary + ($total_hours * $hourly_rate);
            
            return [
                'employee_id' => $employee_id,
                'month' => $month,
                'year' => $year,
                'working_days' => $working_days,
                'total_hours' => $total_hours,
                'base_salary' => $base_salary,
                'hourly_earnings' => $total_hours * $hourly_rate,
                'total_salary' => $total_salary
            ];
        }
        
        return null;
    }

    public function saveSalaryRecord($salary_data) {
        $conn = $this->db->getConnection();
        
        $stmt = $conn->prepare("
            INSERT INTO salary_records 
            (employee_id, month, year, working_days, total_hours, base_salary, hourly_earnings, total_salary) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ");
        
        $stmt->bind_param(
            "siiiddd", 
            $salary_data['employee_id'], 
            $salary_data['month'], 
            $salary_data['year'], 
            $salary_data['working_days'], 
            $salary_data['total_hours'], 
            $salary_data['base_salary'], 
            $salary_data['hourly_earnings'], 
            $salary_data['total_salary']
        );
        
        return $stmt->execute();
    }
}

// Example usage for admin
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $calculator = new SalaryCalculator();
        $employee_id = $_POST['employee_id'] ?? '';
        $month = $_POST['month'] ?? date('m');
        $year = $_POST['year'] ?? date('Y');
        
        // Validate inputs
        if (empty($employee_id)) {
            throw new Exception("Employee ID is required");
        }
        
        $salary_data = $calculator->calculateMonthlySalary($employee_id, $month, $year);
        
        if ($salary_data) {
            // Optionally save the salary record
            $calculator->saveSalaryRecord($salary_data);
            echo json_encode($salary_data);
        } else {
            echo json_encode(['error' => 'No attendance records found for this employee in the selected month']);
        }
    } catch (Exception $e) {
        echo json_encode(['error' => $e->getMessage()]);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Calculation - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #333;
            --accent-color: #444;
            --success-color: #4CAF50;
            --danger-color: #f44336;
            --text-light: #fff;
            --text-dark: #333;
            --light-bg: #f5f5f5;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }
        
        .header {
            background-color: var(--secondary-color);
            color: var(--text-light);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .header h2 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
        }
        
        .logo {
            width: 80px;
            height: auto;
        }
        
        .admin-badge {
            background-color: var(--primary-color);
            color: var(--secondary-color);
            font-size: 0.7rem;
            padding: 3px 8px;
            border-radius: 10px;
            margin-left: 10px;
            font-weight: bold;
            vertical-align: middle;
        }
        
        .container {
            max-width: 900px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .page-title {
            margin-bottom: 30px;
            text-align: center;
            color: var(--secondary-color);
        }
        
        .form-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 30px;
            justify-content: center;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: opacity 0.3s;
            font-size: 16px;
        }
        
        .btn:hover {
            opacity: 0.9;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: var(--text-dark);
        }
        
        .btn-secondary {
            background-color: var(--secondary-color);
            color: var(--text-light);
        }
        
        .back-btn {
            background-color: var(--success-color);
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            display: inline-block;
            font-weight: bold;
            margin-bottom: 20px;
        }
        
        .back-btn:hover {
            opacity: 0.9;
        }
        
        .result-container {
            margin-top: 30px;
            padding: 20px;
            border-radius: 8px;
            background-color: #f9f9f9;
            display: none;
        }
        
        .result-container.show {
            display: block;
        }
        
        .result-title {
            color: var(--secondary-color);
            margin-top: 0;
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 10px;
        }
        
        .result-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
        }
        
        .result-item {
            margin-bottom: 15px;
        }
        
        .result-label {
            font-weight: bold;
            margin-bottom: 5px;
            color: var(--secondary-color);
        }
        
        .result-value {
            font-size: 18px;
        }
        
        .total-salary {
            font-size: 24px;
            font-weight: bold;
            color: var(--success-color);
            margin-top: 20px;
            text-align: right;
        }
        
        .error-message {
            color: var(--danger-color);
            padding: 10px;
            background-color: #ffebee;
            border-radius: 4px;
            margin-top: 20px;
            display: none;
        }
        
        .month-select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
        }
        
        @media (max-width: 768px) {
            .form-container {
                flex-direction: column;
            }
            
            .form-group {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Salary Calculation <span class="admin-badge">Admin Only</span></h2>
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
        </div>
    </div>

    <div class="container">
        <a href="adminHome.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Admin Home
        </a>
        
        <h1 class="page-title">Employee Salary Calculator</h1>
        
        <form id="salaryForm">
            <div class="form-container">
                <div class="form-group">
                    <label for="employee_id">Employee ID:</label>
                    <input type="text" id="employee_id" name="employee_id" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="month">Month:</label>
                    <select id="month" name="month" class="month-select">
                        <option value="1">January</option>
                        <option value="2">February</option>
                        <option value="3">March</option>
                        <option value="4">April</option>
                        <option value="5">May</option>
                        <option value="6">June</option>
                        <option value="7">July</option>
                        <option value="8">August</option>
                        <option value="9">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="year">Year:</label>
                    <input type="number" id="year" name="year" class="form-control" value="<?php echo date('Y'); ?>" min="2000" max="2100">
                </div>
            </div>
            
            <div style="text-align: center;">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-calculator"></i> Calculate Salary
                </button>
            </div>
        </form>

        <div id="error-message" class="error-message"></div>

        <div id="salaryResult" class="result-container">
            <h3 class="result-title">Salary Details</h3>
            <div class="result-grid">
                <div class="result-item">
                    <div class="result-label">Employee ID:</div>
                    <div id="result-emp-id" class="result-value"></div>
                </div>
                
                <div class="result-item">
                    <div class="result-label">Month/Year:</div>
                    <div id="result-period" class="result-value"></div>
                </div>
                
                <div class="result-item">
                    <div class="result-label">Working Days:</div>
                    <div id="result-days" class="result-value"></div>
                </div>
                
                <div class="result-item">
                    <div class="result-label">Total Hours:</div>
                    <div id="result-hours" class="result-value"></div>
                </div>
                
                <div class="result-item">
                    <div class="result-label">Base Salary:</div>
                    <div id="result-base" class="result-value"></div>
                </div>
                
                <div class="result-item">
                    <div class="result-label">Hourly Earnings:</div>
                    <div id="result-hourly" class="result-value"></div>
                </div>
            </div>
            
            <div class="total-salary">
                Total Salary: <span id="result-total"></span>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Set default month and year
        const currentDate = new Date();
        document.getElementById('month').value = currentDate.getMonth() + 1;
        document.getElementById('year').value = currentDate.getFullYear();
        
        // Handle form submission
        document.getElementById('salaryForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const errorMsg = document.getElementById('error-message');
            errorMsg.style.display = 'none';
            
            let formData = new FormData(this);
            
            fetch('salary_calculation.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.error) {
                    errorMsg.textContent = data.error;
                    errorMsg.style.display = 'block';
                    document.getElementById('salaryResult').classList.remove('show');
                } else {
                    // Format month name
                    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 
                                       'July', 'August', 'September', 'October', 'November', 'December'];
                    const monthName = monthNames[data.month - 1];
                    
                    // Update result fields
                    document.getElementById('result-emp-id').textContent = data.employee_id;
                    document.getElementById('result-period').textContent = `${monthName} ${data.year}`;
                    document.getElementById('result-days').textContent = data.working_days;
                    document.getElementById('result-hours').textContent = `${data.total_hours} hours`;
                    document.getElementById('result-base').textContent = `₱${data.base_salary.toFixed(2)}`;
                    document.getElementById('result-hourly').textContent = `₱${data.hourly_earnings.toFixed(2)}`;
                    document.getElementById('result-total').textContent = `₱${data.total_salary.toFixed(2)}`;
                    
                    // Show result container
                    document.getElementById('salaryResult').classList.add('show');
                    
                    // Scroll to results
                    document.getElementById('salaryResult').scrollIntoView({
                        behavior: 'smooth'
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                errorMsg.textContent = 'An error occurred while calculating the salary. Please try again.';
                errorMsg.style.display = 'block';
            });
        });
    });
    </script>
</body>
</html>