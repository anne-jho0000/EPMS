@echo off
"C:\xampp\php\php.exe" -f "C:\xampp\htdocs\EPMS\cleanup_activities.php"