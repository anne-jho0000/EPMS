<?php
// Include database connection
require_once 'database.php';

// Handle delete request
if (isset($_GET['delete'])) {
    $employee_id = mysqli_real_escape_string($conn, $_GET['delete']);
    
    // Prepare delete SQL
    $delete_sql = "DELETE FROM employees WHERE emp_id = '$employee_id'";
    
    if (mysqli_query($conn, $delete_sql)) {
        // Redirect to prevent form resubmission and show success
        header("Location: employee_details.php?deleted=success");
        exit();
    } else {
        $error_message = "Error deleting employee: " . mysqli_error($conn);
    }
}

// Fetch employee details
$sql = "SELECT * FROM employees";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Details - EPMS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            position: relative;
        }

        .logo {
            position: absolute;
            top: 12px;
            left: 20px;
            width: 140px;
            height: 65px;
        }

        .container {
            margin-top: 60px;
            width: 100%;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background: linear-gradient(to right,rgb(223, 198, 135),rgb(246, 192, 55));
            color: #333;
            font-weight: bold;
        }

        .edit-btn {
            background:rgba(242, 190, 59, 0.95);
            color: #333;
            border: none;
            padding: 5px 10px;
            margin-right: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            border-radius: 4px;
        }

        .edit-btn:hover {
            background: #daa520;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }

        .delete-btn {
            background:rgb(83, 82, 81);
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            transition: all 0.3s ease;
            border-radius: 4px;
        }

        .delete-btn:hover {
            background: #c17d00;
            transform: translateY(-2px);
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        .error-message {
            color: red;
            margin-bottom: 15px;
        }
        .success-message {
            color: green;
            margin-bottom: 15px;
        }
        
        /* Add new style for back button */

        .back-btn {
            position: absolute;
            top: 20px;
            right: 20px;
            background: linear-gradient(to right,rgb(128, 127, 123),rgb(47, 38, 16));
            color: gold;
            text-decoration: none;
            padding: 12px 24px;
            border-radius: 25px;
            display: inline-block;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            z-index: 1000;
        }
        .back-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }
    </style>
    <script>
    function confirmDelete(employeeId) {
        if (confirm('Are you sure you want to delete this employee?')) {
            window.location.href = 'employee_details.php?delete=' + employeeId;
        }
    }
    </script>
</head>
<body>
    <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
    <a href="adminHome.php" class="back-btn">Back to Admin Home</a>
    
    <div class="container">
        <?php if(isset($_GET['deleted']) && $_GET['deleted'] == 'success'): ?>
            <div class="success-message">Employee deleted successfully!</div>
        <?php endif; ?>

        <?php if(isset($error_message)): ?>
            <div class="error-message"><?php echo $error_message; ?></div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Employee ID</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Hire Date</th>
                    <th>Job Title</th>
                    <th>Department</th>
                    <th>Salary</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if(mysqli_num_rows($result) > 0) { ?>
                    <?php while($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['emp_id'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['first_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['last_name'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['email'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['phone'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['hire_date'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['job_title'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['department'] ?? ''); ?></td>
                            <td>$<?php echo number_format($row['salary'] ?? 0, 2); ?></td>
                            <td>
                                <a href="edit_employee.php?id=<?php echo $row['emp_id']; ?>" class="edit-btn">Edit</a>
                                <button onclick="confirmDelete('<?php echo $row['emp_id']; ?>')" class="delete-btn">Delete</button>
                            </td>
                        </tr>
                    <?php } ?>
                <?php } else { ?>
                    <tr>
                        <td colspan="10">No employees found</td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
// Close the connection
mysqli_close($conn);
?>