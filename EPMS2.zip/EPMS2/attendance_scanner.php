<?php
session_start();
require_once 'database.php';

class AttendanceScanner {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function scanQRCode($emp_id, $action) {
        // Check if employee exists
        $stmt = $this->conn->prepare("SELECT emp_id FROM employees WHERE emp_id = ?");
        if ($stmt === false) {
            return [
                'status' => 'error',
                'message' => 'Database error: ' . $this->conn->error
            ];
        }
        
        $stmt->bind_param("i", $emp_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $today = date('Y-m-d');
            $now = date('Y-m-d H:i:s');
            
            // Check if we need to create a new attendance record or update existing one
            if ($action == 'check_in') {
                // Check if already checked in today
                $checkStmt = $this->conn->prepare("SELECT id FROM attendance WHERE emp_id = ? AND attendance_date = ?");
                $checkStmt->bind_param("is", $emp_id, $today);
                $checkStmt->execute();
                $checkResult = $checkStmt->get_result();
                
                if ($checkResult->num_rows > 0) {
                    return [
                        'status' => 'error',
                        'message' => 'Already checked in today'
                    ];
                }
                
                // Create new attendance record
                $stmt = $this->conn->prepare("INSERT INTO attendance (emp_id, attendance_date, check_in, status) VALUES (?, ?, ?, 'present')");
                $stmt->bind_param("iss", $emp_id, $today, $now);
            } else { // check_out
                // Update existing record
                $stmt = $this->conn->prepare("UPDATE attendance SET check_out = ?, worked_hours = TIMESTAMPDIFF(HOUR, check_in, ?) WHERE emp_id = ? AND attendance_date = ?");
                $stmt->bind_param("ssis", $now, $now, $emp_id, $today);
            }
            
            if ($stmt->execute()) {
                // Get the current time in 12-hour format with AM/PM
                $currentTime = new DateTime();
                $formattedTime = $currentTime->format('g:i A');
                return [
                    'status' => 'success',
                    'message' => ucfirst($action) . ' recorded successfully at ' . $formattedTime
                ];
            } else {
                return [
                    'status' => 'error',
                    'message' => 'Failed to record ' . $action . ': ' . $this->conn->error
                ];
            }
        } else {
            return [
                'status' => 'error',
                'message' => 'Invalid Employee ID'
            ];
        }
    }
}

// Handle QR Code Scanning
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['emp_id'])) {
    $scanner = new AttendanceScanner($conn);
    $emp_id = $_POST['emp_id'] ?? '';
    $action = $_POST['action'] ?? 'check_in';

    $result = $scanner->scanQRCode($emp_id, $action);
    
    // Return JSON for AJAX requests
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode($result);
        exit;
    }
    
    // For regular form submissions, store result in session
    $_SESSION['scan_result'] = $result;
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit;
}

// Get result from session if exists
$result = $_SESSION['scan_result'] ?? null;
if ($result) {
    unset($_SESSION['scan_result']); // Clear after use
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Attendance Scanner</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <!-- Include the QR Scanner library -->
    <script src="https://unpkg.com/html5-qrcode"></script>
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #333;
            --accent-color: #444;
            --success-color: #4CAF50;
            --danger-color: #f44336;
            --text-light: #fff;
            --text-dark: #333;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            color: var(--text-dark);
            margin: 0;
            padding: 0;
        }
        
        .header {
            background-color: var(--secondary-color);
            color: var(--text-light);
            padding: 15px 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
        }
        
        .logo {
            width: 80px;
            height: auto;
            margin-right: 15px;
        }
        
        #current-time-display {
            text-align: center;
            font-size: 1.2rem;
            margin-bottom: 20px;
            font-weight: bold;
        }
        
        .text-center {
            text-align: center;
        }
        
        .mb-3 {
            margin-bottom: 15px;
        }
        
        .system-info {
            display: flex;
            flex-direction: column;
        }
        
        .system-name {
            font-size: 1rem;
            margin: 0;
        }
        
        .system-title {
            font-size: 1.3rem;
            color: var(--primary-color);
            margin: 0;
            font-weight: bold;
        }
        
        .back-button {
            display: inline-block;
            padding: 8px 15px;
            background-color: var(--primary-color);
            color: var(--text-dark);
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
            font-weight: bold;
        }
        
        .back-button:hover {
            background-color: #e6c300;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .scanner-container {
            margin-bottom: 20px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        #qr-reader {
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
            border: 2px solid var(--primary-color);
            border-radius: 8px;
            overflow: hidden;
        }
        
        .manual-entry {
            margin-top: 30px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--secondary-color);
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
        }
        
        .btn {
            padding: 10px 15px;
            background-color: var(--success-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            opacity: 0.9;
        }
        
        .btn-secondary {
            background-color: var(--secondary-color);
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: var(--text-dark);
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .scanner-options {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        
        .scanner-options button {
            margin: 0 10px;
        }
        
        h1, h3 {
            color: var(--secondary-color);
            text-align: center;
        }
        
        h1 {
            margin-bottom: 30px;
            font-size: 1.8rem;
        }
        
        h3 {
            margin-bottom: 20px;
            font-size: 1.4rem;
        }
        
        /* New styles based on the image */
        .scanner-container {
            position: relative;
            min-height: 300px;
        }
        
        #qr-reader-results {
            margin-top: 15px;
        }
        
        .qr-placeholder {
            width: 100%;
            height: 4px;
            background-color: var(--primary-color);
            margin: 20px auto;
            max-width: 600px;
        }
        
        /* Mobile responsiveness */
        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                text-align: center;
                padding: 10px;
            }
            
            .logo-container {
                margin-bottom: 10px;
            }
            
            .back-button {
                margin-top: 10px;
            }
            
            .system-info {
                text-align: center;
            }
            
            .logo {
                width: 60px;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
            <div class="system-info">
                <h3 class="system-name">Employment Payment Management System</h3>
                <h2 class="system-title">EPMS</h2>
            </div>
        </div>
        
        <a href="employeeHome.php" class="back-button">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
    </div>
    
    <div class="container">
        <h1>QR Attendance Scanner</h1>
        
        <div id="current-time-display" class="text-center mb-3">
            Current Time: <span id="current-time" style="font-weight: bold;"></span>
        </div>
        
        <?php if ($result): ?>
            <div class="alert alert-<?php echo $result['status'] === 'success' ? 'success' : 'danger'; ?>">
                <?php echo $result['message']; ?>
            </div>
        <?php endif; ?>
        
        <div class="scanner-options">
            <button class="btn btn-primary" id="startButton">
                <i class="fas fa-camera"></i> Start Scanner
            </button>
            <button class="btn btn-secondary" id="stopButton" disabled>
                <i class="fas fa-stop"></i> Stop Scanner
            </button>
        </div>
        
        <div class="scanner-container">
            <div id="qr-reader"></div>
            <div id="qr-reader-results"></div>
            <div class="qr-placeholder"></div>
        </div>
        
        <div class="manual-entry">
            <h3>Manual Entry</h3>
            <form id="attendanceForm" method="POST">
                <div class="form-group">
                    <label for="emp_id">Employee ID:</label>
                    <input type="text" id="emp_id" name="emp_id" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="action">Action:</label>
                    <select id="action" name="action" class="form-control" required>
                        <option value="check_in">Check In</option>
                        <option value="check_out">Check Out</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-check"></i> Submit
                </button>
            </form>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const html5QrCode = new Html5Qrcode("qr-reader");
            const qrResultContainer = document.getElementById('qr-reader-results');
            const startButton = document.getElementById('startButton');
            const stopButton = document.getElementById('stopButton');
            const empIdInput = document.getElementById('emp_id');
            const actionSelect = document.getElementById('action');
            
            let isScanning = false;
            
            // Add current time display
            // Updated time display function to match PHP format
            function updateCurrentTime() {
                const now = new Date();
                const hours = now.getHours();
                const minutes = now.getMinutes().toString().padStart(2, '0');
                const ampm = hours >= 12 ? 'PM' : 'AM';
                let displayHours = hours % 12;
                displayHours = displayHours === 0 ? 12 : displayHours;
                
                // Format time to match PHP format (no leading zero for hours)
                const timeString = `${displayHours}:${minutes} ${ampm}`;
                
                const timeDisplay = document.getElementById('current-time');
                if (timeDisplay) {
                    timeDisplay.textContent = timeString;
                }
            }
            
            // Update time every second
            setInterval(updateCurrentTime, 1000);
            updateCurrentTime(); // Initial update
            
            // Function to handle successful QR code scan
            function onScanSuccess(decodedText, decodedResult) {
                // Stop scanning
                html5QrCode.stop().then(() => {
                    isScanning = false;
                    startButton.disabled = false;
                    stopButton.disabled = true;
                    
                    // Set the scanned value to the input field
                    empIdInput.value = decodedText;
                    
                    // Show success message
                    qrResultContainer.innerHTML = `
                        <div class="alert alert-success">
                            QR Code scanned successfully: ${decodedText}
                        </div>
                    `;
                    
                    // Submit the form automatically
                    document.getElementById('attendanceForm').submit();
                });
            }
            
            // Start QR Scanner
            startButton.addEventListener('click', function() {
                if (!isScanning) {
                    const config = { fps: 10, qrbox: { width: 250, height: 250 } };
                    
                    html5QrCode.start(
                        { facingMode: "environment" }, // Use back camera
                        config,
                        onScanSuccess
                    ).then(() => {
                        isScanning = true;
                        startButton.disabled = true;
                        stopButton.disabled = false;
                        qrResultContainer.innerHTML = '<div class="alert alert-success">Scanner started. Point camera at a QR code.</div>';
                    }).catch(err => {
                        qrResultContainer.innerHTML = `
                            <div class="alert alert-danger">
                                Error starting scanner: ${err}
                            </div>
                        `;
                    });
                }
            });
            
            // Stop QR Scanner
            stopButton.addEventListener('click', function() {
                if (isScanning) {
                    html5QrCode.stop().then(() => {
                        isScanning = false;
                        startButton.disabled = false;
                        stopButton.disabled = true;
                        qrResultContainer.innerHTML = '<div class="alert alert-success">Scanner stopped.</div>';
                    });
                }
            });
        });
    </script>
</body>
</html>