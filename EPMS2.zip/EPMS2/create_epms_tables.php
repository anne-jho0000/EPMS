<?php
// Include database connection
require_once 'database.php';

// Function to create tables with error handling - suppress output
function createTable($conn, $tableName, $createTableSQL) {
    $checkTable = mysqli_query($conn, "SHOW TABLES LIKE '$tableName'");
    
    if (mysqli_num_rows($checkTable) == 0) {
        return mysqli_query($conn, $createTableSQL);
    }
    return true;
}

// SQL to create the table
$adminTableSQL = "CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    admin_id VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)";

// SQL for Employees Table
$employeesTableSQL = "CREATE TABLE employees (
    emp_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15) NOT NULL,
    hire_date DATE NOT NULL,
    job_title VARCHAR(100) NOT NULL,
    department VARCHAR(50) NOT NULL,
    salary DECIMAL(10,2),
    password VARCHAR(255) NOT NULL,
    qr_code VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// SQL to create employee benefits table
$benefitTableSQL = "CREATE TABLE IF NOT EXISTS employee_benefits (
    benefit_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    emp_id INT(11) NOT NULL,
    sss_number VARCHAR(20),
    sss_contribution DECIMAL(10,2) DEFAULT 0.00,
    pagibig_number VARCHAR(20),
    pagibig_contribution DECIMAL(10,2) DEFAULT 0.00,
    philhealth_number VARCHAR(20),
    philhealth_contribution DECIMAL(10,2) DEFAULT 0.00, 
    tin_number VARCHAR(20),
    tax_contribution DECIMAL(10,2) DEFAULT 0.00,
    other_benefits TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$employeeLoginTableSQL = "CREATE TABLE employee_login (
    emp_id INT(11) NOT NULL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    FOREIGN KEY (username) REFERENCES employees(username) ON DELETE CASCADE
)";

// SQL to create attendance table with overtime and tardiness fields
$attendanceTableSQL = "CREATE TABLE attendance (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    emp_id INT(11) NOT NULL,
    attendance_date DATE NOT NULL,
    check_in DATETIME,
    check_out DATETIME,
    expected_check_in TIME DEFAULT '09:00:00',
    expected_check_out TIME DEFAULT '17:00:00',
    status ENUM('present', 'absent', 'leave', 'half-day', 'weekend') NOT NULL DEFAULT 'absent',
    worked_hours DECIMAL(5,2) DEFAULT 0,
    tardiness INT DEFAULT 0 COMMENT 'Minutes late (calculated field)',
    overtime INT DEFAULT 0 COMMENT 'Minutes of overtime (calculated field)',
    notes TEXT,
    latitude DECIMAL(10,7),
    longitude DECIMAL(10,7),
    ip_address VARCHAR(45),
    device_info VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_attendance (emp_id, attendance_date),
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";


// SQL for Salary Calculations Table
$salaryCalculationsTableSQL = "CREATE TABLE salary_calculations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    month INT NOT NULL,
    year INT NOT NULL,
    base_salary DECIMAL(10,2) NOT NULL,
    hourly_rate DECIMAL(10,2) NOT NULL,
    working_days INT,
    total_hours DECIMAL(10,2),
    overtime_hours DECIMAL(10,2),
    total_earnings DECIMAL(10,2),
    deductions DECIMAL(10,2),
    net_salary DECIMAL(10,2),
    payment_status ENUM('Pending', 'Processed', 'Paid') DEFAULT 'Pending',
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    UNIQUE KEY unique_employee_month (emp_id, month, year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// SQL for Leave Management Table
$leaveTableSQL = "CREATE TABLE leave_management (
    id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    leave_type ENUM('Casual', 'Sick', 'Earned', 'Unpaid') NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_days INT NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    reason TEXT,
    applied_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_by INT,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    FOREIGN KEY (approved_by) REFERENCES employees(emp_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// SQL for Employee Requests Table
$requestsTableSQL = "CREATE TABLE employee_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    request_type VARCHAR(50) NOT NULL,
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected') DEFAULT 'Pending',
    request_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    response TEXT,
    response_date DATETIME,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// SQL for Admin Activities Table
$adminActivitiesTableSQL = "CREATE TABLE admin_activities (
    activity_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id VARCHAR(50) NOT NULL,
    activity_type VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(admin_id) ON DELETE CASCADE
)";

// Create admin activities table
createTable($conn, 'admin_activities', $adminActivitiesTableSQL);

// Create Tables
echo "<h2>EPMS Database Table Creation</h2>";

// Attempt to create tables
$tables = [
    ['admin', $adminTableSQL],
    ['employees', $employeesTableSQL],
    ['benefits', $benefitTableSQL],
    ['employee_login', $employeeLoginTableSQL],
    ['attendance', $attendanceTableSQL],
    ['salary_calculations', $salaryCalculationsTableSQL],
    ['leave_management', $leaveTableSQL],
    ['employee_requests', $requestsTableSQL]
];

// Modify the foreach loop to handle errors
foreach ($tables as $table) {
    $tableName = $table[0];
    $sql = $table[1];
    if (!empty($sql)) {
        createTable($conn, $tableName, $sql);
    }
}
?>