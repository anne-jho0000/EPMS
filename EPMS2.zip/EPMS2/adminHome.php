<?php
// Start session for user authentication
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in
    header("Location: adminLogin.php");
    exit();
}

// Include database connection and admin functions
require_once 'database.php';
require_once 'admin_functions.php';

// Initialize admin activity system
initAdminActivitySystem();

// Fetch admin information
$admin_id = $_SESSION['admin_id'];
$query = "SELECT * FROM admins WHERE admin_id = ?";
$stmt = mysqli_prepare($conn, $query);
if (!$stmt) {
    echo "Prepare failed: " . mysqli_error($conn);
    exit;
}
mysqli_stmt_bind_param($stmt, "s", $admin_id); // Fixed parameter binding
if (!mysqli_stmt_execute($stmt)) {
    echo "Execute failed: " . mysqli_stmt_error($stmt);
    exit;
}
$result = mysqli_stmt_get_result($stmt);
if (!$result) {
    echo "Getting result failed: " . mysqli_stmt_error($stmt);
    exit;
}
$admin = mysqli_fetch_assoc($result);

// Get total employee count
$query = "SELECT COUNT(*) as total FROM employees";
$result = mysqli_query($conn, $query);
if (!$result) {
    echo "Database query failed: " . mysqli_error($conn);
    exit;
}
$row = mysqli_fetch_assoc($result);
$total_employees = $row['total']; // Define the variable

// Get new employees this month
// Get new employees this month
$query = "SELECT COUNT(*) as new_employees FROM employees";
// Check if created_at column exists
$check_column = mysqli_query($conn, "SHOW COLUMNS FROM employees LIKE 'created_at'");
if (mysqli_num_rows($check_column) > 0) {
    $query = "SELECT COUNT(*) as new_employees FROM employees WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())";
} else {
    // Fallback to counting all employees if created_at doesn't exist
    $query = "SELECT COUNT(*) as new_employees FROM employees";
}

$result = mysqli_query($conn, $query);
if (!$result) {
    error_log("New employees query failed: " . mysqli_error($conn));
    $new_employees = 0; // Set a default value
} else {
    $row = mysqli_fetch_assoc($result);
    $new_employees = $row['new_employees'];
}

// Get present employees today
$today = date('Y-m-d');
// Check if attendance table exists
$check_table = mysqli_query($conn, "SHOW TABLES LIKE 'attendance'");
if (mysqli_num_rows($check_table) > 0) {
    $query = "SELECT COUNT(*) as present FROM attendance WHERE date = '$today' AND status = 'present'";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("Present employees query failed: " . mysqli_error($conn));
        $present_today = 0; // Set a default value
    } else {
        $row = mysqli_fetch_assoc($result);
        $present_today = isset($row['present']) ? $row['present'] : 0;
    }
} else {
    error_log("Attendance table does not exist");
    $present_today = 0; // Set a default value
}

// Calculate attendance percentage
$attendance_percentage = ($total_employees > 0) ? round(($present_today / $total_employees) * 100) : 0;

// Get pending requests
$query = "SELECT COUNT(*) as pending FROM employee_requests WHERE status = 'Pending'";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$pending_requests = isset($row['pending']) ? $row['pending'] : 0; // Define the variable

// Get new requests today
$query = "SELECT COUNT(*) as new_today FROM employee_requests WHERE DATE(created_at) = CURDATE() AND status = 'Pending'";
$result = mysqli_query($conn, $query);
if (!$result) {
    // Handle query error
    error_log("Database query failed: " . mysqli_error($conn));
    $new_today = 0; // Set a default value
} else {
    $row = mysqli_fetch_assoc($result);
    $new_today = isset($row['new_today']) ? $row['new_today'] : 0; // Define the variable
}
// Get recent activities
// Try to use stored procedure first
$recent_activities = false;
try {
    // Check if the function exists before calling it
    if (function_exists('getRecentAdminActivities')) {
        $recent_activities = getRecentAdminActivities(4);
    }
} catch (Exception $e) {
    error_log("Error calling getRecentAdminActivities: " . $e->getMessage());
}

// If stored procedure fails or function doesn't exist, fall back to direct query
if ($recent_activities === false) {
    $query = "SELECT * FROM (
        SELECT 'New Employee Added' as activity_type, CONCAT(first_name, ' ', last_name) as full_name, department, created_at, NULL as request_type, NULL as details, 'employee' as source
        FROM employees
        WHERE created_at IS NOT NULL AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        
        UNION ALL
        
        SELECT 'Salary Processed' as activity_type, NULL as full_name, NULL as department, processed_date as created_at, NULL as request_type, CONCAT('Month: ', month) as details, 'salary' as source
        FROM salary_payments
        WHERE processed_date IS NOT NULL AND processed_date >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        
        UNION ALL
        
        SELECT 'Employee Request' as activity_type, NULL as full_name, NULL as department, created_at, request_type, subject as details, 'request' as source
        FROM employee_requests
        WHERE created_at IS NOT NULL AND created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
    ) AS activities
    ORDER BY created_at DESC
    LIMIT 4";

    $recent_activities_result = mysqli_query($conn, $query);
    
    // Check if query was successful and handle error properly
    if ($recent_activities_result === false) {
        error_log("Recent activities query failed: " . mysqli_error($conn));
        $recent_activities_result = null;  // Set to null instead of false
    }
}

// Format activity types for display
function formatActivityType($type) {
    return ucwords(str_replace('_', ' ', $type));
}

// Format timestamps for display
function formatTimestamp($timestamp) {
    $date = new DateTime($timestamp);
    $now = new DateTime();
    $interval = $now->diff($date);
    
    if ($interval->days == 0) {
        if ($interval->h == 0) {
            if ($interval->i == 0) {
                return "Just now";
            }
            return $interval->i . " minute" . ($interval->i != 1 ? "s" : "") . " ago";
        }
        return $interval->h . " hour" . ($interval->h != 1 ? "s" : "") . " ago";
    } elseif ($interval->days == 1) {
        return "Yesterday at " . $date->format('g:i A');
    } elseif ($interval->days < 7) {
        return $interval->days . " days ago";
    } else {
        return $date->format('M j, Y g:i A');
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding-top: 20px;
        }
        
        .logo-container {
            text-align: center;
            padding: 10px;
            margin-bottom: 20px;
        }
        
        .logo-img {
            width: 100px;
            height: 100px;
            object-fit: contain;
        }
        
        .system-name {
            text-align: center;
            font-size: 14px;
            margin-top: 15px;
            color: #f0c14b;
        }
        
        .admin-profile {
            text-align: center;
            padding: 20px 0;
            border-top: 1px solid #444;
            border-bottom: 1px solid #444;
            margin: 20px 0;
        }
        
        .profile-img {
            display: inline-block;
            padding: 8px 15px;
            background-color: #f0c14b;
            border-radius: 20px;
            font-weight: bold;
            color: #333;
        }
        
        .admin-name {
            margin-top: 10px;
            font-weight: bold;
        }
        
        .admin-role {
            font-size: 12px;
            color: #ccc;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-item {
            padding: 15px 20px;
            transition: all 0.3s;
        }
        
        .nav-item:hover, .nav-item.active {
            background-color: #444;
            border-left: 4px solid #f0c14b;
        }
        
        .nav-item i {
            margin-right: 10px;
            color: #f0c14b;
        }
        
        .nav-link {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .content {
            flex: 1;
            background-color: #f5f5f5;
        }
        
        .header {
            background-color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .dashboard-title {
            font-size: 24px;
            color: #333;
        }
        
        .add-btn {
            background-color: #f0c14b;
            color: #333;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        
        .add-btn i {
            margin-right: 5px;
        }
        
        .dashboard-content {
            padding: 20px;
        }
        
        .stats-container {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            flex: 1;
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            position: relative;
        }
        
        .stat-icon {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            background-color: rgba(240, 193, 75, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #f0c14b;
        }
        
        .stat-title {
            color: #777;
            font-size: 16px;
            margin-bottom: 10px;
        }
        
        .stat-value {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .stat-detail {
            font-size: 12px;
            color: #4CAF50;
        }
        
        .activities-container {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .activities-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .activities-title {
            font-size: 18px;
            color: #333;
        }
        
        .view-all {
            color: #777;
            text-decoration: none;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            background-color: rgba(240, 193, 75, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #f0c14b;
            margin-right: 15px;
        }
        
        .activity-details {
            flex: 1;
        }
        
        .activity-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .activity-description {
            color: #777;
            font-size: 14px;
        }
        
        .activity-time {
            color: #999;
            font-size: 12px;
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img">
            <div class="system-name">
                Employment Payment<br>Management System<br>EPMS
            </div>
        </div>
        
        <div class="admin-profile">
            <button class="profile-img">Admin Profile</button>
            <div class="admin-name"><?php echo htmlspecialchars(isset($admin) && isset($admin['full_name']) ? $admin['full_name'] : 'Admin User'); ?></div>
            <div class="admin-role"><?php echo htmlspecialchars(isset($admin) && isset($admin['role']) ? $admin['role'] : 'Admin'); ?></div>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item active">
                <a href="adminHome.php" class="nav-link">
                    <i class="fas fa-home"></i> Admin Home
                </a>
            </li>
            <li class="nav-item">
                <a href="employee_details.php" class="nav-link">
                    <i class="fas fa-users"></i> Employee Details
                </a>
            </li>
            <li class="nav-item">
                <a href="view_attendance.php" class="nav-link">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
            </li>
            <li class="nav-item">
                <a href="salary_calculation.php" class="nav-link">
                    <i class="fas fa-calculator"></i> Salary Calculation
                </a>
            </li>
            <li class="nav-item">
                <a href="admin_requests.php" class="nav-link">
                    <i class="fas fa-bell"></i> Employee Requests
                </a>
            </li>
            <li class="nav-item">
                <a href="index.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>
    
    <div class="content">
        <div class="header">
            <h1>Admin Dashboard</h1>
            <a href="add_employee.php" class="add-btn">+ Add Employee</a>
        </div>
        
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-title">Total Employees</div>
                <div class="stat-value"><?php echo $total_employees; ?></div>
                <div class="stat-detail">+<?php echo $new_employees; ?> this month</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-clipboard-check"></i>
                </div>
                <div class="stat-title">Present Today</div>
                <div class="stat-value"><?php echo $present_today; ?></div>
                <div class="stat-detail"><?php echo $attendance_percentage; ?>% attendance</div>
            </div>
            
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-clock"></i>
                </div>
                <div class="stat-title">Pending Requests</div>
                <div class="stat-value"><?php echo $pending_requests; ?></div>
                <div class="stat-detail"><?php echo $new_today; ?> new today</div>
            </div>
        </div>
        
        <div class="activities-container">
            <div class="activities-header">
                <h2 class="activities-title">Recent Activity</h2>
                <a href="activities.php" class="view-all">View All</a>
            </div>
            
            <div class="activity-note" style="font-size: 12px; color: #777; margin-bottom: 10px;">
                Showing activities from the past 7 days only. Older activities are automatically removed.
            </div>
            
            <div class="activity-list">
                <?php 
                // Check if we have activities from the stored procedure
                if (is_array($recent_activities) && count($recent_activities) > 0): 
                ?>
                    <?php foreach ($recent_activities as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <i class="fas fa-bell"></i>
                            </div>
                            <div class="activity-details">
                                <div class="activity-title"><?php echo htmlspecialchars($activity['action_type']); ?></div>
                                <div class="activity-description"><?php echo htmlspecialchars($activity['admin_name']); ?> - <?php echo htmlspecialchars($activity['action_details']); ?></div>
                            </div>
                            <div class="activity-time">
                                <?php echo formatTimestamp($activity['action_time']); ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php 
                // Check if we have activities from the direct query
                elseif (isset($recent_activities_result) && $recent_activities_result && mysqli_num_rows($recent_activities_result) > 0): 
                ?>
                    <?php while ($activity = mysqli_fetch_assoc($recent_activities_result)): ?>
                        <div class="activity-item">
                            <div class="activity-icon">
                                <i class="fas fa-bell"></i>
                            </div>
                            <div class="activity-details">
                                <div class="activity-title"><?php echo htmlspecialchars($activity['activity_type']); ?></div>
                                <div class="activity-description">
                                    <?php 
                                    if (!empty($activity['full_name'])) {
                                        echo htmlspecialchars($activity['full_name']);
                                    }
                                    if (!empty($activity['details'])) {
                                        echo ' - ' . htmlspecialchars($activity['details']);
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="activity-time">
                                <?php echo formatTimestamp($activity['created_at']); ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="no-activities">No recent activities found.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        // Optional JavaScript for enhanced UI interactions
    </script>
</body>
</html>