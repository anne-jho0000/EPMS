DELIMITER //

-- Procedure to log admin activity
CREATE PROCEDURE IF NOT EXISTS sp_log_admin_activity(
    IN p_admin_id INT,
    IN p_admin_name VARCHAR(100),
    IN p_action_type VARCHAR(50),
    IN p_action_details TEXT,
    IN p_ip_address VARCHAR(50)
)
BEGIN
    INSERT INTO admin_activity_log (
        admin_id, 
        admin_name, 
        action_type, 
        action_details, 
        ip_address
    ) VALUES (
        p_admin_id, 
        p_admin_name, 
        p_action_type, 
        p_action_details, 
        p_ip_address
    );
    
    SELECT LAST_INSERT_ID() AS log_id;
END //

-- Procedure to update admin's last login time
CREATE PROCEDURE IF NOT EXISTS sp_update_admin_last_login(
    IN p_admin_id INT
)
BEGIN
    UPDATE admins 
    SET last_login = NOW() 
    WHERE id = p_admin_id;
    
    SELECT ROW_COUNT() AS updated_rows;
END //

-- Procedure to get recent admin activities
CREATE PROCEDURE IF NOT EXISTS sp_get_recent_admin_activities(
    IN p_limit INT
)
BEGIN
    SELECT 
        log_id,
        admin_name,
        action_type,
        action_details,
        action_time,
        ip_address
    FROM 
        admin_activity_log
    ORDER BY 
        action_time DESC
    LIMIT p_limit;
END //

DELIMITER ;