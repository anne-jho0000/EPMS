DELIMITER //

CREATE PROCEDURE IF NOT EXISTS sp_create_admin_log_table()
BEGIN
    -- Check if table exists
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.tables 
        WHERE table_schema = DATABASE() 
        AND table_name = 'admin_activity_log'
    ) THEN
        -- Create the admin activity log table
        CREATE TABLE admin_activity_log (
            log_id INT AUTO_INCREMENT PRIMARY KEY,
            admin_id INT NOT NULL,
            admin_name VARCHAR(100) NOT NULL,
            action_type VARCHAR(50) NOT NULL,
            action_details TEXT,
            action_time DATETIME DEFAULT CURRENT_TIMESTAMP,
            ip_address VARCHAR(50),
            FOREIGN KEY (admin_id) REFERENCES admins(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        
        SELECT 'Admin activity log table created successfully' AS message;
    ELSE
        SELECT 'Admin activity log table already exists' AS message;
    END IF;
END //

DELIMITER ;