<?php
session_start();
require_once 'database.php';

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header("Location: employeeLogin.php");
    exit();
}

$success_message = '';
$error_message = '';
$emp_id = $_SESSION['employee_id'];

// Fetch current employee and benefit details
$query = "SELECT e.*, eb.* 
          FROM employees e 
          LEFT JOIN employee_benefits eb ON e.emp_id = eb.emp_id 
          WHERE e.emp_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $emp_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$data = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get employee details
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    
    // Get benefit details
    $sss_number = mysqli_real_escape_string($conn, $_POST['sss_number']);
    $pagibig_number = mysqli_real_escape_string($conn, $_POST['pagibig_number']);
    $philhealth_number = mysqli_real_escape_string($conn, $_POST['philhealth_number']);
    $tin_number = mysqli_real_escape_string($conn, $_POST['tin_number']);
    
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Update employee details
        $update_emp = "UPDATE employees SET 
                      email = ?,
                      phone = ?,
                      updated_at = NOW()
                      WHERE emp_id = ?";
        
        $stmt = mysqli_prepare($conn, $update_emp);
        mysqli_stmt_bind_param($stmt, "ssi", $email, $phone, $emp_id);
        mysqli_stmt_execute($stmt);
        
        // Check if benefit record exists
        $check_benefit = "SELECT benefit_id FROM employee_benefits WHERE emp_id = ?";
        $stmt = mysqli_prepare($conn, $check_benefit);
        mysqli_stmt_bind_param($stmt, "i", $emp_id);
        mysqli_stmt_execute($stmt);
        $benefit_result = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($benefit_result) > 0) {
            // Update existing benefit record
            $update_benefit = "UPDATE employee_benefits SET 
                             sss_number = ?,
                             pagibig_number = ?,
                             philhealth_number = ?,
                             tin_number = ?,
                             updated_at = NOW()
                             WHERE emp_id = ?";
            
            $stmt = mysqli_prepare($conn, $update_benefit);
            mysqli_stmt_bind_param($stmt, "ssssi", 
                $sss_number, 
                $pagibig_number, 
                $philhealth_number, 
                $tin_number, 
                $emp_id
            );
        } else {
            // Insert new benefit record
            $insert_benefit = "INSERT INTO employee_benefits 
                             (emp_id, sss_number, pagibig_number, philhealth_number, tin_number) 
                             VALUES (?, ?, ?, ?, ?)";
            
            $stmt = mysqli_prepare($conn, $insert_benefit);
            mysqli_stmt_bind_param($stmt, "issss", 
                $emp_id, 
                $sss_number, 
                $pagibig_number, 
                $philhealth_number, 
                $tin_number
            );
        }
        
        mysqli_stmt_execute($stmt);
        mysqli_commit($conn);
        $success_message = "Your details have been updated successfully!";
        
        // Refresh data
        $result = mysqli_query($conn, "SELECT e.*, eb.* FROM employees e 
                                     LEFT JOIN employee_benefits eb ON e.emp_id = eb.emp_id 
                                     WHERE e.emp_id = $emp_id");
        $data = mysqli_fetch_assoc($result);
        
    } catch (Exception $e) {
        mysqli_rollback($conn);
        $error_message = "Error updating details: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Details - EPMS</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .update-form {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .form-section {
            margin-bottom: 30px;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .form-section h3 {
            margin-top: 0;
            color: #333;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .btn-update {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .btn-update:hover {
            background-color: #45a049;
        }
        
        .alert {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="update-form">
            <h2>Update Your Details</h2>
            
            <?php if ($success_message): ?>
                <div class="alert alert-success"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <?php if ($error_message): ?>
                <div class="alert alert-danger"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-section">
                    <h3>Personal Information</h3>
                    <div class="form-group">
                        <label for="email">Email Address:</label>
                        <input type="email" id="email" name="email" class="form-control" 
                               value="<?php echo htmlspecialchars($data['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number:</label>
                        <input type="tel" id="phone" name="phone" class="form-control" 
                               value="<?php echo htmlspecialchars($data['phone']); ?>" required>
                    </div>
                </div>
                
                <div class="form-section">
                    <h3>Government Benefits Information</h3>
                    <div class="form-group">
                        <label for="sss_number">SSS Number:</label>
                        <input type="text" id="sss_number" name="sss_number" class="form-control" 
                               value="<?php echo htmlspecialchars($data['sss_number'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="pagibig_number">Pag-IBIG Number:</label>
                        <input type="text" id="pagibig_number" name="pagibig_number" class="form-control" 
                               value="<?php echo htmlspecialchars($data['pagibig_number'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="philhealth_number">PhilHealth Number:</label>
                        <input type="text" id="philhealth_number" name="philhealth_number" class="form-control" 
                               value="<?php echo htmlspecialchars($data['philhealth_number'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="tin_number">TIN Number:</label>
                        <input type="text" id="tin_number" name="tin_number" class="form-control" 
                               value="<?php echo htmlspecialchars($data['tin_number'] ?? ''); ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <button type="submit" class="btn-update">Update Details</button>
                    <a href="employeeHome.php" class="btn btn-secondary">Back to Home</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>