<?php

// Include database connection
require_once 'database.php';


// Get employee information
$emp_id = $_SESSION['employee_id'];
$query = "SELECT * FROM employees WHERE emp_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $emp_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$employee = mysqli_fetch_assoc($result);

// Get salary records for the employee
$sql = "SELECT * FROM salary_calculations WHERE emp_id = ? ORDER BY year DESC, month DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $emp_id);
mysqli_stmt_execute($stmt);
$salary_records = mysqli_stmt_get_result($stmt);

// Get current month and year for default filter
$current_month = date('m');
$current_year = date('Y');

// Handle filter submission
$filter_month = isset($_GET['month']) ? $_GET['month'] : $current_month;
$filter_year = isset($_GET['year']) ? $_GET['year'] : $current_year;

// Get filtered salary record
$filtered_sql = "SELECT * FROM salary_calculations WHERE emp_id = ? AND month = ? AND year = ?";
$stmt = mysqli_prepare($conn, $filtered_sql);
mysqli_stmt_bind_param($stmt, "iii", $emp_id, $filter_month, $filter_year);
mysqli_stmt_execute($stmt);
$filtered_result = mysqli_stmt_get_result($stmt);
$filtered_salary = mysqli_fetch_assoc($filtered_result);

// Month names array
$month_names = [
    '01' => 'January', '02' => 'February', '03' => 'March', '04' => 'April',
    '05' => 'May', '06' => 'June', '07' => 'July', '08' => 'August',
    '09' => 'September', '10' => 'October', '11' => 'November', '12' => 'December'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Payroll - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #333;
            --accent-color: #444;
            --success-color: #4CAF50;
            --danger-color: #f44336;
            --warning-color: #ff9800;
            --text-light: #fff;
            --text-dark: #333;
            --light-bg: #f5f5f5;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }
        
        .header {
            background-color: var(--secondary-color);
            color: var(--text-light);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .header h2 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
        }
        
        .logo {
            width: 80px;
            height: auto;
        }
        
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .page-title {
            margin-bottom: 30px;
            text-align: center;
            color: var(--secondary-color);
        }
        
        .back-btn {
            background-color: var(--success-color);
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            display: inline-block;
            font-weight: bold;
            margin-bottom: 20px;
        }
        
        .back-btn:hover {
            opacity: 0.9;
        }
        
        .filter-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 30px;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 8px;
        }
        
        .filter-group {
            flex: 1;
            min-width: 200px;
        }
        
        .filter-label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .filter-select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .filter-btn {
            padding: 10px 20px;
            background-color: var(--primary-color);
            color: var(--text-dark);
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: opacity 0.3s;
            font-size: 16px;
            align-self: flex-end;
        }
        
        .filter-btn:hover {
            opacity: 0.9;
        }
        
        .payslip-container {
            margin-top: 30px;
            border: 1px solid #ddd;
            border-radius: 8px;
            overflow: hidden;
        }
        
        .payslip-header {
            background-color: var(--primary-color);
            color: var(--text-dark);
            padding: 15px;
            text-align: center;
            font-weight: bold;
            font-size: 18px;
        }
        
        .payslip-body {
            padding: 20px;
        }
        
        .employee-info {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 20px;
            padding-bottom: 20px;
            border-bottom: 1px solid #eee;
        }
        
        .info-group {
            flex: 1;
            min-width: 200px;
        }
        
        .info-label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #777;
        }
        
        .info-value {
            font-size: 16px;
        }
        
        .salary-details {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .detail-item {
            margin-bottom: 15px;
        }
        
        .detail-label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #777;
        }
        
        .detail-value {
            font-size: 18px;
        }
        
        .total-section {
            background-color: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .total-row {
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .total-row:last-child {
            border-bottom: none;
        }
        
        .total-label {
            font-weight: bold;
        }
        
        .total-value {
            font-size: 18px;
        }
        
        .grand-total {
            font-size: 24px;
            font-weight: bold;
            color: var(--success-color);
        }
        
        .no-record {
            text-align: center;
            padding: 30px;
            color: #777;
        }
        
        .print-btn {
            display: block;
            width: 100%;
            padding: 12px;
            background-color: var(--secondary-color);
            color: white;
            text-align: center;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            margin-top: 20px;
            font-size: 16px;
        }
        
        .print-btn:hover {
            opacity: 0.9;
        }
        
        .history-container {
            margin-top: 40px;
        }
        
        .history-title {
            margin-bottom: 20px;
            color: var(--secondary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 10px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        
        th {
            background-color: var(--primary-color);
            color: var(--text-dark);
            font-weight: bold;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tr:hover {
            background-color: #f1f1f1;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
        }
        
        .status-pending {
            background-color: var(--warning-color);
            color: white;
        }
        
        .status-processed {
            background-color: var(--primary-color);
            color: var(--text-dark);
        }
        
        .status-paid {
            background-color: var(--success-color);
            color: white;
        }
        
        @media print {
            .header, .back-btn, .filter-container, .print-btn, .history-container {
                display: none;
            }
            
            .container {
                box-shadow: none;
                margin: 0;
                padding: 0;
            }
            
            .payslip-container {
                border: none;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Employee Payroll</h2>
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
        </div>
    </div>

    <div class="container">
        <a href="employeeHome.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        
        <h1 class="page-title">Payroll Information</h1>
        
        <form method="GET" action="">
            <div class="filter-container">
                <div class="filter-group">
                    <label class="filter-label" for="month">Month:</label>
                    <select id="month" name="month" class="filter-select">
                        <?php foreach ($month_names as $num => $name): ?>
                            <option value="<?php echo $num; ?>" <?php echo ($filter_month == $num) ? 'selected' : ''; ?>>
                                <?php echo $name; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div class="filter-group">
                    <label class="filter-label" for="year">Year:</label>
                    <select id="year" name="year" class="filter-select">
                        <?php for ($y = date('Y'); $y >= date('Y') - 5; $y--): ?>
                            <option value="<?php echo $y; ?>" <?php echo ($filter_year == $y) ? 'selected' : ''; ?>>
                                <?php echo $y; ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <button type="submit" class="filter-btn">
                    <i class="fas fa-filter"></i> Filter
                </button>
            </div>
        </form>
        
        <div class="payslip-container">
            <div class="payslip-header">
                Payslip for <?php echo isset($month_names[$filter_month]) ? $month_names[$filter_month] : 'Unknown Month'; ?> <?php echo $filter_year; ?>
            </div>
            
            <div class="payslip-body">
                <?php if ($filtered_salary): ?>
                    <div class="employee-info">
                        <div class="info-group">
                            <div class="info-label">Employee ID:</div>
                            <div class="info-value"><?php echo htmlspecialchars($employee['emp_id']); ?></div>
                        </div>
                        
                        <div class="info-group">
                            <div class="info-label">Name:</div>
                            <div class="info-value"><?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></div>
                        </div>
                        
                        <div class="info-group">
                            <div class="info-label">Department:</div>
                            <div class="info-value"><?php echo htmlspecialchars($employee['department']); ?></div>
                        </div>
                        
                        <div class="info-group">
                            <div class="info-label">Position:</div>
                            <div class="info-value"><?php echo htmlspecialchars($employee['job_title']); ?></div>
                        </div>
                    </div>
                    
                    <div class="salary-details">
                        <div class="detail-item">
                            <div class="detail-label">Working Days:</div>
                            <div class="detail-value"><?php echo $filtered_salary['working_days']; ?> days</div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-label">Total Hours:</div>
                            <div class="detail-value"><?php echo $filtered_salary['total_hours']; ?> hours</div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-label">Base Salary:</div>
                            <div class="detail-value">₱<?php echo number_format($filtered_salary['base_salary'], 2); ?></div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="detail-label">Overtime Hours:</div>
                            <div class="detail-value"><?php echo $filtered_salary['overtime_hours']; ?> hours</div>
                        </div>
                    </div>
                    
                    <div class="total-section">
                        <div class="total-row">
                            <div class="total-label">Base Salary:</div>
                            <div class="total-value">₱<?php echo number_format($filtered_salary['base_salary'], 2); ?></div>
                        </div>
                        
                        <div class="total-row">
                            <div class="total-label">Overtime Earnings:</div>
                            <div class="total-value">₱<?php echo number_format($filtered_salary['total_earnings'] - $filtered_salary['base_salary'], 2); ?></div>
                        </div>
                        
                        <div class="total-row">
                            <div class="total-label">Total Earnings:</div>
                            <div class="total-value">₱<?php echo number_format($filtered_salary['total_earnings'], 2); ?></div>
                        </div>
                        
                        <div class="total-row">
                            <div class="total-label">Deductions:</div>
                            <div class="total-value">₱<?php echo number_format($filtered_salary['deductions'], 2); ?></div>
                        </div>
                        
                        <div class="total-row">
                            <div class="total-label">Net Salary:</div>
                            <div class="total-value grand-total">₱<?php echo number_format($filtered_salary['net_salary'], 2); ?></div>
                        </div>
                    </div>
                    
                    <button class="print-btn" onclick="window.print()">
                        <i class="fas fa-print"></i> Print Payslip
                    </button>
                <?php else: ?>
                    <div class="no-record">
                        <i class="fas fa-exclamation-circle" style="font-size: 48px; color: #ddd; margin-bottom: 15px;"></i>
                        <p>No salary record found for <?php echo isset($month_names[$filter_month]) ? $month_names[$filter_month] : 'Unknown Month'; ?> <?php echo $filter_year; ?>.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="history-container">
            <h3 class="history-title">Salary History</h3>
            
            <?php if (mysqli_num_rows($salary_records) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Period</th>
                            <th>Working Days</th>
                            <th>Total Hours</th>
                            <th>Total Earnings</th>
                            <th>Net Salary</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($record = mysqli_fetch_assoc($salary_records)): ?>
                            <tr>
                                <td><?php echo isset($month_names[$record['month']]) ? $month_names[$record['month']] : 'Unknown'; ?> <?php echo $record['year']; ?></td>
                                <td><?php echo $record['working_days']; ?> days</td>
                                <td><?php echo $record['total_hours']; ?> hours</td>
                                <td>₱<?php echo number_format($record['total_earnings'], 2); ?></td>
                                <td>₱<?php echo number_format($record['net_salary'], 2); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo strtolower($record['payment_status']); ?>">
                                        <?php echo $record['payment_status']; ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="?month=<?php echo $record['month']; ?>&year=<?php echo $record['year']; ?>" class="back-btn" style="margin-bottom: 0;">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No salary records found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php
// Close connection
mysqli_close($conn);
?>