<?php
// Include database connection file
require_once 'database.php';

// Start session to manage user login state
session_start();


// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header("Location: employeeLogin.php");
    exit();
}

// Get employee details from database
$employeeId = $_SESSION['employee_id'];
$stmt = $conn->prepare("SELECT * FROM employees WHERE emp_id = ?");

if ($stmt === false) {
    die('Prepare failed: ' . $conn->error);
}

$stmt->bind_param("i", $employeeId);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $employeeData = $result->fetch_assoc();
} else {
    // Handle the case when employee data is not found
    session_destroy();
    header("Location: employeeLogin.php?error=invalid_session");
    exit();
}


// Get attendance data
$attendanceRate = 0; // Default value
$currentMonth = date('m');
$currentYear = date('Y');

// Check if attendance table exists before querying
$checkAttendanceQuery = "SHOW TABLES LIKE 'attendance'";
$attendanceTableResult = $conn->query($checkAttendanceQuery);

if ($attendanceTableResult && $attendanceTableResult->num_rows > 0) {
    // Table exists, proceed with query
    $attendanceQuery = $conn->prepare("SELECT COUNT(*) as total_days,
                              SUM(CASE WHEN status = 'present' THEN 1 ELSE 0 END) as present_days
                              FROM attendance
                              WHERE emp_id = ? AND MONTH(attendance_date) = ? AND YEAR(attendance_date) = ?");
    
    if ($attendanceQuery === false) {
        error_log('Prepare failed for attendance query: ' . $conn->error);
    } else {
        $attendanceQuery->bind_param("iii", $employeeId, $currentMonth, $currentYear);
        $attendanceQuery->execute();
        $attendanceResult = $attendanceQuery->get_result();
        $attendanceData = $attendanceResult->fetch_assoc();
        
        $totalDays = $attendanceData && isset($attendanceData['total_days']) ? $attendanceData['total_days'] : 0;
        $presentDays = $attendanceData && isset($attendanceData['present_days']) ? $attendanceData['present_days'] : 0;
        
        // Calculate attendance rate
        $attendanceRate = $totalDays > 0 ? ($presentDays / $totalDays) * 100 : 0;
    }
} else {
    error_log('Table attendance does not exist in database');
}

// Get leave balance by calculating from leave_management table
$leaveBalance = 0; // Default value

// Calculate total approved leave days for the employee
$leaveQuery = $conn->prepare("
    SELECT 
        SUM(total_days) as used_days 
    FROM 
        leave_management 
    WHERE 
        emp_id = ? 
        AND status = 'Approved' 
        AND YEAR(start_date) = ?
");

if ($leaveQuery === false) {
    error_log('Prepare failed for leave calculation: ' . $conn->error);
} else {
    $currentYear = date('Y');
    $leaveQuery->bind_param("is", $employeeId, $currentYear);
    $leaveQuery->execute();
    $leaveResult = $leaveQuery->get_result();
    $leaveData = $leaveResult->fetch_assoc();
    
    // Assuming employees get 30 days of leave per year (adjust as needed)
    $totalAnnualLeave = 30;
    $usedDays = $leaveData && $leaveData['used_days'] ? $leaveData['used_days'] : 0;
    $leaveBalance = $totalAnnualLeave - $usedDays;
}


// Get pending requests (likely these are leave requests that are pending)
$pendingRequests = 0; // Default value

// We can count pending leave requests from the leave_management table
$requestQuery = $conn->prepare("SELECT COUNT(*) as pending_count FROM leave_management 
                        WHERE emp_id = ? AND status = 'Pending'");
if ($requestQuery === false) {
    error_log('Prepare failed for pending requests: ' . $conn->error);
} else {
    $requestQuery->bind_param("i", $employeeId);
    $requestQuery->execute();
    $requestResult = $requestQuery->get_result();
    $requestData = $requestResult->fetch_assoc();
    $pendingRequests = $requestData['pending_count'];
}


// Get calendar data for current month
$calendarData = []; // Initialize as empty array

$checkAttendanceQuery = "SHOW TABLES LIKE 'attendance'";
$attendanceTableResult = $conn->query($checkAttendanceQuery);

if ($attendanceTableResult && $attendanceTableResult->num_rows > 0) {
    // Table exists, proceed with query
    $calendarQuery = $conn->prepare("SELECT attendance_date, status FROM attendance 
                             WHERE emp_id = ? AND MONTH(attendance_date) = ? AND YEAR(attendance_date) = ?");
    if ($calendarQuery === false) {
        error_log('Prepare failed for calendar query: ' . $conn->error);
    } else {
        $calendarQuery->bind_param("iii", $employeeId, $currentMonth, $currentYear);
        $calendarQuery->execute();
        $calendarResult = $calendarQuery->get_result();
        
        while ($row = $calendarResult->fetch_assoc()) {
            $day = date('j', strtotime($row['attendance_date']));
            $calendarData[$day] = $row['status'];
        }
    }
} else {
    error_log('Table attendance does not exist in database');
}

// Ensure employee data has required fields
if (!isset($employeeData['name'])) {
    $employeeData['name'] = 'Employee';  // Default value
}

if (!isset($employeeData['position'])) {
    $employeeData['position'] = 'Staff';  // Default value
}


// Include header/footer templates
// Remove this line:
// include 'includes/header.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EPMS Employee Portal</title>
    <link rel="stylesheet" href="css/style.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
</head>
<style>
    /* Reset and base styles */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

body {
    background-color: #f5f5f5;
    color: #333;
    min-height: 100vh;
}

.container {
    display: flex;
    min-height: 100vh;
}

/* Sidebar styles */
.sidebar {
    width: 250px;
    background-color: #333;
    color: #fff;
    display: flex;
    flex-direction: column;
    position: fixed;
    height: 100vh;
    overflow-y: auto;
}

.logo-container {
    padding: 20px;
    display: flex;
    flex-direction: column;
    align-items: center;
    background-color: #444;
    text-align: center;
}

.logo-container img {
    width: 70px;
    height: auto;
    margin-bottom: 10px;
}

.company-name h3 {
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 5px;
    line-height: 1.2;
}

.company-name h2 {
    font-size: 18px;
    color: #FFD700;
    font-weight: 700;
}

.profile-section {
    padding: 20px;
    border-bottom: 1px solid #444;
    position: relative;
}

.profile-highlight {
    position: absolute;
    top: 10px;
    left: 0;
    background-color: #FFD700;
    color: #333;
    padding: 5px 10px;
    border-radius: 0 20px 20px 0;
    font-size: 13px;
    font-weight: 600;
}

.profile-section h2 {
    margin-top: 20px;
    font-size: 20px;
    margin-bottom: 5px;
}

.profile-section p {
    color: #ccc;
    font-size: 14px;
}

.main-nav {
    padding: 10px 0;
    flex-grow: 1;
}

.main-nav ul {
    list-style-type: none;
}

.main-nav li {
    padding: 0;
    margin-bottom: 5px;
}

.main-nav a {
    display: flex;
    align-items: center;
    padding: 12px 20px;
    color: #ccc;
    text-decoration: none;
    transition: all 0.3s;
}

.main-nav a:hover {
    background-color: #444;
    color: #fff;
}

.main-nav li.active a {
    background-color: #555;
    color: #FFD700;
    border-left: 4px solid #FFD700;
}

.main-nav i {
    margin-right: 10px;
    width: 20px;
    text-align: center;
}

/* Main content styles */
.main-content {
    flex: 1;
    margin-left: 250px;
    padding: 20px;
}

header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding: 0 10px;
}

header h1 {
    font-size: 24px;
    color: #444;
}

.new-request-btn .btn {
    background-color: #FFD700;
    color: #333;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-weight: 600;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    transition: all 0.3s;
}

.new-request-btn .btn:hover {
    background-color: #E5C100;
}

.new-request-btn .btn i {
    margin-right: 8px;
}

/* Dashboard tiles */
.dashboard-tiles {
    display: flex;
    gap: 20px;
    margin-bottom: 30px;
}

.tile {
    background-color: #fff;
    border-radius: 10px;
    padding: 20px;
    flex: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
    position: relative;
    overflow: hidden;
}

.tile-content {
    z-index: 1;
}

.tile h2 {
    font-size: 18px;
    margin-bottom: 10px;
    color: #555;
}

.tile-value {
    font-size: 36px;
    font-weight: 700;
    margin-bottom: 5px;
    color: #333;
}

.tile-label {
    font-size: 14px;
    color: #66a832;
}

.tile-icon {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    justify-content: center;
    align-items: center;
    color: #fff;
    font-size: 24px;
    z-index: 1;
}

.user-icon {
    background-color: rgba(255, 215, 0, 0.2);
    color: #FFD700;
}

.calendar-icon {
    background-color: rgba(66, 139, 202, 0.2);
    color: #428bca;
}

.clock-icon {
    background-color: rgba(92, 92, 92, 0.2);
    color: #5c5c5c;
}

/* Calendar section */
.calendar-section {
    background-color: #fff;
    border-radius: 10px;
    padding: 20px;
    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
}

.calendar-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.calendar-header h2 {
    font-size: 18px;
    color: #555;
}

.view-history {
    color: #428bca;
    text-decoration: none;
}

.view-history:hover {
    text-decoration: underline;
}

/* Calendar table */
.calendar {
    width: 100%;
    border-collapse: collapse;
    margin-bottom: 15px;
}

.calendar th, .calendar td {
    text-align: center;
    padding: 10px;
    width: 14.28%;
}

.calendar th {
    font-weight: 600;
    color: #555;
}

.calendar td {
    border: 1px solid #eee;
    height: 50px;
    vertical-align: middle;
    font-weight: 500;
}

.calendar td.current-day {
    background-color: #FFD700;
    color: #333;
    font-weight: bold;
}

.calendar td.status-present {
    border-bottom: 3px solid #66a832;
}

.calendar td.status-absent {
    border-bottom: 3px solid #d9534f;
}

.calendar td.status-leave {
    border-bottom: 3px solid #5bc0de;
}

/* Calendar legend */
.calendar-legend {
    display: flex;
    justify-content: center;
    gap: 20px;
    margin-top: 10px;
}

.legend-item {
    display: flex;
    align-items: center;
    font-size: 14px;
    color: #555;
}

.legend-mark {
    width: 12px;
    height: 12px;
    margin-right: 5px;
    display: inline-block;
    border-radius: 50%;
}

.legend-mark.present {
    background-color: #66a832;
}

.legend-mark.absent {
    background-color: #d9534f;
}

.legend-mark.leave {
    background-color: #5bc0de;
}

/* Responsive adjustments */
@media (max-width: 992px) {
    .dashboard-tiles {
        flex-direction: column;
    }
    
    .tile {
        margin-bottom: 15px;
    }
}

@media (max-width: 768px) {
    .container {
        flex-direction: column;
    }
    
    .sidebar {
        width: 100%;
        height: auto;
        position: relative;
    }
    
    .main-content {
        margin-left: 0;
    }
    
    .calendar th, .calendar td {
        padding: 5px;
    }
}
    </style>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo-container">
                <img src="images/logo2.png" alt="EPMS Logo">
                <div class="company-name">
                    <h3>Employment Payment<br>Management System</h3>
                    
                </div>
            </div>
            
            <div class="profile-section">
                <div class="profile-highlight">Employee Profile</div>
                <h2><?php echo htmlspecialchars($employeeData['name']); ?></h2>
                <p><?php echo htmlspecialchars($employeeData['position']); ?></p>
            </div>
            
            <nav class="main-nav">
                <ul>
                    <li class="active">
                        <a href="employeeHome.php"><i class="fas fa-home"></i> Employee Home</a>
                    </li>
                    <li>
                        <a href="attendance_scanner.php"><i class="fas fa-calendar-check"></i> Attendance</a>
                    </li>
                    <li>
                        <a href="employee_details.php"><i class="fas fa-user-edit"></i> Update Details</a>
                    </li>
                    <li>
                        <a href="employee_request.php"><i class="fas fa-clipboard-list"></i> Requests</a>
                    </li>
                    <li>
                        <a href="viewPayroll.php"><i class="fas fa-money-bill-wave"></i> View Payroll</a>
                    </li>
                    <li>
                        <a href="index.php"><i class="fas fa-sign-out-alt"></i> Sign Out</a>
                    </li>
                </ul>
            </nav>
        </div>
        
        <div class="main-content">
    <header>
        <h1>EPMS Employee Portal</h1>
        <div class="new-request-btn">
            <a href="newRequest.php" class="btn">
                <i class="fas fa-plus"></i> New Request
            </a>
        </div>
    </header>
            
    <div class="dashboard-tiles">
        <div class="tile">
            <div class="tile-content">
                <h2>Attendance Rate</h2>
                <div class="tile-value"><?php echo number_format($attendanceRate, 1); ?>%</div>
                <div class="tile-label">This month</div>
            </div>
            <div class="tile-icon user-icon">
                <i class="fas fa-user-check"></i>
            </div>
        </div>

        <div class="tile">
            <div class="tile-content">
                <h2>Leave Balance</h2>
                <div class="tile-value"><?php echo $leaveBalance; ?></div>
                <div class="tile-label">Days remaining</div>
            </div>
            <div class="tile-icon calendar-icon">
                <i class="fas fa-calendar-alt"></i>
            </div>
        </div>

        <div class="tile">
            <div class="tile-content">
                <h2>Pending Requests</h2>
                <div class="tile-value"><?php echo $pendingRequests; ?></div>
                <div class="tile-label">Waiting for approval</div>
            </div>
            <div class="tile-icon pending-icon">
                <i class="fas fa-clock"></i>
            </div>
        </div>
    </div>
            
            <div class="calendar-section">
                <div class="calendar-header">
                    <h2>March 2025 Attendance</h2>
                    <a href="attendanceHistory.php" class="view-history">View Full History</a>
                </div>
                
                <table class="calendar">
                    <thead>
                        <tr>
                            <th>Sun</th>
                            <th>Mon</th>
                            <th>Tue</th>
                            <th>Wed</th>
                            <th>Thu</th>
                            <th>Fri</th>
                            <th>Sat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        // Get the first day of the month
                        $firstDay = mktime(0, 0, 0, $currentMonth, 1, $currentYear);
                        $daysInMonth = date('t', $firstDay);
                        $startingDay = date('w', $firstDay);
                        
                        // Create the calendar
                        $day = 1;
                        $calendar = "";
                        
                        // Calendar rows
                        for ($i = 0; $i < 6; $i++) {
                            echo "<tr>";
                            
                            // Calendar columns
                            for ($j = 0; $j < 7; $j++) {
                                if (($i == 0 && $j < $startingDay) || ($day > $daysInMonth)) {
                                    // Empty cells before the first day or after the last day
                                    echo "<td></td>";
                                } else {
                                    // Determine cell class based on attendance status
                                    $cellClass = "";
                                    if (isset($calendarData[$day])) {
                                        $cellClass = "status-" . $calendarData[$day];
                                    }
                                    
                                    // Highlight current day
                                    if ($day == date('j') && $currentMonth == date('m') && $currentYear == date('Y')) {
                                        $cellClass .= " current-day";
                                    }
                                    
                                    echo "<td class='$cellClass'>$day</td>";
                                    $day++;
                                }
                            }
                            
                            echo "</tr>";
                            
                            // Stop once we've displayed all days
                            if ($day > $daysInMonth) {
                                break;
                            }
                        }
                        ?>
                    </tbody>
                </table>
                
                <div class="calendar-legend">
                    <div class="legend-item">
                        <span class="legend-mark present"></span> Present
                    </div>
                    <div class="legend-item">
                        <span class="legend-mark absent"></span> Absent
                    </div>
                    <div class="legend-item">
                        <span class="legend-mark leave"></span> Leave
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="js/script.js"></script>
</body>
</html>