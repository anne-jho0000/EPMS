<?php
// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>EPMS Database Setup</h2>";

// Include the create_epms_tables.php file
require_once 'create_epms_tables.php';

// Add success message
echo "<div style='margin-top: 20px; padding: 10px; background-color: #dff0d8; border: 1px solid #d6e9c6; color: #3c763d; border-radius: 4px;'>";
echo "Database setup completed! You can now use the EPMS system.";
echo "</div>";

echo "<div style='margin-top: 20px;'>";
echo "<a href='index.php' style='padding: 10px 20px; background-color: #f0c14b; color: #333; text-decoration: none; border-radius: 4px;'>Go to Login Page</a>";
echo "</div>";
?>