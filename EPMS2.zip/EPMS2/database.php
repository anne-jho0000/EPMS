<?php
$db_server = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "epms_db";

// Buffer the output
ob_start();

// First, connect without database selection
$conn = mysqli_connect($db_server, $db_user, $db_pass);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Create database if it doesn't exist
$create_db = "CREATE DATABASE IF NOT EXISTS $db_name";
mysqli_query($conn, $create_db);

// Close the initial connection
mysqli_close($conn);

// Create new connection with database selected
$conn = mysqli_connect($db_server, $db_user, $db_pass, $db_name);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Now include the table creation code
require_once 'create_epms_tables.php';

// Clear the buffer
ob_end_clean();
?>