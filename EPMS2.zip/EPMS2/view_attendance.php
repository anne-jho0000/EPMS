<?php
// Include database connection
require_once 'database.php';

// Check if filter is applied
$filter_employee = isset($_GET['employee']) ? mysqli_real_escape_string($conn, $_GET['employee']) : '';
$filter_date = isset($_GET['date']) ? mysqli_real_escape_string($conn, $_GET['date']) : '';
$filter_status = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : '';

// Construct the base query
$sql = "SELECT a.*, e.first_name, e.last_name FROM attendance a 
        LEFT JOIN employees e ON a.emp_id = e.emp_id 
        WHERE 1=1";

// Add filter conditions
if (!empty($filter_employee)) {
    $sql .= " AND a.emp_id = '$filter_employee'";
}
if (!empty($filter_date)) {
    $sql .= " AND a.attendance_date = '$filter_date'";
}
if (!empty($filter_status)) {
    $sql .= " AND a.status = '$filter_status'";
}

// Execute the query
$result = mysqli_query($conn, $sql);

// Check if query was successful
if ($result === false) {
    die("Query failed: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee Attendance</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #333;
            --accent-color: #444;
            --success-color:rgb(247, 222, 1);
            --danger-color: #f44336;
            --text-light: #fff;
            --text-dark: #333;
            --light-bg: #f5f5f5;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }
        
        .header {
            background-color: var(--secondary-color);
            color: var(--text-light);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .header h2 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
        }
        
        .logo {
            width: 80px;
            height: auto;
        }
        
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .page-title {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .filter-section {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            align-items: center;
            flex-wrap: wrap;
        }
        
        .filter-section select, 
        .filter-section input {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        
        th {
            background-color: var(--primary-color);
            color: var(--text-dark);
            font-weight: bold;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tr:hover {
            background-color: #f1f1f1;
        }
        
        .btn {
            padding: 8px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: opacity 0.3s;
        }
        
        .btn:hover {
            opacity: 0.9;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: var(--text-dark);
        }
        
        .btn-secondary {
            background-color: var(--secondary-color);
            color: var(--text-light);
        }
        
        .btn-success {
            background-color: var(--success-color);
            color: white;
        }
        
        .back-btn {
            background-color: var(--success-color);
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            display: inline-block;
            font-weight: bold;
            color: black;
        }
        
        .back-btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Employee Attendance</h2>
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
        </div>
    </div>

    <div class="container">
        <div class="page-title">
            <h2>Attendance Records</h2>
            <a href="adminHome.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Admin Home
            </a>
        </div>

        <form method="GET" class="filter-section">
            <select name="employee">
                <option value="">All Employees</option>
                <?php 
                // Fetch employees for dropdown
                $emp_query = mysqli_query($conn, "SELECT emp_id, first_name, last_name FROM employees");
                while ($emp = mysqli_fetch_assoc($emp_query)) {
                    $selected = ($emp['emp_id'] == $filter_employee) ? 'selected' : '';
                    echo "<option value='{$emp['emp_id']}' $selected>{$emp['first_name']} {$emp['last_name']}</option>";
                }
                ?>
            </select>

            <input type="date" name="date" value="<?php echo htmlspecialchars($filter_date); ?>">

            <select name="status">
                <option value="">All Statuses</option>
                <option value="present" <?php echo ($filter_status == 'present') ? 'selected' : ''; ?>>Present</option>
                <option value="absent" <?php echo ($filter_status == 'absent') ? 'selected' : ''; ?>>Absent</option>
                <option value="late" <?php echo ($filter_status == 'late') ? 'selected' : ''; ?>>Late</option>
            </select>

            <button type="submit" class="btn btn-primary">
                <i class="fas fa-filter"></i> Filter
            </button>
            <button type="button" onclick="window.location.href='view_attendance.php'" class="btn btn-secondary">
                <i class="fas fa-redo"></i> Reset
            </button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>Employee</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Check In</th>
                    <th>Check Out</th>
                    <th>Expected In</th>
                    <th>Expected Out</th>
                    <th>Tardiness</th>
                    <th>Overtime</th>
                    <th>Notes</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                // Check if there are any results
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        // Create employee name from joined query
                        $employee_name = isset($row['first_name']) && isset($row['last_name']) ? 
                                        $row['first_name'] . ' ' . $row['last_name'] : 'Unknown';

                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($employee_name) . "</td>";
                        echo "<td>" . htmlspecialchars($row['attendance_date'] ?? '') . "</td>";
                        echo "<td>" . htmlspecialchars($row['status'] ?? '') . "</td>";
                        echo "<td>" . htmlspecialchars($row['check_in'] ?? '') . "</td>";
                        echo "<td>" . htmlspecialchars($row['check_out'] ?? '') . "</td>";
                        echo "<td>" . htmlspecialchars($row['expected_in'] ?? '') . "</td>";
                        echo "<td>" . htmlspecialchars($row['expected_out'] ?? '') . "</td>";
                        echo "<td>" . htmlspecialchars($row['tardiness'] ?? '0') . "</td>";
                        echo "<td>" . htmlspecialchars($row['overtime'] ?? '0') . "</td>";
                        echo "<td>" . htmlspecialchars($row['notes'] ?? '') . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='10'>No attendance records found</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<?php
// Close the connection
mysqli_close($conn);
?>