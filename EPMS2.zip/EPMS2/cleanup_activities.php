<?php
// Include database connection
require_once 'database.php';

// Set error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Log the start of cleanup process
error_log("Starting activity cleanup process");

try {
    // Clean up old activities from admin_activities
    $query = "DELETE FROM admin_activities WHERE created_at < DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
    $result = mysqli_query($conn, $query);
    
    if ($result) {
        $deleted_count = mysqli_affected_rows($conn);
        error_log("Deleted $deleted_count old admin activities");
    } else {
        error_log("Error cleaning up admin activities: " . mysqli_error($conn));
    }
    
    // Check if admin_activity_log exists and clean it up too
    $check_table = mysqli_query($conn, "SHOW TABLES LIKE 'admin_activity_log'");
    if (mysqli_num_rows($check_table) > 0) {
        $query = "DELETE FROM admin_activity_log WHERE action_time < DATE_SUB(CURDATE(), INTERVAL 7 DAY)";
        $result = mysqli_query($conn, $query);
        
        if ($result) {
            $deleted_count = mysqli_affected_rows($conn);
            error_log("Deleted $deleted_count old admin activity logs");
        } else {
            error_log("Error cleaning up admin activity logs: " . mysqli_error($conn));
        }
    }
    
    echo "Cleanup completed successfully. Removed activities older than 7 days.";
} catch (Exception $e) {
    error_log("Exception during cleanup: " . $e->getMessage());
    echo "Error during cleanup: " . $e->getMessage();
}
?>