<?php
$db_host = 'localhost';
$db_user = 'root'; // Your DB username (needs CREATE DATABASE, CREATE TABLE, INSERT perms)
$db_pass = '';     // Your DB password
$db_name = 'epms_database'; // Your DB name

// --- Database and Table Schema ---
$sql_statements = [
    "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role ENUM('admin', 'employee') NOT NULL,
        employee_id INT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

    "CREATE TABLE IF NOT EXISTS employees (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_code VARCHAR(20) NOT NULL UNIQUE,
        first_name VARCHAR(50) NOT NULL,
        last_name VARCHAR(50) NOT NULL,
        email VARCHAR(100) UNIQUE,
        phone VARCHAR(20),
        address TEXT,
        date_hired DATE,
        position VARCHAR(100),
        department VARCHAR(100),
        basic_salary DECIMAL(10, 2) DEFAULT 0.00,
        sss_no VARCHAR(50),
        philhealth_no VARCHAR(50),
        pagibig_no VARCHAR(50),
        tin_no VARCHAR(50),
        mode_of_payment VARCHAR(50) DEFAULT 'Bank Transfer',
        bank_account_no VARCHAR(50),
        status ENUM('active', 'deleted', 'resigned') DEFAULT 'active',
        qr_code_path VARCHAR(255) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

    "ALTER TABLE users ADD CONSTRAINT fk_employee_id FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE SET NULL ON UPDATE CASCADE;", // Add FK after both tables exist

    "CREATE TABLE IF NOT EXISTS attendance (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        time_in DATETIME,
        time_out DATETIME,
        date_recorded DATE NOT NULL,
        status ENUM('present', 'absent', 'late') DEFAULT 'present',
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

    "CREATE TABLE IF NOT EXISTS payroll (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        pay_period_start DATE NOT NULL,
        pay_period_end DATE NOT NULL,
        basic_pay DECIMAL(10, 2) NOT NULL,
        allowances DECIMAL(10, 2) DEFAULT 0.00,
        sss_contribution DECIMAL(10, 2) DEFAULT 0.00,
        philhealth_contribution DECIMAL(10, 2) DEFAULT 0.00,
        pagibig_contribution DECIMAL(10, 2) DEFAULT 0.00,
        withholding_tax DECIMAL(10, 2) DEFAULT 0.00,
        other_deductions DECIMAL(10, 2) DEFAULT 0.00,
        net_pay DECIMAL(10, 2) NOT NULL,
        date_generated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

    "CREATE TABLE IF NOT EXISTS employee_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        employee_id INT NOT NULL,
        request_type VARCHAR(100) NOT NULL,
        details TEXT,
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        responded_at TIMESTAMP NULL,
        admin_remarks TEXT,
        FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

    "CREATE TABLE IF NOT EXISTS contact_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        message TEXT NOT NULL,
        submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;",

    "CREATE TABLE IF NOT EXISTS page_visits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ip_address VARCHAR(45),
        user_agent TEXT,
        page VARCHAR(255),
        visit_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;"
];

// --- Database Connection and Setup Logic ---
$setup_messages = [];
$conn = null;

// Try to connect to MySQL server (without selecting DB first)
$temp_conn = mysqli_connect($db_host, $db_user, $db_pass);

if (!$temp_conn) {
    die("Initial MySQL server connection failed: " . mysqli_connect_error() . "<br>Please ensure MySQL is running and credentials (host, user, password) are correct in config/db.php.");
}

// Try to select the database
if (!mysqli_select_db($temp_conn, $db_name)) {
    // Database does not exist, try to create it
    $setup_messages[] = "Database '$db_name' not found. Attempting to create...";
    $sql_create_db = "CREATE DATABASE IF NOT EXISTS `$db_name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;";
    if (mysqli_query($temp_conn, $sql_create_db)) {
        $setup_messages[] = "Database '$db_name' created successfully or already exists.";
        mysqli_select_db($temp_conn, $db_name); // Select it now
    } else {
        mysqli_close($temp_conn);
        die("Error creating database '$db_name': " . mysqli_error($temp_conn) . "<br>Please check MySQL user permissions or create the database manually.");
    }
} else {
    $setup_messages[] = "Database '$db_name' selected successfully.";
}

// Now establish the final connection to the specific database
$conn = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if (!$conn) {
    // This should ideally not happen if the above logic worked, but as a fallback.
    mysqli_close($temp_conn);
    die("Connection to database '$db_name' failed: " . mysqli_connect_error());
}
mysqli_close($temp_conn); // Close the temporary connection

// Set character set
mysqli_set_charset($conn, "utf8mb4");
$setup_messages[] = "Database character set set to utf8mb4.";

// Create tables if they don't exist
foreach ($sql_statements as $sql) {
    if (mysqli_query($conn, $sql)) {
        // Extract table name for message (simple parsing)
        if (preg_match('/CREATE TABLE IF NOT EXISTS `?(\w+)`?/', $sql, $matches) || preg_match('/ALTER TABLE `?(\w+)`?/', $sql, $matches)) {
            $setup_messages[] = "Table/Constraint '{$matches[1]}' checked/created successfully.";
        } else {
             $setup_messages[] = "SQL statement executed successfully: " . substr($sql, 0, 50) . "...";
        }
    } else {
        // Do not die here, allow other operations to proceed if possible, but log error
        $setup_messages[] = "Error executing SQL: " . mysqli_error($conn) . " --- SQL: " . substr($sql, 0, 100) . "...";
        // For critical failures, you might still want to die:
        // die("Critical error creating table: " . mysqli_error($conn));
    }
}


// Check and create default admin user
$admin_username = 'admin';
$admin_password = 'admin123'; // **IMPORTANT: Change this immediately after first login!**
$hashed_password = password_hash($admin_password, PASSWORD_DEFAULT);

$stmt_check_admin = $conn->prepare("SELECT id FROM users WHERE username = ?");
if ($stmt_check_admin) {
    $stmt_check_admin->bind_param("s", $admin_username);
    $stmt_check_admin->execute();
    $result_admin = $stmt_check_admin->get_result();

    if ($result_admin->num_rows == 0) {
        $setup_messages[] = "Default admin user '$admin_username' not found. Attempting to create...";
        $stmt_insert_admin = $conn->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, 'admin')");
        if ($stmt_insert_admin) {
            $stmt_insert_admin->bind_param("ss", $admin_username, $hashed_password);
            if ($stmt_insert_admin->execute()) {
                $setup_messages[] = "Default admin user '$admin_username' created successfully with password '$admin_password'. <strong style='color:red;'>PLEASE CHANGE THIS PASSWORD IMMEDIATELY AFTER LOGIN.</strong>";
            } else {
                $setup_messages[] = "Error creating default admin user: " . $stmt_insert_admin->error;
            }
            $stmt_insert_admin->close();
        } else {
             $setup_messages[] = "Error preparing statement for admin insert: " . $conn->error;
        }
    } else {
        $setup_messages[] = "Default admin user '$admin_username' already exists.";
    }
    $stmt_check_admin->close();
} else {
    $setup_messages[] = "Error preparing statement for admin check: " . $conn->error;
}

// Start session on every page that includes this
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Store setup messages in session to display them once (e.g., on dashboard or a setup page)
// This is optional. For silent setup, you can remove this.
if (!empty($setup_messages) && !isset($_SESSION['setup_messages_displayed'])) {
    $_SESSION['setup_log'] = $setup_messages;
    // You could redirect to a page that displays these logs, or display them on the first page loaded.
    // For now, we'll just store them. You can access $_SESSION['setup_log'] in your index.php or dashboard.php
    // and then unset it after displaying.
}
// To display setup messages on the current page (useful for debugging first run):
/*
if (!empty($_SESSION['setup_log']) && basename($_SERVER['PHP_SELF']) == 'index.php') { // Example: display on index.php
    echo "<div style='border:1px solid #ccc; padding:10px; margin:10px; background-color:#f0f0f0;'><strong>Setup Log:</strong><br>";
    foreach ($_SESSION['setup_log'] as $msg) {
        echo $msg . "<br>";
    }
    echo "</div>";
    unset($_SESSION['setup_log']); // Display only once
}
*/
?>