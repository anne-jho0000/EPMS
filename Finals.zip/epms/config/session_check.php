<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

function require_login($required_role = null) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ../auth/login.php?redirect=" . urlencode($_SERVER['REQUEST_URI']));
        exit();
    }
    if ($required_role && $_SESSION['user_role'] !== $required_role) {
        // Redirect to a generic dashboard or an error page
        if ($_SESSION['user_role'] === 'admin') {
            header("Location: ../admin/dashboard.php");
        } else {
            header("Location: ../employee/dashboard.php");
        }
        exit();
    }
}
?>