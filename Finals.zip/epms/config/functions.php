<?php
// Included via db.php or directly

function sanitize_input($data, $connection) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    if($connection) { // Ensure $conn is passed and valid
        $data = mysqli_real_escape_string($connection, $data);
    }
    return $data;
}

function get_employee_details($conn, $employee_id) {
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->bind_param("i", $employee_id);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

// Add more helper functions as needed...
?>