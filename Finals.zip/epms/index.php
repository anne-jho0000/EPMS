<?php
// Include database connection
require_once 'config/db.php'; // Correct path
require_once 'config/functions.php'; // Correct path

// Initialize variables
$message = '';
$page_title = 'Employment Payment Management System';

// ... (rest of your existing PHP logic for contact form and features) ...
// MAKE SURE TO PASS $conn to sanitize_input if you use it:
// $name = sanitize_input($_POST['name'], $conn);

// Your existing features array
$features = [
    [ /* ... */ ]
];


// Track page visit (if connected to database)
if($conn) {
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $page = 'landing_page';
    
    // Use prepared statement
    $stmt = $conn->prepare("INSERT INTO page_visits (ip_address, user_agent, page, visit_date) VALUES (?, ?, ?, NOW())");
    if ($stmt) {
        $stmt->bind_param("sss", $ip_address, $user_agent, $page);
        $stmt->execute();
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employment Payment Management System (EPMS)</title>
    <link rel="stylesheet" href="css/style.css"> <!-- Corrected path -->
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo">
            <img src="images/epms_logo.png" alt="EPMS Logo"> <!-- Use your actual logo file -->
        </div>
        <button class="nav-toggle" id="navToggle">☰</button>
        <nav class="nav-links" id="navLinks">
            <a href="index.php">Home</a>
            <a href="about.html">About</a>
            <a href="#features">Features</a>
            <a href="#support">Support</a>
        </nav>
        <div class="login-buttons">
            <!-- These should ideally point to a single login page: auth/login.php -->
            <button class="login-btn employee-btn" onclick="location.href='auth/login.php?role=employee';">
                Employee Login
            </button>
            <button class="login-btn admin-btn" onclick="location.href='auth/login.php?role=admin';">Admin Login</button>
        </div>
    </header>

    <!-- Main Banner -->
    <section class="hero">
        <img src="images/epms_logo.png" alt="EPMS Logo" class="hero-logo"> <!-- Use your actual logo file -->
        <h1>Employment Payment Management System</h1> <!-- Removed inline style -->
        <p>Streamline your payroll processing, manage employee compensation, and ensure timely payments with our comprehensive EPMS solution.</p> <!-- Removed inline style -->
        <a href="about.html" class="cta-button">Learn More</a>
    </section>

    <section id="features" class="features">
        <div class="container">
            <h2 class="section-title">Key Features</h2>
            <div class="features-grid">
                <?php foreach($features as $feature): ?>
                <div class="feature-card">
                    <div class="feature-icon"><?php echo htmlspecialchars($feature['icon']); ?></div>
                    <h3><?php echo htmlspecialchars($feature['title']); ?></h3>
                    <p><?php echo htmlspecialchars($feature['description']); ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

   <!-- Contact Section -->
    <section id="support" class="contact-section">
        <div class="container">
            <div class="contact-wrapper">
                <div class="assistance-header">
                    <h2>Need Assistance?</h2>
                    <p>We're here to help! Reach out to us through the following channels:</p>
                </div>
                
                <div class="contact-info">
                    <h3>Contact Us</h3>
                    <div class="contact-details">
                        <!-- ... your contact items ... -->
                    </div>
                </div>
                
                <?php if(!empty($message)): ?>
                    <div class="message <?php echo (strpos($message, "Error") !== false || strpos($message, "error") !== false) ? 'error' : ''; ?>">
                        <?php echo htmlspecialchars($message); ?>
                    </div>
                <?php endif; ?>
                
                <div class="contact-form">
                    <h3>Send us a message</h3>
                    <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>#support">
                        <input type="hidden" name="contact_form" value="1">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" id="name" name="name" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="message_content">Message</label> <!-- Changed name to avoid conflict if 'message' var is used for status -->
                            <textarea id="message_content" name="message" rows="4" required></textarea>
                        </div>
                        <button type="submit" class="submit-btn">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer"> <!-- Added class -->
        <div class="footer-content">
            <div class="footer-logo">
                <img src="images/epms_logo.png" alt="EPMS Logo"> <!-- Use your actual logo file -->
                <p>Employment Payment Management System</p>
            </div>
            <div class="footer-links">
                <h4>Quick Links</h4>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="#features">Features</a></li>
                    <li><a href="#support">Support</a></li>
                    <li><a href="privacy.php">Privacy Policy</a></li>
                </ul>
            </div>
            <div class="footer-contact">
                <h4>Contact Us</h4>
                <p>Email: joromaraog@my.cspc.edu.ph</p>
                <p>Phone: 09108038359</p>
            </div>
        </div>
        <div class="copyright">
            <p>© <?php echo date("Y"); ?> Employment Payment Management System. All Rights Reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script> <!-- Corrected path -->
</body>
</html>