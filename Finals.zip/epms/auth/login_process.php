<?php
require_once '../config/db.php';
require_once '../config/functions.php'; // For sanitize_input

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = sanitize_input($_POST['username'], $conn);
    $password = $_POST['password']; // Don't sanitize password before verification

    $stmt = $conn->prepare("SELECT id, username, password, role, employee_id FROM users WHERE username = ?");
    if (!$stmt) {
        header("Location: login.php?error=Database error: " . $conn->error);
        exit();
    }
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            // Password is correct, start session
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_role'] = $user['role'];
            if ($user['role'] === 'employee') {
                $_SESSION['employee_id'] = $user['employee_id'];
            }

            if ($user['role'] === 'admin') {
                header("Location: ../admin/dashboard.php");
            } elseif ($user['role'] === 'employee') {
                header("Location: ../employee/dashboard.php");
            } else {
                header("Location: login.php?error=Unknown user role.");
            }
            exit();
        } else {
            header("Location: login.php?error=Invalid username or password.");
            exit();
        }
    } else {
        header("Location: login.php?error=Invalid username or password.");
        exit();
    }
    $stmt->close();
} else {
    header("Location: login.php");
    exit();
}
$conn->close();
?>