CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL, -- Store hashed passwords!
    role ENUM('admin', 'employee') NOT NULL,
    employee_id INT NULL, -- Link to employees table if role is 'employee'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE employees (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_code VARCHAR(20) NOT NULL UNIQUE, -- For QR code identification
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    address TEXT,
    date_hired DATE,
    position VARCHAR(100),
    department VARCHAR(100),
    basic_salary DECIMAL(10, 2) DEFAULT 0.00,
    -- Government Benefits Numbers
    sss_no VARCHAR(50),
    philhealth_no VARCHAR(50),
    pagibig_no VARCHAR(50),
    tin_no VARCHAR(50),
    -- Payroll specific
    mode_of_payment VARCHAR(50) DEFAULT 'Bank Transfer', -- e.g., Bank Transfer, Check, Cash
    bank_account_no VARCHAR(50),
    status ENUM('active', 'deleted', 'resigned') DEFAULT 'active',
    qr_code_path VARCHAR(255) NULL, -- Path to the generated QR image
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE attendance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    time_in DATETIME,
    time_out DATETIME,
    date_recorded DATE NOT NULL,
    status ENUM('present', 'absent', 'late') DEFAULT 'present', -- Could be more complex
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE TABLE payroll (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    pay_period_start DATE NOT NULL,
    pay_period_end DATE NOT NULL,
    basic_pay DECIMAL(10, 2) NOT NULL,
    allowances DECIMAL(10, 2) DEFAULT 0.00,
    sss_contribution DECIMAL(10, 2) DEFAULT 0.00,
    philhealth_contribution DECIMAL(10, 2) DEFAULT 0.00,
    pagibig_contribution DECIMAL(10, 2) DEFAULT 0.00,
    withholding_tax DECIMAL(10, 2) DEFAULT 0.00,
    other_deductions DECIMAL(10, 2) DEFAULT 0.00,
    net_pay DECIMAL(10, 2) NOT NULL,
    date_generated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

CREATE TABLE employee_requests (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL,
    request_type VARCHAR(100) NOT NULL, -- e.g., 'Profile Update', 'Leave Request'
    details TEXT,
    status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    responded_at TIMESTAMP NULL,
    admin_remarks TEXT,
    FOREIGN KEY (employee_id) REFERENCES employees(id) ON DELETE CASCADE
);

-- Add a default admin user (change password in a real scenario)
-- HASH YOUR PASSWORDS! This is plain text for example only.
-- Use password_hash('admin123', PASSWORD_DEFAULT) in PHP to generate a hash
INSERT INTO users (username, password, role) VALUES ('admin', '$2y$10$YOUR_STRONG_PASSWORD_HASH_HERE', 'admin');
-- Example employee user (linked to employee_id once an employee is created)
-- INSERT INTO users (username, password, role, employee_id) VALUES ('emp001', '$2y$10$HASHED_PASSWORD', 'employee', 1);

-- Your landing page tables
CREATE TABLE contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    submission_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE page_visits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip_address VARCHAR(45),
    user_agent TEXT,
    page VARCHAR(255),
    visit_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);