<header class="header">
    <div class="logo">
        <img src="../images/epms(logo).jpg" alt="EPMS Logo">
        <span>EPMS Admin</span>
    </div>
    <button class="nav-toggle" id="navToggle">☰</button>
    <nav class="nav-links" id="navLinks">
        <a href="dashboard.php">Dashboard</a>
        <a href="manage_employee.php">Employees</a>
        <a href="manage_payroll.php">Payroll</a>
        <a href="manage_requests.php">Requests</a>
        <a href="generate_qr.php">QR Codes</a>
        <!-- Add more links as needed -->
    </nav>
    <div class="user-actions">
        <span>Hi, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
        <a href="../auth/logout.php" class="btn">Logout</a>
    </div>
</header>