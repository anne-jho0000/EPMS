<footer class="footer" >
    <p>© <?php echo date("Y"); ?> EPMS - Admin Panel. All Rights Reserved.</p>
</footer>