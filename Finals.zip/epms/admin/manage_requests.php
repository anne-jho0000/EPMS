<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('admin');
$page_title = "Manage Employee Requests - EPMS Admin";

// Fetch pending requests (you can add filters for approved/rejected later)
$filter_status = isset($_GET['status']) ? sanitize_input($_GET['status'], $conn) : 'pending';

$sql = "SELECT er.*, e.first_name, e.last_name, e.employee_code 
        FROM employee_requests er
        JOIN employees e ON er.employee_id = e.id";

$conditions = []; // To build WHERE clause if needed for more complex filters in future
$params = [];
$types = "";

if ($filter_status !== 'all') {
    $sql .= " WHERE er.status = ?";
    $params[] = $filter_status;
    $types .= "s";
}
$sql .= " ORDER BY er.requested_at DESC"; // Order by most recent requests

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$requests = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get message from session if redirected from an action
$message = '';
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Clear the message after displaying
}
// Get error message from session
$error_message = '';
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clear the error message
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body> <?php /* Body will be styled by style.css for flexbox */ ?>
    <?php include_once '_admin_header.php'; ?>

    <div class="main-content-wrapper"> <?php /* <<< ADDED THIS WRAPPER */ ?>
        <div class="main-content">
            <div class="container">
                <h1>Manage Employee Requests</h1>

                <?php if (!empty($message)): ?>
                    <div class="message success"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
                <?php endif; ?>

                <form method="GET" action="manage_requests.php" class="form-container" style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom:20px;">
                     <fieldset>
                        <legend>Filter Requests</legend>
                        <div class="form-group" style="display: inline-block; margin-right: 10px;">
                            <label for="status_filter">Filter by status:</label>
                            <select name="status" id="status_filter">
                                <option value="pending" <?php if ($filter_status == 'pending') echo 'selected'; ?>>Pending</option>
                                <option value="approved" <?php if ($filter_status == 'approved') echo 'selected'; ?>>Approved</option>
                                <option value="rejected" <?php if ($filter_status == 'rejected') echo 'selected'; ?>>Rejected</option>
                                <option value="all" <?php if ($filter_status == 'all') echo 'selected'; ?>>All</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="manage_requests.php" class="btn btn-secondary">Clear Filter</a> <?php /* Link to clear to default (pending) */ ?>
                    </fieldset>
                </form>


                <?php if (count($requests) > 0): ?>
                <div style="overflow-x: auto;"> <?php /* Wrapper for responsive table */ ?>
                <table>
                    <thead>
                        <tr>
                            <th>Req. ID</th>
                            <th>Employee</th>
                            <th>Type</th>
                            <th>Details</th>
                            <th>Requested At</th>
                            <th>Status</th>
                            <th>Admin Remarks / Responded At</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests as $req): ?>
                        <tr>
                            <td><?php echo $req['id']; ?></td>
                            <td><?php echo htmlspecialchars($req['first_name'] . ' ' . $req['last_name'] . ' (' . $req['employee_code'] . ')'); ?></td>
                            <td><?php echo htmlspecialchars($req['request_type']); ?></td>
                            <td>
                                <?php
                                if ($req['request_type'] == 'Profile Update') {
                                    $details_array = json_decode($req['details'], true);
                                    echo "<ul style='margin:0; padding-left: 15px;'>"; // Use a list for better readability
                                    if (is_array($details_array)) {
                                        foreach ($details_array as $field => $value) {
                                            echo "<li><strong>" . ucfirst(str_replace('_', ' ', $field)) . ":</strong> " . htmlspecialchars($value) . "</li>";
                                        }
                                    } else {
                                        echo "<li>" . htmlspecialchars($req['details']) . "</li>";
                                    }
                                    echo "</ul>";
                                    // Display original admin_remarks (reason provided by employee for update) separately if it exists
                                    if(!empty($req['admin_remarks']) && $req['status'] == 'pending' && isset($details_array['request_reason_by_employee_for_admin_review'])){ // A bit clunky, better to have a separate field
                                       // This part is tricky: 'admin_remarks' in the DB is for the admin's response.
                                       // The 'request_reason' from employee profile update form was intended for admin_remarks in employee_requests table.
                                       // Let's assume for now the 'admin_remarks' on a PENDING request is the employee's reason.
                                       // It gets overwritten when admin responds.
                                       // A better schema would have separate fields: employee_reason, admin_response_remarks.
                                       // For now, we'll show the employee's original reason if it's pending.
                                       echo "<p style='margin-top:5px;'><em>Employee Reason: " . htmlspecialchars($req['admin_remarks']) . "</em></p>";
                                    }

                                } else { // For other request types
                                    echo nl2br(htmlspecialchars($req['details']));
                                }
                                ?>
                            </td>
                            <td><?php echo date('M d, Y H:i', strtotime($req['requested_at'])); ?></td>
                            <td><span class="status-badge status-<?php echo strtolower(htmlspecialchars($req['status'])); ?>"><?php echo ucfirst(htmlspecialchars($req['status'])); ?></span></td>
                            <td>
                                <?php 
                                if ($req['responded_at']) {
                                    echo nl2br(htmlspecialchars($req['admin_remarks']));
                                    echo '<br><small>(Responded: '.date('M d, Y H:i', strtotime($req['responded_at'])).')</small>';
                                } else if ($req['status'] != 'pending' && !empty($req['admin_remarks'])) {
                                     echo nl2br(htmlspecialchars($req['admin_remarks'])); // Show admin remarks if responded but no responded_at (should not happen)
                                } else if ($req['status'] == 'pending' && !empty($req['admin_remarks'])) {
                                    // This case is if the initial 'admin_remarks' was the employee's reason, already shown above.
                                    // If you want to be sure, you'd need to differentiate.
                                    // echo "<i>Employee reason available</i>"; 
                                } else {
                                    echo "N/A";
                                }
                                ?>
                            </td>
                            <td>
                                <?php if ($req['status'] == 'pending'): ?>
                                <form action="request_action.php" method="POST" style="display:inline-block; margin-bottom: 5px; width: 200px;">
                                    <input type="hidden" name="request_id" value="<?php echo $req['id']; ?>">
                                    <div class="form-group" style="margin-bottom:5px;">
                                        <textarea name="admin_remarks" placeholder="Remarks (optional)" rows="2" style="width:100%;"></textarea>
                                    </div>
                                    <button type="submit" name="action" value="approve" class="btn btn-success btn-sm" style="margin-right:5px;">Approve</button>
                                    <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm">Reject</button>
                                </form>
                                <?php else: ?>
                                    <small>Processed</small>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <?php else: ?>
                <p>No <?php echo htmlspecialchars($filter_status); ?> requests found.</p>
                <?php endif; ?>
            </div>
        </div>
    </div> <?php /* <<< END OF WRAPPER */ ?>

    <?php include_once '_admin_footer.php'; ?>
    <script src="../js/script.js"></script>
    <style>
        /* Optional: Add some styling for status badges for better visual indication */
        .status-badge {
            padding: 3px 8px;
            border-radius: 10px;
            font-size: 0.85em;
            color: #fff;
            text-transform: capitalize;
        }
        .status-pending { background-color: #ffc107; color: #333; } /* Yellow */
        .status-approved { background-color: #28a745; } /* Green */
        .status-rejected { background-color: #dc3545; } /* Red */
    </style>
</body>
</html>