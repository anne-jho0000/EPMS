<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('admin'); // Restrict access to admin

$page_title = "Admin Dashboard - EPMS";

// Fetch some stats (example)
$result_employees = $conn->query("SELECT COUNT(*) as total_employees FROM employees WHERE status = 'active'");
$total_employees = $result_employees->fetch_assoc()['total_employees'];

$result_requests = $conn->query("SELECT COUNT(*) as pending_requests FROM employee_requests WHERE status = 'pending'");
$pending_requests = $result_requests->fetch_assoc()['pending_requests'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <?php /* CSS for sticky footer is in style.css, no extra <style> needed here */ ?>
</head>
<body> <?php /* The <body> tag will have display:flex and other properties from style.css */ ?>
    <?php include_once '_admin_header.php'; // Shared admin header ?>

    <div class="main-content-wrapper"> <?php /* <<< ADDED THIS WRAPPER */ ?>
        <div class="main-content">
            <div class="container">
                <h1>Admin Dashboard</h1>
                <p>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?>!</p>

                <div class="dashboard-stats" style="display:flex; gap: 20px; margin-bottom: 20px;">
                    <div style="border:1px solid #ddd; padding:20px; border-radius:5px; background-color:#f9f9f9; flex:1;">
                        <h3>Active Employees</h3>
                        <p style="font-size:2em; color: #FFD700;"><?php echo $total_employees; ?></p>
                    </div>
                    <div style="border:1px solid #ddd; padding:20px; border-radius:5px; background-color:#f9f9f9; flex:1;">
                        <h3>Pending Requests</h3>
                        <p style="font-size:2em; color: #FFD700;"><?php echo $pending_requests; ?></p>
                    </div>
                </div>

                <h2>Quick Actions</h2>
                <ul>
                    <?php /* Corrected filename from manage_employee.php to manage_employees.php */ ?>
                    <li><a href="manage_employee.php" class="btn btn-primary">Manage Employees</a></li>
                    <li><a href="manage_payroll.php" class="btn btn-primary">Manage Payroll</a></li>
                    <li><a href="manage_requests.php" class="btn btn-primary">View Employee Requests</a></li>
                    <li><a href="generate_qr.php" class="btn btn-primary">Generate Employee QR Codes</a></li>
                    <li><a href="settings.php" class="btn btn-primary">System Settings</a></li> <?php /* Added link to settings */ ?>
                </ul>
            </div>
        </div>
    </div> <?php /* <<< END OF WRAPPER */ ?>

    <?php include_once '_admin_footer.php'; // Shared admin footer ?>
    <script src="../js/script.js"></script>
</body>
</html>