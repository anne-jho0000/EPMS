<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_once '../config/functions.php';
require_login('admin');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action == 'add_employee' || $action == 'edit_employee') {
        // Sanitize and retrieve all form data
        $employee_code   = sanitize_input($_POST['employee_code'], $conn);
        $first_name      = sanitize_input($_POST['first_name'], $conn);
        $last_name       = sanitize_input($_POST['last_name'], $conn);
        $email           = sanitize_input($_POST['email'], $conn);
        $phone           = sanitize_input($_POST['phone'], $conn);
        $address         = sanitize_input($_POST['address'], $conn);
        $date_hired      = !empty($_POST['date_hired']) ? sanitize_input($_POST['date_hired'], $conn) : NULL;
        $position        = sanitize_input($_POST['position'], $conn);
        $department      = sanitize_input($_POST['department'], $conn);
        $basic_salary    = filter_var($_POST['basic_salary'], FILTER_VALIDATE_FLOAT);
        $sss_no          = sanitize_input($_POST['sss_no'], $conn);
        $philhealth_no   = sanitize_input($_POST['philhealth_no'], $conn);
        $pagibig_no      = sanitize_input($_POST['pagibig_no'], $conn);
        $tin_no          = sanitize_input($_POST['tin_no'], $conn);
        $mode_of_payment = sanitize_input($_POST['mode_of_payment'], $conn);
        $bank_account_no = sanitize_input($_POST['bank_account_no'], $conn);
        $status          = sanitize_input($_POST['status'], $conn);

        if ($basic_salary === false || $basic_salary < 0) {
            $_SESSION['error_message'] = "Invalid Basic Salary.";
            header("Location: employee_form.php" . ($action == 'edit_employee' ? "?id=" . $_POST['employee_id'] : ""));
            exit();
        }

        if ($action == 'add_employee') {
            // Check for unique employee_code and email
            $stmt_check = $conn->prepare("SELECT id FROM employees WHERE employee_code = ? OR (email = ? AND email != '')");
            $stmt_check->bind_param("ss", $employee_code, $email);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            if ($result_check->num_rows > 0) {
                $_SESSION['error_message'] = "Employee Code or Email already exists.";
                header("Location: employee_form.php");
                exit();
            }
            $stmt_check->close();

            $sql = "INSERT INTO employees (employee_code, first_name, last_name, email, phone, address, date_hired, position, department, basic_salary, sss_no, philhealth_no, pagibig_no, tin_no, mode_of_payment, bank_account_no, status) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssssssssdsssssss", 
                $employee_code, $first_name, $last_name, $email, $phone, $address, $date_hired, 
                $position, $department, $basic_salary, $sss_no, $philhealth_no, $pagibig_no, 
                $tin_no, $mode_of_payment, $bank_account_no, $status
            );

            if ($stmt->execute()) {
                $new_employee_id = $stmt->insert_id;
                // Create user account
                $username = $employee_code; // Use employee_code as username
                $default_password_plain = $employee_code . "123"; // Example: EMP001123
                $default_password_hashed = password_hash($default_password_plain, PASSWORD_DEFAULT);

                $stmt_user = $conn->prepare("INSERT INTO users (username, password, role, employee_id) VALUES (?, ?, 'employee', ?)");
                $stmt_user->bind_param("ssi", $username, $default_password_hashed, $new_employee_id);
                if ($stmt_user->execute()) {
                    $_SESSION['message'] = "Employee added successfully. User account created with username '$username' and default password '$default_password_plain'.";
                } else {
                     $_SESSION['message'] = "Employee added successfully, but failed to create user account: " . $stmt_user->error;
                }
                $stmt_user->close();
                header("Location: manage_employee.php");
            } else {
                $_SESSION['error_message'] = "Error adding employee: " . $stmt->error;
                header("Location: employee_form.php");
            }
            $stmt->close();

        } elseif ($action == 'edit_employee') {
            $employee_id = intval($_POST['employee_id']);
            if ($employee_id <= 0) {
                $_SESSION['error_message'] = "Invalid Employee ID.";
                header("Location: manage_employee.php");
                exit();
            }

            // Check for unique email (if changed)
            $stmt_check_email = $conn->prepare("SELECT id FROM employees WHERE email = ? AND email != '' AND id != ?");
            $stmt_check_email->bind_param("si", $email, $employee_id);
            $stmt_check_email->execute();
            if ($stmt_check_email->get_result()->num_rows > 0) {
                 $_SESSION['error_message'] = "Email already in use by another employee.";
                 header("Location: employee_form.php?id=" . $employee_id);
                 exit();
            }
            $stmt_check_email->close();


            $sql = "UPDATE employees SET first_name=?, last_name=?, email=?, phone=?, address=?, date_hired=?, 
                    position=?, department=?, basic_salary=?, sss_no=?, philhealth_no=?, pagibig_no=?, 
                    tin_no=?, mode_of_payment=?, bank_account_no=?, status=? WHERE id=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssdsssssssi", 
                $first_name, $last_name, $email, $phone, $address, $date_hired, $position, 
                $department, $basic_salary, $sss_no, $philhealth_no, $pagibig_no, $tin_no, 
                $mode_of_payment, $bank_account_no, $status, $employee_id
            );

            if ($stmt->execute()) {
                $_SESSION['message'] = "Employee details updated successfully.";
                // If status changed from active, consider user account status (not implemented here)
                header("Location: manage_employee.php");
            } else {
                $_SESSION['error_message'] = "Error updating employee: " . $stmt->error;
                header("Location: employee_form.php?id=" . $employee_id);
            }
            $stmt->close();
        }

    } elseif ($action == 'delete') {
        $employee_id = intval($_POST['employee_id']);
        if ($employee_id > 0) {
            // Soft delete: update status to 'deleted'
            $stmt = $conn->prepare("UPDATE employees SET status = 'deleted' WHERE id = ?");
            $stmt->bind_param("i", $employee_id);
            if ($stmt->execute()) {
                 // Optionally, disable the associated user account in 'users' table
                $stmt_user_disable = $conn->prepare("UPDATE users SET role = 'employee_disabled' WHERE employee_id = ? AND role = 'employee'"); // Example of disabling
                // $stmt_user_disable->bind_param("i", $employee_id);
                // $stmt_user_disable->execute();
                // $stmt_user_disable->close();
                $_SESSION['message'] = "Employee marked as deleted.";
            } else {
                $_SESSION['error_message'] = "Error deleting employee: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $_SESSION['error_message'] = "Invalid Employee ID for deletion.";
        }
        header("Location: manage_employee.php");
        exit();

    } elseif ($action == 'restore') {
        $employee_id = intval($_POST['employee_id']);
        if ($employee_id > 0) {
            $stmt = $conn->prepare("UPDATE employees SET status = 'active' WHERE id = ?");
            $stmt->bind_param("i", $employee_id);
            if ($stmt->execute()) {
                // Optionally, re-enable the associated user account
                // $stmt_user_enable = $conn->prepare("UPDATE users SET role = 'employee' WHERE employee_id = ? AND role = 'employee_disabled'");
                // $stmt_user_enable->bind_param("i", $employee_id);
                // $stmt_user_enable->execute();
                // $stmt_user_enable->close();
                $_SESSION['message'] = "Employee restored successfully.";
            } else {
                $_SESSION['error_message'] = "Error restoring employee: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $_SESSION['error_message'] = "Invalid Employee ID for restoration.";
        }
        header("Location: manage_employee.php?status=deleted"); // Redirect back to deleted list
        exit();
    } else {
        $_SESSION['error_message'] = "Invalid action.";
        header("Location: manage_employee.php");
        exit();
    }
} else {
    header("Location: manage_employee.php");
    exit();
}
$conn->close();
?>