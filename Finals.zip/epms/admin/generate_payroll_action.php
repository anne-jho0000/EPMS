<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_once '../config/functions.php';
require_login('admin');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['pay_period_start'], $_POST['pay_period_end'])) {
    $pay_period_start = sanitize_input($_POST['pay_period_start'], $conn);
    $pay_period_end = sanitize_input($_POST['pay_period_end'], $conn);
    $selected_employee_ids = isset($_POST['employee_ids']) ? $_POST['employee_ids'] : [];

    if (empty($selected_employee_ids)) {
        $_SESSION['error_message'] = "No employees selected for payroll generation.";
        header("Location: manage_payroll.php");
        exit();
    }
    if (strtotime($pay_period_end) < strtotime($pay_period_start)) {
        $_SESSION['error_message'] = "Pay period end date cannot be before start date.";
        header("Location: manage_payroll.php");
        exit();
    }

    $success_count = 0;
    $error_count = 0;
    $error_details = [];

    foreach ($selected_employee_ids as $employee_id) {
        $employee_id = intval($employee_id);

        // Check if payroll for this employee and period already exists
        $stmt_check = $conn->prepare("SELECT id FROM payroll WHERE employee_id = ? AND pay_period_start = ? AND pay_period_end = ?");
        $stmt_check->bind_param("iss", $employee_id, $pay_period_start, $pay_period_end);
        $stmt_check->execute();
        if ($stmt_check->get_result()->num_rows > 0) {
            $error_count++;
            $error_details[] = "Payroll for employee ID $employee_id for period $pay_period_start to $pay_period_end already exists.";
            $stmt_check->close();
            continue; // Skip this employee
        }
        $stmt_check->close();


        $stmt_emp = $conn->prepare("SELECT basic_salary, first_name, last_name FROM employees WHERE id = ? AND status = 'active'");
        $stmt_emp->bind_param("i", $employee_id);
        $stmt_emp->execute();
        $result_emp = $stmt_emp->get_result();
        $employee_data = $result_emp->fetch_assoc();
        $stmt_emp->close();

        if ($employee_data) {
            $basic_pay = floatval($employee_data['basic_salary']);
            
            // --- Placeholder Payroll Calculations ---
            // These are VERY simplified. Replace with actual country-specific logic.
            $allowances = 0.00; // Example: Add logic for allowances if any

            // SSS: Example 4.5% of basic salary (employee share)
            $sss_contribution = $basic_pay * 0.045;

            // PhilHealth: Example 2% of basic salary (employee share, capped)
            $philhealth_contribution = min($basic_pay * 0.02, 1600); // Max contribution example

            // Pag-IBIG: Example fixed 100 PHP
            $pagibig_contribution = 100.00;
            
            $taxable_income = $basic_pay - $sss_contribution - $philhealth_contribution - $pagibig_contribution;
            
            // Withholding Tax: Example very simple progressive tax
            $withholding_tax = 0.00;
            if ($taxable_income > 20833) { // Above ~250k/year non-taxable
                 if ($taxable_income <= 33333) $withholding_tax = ($taxable_income - 20833) * 0.15; // 15% on excess of 20833
                 else if ($taxable_income <= 66667) $withholding_tax = 1875 + (($taxable_income - 33333) * 0.20); // 1875 + 20% on excess of 33333
                 // ... and so on. This needs proper tax tables.
            }


            $other_deductions = 0.00; // Example: loans, etc.
            // --- End Placeholder Payroll Calculations ---

            $total_deductions = $sss_contribution + $philhealth_contribution + $pagibig_contribution + $withholding_tax + $other_deductions;
            $net_pay = $basic_pay + $allowances - $total_deductions;

            $stmt_insert = $conn->prepare("INSERT INTO payroll (employee_id, pay_period_start, pay_period_end, basic_pay, allowances, sss_contribution, philhealth_contribution, pagibig_contribution, withholding_tax, other_deductions, net_pay, date_generated) 
                                           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            $stmt_insert->bind_param("issdddddddd", 
                $employee_id, $pay_period_start, $pay_period_end, $basic_pay, $allowances, 
                $sss_contribution, $philhealth_contribution, $pagibig_contribution, 
                $withholding_tax, $other_deductions, $net_pay
            );

            if ($stmt_insert->execute()) {
                $success_count++;
            } else {
                $error_count++;
                $error_details[] = "Error for employee " . $employee_data['first_name'] . " " . $employee_data['last_name'] . ": " . $stmt_insert->error;
            }
            $stmt_insert->close();

        } else {
            $error_count++;
            $error_details[] = "Could not find active employee data for ID: $employee_id";
        }
    }

    $final_message = "$success_count payroll records generated successfully.";
    if ($error_count > 0) {
        $_SESSION['error_message'] = "$error_count errors occurred. " . implode("<br>", $error_details);
    }
    $_SESSION['message'] = $final_message;

} else {
    $_SESSION['error_message'] = "Invalid request to generate payroll.";
}

header("Location: manage_payroll.php");
exit();
?>