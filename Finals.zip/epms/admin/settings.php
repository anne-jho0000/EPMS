<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('admin'); // Restrict access to admin

$page_title = "System Settings - EPMS Admin";

// In the future, you might fetch existing settings from a 'settings' table
// For example:
// $stmt = $conn->query("SELECT * FROM system_settings WHERE setting_key LIKE 'salary_component_%'");
// $salary_components = $stmt->fetch_all(MYSQLI_ASSOC);

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$error_message = isset($_SESSION['error_message']) ? $_SESSION['error_message'] : '';
unset($_SESSION['message']);
unset($_SESSION['error_message']);

// Handle form submission if settings are being updated (future implementation)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'update_settings') {
        // Process and save settings
        // Example:
        // foreach ($_POST['salary_components'] as $key => $value) {
        //    $clean_key = sanitize_input($key, $conn);
        //    $clean_value = sanitize_input($value, $conn);
        //    // UPDATE or INSERT into system_settings table
        // }
        $_SESSION['message'] = "Settings (would be) updated successfully!"; // Placeholder
        header("Location: settings.php");
        exit();
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include_once '_admin_header.php'; // Shared admin header ?>

    <div class="main-content">
        <div class="container">
            <h1>System Settings</h1>

            <?php if ($message): ?>
                <div class="message success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            <?php if ($error_message): ?>
                <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <p>This page is intended for future system configurations such as managing default salary components, tax table versions, deduction types, and other global settings for the EPMS.</p>
            
            <form action="settings.php" method="POST" class="form-container">
                 <input type="hidden" name="action" value="update_settings">

                <fieldset>
                    <legend>Salary Components (Example - Future Feature)</legend>
                    <p><em>Here, you would list existing salary components and allow adding/editing them. For example: Basic Pay (fixed), Housing Allowance, Transport Allowance, etc. These could then be assigned to employees or used in payroll calculations.</em></p>
                    
                    <!-- Example structure for a future setting -->
                    <div class="form-group">
                        <label for="default_currency">Default Currency Symbol:</label>
                        <input type="text" id="default_currency" name="settings[default_currency]" value="PHP" placeholder="e.g., $, €, PHP"> 
                        <!-- In a real scenario, this value would be loaded from the database -->
                    </div>
                     <div class="form-group">
                        <label for="tax_year">Current Tax Year:</label>
                        <input type="number" id="tax_year" name="settings[tax_year]" value="<?php echo date('Y'); ?>" placeholder="e.g., <?php echo date('Y'); ?>">
                    </div>
                </fieldset>
                
                <fieldset>
                    <legend>Contribution Rates (Example - Future Feature)</legend>
                    <p><em>Define default percentage or fixed amounts for SSS, PhilHealth, Pag-IBIG. These might have brackets or be updated annually.</em></p>
                     <div class="form-group">
                        <label for="sss_employee_share_percentage">SSS Employee Share (%):</label>
                        <input type="number" step="0.01" id="sss_employee_share_percentage" name="settings[sss_employee_share_percentage]" value="4.5" placeholder="e.g., 4.5">
                    </div>
                </fieldset>

                <button type="submit" class="btn btn-primary" disabled>Save Settings (Future)</button>
                <small><em>Note: Save functionality is not yet implemented.</em></small>
            </form>

        </div>
    </div>

    <?php include_once '_admin_footer.php'; // Shared admin footer ?>
    <script src="../js/script.js"></script>
</body>
</html>