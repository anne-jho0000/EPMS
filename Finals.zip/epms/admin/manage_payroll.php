<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('admin');
$page_title = "Manage Payroll - EPMS Admin";

// Fetch active employees for selection
$stmt_emp = $conn->query("SELECT id, employee_code, first_name, last_name FROM employees WHERE status = 'active' ORDER BY last_name, first_name");
$employees = $stmt_emp->fetch_all(MYSQLI_ASSOC);

// Get message from session if redirected from an action
$message = '';
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Clear the message after displaying
}
// Get error message from session
$error_message = '';
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clear the error message
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body> <?php /* Body will be styled by style.css for flexbox */ ?>
    <?php include_once '_admin_header.php'; ?>

    <div class="main-content-wrapper"> <?php /* <<< ADDED THIS WRAPPER */ ?>
        <div class="main-content"> <?php /* Removed .form-container from here, applied to form directly */ ?>
            <div class="container">
                <h1>Generate Payroll</h1>

                <?php if (!empty($message)): ?>
                    <div class="message success"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
                <?php endif; ?>

                <p>Select the pay period and employees for whom you want to generate payroll.</p>

                <form action="generate_payroll_action.php" method="POST" class="form-container"> <?php /* Added .form-container class to the form */ ?>
                    <fieldset>
                        <legend>Pay Period</legend>
                        <div class="form-group">
                            <label for="pay_period_start">Pay Period Start Date:</label>
                            <input type="date" id="pay_period_start" name="pay_period_start" required>
                        </div>
                        <div class="form-group">
                            <label for="pay_period_end">Pay Period End Date:</label>
                            <input type="date" id="pay_period_end" name="pay_period_end" required>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Select Employees</legend>
                        <div class="form-group">
                            <label><input type="checkbox" id="select_all_employees"> Select All Active Employees</label>
                        </div>
                        <?php if (count($employees) > 0): ?>
                            <div class="employee-list-scrollable" style="max-height: 300px; overflow-y: auto; border: 1px solid #eee; padding: 10px; margin-bottom: 15px;">
                                <?php foreach ($employees as $emp): ?>
                                <div class="form-group">
                                    <label>
                                        <input type="checkbox" name="employee_ids[]" value="<?php echo $emp['id']; ?>" class="employee-checkbox">
                                        <?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name'] . ' (' . $emp['employee_code'] . ')'); ?>
                                    </label>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        <?php else: ?>
                            <p>No active employees found.</p>
                        <?php endif; ?>
                    </fieldset>
                    
                    <?php if (count($employees) > 0): ?>
                    <button type="submit" class="btn btn-primary">Generate Payroll</button>
                    <?php endif; ?>
                    <a href="view_payroll_report.php" class="btn btn-secondary">View Payroll Reports</a>
                </form>
            </div>
        </div>
    </div> <?php /* <<< END OF WRAPPER */ ?>

    <?php include_once '_admin_footer.php'; ?>
    <script src="../js/script.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const selectAllCheckbox = document.getElementById('select_all_employees');
            const employeeCheckboxes = document.querySelectorAll('.employee-checkbox');

            if (selectAllCheckbox && employeeCheckboxes.length > 0) { // Check if checkboxes exist
                selectAllCheckbox.addEventListener('change', function() {
                    employeeCheckboxes.forEach(checkbox => {
                        checkbox.checked = this.checked;
                    });
                });
            }
        });
    </script>
</body>
</html>