<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('admin');
require_once '../vendor/autoload.php'; // For QR Code Generator

use chillerlan\QRCode\{QRCode, QROptions};

$page_title = "Generate Employee QR Codes - EPMS Admin";

// Fetch active employees
$stmt = $conn->prepare("SELECT id, employee_code, first_name, last_name FROM employees WHERE status = 'active' ORDER BY employee_code");
$stmt->execute();
$result = $stmt->get_result();
$employees = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$qr_options = new QROptions([
    'outputType' => QRCode::OUTPUT_IMAGE_PNG,
    'eccLevel'   => QRCode::ECC_L,
    'scale'      => 5,
    'imageBase64' => true, // Output as base64 string for easy embedding
]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .qr-grid { display: flex; flex-wrap: wrap; gap: 20px; }
        .qr-item { border: 1px solid #ccc; padding: 15px; text-align: center; border-radius: 5px; background: #fff;}
        .qr-item img { display: block; margin: 0 auto 10px auto; }
    </style>
</head>
<body>
    <?php include_once '_admin_header.php'; ?>

    <div class="main-content">
        <div class="container">
            <h1>Employee QR Codes for Attendance</h1>
            <p>These QR codes contain the employee's unique code for attendance scanning.</p>

            <?php if (count($employees) > 0): ?>
            <div class="qr-grid">
                <?php foreach ($employees as $emp): ?>
                    <?php
                    // Data for QR code is the employee_code
                    $qr_data = $emp['employee_code'];
                    $qrcode_image = (new QRCode($qr_options))->render($qr_data);
                    ?>
                    <div class="qr-item">
                        <img src="<?php echo htmlspecialchars($qrcode_image); ?>" alt="QR Code for <?php echo htmlspecialchars($emp['employee_code']); ?>">
                        <strong><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></strong><br>
                        (<?php echo htmlspecialchars($emp['employee_code']); ?>)
                    </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <p>No active employees found to generate QR codes.</p>
            <?php endif; ?>
        </div>
    </div>

    <?php include_once '_admin_footer.php'; ?>
    <script src="../js/script.js"></script>
</body>
</html>