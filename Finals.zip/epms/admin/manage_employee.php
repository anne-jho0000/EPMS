<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_once '../config/functions.php'; // ***** ADDED THIS LINE *****
require_login('admin');
$page_title = "Manage Employees - EPMS Admin";

// Fetch employees
$search_term = isset($_GET['search']) ? sanitize_input($_GET['search'], $conn) : '';
$filter_status = isset($_GET['status']) ? sanitize_input($_GET['status'], $conn) : 'active'; // Default to active

$sql = "SELECT id, employee_code, first_name, last_name, email, position, department, status FROM employees";
$conditions = [];
$params = [];
$types = "";

if ($search_term) {
    $conditions[] = "(first_name LIKE ? OR last_name LIKE ? OR employee_code LIKE ? OR email LIKE ?)";
    $like_search = "%" . $search_term . "%";
    array_push($params, $like_search, $like_search, $like_search, $like_search);
    $types .= "ssss";
}

if ($filter_status && $filter_status !== 'all') {
    $conditions[] = "status = ?";
    array_push($params, $filter_status);
    $types .= "s";
}

if (!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}
$sql .= " ORDER BY last_name, first_name";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$employees = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get message from session if redirected from an action
$message = '';
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Clear the message after displaying
}
// Get error message from session
$error_message = '';
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clear the error message
}

// If message is passed via GET (e.g., from a non-redirecting action, though less common now)
if (empty($message) && isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body> <?php /* Body will be styled by style.css for flexbox */ ?>
    <?php include_once '_admin_header.php'; ?>

    <div class="main-content-wrapper">
        <div class="main-content">
            <div class="container">
                <h1>Manage Employees</h1>
                <a href="employee_form.php" class="btn btn-success" style="margin-bottom: 20px;">Add New Employee</a>

                <?php if (!empty($message)): ?>
                    <div class="message success"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
                <?php endif; ?>
                
                <form method="GET" action="manage_employee.php" class="form-container" style="background-color: #f9f9f9; padding: 15px; border-radius: 5px; margin-bottom: 20px;">
                    <fieldset>
                        <legend>Filter & Search</legend>
                        <div class="form-group" style="display: inline-block; margin-right: 10px;">
                             <label for="search_box" class="sr-only">Search</label>
                            <input type="text" id="search_box" name="search" placeholder="Search..." value="<?php echo htmlspecialchars($search_term); ?>" style="min-width: 200px;">
                        </div>
                        <div class="form-group" style="display: inline-block; margin-right: 10px;">
                            <label for="status_filter" class="sr-only">Status</label>
                            <select name="status" id="status_filter">
                                <option value="active" <?php if ($filter_status == 'active') echo 'selected'; ?>>Active</option>
                                <option value="deleted" <?php if ($filter_status == 'deleted') echo 'selected'; ?>>Deleted</option>
                                <option value="resigned" <?php if ($filter_status == 'resigned') echo 'selected'; ?>>Resigned</option>
                                <option value="all" <?php if ($filter_status == 'all') echo 'selected'; ?>>All</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">Filter</button>
                        <a href="manage_employee.php" class="btn btn-secondary">Clear</a>
                    </fieldset>
                </form>

                <?php if (count($employees) > 0): ?>
                <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>Emp. Code</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Position</th>
                            <th>Department</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($employees as $emp): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($emp['employee_code']); ?></td>
                            <td><?php echo htmlspecialchars($emp['first_name'] . ' ' . $emp['last_name']); ?></td>
                            <td><?php echo htmlspecialchars($emp['email']); ?></td>
                            <td><?php echo htmlspecialchars($emp['position']); ?></td>
                            <td><?php echo htmlspecialchars($emp['department']); ?></td>
                            <td><?php echo ucfirst(htmlspecialchars($emp['status'])); ?></td>
                            <td>
                                <a href="employee_form.php?id=<?php echo $emp['id']; ?>" class="btn btn-secondary btn-sm">Edit</a>
                                <?php if ($emp['status'] == 'deleted'): ?>
                                    <form action="employee_actions.php" method="POST" style="display:inline;" class="restore-form">
                                        <input type="hidden" name="action" value="restore">
                                        <input type="hidden" name="employee_id" value="<?php echo $emp['id']; ?>">
                                        <button type="submit" class="btn btn-success btn-sm">Restore</button>
                                    </form>
                                <?php else: ?>
                                    <form action="employee_actions.php" method="POST" style="display:inline;" class="delete-form">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="employee_id" value="<?php echo $emp['id']; ?>">
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <?php else: ?>
                <p>No employees found matching your criteria.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include_once '_admin_footer.php'; ?>
    <script src="../js/script.js"></script>
</body>
</html>