<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('admin');
$page_title = "Payroll Report - EPMS Admin";

// Filters
$filter_employee_id = isset($_GET['employee_id']) ? intval($_GET['employee_id']) : 0;
$filter_pay_period_start = isset($_GET['pay_period_start']) ? sanitize_input($_GET['pay_period_start'], $conn) : '';
$filter_pay_period_end = isset($_GET['pay_period_end']) ? sanitize_input($_GET['pay_period_end'], $conn) : '';

$sql = "SELECT p.*, e.first_name, e.last_name, e.employee_code 
        FROM payroll p
        JOIN employees e ON p.employee_id = e.id";

$conditions = [];
$params = [];
$types = "";

if ($filter_employee_id > 0) {
    $conditions[] = "p.employee_id = ?";
    $params[] = $filter_employee_id;
    $types .= "i";
}
if (!empty($filter_pay_period_start)) {
    $conditions[] = "p.pay_period_start >= ?";
    $params[] = $filter_pay_period_start;
    $types .= "s";
}
if (!empty($filter_pay_period_end)) {
    $conditions[] = "p.pay_period_end <= ?";
    $params[] = $filter_pay_period_end;
    $types .= "s";
}

if (!empty($conditions)) {
    $sql .= " WHERE " . implode(" AND ", $conditions);
}
$sql .= " ORDER BY p.date_generated DESC, e.last_name, e.first_name";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();
$payrolls = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Fetch employees for filter dropdown
$stmt_emp_filter = $conn->query("SELECT id, employee_code, first_name, last_name FROM employees WHERE status = 'active' ORDER BY last_name, first_name");
$employees_for_filter = $stmt_emp_filter->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include_once '_admin_header.php'; ?>

    <div class="main-content">
        <div class="container">
            <h1>Payroll Report</h1>
             <a href="manage_payroll.php" class="btn btn-primary" style="margin-bottom: 20px;">Generate New Payroll</a>

            <form method="GET" action="view_payroll_report.php" class="form-container" style="margin-bottom: 20px; background-color: #f9f9f9; padding: 15px; border-radius: 5px;">
                <fieldset>
                    <legend>Filter Report</legend>
                    <div class="form-group">
                        <label for="employee_id">Employee:</label>
                        <select name="employee_id" id="employee_id">
                            <option value="0">All Employees</option>
                            <?php foreach ($employees_for_filter as $emp_filter): ?>
                                <option value="<?php echo $emp_filter['id']; ?>" <?php if ($filter_employee_id == $emp_filter['id']) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($emp_filter['first_name'] . ' ' . $emp_filter['last_name'] . ' (' . $emp_filter['employee_code'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="pay_period_start">Pay Period Start From:</label>
                        <input type="date" id="pay_period_start" name="pay_period_start" value="<?php echo htmlspecialchars($filter_pay_period_start); ?>">
                    </div>
                    <div class="form-group">
                        <label for="pay_period_end">Pay Period End To:</label>
                        <input type="date" id="pay_period_end" name="pay_period_end" value="<?php echo htmlspecialchars($filter_pay_period_end); ?>">
                    </div>
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <a href="view_payroll_report.php" class="btn btn-secondary">Clear Filters</a>
                </fieldset>
            </form>


            <?php if (count($payrolls) > 0): ?>
            <div style="overflow-x:auto;"> <!-- For responsive table -->
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Employee</th>
                        <th>Pay Period</th>
                        <th>Basic Pay</th>
                        <th>Allowances</th>
                        <th>SSS</th>
                        <th>PhilHealth</th>
                        <th>Pag-IBIG</th>
                        <th>Tax</th>
                        <th>Other Deductions</th>
                        <th>Net Pay</th>
                        <th>Generated On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payrolls as $pr): ?>
                    <tr>
                        <td><?php echo $pr['id']; ?></td>
                        <td><?php echo htmlspecialchars($pr['first_name'] . ' ' . $pr['last_name']); ?><br><small>(<?php echo htmlspecialchars($pr['employee_code']); ?>)</small></td>
                        <td><?php echo date('M d, Y', strtotime($pr['pay_period_start'])) . ' - ' . date('M d, Y', strtotime($pr['pay_period_end'])); ?></td>
                        <td><?php echo number_format($pr['basic_pay'], 2); ?></td>
                        <td><?php echo number_format($pr['allowances'], 2); ?></td>
                        <td><?php echo number_format($pr['sss_contribution'], 2); ?></td>
                        <td><?php echo number_format($pr['philhealth_contribution'], 2); ?></td>
                        <td><?php echo number_format($pr['pagibig_contribution'], 2); ?></td>
                        <td><?php echo number_format($pr['withholding_tax'], 2); ?></td>
                        <td><?php echo number_format($pr['other_deductions'], 2); ?></td>
                        <td><strong><?php echo number_format($pr['net_pay'], 2); ?></strong></td>
                        <td><?php echo date('Y-m-d H:i', strtotime($pr['date_generated'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php else: ?>
            <p>No payroll records found matching your criteria.</p>
            <?php endif; ?>
        </div>
    </div>

    <?php include_once '_admin_footer.php'; ?>
    <script src="../js/script.js"></script>
</body>
</html>