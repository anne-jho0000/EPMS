<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_once '../config/functions.php'; // For sanitize_input
require_login('admin');

$page_title = "Employee Form - EPMS Admin";
$employee_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$employee = [
    'employee_code' => '', 'first_name' => '', 'last_name' => '', 'email' => '', 'phone' => '',
    'address' => '', 'date_hired' => '', 'position' => '', 'department' => '',
    'basic_salary' => '', 'sss_no' => '', 'philhealth_no' => '', 'pagibig_no' => '',
    'tin_no' => '', 'mode_of_payment' => 'Bank Transfer', 'bank_account_no' => '', 'status' => 'active'
];
$form_action = 'add_employee';
$submit_button_text = 'Add Employee';

if ($employee_id > 0) {
    $page_title = "Edit Employee - EPMS Admin";
    $form_action = 'edit_employee';
    $submit_button_text = 'Update Employee';

    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->bind_param("i", $employee_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $employee = $result->fetch_assoc();
    } else {
        // Use session for error message on redirect
        $_SESSION['error_message'] = "Employee not found.";
        header("Location: manage_employee.php"); // Corrected link
        exit();
    }
    $stmt->close();
}

// Get message from session if redirected from an action
$message = '';
if (isset($_SESSION['message'])) {
    $message = $_SESSION['message'];
    unset($_SESSION['message']); // Clear the message after displaying
}
// Get error message from session
$error_message = '';
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']); // Clear the error message
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body> <?php /* Body will be styled by style.css for flexbox */ ?>
    <?php include_once '_admin_header.php'; ?>

    <div class="main-content-wrapper"> <?php /* <<< ADDED THIS WRAPPER */ ?>
        <div class="main-content"> <?php /* Removed .form-container, applied to form directly */ ?>
            <div class="container">
                <h1><?php echo ($employee_id > 0) ? 'Edit Employee' : 'Add New Employee'; ?></h1>

                <?php if (!empty($message)): ?>
                    <div class="message success"><?php echo htmlspecialchars($message); ?></div>
                <?php endif; ?>
                <?php if (!empty($error_message)): ?>
                    <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
                <?php endif; ?>

                <form action="employee_actions.php" method="POST" class="form-container"> <?php /* Added .form-container to form */ ?>
                    <input type="hidden" name="action" value="<?php echo $form_action; ?>">
                    <?php if ($employee_id > 0): ?>
                        <input type="hidden" name="employee_id" value="<?php echo $employee_id; ?>">
                    <?php endif; ?>

                    <fieldset>
                        <legend>Personal Information</legend>
                        <div class="form-group">
                            <label for="employee_code">Employee Code (Unique):</label>
                            <input type="text" id="employee_code" name="employee_code" value="<?php echo htmlspecialchars($employee['employee_code']); ?>" required <?php echo ($employee_id > 0) ? 'readonly' : ''; ?>>
                            <?php if ($employee_id == 0): ?>
                                <small>This will also be their initial username for login.</small>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label for="first_name">First Name:</label>
                            <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($employee['first_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="last_name">Last Name:</label>
                            <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($employee['last_name']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email:</label>
                            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($employee['email']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone:</label>
                            <input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($employee['phone']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="address">Address:</label>
                            <textarea id="address" name="address"><?php echo htmlspecialchars($employee['address']); ?></textarea>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Employment Details</legend>
                        <div class="form-group">
                            <label for="date_hired">Date Hired:</label>
                            <input type="date" id="date_hired" name="date_hired" value="<?php echo htmlspecialchars($employee['date_hired']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="position">Position:</label>
                            <input type="text" id="position" name="position" value="<?php echo htmlspecialchars($employee['position']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="department">Department:</label>
                            <input type="text" id="department" name="department" value="<?php echo htmlspecialchars($employee['department']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="status">Status:</label>
                            <select id="status" name="status" required>
                                <option value="active" <?php echo ($employee['status'] == 'active') ? 'selected' : ''; ?>>Active</option>
                                <option value="resigned" <?php echo ($employee['status'] == 'resigned') ? 'selected' : ''; ?>>Resigned</option>
                                <option value="deleted" <?php echo ($employee['status'] == 'deleted') ? 'selected' : ''; ?>>Deleted</option>
                            </select>
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Salary & Payment</legend>
                        <div class="form-group">
                            <label for="basic_salary">Basic Salary (Monthly):</label>
                            <input type="number" step="0.01" id="basic_salary" name="basic_salary" value="<?php echo htmlspecialchars($employee['basic_salary']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="mode_of_payment">Mode of Payment:</label>
                            <select id="mode_of_payment" name="mode_of_payment">
                                <option value="Bank Transfer" <?php echo ($employee['mode_of_payment'] == 'Bank Transfer') ? 'selected' : ''; ?>>Bank Transfer</option>
                                <option value="Check" <?php echo ($employee['mode_of_payment'] == 'Check') ? 'selected' : ''; ?>>Check</option>
                                <option value="Cash" <?php echo ($employee['mode_of_payment'] == 'Cash') ? 'selected' : ''; ?>>Cash</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="bank_account_no">Bank Account No.:</label>
                            <input type="text" id="bank_account_no" name="bank_account_no" value="<?php echo htmlspecialchars($employee['bank_account_no']); ?>">
                        </div>
                    </fieldset>

                    <fieldset>
                        <legend>Government IDs</legend>
                        <div class="form-group">
                            <label for="sss_no">SSS No.:</label>
                            <input type="text" id="sss_no" name="sss_no" value="<?php echo htmlspecialchars($employee['sss_no']); ?>">
                        </div>
                        <div class="form-goup">
                            <label for="philhealth_no">PhilHealth No.:</label>
                            <input type="text" id="philhealth_no" name="philhealth_no" value="<?php echo htmlspecialchars($employee['philhealth_no']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="pagibig_no">Pag-IBIG No.:</label>
                            <input type="text" id="pagibig_no" name="pagibig_no" value="<?php echo htmlspecialchars($employee['pagibig_no']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="tin_no">TIN No.:</label>
                            <input type="text" id="tin_no" name="tin_no" value="<?php echo htmlspecialchars($employee['tin_no']); ?>">
                        </div>
                    </fieldset>

                    <button type="submit" class="btn btn-primary"><?php echo $submit_button_text; ?></button>
                    <a href="manage_employee.php" class="btn btn-secondary">Cancel</a> <?php /* <<< CORRECTED LINK HERE */ ?>
                </form>
            </div>
        </div>
    </div> <?php /* <<< END OF WRAPPER */ ?>

    <?php include_once '_admin_footer.php'; ?>
    <script src="../js/script.js"></script>
</body>
</html>