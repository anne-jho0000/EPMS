<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_once '../config/functions.php';
require_login('admin');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_id'], $_POST['action'])) {
    $request_id = intval($_POST['request_id']);
    $action = $_POST['action']; // 'approve' or 'reject'
    $admin_remarks = isset($_POST['admin_remarks']) ? sanitize_input($_POST['admin_remarks'], $conn) : null;

    if ($request_id <= 0 || !in_array($action, ['approve', 'reject'])) {
        $_SESSION['error_message'] = "Invalid request ID or action.";
        header("Location: manage_requests.php");
        exit();
    }

    // Fetch the request details
    $stmt_req = $conn->prepare("SELECT * FROM employee_requests WHERE id = ? AND status = 'pending'");
    $stmt_req->bind_param("i", $request_id);
    $stmt_req->execute();
    $result_req = $stmt_req->get_result();
    $request_data = $result_req->fetch_assoc();
    $stmt_req->close();

    if (!$request_data) {
        $_SESSION['error_message'] = "Request not found or already processed.";
        header("Location: manage_requests.php");
        exit();
    }

    $conn->begin_transaction(); // Start transaction

    try {
        if ($action == 'approve') {
            if ($request_data['request_type'] == 'Profile Update') {
                $updates = json_decode($request_data['details'], true);
                if (is_array($updates)) {
                    $sql_update_parts = [];
                    $params = [];
                    $types = "";
                    foreach ($updates as $field => $value) {
                        // Whitelist allowed fields to prevent SQL injection via field names
                        $allowed_fields = ['email', 'phone', 'address', 'mode_of_payment', 'bank_account_no'];
                        if (in_array($field, $allowed_fields)) {
                            $sql_update_parts[] = "`" . $field . "` = ?";
                            $params[] = $value;
                            $types .= "s"; // Assuming all are strings for simplicity
                        }
                    }

                    if (!empty($sql_update_parts)) {
                        $sql_update_employee = "UPDATE employees SET " . implode(", ", $sql_update_parts) . " WHERE id = ?";
                        $params[] = $request_data['employee_id'];
                        $types .= "i";

                        $stmt_update_emp = $conn->prepare($sql_update_employee);
                        $stmt_update_emp->bind_param($types, ...$params);
                        if (!$stmt_update_emp->execute()) {
                            throw new Exception("Failed to update employee profile: " . $stmt_update_emp->error);
                        }
                        $stmt_update_emp->close();
                    }
                } else {
                    throw new Exception("Invalid update details format.");
                }
            }
            // Add logic for other request_types if any

            $new_status = 'approved';
        } else { // action == 'reject'
            $new_status = 'rejected';
        }

        // Update the request status
        $stmt_update_req = $conn->prepare("UPDATE employee_requests SET status = ?, responded_at = NOW(), admin_remarks = ? WHERE id = ?");
        $stmt_update_req->bind_param("ssi", $new_status, $admin_remarks, $request_id);
        if (!$stmt_update_req->execute()) {
            throw new Exception("Failed to update request status: " . $stmt_update_req->error);
        }
        $stmt_update_req->close();

        $conn->commit(); // All good, commit transaction
        $_SESSION['message'] = "Request has been " . $new_status . ".";

    } catch (Exception $e) {
        $conn->rollback(); // Something went wrong, rollback
        $_SESSION['error_message'] = "Error processing request: " . $e->getMessage();
    }

} else {
    $_SESSION['error_message'] = "Invalid submission.";
}

header("Location: manage_requests.php");
exit();
?>