<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('employee');
$page_title = "Log Attendance - EPMS";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
    <!-- Path to html5-qrcode.min.js -->
    <script src="../js/html5-qrcode.min.js"></script>
</head>
<body>
    <?php include_once '_employee_header.php'; ?>

    <div class="main-content">
        <div class="container">
            <h1>Log Attendance</h1>
            <p>Scan your employee QR code to log your attendance.</p>
            
            <div id="qr-reader" style="width:100%; max-width:400px; margin: 20px auto;"></div>
            <div id="qr-reader-results" style="text-align:center; margin-top:15px; font-weight:bold;"></div>

            <div style="text-align:center; margin-top:20px;">
                <p><strong>Instructions:</strong></p>
                <ol style="text-align:left; display:inline-block;">
                    <li>Allow camera access when prompted.</li>
                    <li>Position your employee QR code in front of the camera.</li>
                    <li>Once scanned, your attendance will be recorded.</li>
                </ol>
            </div>

        </div>
    </div>

    <?php include_once '_employee_footer.php'; ?>
    <!-- Main script.js should be loaded after html5-qrcode.min.js if it uses its functions -->
    <script src="../js/script.js"></script> 
</body>
</html>