<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_once '../config/functions.php';
require_login('employee');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['updated_values'])) {
    $employee_id = $_SESSION['employee_id'];
    $updated_values = $_POST['updated_values'];
    $request_reason = isset($_POST['request_reason']) ? sanitize_input($_POST['request_reason'], $conn) : null;

    $changes_requested = [];
    foreach ($updated_values as $field => $new_value) {
        $sanitized_new_value = sanitize_input($new_value, $conn);
        if (!empty(trim($sanitized_new_value))) { // Only include if a new value is provided
            // You might want to compare with current value to see if it's an actual change
            // For simplicity, we'll just record any non-empty new value.
            $changes_requested[$field] = $sanitized_new_value;
        }
    }

    if (empty($changes_requested)) {
        $_SESSION['error_message'] = "No changes were submitted. Please enter new values for the fields you wish to update.";
        header("Location: profile.php");
        exit();
    }

    $details_json = json_encode($changes_requested); // Store changes as JSON

    $stmt = $conn->prepare("INSERT INTO employee_requests (employee_id, request_type, details, requested_at, admin_remarks) VALUES (?, 'Profile Update', ?, NOW(), ?)");
    $stmt->bind_param("iss", $employee_id, $details_json, $request_reason);

    if ($stmt->execute()) {
        $_SESSION['message'] = "Your profile update request has been submitted successfully and is pending approval.";
    } else {
        $_SESSION['error_message'] = "Error submitting update request: " . $stmt->error;
    }
    $stmt->close();
} else {
    $_SESSION['error_message'] = "Invalid request.";
}

header("Location: profile.php");
exit();
?>