<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('employee');
$page_title = "My Payroll - EPMS";
$employee_id = $_SESSION['employee_id'];

$sql = "SELECT p.* 
        FROM payroll p
        WHERE p.employee_id = ?
        ORDER BY p.pay_period_end DESC, p.date_generated DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$result = $stmt->get_result();
$payrolls = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include_once '_employee_header.php'; ?>

    <div class="main-content">
        <div class="container">
            <h1>My Payroll History</h1>

            <?php if (count($payrolls) > 0): ?>
            <div style="overflow-x:auto;"> <!-- For responsive table -->
            <table>
                <thead>
                    <tr>
                        <th>Pay Period</th>
                        <th>Basic Pay</th>
                        <th>Allowances</th>
                        <th>SSS Ded.</th>
                        <th>PhilHealth Ded.</th>
                        <th>Pag-IBIG Ded.</th>
                        <th>Withholding Tax</th>
                        <th>Other Deductions</th>
                        <th>Net Pay</th>
                        <th>Date Generated</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($payrolls as $pr): ?>
                    <tr>
                        <td><?php echo date('F d, Y', strtotime($pr['pay_period_start'])) . ' - ' . date('F d, Y', strtotime($pr['pay_period_end'])); ?></td>
                        <td><?php echo number_format($pr['basic_pay'], 2); ?></td>
                        <td><?php echo number_format($pr['allowances'], 2); ?></td>
                        <td><?php echo number_format($pr['sss_contribution'], 2); ?></td>
                        <td><?php echo number_format($pr['philhealth_contribution'], 2); ?></td>
                        <td><?php echo number_format($pr['pagibig_contribution'], 2); ?></td>
                        <td><?php echo number_format($pr['withholding_tax'], 2); ?></td>
                        <td><?php echo number_format($pr['other_deductions'], 2); ?></td>
                        <td><strong><?php echo number_format($pr['net_pay'], 2); ?></strong></td>
                        <td><?php echo date('Y-m-d H:i', strtotime($pr['date_generated'])); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php else: ?>
            <p>No payroll records found for you yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <?php include_once '_employee_footer.php'; ?>
    <script src="../js/script.js"></script>
</body>
</html>