<?php
header('Content-Type: application/json'); // Important for JS fetch
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('employee'); // Ensure employee is logged in

$response = ['status' => 'error', 'message' => 'Invalid request.'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['employee_code'])) {
    $scanned_employee_code = sanitize_input($_POST['employee_code'], $conn);
    $current_employee_id = $_SESSION['employee_id']; // The logged-in employee

    // Verify that the scanned code belongs to the logged-in employee
    $stmt_verify = $conn->prepare("SELECT id, employee_code FROM employees WHERE id = ? AND employee_code = ? AND status = 'active'");
    $stmt_verify->bind_param("is", $current_employee_id, $scanned_employee_code);
    $stmt_verify->execute();
    $result_verify = $stmt_verify->get_result();

    if ($result_verify->num_rows === 1) {
        $employee = $result_verify->fetch_assoc();
        $employee_id_from_scan = $employee['id']; // This should match $current_employee_id
        $today = date('Y-m-d');
        $now = date('Y-m-d H:i:s');

        // Check if already clocked in today
        $stmt_check = $conn->prepare("SELECT id, time_in, time_out FROM attendance WHERE employee_id = ? AND date_recorded = ?");
        $stmt_check->bind_param("is", $employee_id_from_scan, $today);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();
        $attendance_record = $result_check->fetch_assoc();
        $stmt_check->close();

        if ($attendance_record) { // Record exists for today
            if (empty($attendance_record['time_out'])) {
                // Clock out
                $stmt_update = $conn->prepare("UPDATE attendance SET time_out = ? WHERE id = ?");
                $stmt_update->bind_param("si", $now, $attendance_record['id']);
                if ($stmt_update->execute()) {
                    $response = ['status' => 'success', 'message' => 'Clocked out successfully at ' . date('h:i A', strtotime($now))];
                } else {
                    $response = ['status' => 'error', 'message' => 'Error clocking out: ' . $stmt_update->error];
                }
                $stmt_update->close();
            } else {
                $response = ['status' => 'info', 'message' => 'Already clocked in and out for today.'];
            }
        } else {
            // Clock in
            $stmt_insert = $conn->prepare("INSERT INTO attendance (employee_id, time_in, date_recorded) VALUES (?, ?, ?)");
            $stmt_insert->bind_param("iss", $employee_id_from_scan, $now, $today);
            if ($stmt_insert->execute()) {
                $response = ['status' => 'success', 'message' => 'Clocked in successfully at ' . date('h:i A', strtotime($now))];
            } else {
                $response = ['status' => 'error', 'message' => 'Error clocking in: ' . $stmt_insert->error];
            }
            $stmt_insert->close();
        }
    } else {
        $response = ['status' => 'error', 'message' => 'QR Code mismatch or employee not active. Please use your own QR code.'];
    }
    $stmt_verify->close();

} else {
     $response = ['status' => 'error', 'message' => 'No employee code received or invalid request method.'];
}

$conn->close();
echo json_encode($response);
exit();
?>