<header class="header">
    <div class="logo">
        <img src="../images/epms_logo.png" alt="EPMS Logo">
        <span>EPMS Employee Portal</span>
    </div>
     <button class="nav-toggle" id="navToggle">☰</button>
    <nav class="nav-links" id="navLinks">
        <a href="dashboard.php">Dashboard</a>
        <a href="profile.php">Profile</a>
        <a href="view_payroll.php">Payroll</a>
        <a href="attendance.php">Attendance</a>
    </nav>
    <div class="user-actions">
        <span>Hi, <?php echo htmlspecialchars($_SESSION['username']); // Or employee name ?></span>
        <a href="../auth/logout.php" class="btn">Logout</a>
    </div>
</header>