<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_once '../config/functions.php';
require_login('employee');

$page_title = "My Profile - EPMS";
$employee_id = $_SESSION['employee_id'];

$stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$result = $stmt->get_result();
$employee = $result->fetch_assoc();
$stmt->close();

if (!$employee) {
    // Should not happen if session employee_id is valid
    die("Employee record not found.");
}

$message = isset($_SESSION['message']) ? $_SESSION['message'] : '';
$error_message = isset($_SESSION['error_message']) ? $_SESSION['error_message'] : '';
unset($_SESSION['message']);
unset($_SESSION['error_message']);

// Fields employee can request to update
$editable_fields = [
    'email' => 'Email',
    'phone' => 'Phone',
    'address' => 'Address',
    'mode_of_payment' => 'Mode of Payment',
    'bank_account_no' => 'Bank Account No.'
    // Add more if needed
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include_once '_employee_header.php'; ?>

    <div class="main-content">
        <div class="container">
            <h1>My Profile</h1>

            <?php if ($message): ?>
                <div class="message success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>
            <?php if ($error_message): ?>
                <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
            <?php endif; ?>

            <div class="profile-details" style="margin-bottom: 30px;">
                <h2>Personal & Employment Information</h2>
                <p><strong>Employee Code:</strong> <?php echo htmlspecialchars($employee['employee_code']); ?></p>
                <p><strong>Name:</strong> <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></p>
                <p><strong>Email:</strong> <?php echo htmlspecialchars($employee['email']); ?></p>
                <p><strong>Phone:</strong> <?php echo htmlspecialchars($employee['phone']); ?></p>
                <p><strong>Address:</strong> <?php echo nl2br(htmlspecialchars($employee['address'])); ?></p>
                <p><strong>Date Hired:</strong> <?php echo htmlspecialchars($employee['date_hired'] ? date('F j, Y', strtotime($employee['date_hired'])) : 'N/A'); ?></p>
                <p><strong>Position:</strong> <?php echo htmlspecialchars($employee['position']); ?></p>
                <p><strong>Department:</strong> <?php echo htmlspecialchars($employee['department']); ?></p>
                <p><strong>Status:</strong> <?php echo ucfirst(htmlspecialchars($employee['status'])); ?></p>
                
                <h2>Payment Information</h2>
                <p><strong>Mode of Payment:</strong> <?php echo htmlspecialchars($employee['mode_of_payment']); ?></p>
                <p><strong>Bank Account No.:</strong> <?php echo htmlspecialchars($employee['bank_account_no'] ? $employee['bank_account_no'] : 'N/A'); ?></p>

                <h2>Government IDs</h2>
                <p><strong>SSS No.:</strong> <?php echo htmlspecialchars($employee['sss_no'] ? $employee['sss_no'] : 'N/A'); ?></p>
                <p><strong>PhilHealth No.:</strong> <?php echo htmlspecialchars($employee['philhealth_no'] ? $employee['philhealth_no'] : 'N/A'); ?></p>
                <p><strong>Pag-IBIG No.:</strong> <?php echo htmlspecialchars($employee['pagibig_no'] ? $employee['pagibig_no'] : 'N/A'); ?></p>
                <p><strong>TIN No.:</strong> <?php echo htmlspecialchars($employee['tin_no'] ? $employee['tin_no'] : 'N/A'); ?></p>
            </div>

            <hr>

            <div class="profile-update-request form-container">
                <h2>Request Profile Update</h2>
                <p>You can request updates for the following information. Your request will be sent to an administrator for approval.</p>
                <form action="profile_update_action.php" method="POST">
                    <?php foreach ($editable_fields as $field_key => $field_label): ?>
                    <div class="form-group">
                        <label for="<?php echo $field_key; ?>"><?php echo $field_label; ?> (Current: <?php echo htmlspecialchars(empty($employee[$field_key]) ? 'N/A' : $employee[$field_key]); ?>):</label>
                        <?php if ($field_key == 'address'): ?>
                            <textarea id="<?php echo $field_key; ?>" name="updated_values[<?php echo $field_key; ?>]" placeholder="Enter new <?php echo strtolower($field_label); ?>"><?php // echo htmlspecialchars($employee[$field_key]); ?></textarea>
                        <?php elseif ($field_key == 'mode_of_payment'): ?>
                            <select id="<?php echo $field_key; ?>" name="updated_values[<?php echo $field_key; ?>]">
                                <option value="">-- Select New Mode --</option>
                                <option value="Bank Transfer">Bank Transfer</option>
                                <option value="Check">Check</option>
                                <option value="Cash">Cash</option>
                            </select>
                        <?php else: ?>
                            <input type="text" id="<?php echo $field_key; ?>" name="updated_values[<?php echo $field_key; ?>]" placeholder="Enter new <?php echo strtolower($field_label); ?>">
                        <?php endif; ?>
                         <small>Leave blank if no change is requested for this field.</small>
                    </div>
                    <?php endforeach; ?>
                    
                    <div class="form-group">
                         <label for="request_reason">Reason for Update (Optional):</label>
                         <textarea id="request_reason" name="request_reason" placeholder="E.g., Moved to a new address, Changed bank account"></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit Update Request</button>
                </form>
            </div>
        </div>
    </div>

    <?php include_once '_employee_footer.php'; ?>
    <script src="../js/script.js"></script>
</body>
</html>