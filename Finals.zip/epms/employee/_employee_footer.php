<footer class="footer" style="background-color: #333; color: #fff; text-align:center; padding: 10px 0; margin-top:20px;">
    <p>© <?php echo date("Y"); ?> EPMS - Employee Portal. All Rights Reserved.</p>
</footer>