<?php
require_once '../config/db.php';
require_once '../config/session_check.php';
require_login('employee'); // Restrict access

$page_title = "Employee Dashboard - EPMS";
$employee_id = $_SESSION['employee_id'];

// Fetch employee name
$stmt = $conn->prepare("SELECT first_name, last_name FROM employees WHERE id = ?");
$stmt->bind_param("i", $employee_id);
$stmt->execute();
$result = $stmt->get_result();
$employee = $result->fetch_assoc();
$stmt->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <?php include_once '_employee_header.php'; // Shared employee header ?>

    <div class="main-content">
        <div class="container">
            <h1>Employee Dashboard</h1>
            <p>Welcome, <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?>!</p>

            <h2>Quick Links</h2>
            <ul>
                <li><a href="profile.php" class="btn btn-primary">My Profile</a></li>
                <li><a href="view_payroll.php" class="btn btn-primary">View My Payroll</a></li>
                <li><a href="attendance.php" class="btn btn-primary">Log Attendance (QR Scan)</a></li>
                <!-- Add link to submit requests if you implement that -->
            </ul>
        </div>
    </div>

    <?php include_once '_employee_footer.php'; // Shared employee footer ?>
    <script src="../js/script.js"></script>
</body>
</html>