document.addEventListener('DOMContentLoaded', function() {
    // Mobile Nav Toggle
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');
    const loginButtons = document.querySelector('.login-buttons'); // Assuming this is the container for login buttons

    if (navToggle && navLinks) {
        navToggle.addEventListener('click', () => {
            navLinks.classList.toggle('active');
            if (loginButtons) { // Also toggle login buttons if they are part of the collapsible nav
                loginButtons.classList.toggle('active');
            }
        });
    }

    // Confirm delete or restore actions
    // Targets forms with class 'delete-form' or 'restore-form'
    const actionForms = document.querySelectorAll('.delete-form, .restore-form');
    actionForms.forEach(form => {
        form.addEventListener('submit', function(event) {
            let confirmationMessage = 'Are you sure you want to perform this action?'; // Default message
            if (form.classList.contains('delete-form')) {
                confirmationMessage = 'Are you sure you want to delete this item? This action might be irreversible.';
            } else if (form.classList.contains('restore-form')) {
                confirmationMessage = 'Are you sure you want to restore this item?';
            }
            
            if (!confirm(confirmationMessage)) {
                event.preventDefault(); // Stop form submission if user cancels
            }
        });
    });
    
    // QR Code Scanner for Employee Attendance (on attendance.php)
    const qrReaderElement = document.getElementById('qr-reader');
    const qrReaderResultsElement = document.getElementById('qr-reader-results');

    if (qrReaderElement && qrReaderResultsElement) {
        let html5QrcodeScanner; // Declare scanner variable here to access it for .clear() if needed

        function onScanSuccess(decodedText, decodedResult) {
            console.log(`QR Code Scanned: ${decodedText}`, decodedResult); // Log for debugging
            qrReaderResultsElement.innerHTML = `<span style="color: green;">Scanned: ${decodedText}. Processing...</span>`;
            
            // Disable further scanning temporarily to prevent multiple submissions from one scan
            // You might need to re-enable it or clear the scanner based on your flow
            // if (html5QrcodeScanner) {
            //     try {
            //         if (html5QrcodeScanner.getState() === Html5QrcodeScannerState.SCANNING) {
            //             html5QrcodeScanner.pause(true);
            //         }
            //     } catch (e) {
            //         console.warn("Could not pause scanner:", e);
            //     }
            // }


            const formData = new FormData();
            formData.append('employee_code', decodedText);

            fetch('attendance_action.php', { // Assuming attendance_action.php is in the same directory as attendance.php
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    // Try to get error message from server if available
                    return response.json().then(errData => {
                        throw new Error(errData.message || `HTTP error! status: ${response.status}`);
                    }).catch(() => { // Fallback if response is not JSON
                        throw new Error(`HTTP error! status: ${response.status}`);
                    });
                }
                return response.json();
            })
            .then(data => {
                // Display message from server
                if (data.status === 'success') {
                    qrReaderResultsElement.innerHTML = `<span style="color: green;">${data.message}</span>`;
                } else if (data.status === 'info') {
                    qrReaderResultsElement.innerHTML = `<span style="color: blue;">${data.message}</span>`;
                } else { // 'error' or other
                    qrReaderResultsElement.innerHTML = `<span style="color: red;">Error: ${data.message}</span>`;
                }
                alert(data.message); // Show a system alert for clear feedback

                // Optionally, clear the scanner or re-enable scanning after a short delay
                // if (html5QrcodeScanner) {
                //    html5QrcodeScanner.clear().catch(err => console.error("Failed to clear scanner:", err));
                //    // Or to resume:
                //    // setTimeout(() => {
                //    //    if (html5QrcodeScanner.getState() !== Html5QrcodeScannerState.SCANNING) {
                //    //        html5QrcodeScanner.resume();
                //    //    }
                //    //    qrReaderResultsElement.innerHTML = "Ready for next scan.";
                //    // }, 3000); // Resume after 3 seconds
                // }
            })
            .catch(error => {
                console.error('Error processing attendance fetch:', error);
                qrReaderResultsElement.innerHTML = `<span style="color: red;">Request failed: ${error.message}. Check console.</span>`;
                alert(`Request failed: ${error.message}. Please try again.`);
            });
        }

        function onScanFailure(error) {
            // This is called frequently if no QR code is detected by the scanner.
            // It's usually best not to show this to the user unless it's an actual error state.
            // console.warn(`QR Scan Error (often expected when no QR in view): ${error}`);
        }

        try {
            html5QrcodeScanner = new Html5QrcodeScanner(
                "qr-reader", // ID of the HTML element
                { 
                    fps: 10, // Frames per second to attempt scanning
                    qrbox: { width: 250, height: 250 }, // Size of the scanning box (optional)
                    rememberLastUsedCamera: true,       // Remembers the last selected camera (good UX)
                    // supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA] // To only use camera
                },
                /* verbose= */ true // Set to true for more detailed logs from the library in the console
            );
            
            // Start rendering the scanner UI and camera feed.
            // This will show the "Select Camera", "Start Scanning" UI.
            html5QrcodeScanner.render(onScanSuccess, onScanFailure);
            qrReaderResultsElement.innerHTML = "QR Scanner Initialized. Click 'Start Scanning' in the scanner UI above.";

        } catch (e) {
            console.error("Error initializing Html5QrcodeScanner:", e);
            qrReaderResultsElement.innerHTML = `<span style="color: red;">Could not initialize QR Scanner: ${e.message}. Please ensure camera permissions are granted and try refreshing.</span>`;
        }
    } else {
        // Log if the necessary HTML elements are not found - helps in debugging setup.
        if (!qrReaderElement) console.warn("QR Reader element with ID 'qr-reader' not found on this page.");
        if (!qrReaderResultsElement) console.warn("QR Reader results element with ID 'qr-reader-results' not found on this page.");
    }

});