<?php
ini_set('log_errors', 1);
ini_set('error_log', 'php-error.log');
error_reporting(E_ALL); 

// Start session
session_start();

// Include database connection and admin functions
require_once 'database.php'; 
require_once 'admin_functions.php';

if (!$conn || !($conn instanceof mysqli)) {
    // If $conn is not a valid mysqli object, something went wrong in database.php
    // Log this critical error and stop execution or show a friendly error page.
    error_log("Critical: Database connection failed or $conn is not a mysqli object in add_employee.php.");
    die("A critical database error occurred. Please contact support or check server logs.");
}

function validateInput($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// --- Initialize variables for login ---
$admin_code_login_input = "";
$login_err = "";

// --- Initialize variables for registration ---
$errors = [];
$success_message = "";
$fullName_reg = $email_reg = $phone_reg = $adminCode_reg_form = $role_reg = ""; 

// --- Process LOGIN form data ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    // Get admin_id (which is admin_code) from form
    $admin_code_login_input = validateInput($_POST["admin_id"]); 
    $password_from_form = isset($_POST["password"]) ? trim($_POST["password"]) : "";
    error_log("Login attempt for admin_code: [" . $admin_code_login_input . "]");

    if (empty($admin_code_login_input)) {
        $login_err = "Please enter admin ID.";
    } elseif (empty($password_from_form)) {
        $login_err = "Please enter password.";
    } else {
        if (!$conn) {
            $login_err = "Database connection error. Please try again later.";
            error_log("Login attempt: Database connection failed.");
        } else {
            $query = "SELECT admin_id, admin_code, password, full_name, is_active FROM admins WHERE admin_code = ?";
            
            if ($stmt = mysqli_prepare($conn, $query)) {
                mysqli_stmt_bind_param($stmt, "s", $admin_code_login_input);
                
                if (mysqli_stmt_execute($stmt)) {
                    $result = mysqli_stmt_get_result($stmt);
                    
                    if (mysqli_num_rows($result) === 1) {
                        $row = mysqli_fetch_assoc($result);
                        
                        error_log("Admin found: " . $row["admin_code"] . ", is_active: " . $row["is_active"]);
                        
                        if ($row["is_active"] != 1) {
                            $login_err = "Your account is inactive. Please contact support.";
                            error_log("Login failed: Account inactive for admin_code: " . $admin_code_login_input);
                            if (function_exists('logAdminActivity')) {
                                logAdminActivity($row["admin_id"] ?? null, $row["full_name"] ?? $admin_code_login_input, "Login Failed", "Account inactive");
                            }
                        } else {
                            // Check password
                            if (password_verify($password_from_form, $row["password"])) {
                                error_log("Password VERIFIED for admin_code: " . $admin_code_login_input);
                                
                                // Clear any existing session data
                                session_regenerate_id(true);
                                
                                $_SESSION["loggedin"] = true;
                                $_SESSION["admin_id"] = $row["admin_id"];  // Changed from "id" to "admin_id" 
                                $_SESSION["admin_code"] = $row["admin_code"];
                                $_SESSION["admin_name"] = $row["full_name"];
                                
                                if (function_exists('updateAdminLastLogin')) {
                                    updateAdminLastLogin($row["admin_id"]);
                                }
                                
                                if (function_exists('logAdminActivity')) {
                                    logAdminActivity($row["admin_id"], $row["full_name"], "Login", "Admin login successful");
                                }
                                
                                error_log("Session set successfully. Redirecting to adminHome.php");
                                error_log("Session data: " . print_r($_SESSION, true));
                                
                                // Use absolute URL for redirect
                                $redirect_url = "adminHome.php";
                                
                                // Clear output buffer to prevent any output before redirect
                                ob_clean();
                                
                                header("Location: " . $redirect_url);
                                exit();
                            } else {
                                $login_err = "Invalid password.";
                                error_log("Login failed: Invalid password for admin_code: " . $admin_code_login_input);
                                if (function_exists('logAdminActivity')) {
                                    logAdminActivity($row["admin_id"], $row["full_name"], "Failed Login", "Invalid password attempt");
                                }
                            }
                        }
                    } else {
                        $login_err = "Invalid admin ID or password.";
                        error_log("Admin_code NOT FOUND in DB: " . $admin_code_login_input);
                        if (function_exists('logAdminActivity')) {
                            logAdminActivity(null, 'Unknown User', "Failed Login", "Attempt with non-existent admin_code: " . $admin_code_login_input);
                        }
                    }
                } else {
                    $login_err = "Database query execution failed. Please try again later.";
                    error_log("MySQL execute statement error (login): " . mysqli_error($conn));
                }
                
                mysqli_stmt_close($stmt);
            } else {
                $login_err = "Database error (prepare). Please try again later.";
                error_log("MySQL prepare statement error (login): " . mysqli_error($conn));
            }
        }
    }
}

// --- Process admin REGISTRATION form ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["register"])) {
    $fullName_reg = validateInput($_POST["full_name"]);
    $email_reg = validateInput($_POST["email"]);
    $phone_reg = validateInput($_POST["phone"]);
    $adminCode_reg_form = validateInput($_POST["admin_id"]);
    $password_reg = trim($_POST["password"]);
    $confirmPassword_reg = trim($_POST["confirm_password"]);
    $role_reg = validateInput($_POST["role"]);
    
    if (empty($fullName_reg)) $errors[] = "Full name is required.";
    if (empty($email_reg) || !filter_var($email_reg, FILTER_VALIDATE_EMAIL)) $errors[] = "Valid email is required.";
    if (empty($adminCode_reg_form)) $errors[] = "Admin ID is required.";
    elseif (strlen($adminCode_reg_form) < 3) $errors[] = "Admin ID must be at least 3 characters long.";
    if (empty($password_reg)) $errors[] = "Password is required.";
    elseif (strlen($password_reg) < 8) $errors[] = "Password must be at least 8 characters.";
    if ($password_reg !== $confirmPassword_reg) $errors[] = "Passwords do not match.";
    if (empty($role_reg)) $errors[] = "Admin role is required.";
    
    if (empty($errors)) {
        if (!$conn) {
            $errors[] = "Database connection error (registration check).";
        } else {
            $check_query = "SELECT admin_id FROM admins WHERE admin_code = ? OR email = ?";
            $stmt_check = $conn->prepare($check_query);
            if (!$stmt_check) {
                $errors[] = "DB prepare error (reg check): " . $conn->error;
            } else {
                $stmt_check->bind_param("ss", $adminCode_reg_form, $email_reg);
                if (!$stmt_check->execute()) {
                    $errors[] = "DB execution error (reg check): " . $stmt_check->error;
                } else {
                    $check_result = $stmt_check->get_result();
                    if ($check_result->num_rows > 0) {
                        $errors[] = "Admin ID or email already exists.";
                    }
                }
                $stmt_check->close();
            }
        }
    }

    if (empty($errors)) {
        $hashedPassword = password_hash($password_reg, PASSWORD_DEFAULT);
        $insert_query = "INSERT INTO admins (admin_code, full_name, email, phone, password, role) 
                         VALUES (?, ?, ?, ?, ?, ?)";
        $stmt_insert = $conn->prepare($insert_query);

        if (!$stmt_insert) {
            $errors[] = "DB prepare error (reg insert): " . $conn->error;
        } else {
            $stmt_insert->bind_param("ssssss", $adminCode_reg_form, $fullName_reg, $email_reg, $phone_reg, $hashedPassword, $role_reg);
            if ($stmt_insert->execute()) {
                $new_admin_pk_id = $stmt_insert->insert_id;
                $success_message = "New admin registered! Login with Admin ID: " . htmlspecialchars($adminCode_reg_form);
                if (function_exists('logAdminActivity')) {
                    logAdminActivity(null, $fullName_reg, "Admin Registration", "New admin: " . $adminCode_reg_form . " (ID: ".$new_admin_pk_id.")");
                }
                $fullName_reg = $email_reg = $phone_reg = $adminCode_reg_form = $role_reg = ""; 
            } else {
                if ($conn->errno == 1062) { 
                     $errors[] = "Admin ID or email already exists (DB Code 1062).";
                } else {
                    $errors[] = "Registration failed: " . $stmt_insert->error;
                }
            }
            $stmt_insert->close();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - EPMS</title>
    <style>
         * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        body {
            background-color: #1e2633;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .container {
            background-color: #0e1521;
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(255, 216, 77, 0.2);
            width: 100%;
            max-width: 900px;
            overflow: hidden;
            display: flex;
            position: relative;
        }
        
        .login-section {
            width: 40%;
            background-color: #0e1521;
            padding: 40px;
            color: white;
            display: flex;
            flex-direction: column;
        }
        
        .info-section {
            flex: 1;
            background: linear-gradient(135deg, #ffd84d 0%, #ffc107 100%);
            color: #333;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            clip-path: polygon(10% 0, 100% 0, 100% 100%, 0 100%);
        }
        
        .logo {
            max-width: 150px;
            margin-bottom: 30px;
            align-self: center; 
        }
        
        .login-section h1 { 
            font-size: 28px; 
            margin-bottom: 10px;
            text-align: center;
        }
        
        .subtitle {
            margin-bottom: 30px; 
            opacity: 0.8;
            font-size: 12px; 
            text-align: center;
            line-height: 1.4;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            font-size: 0.9em;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #2a314a; 
            border-radius: 4px;
            background-color: #1c2333; 
            color: white;
            font-size: 16px;
        }
        .form-control:focus {
            outline: none;
            border-color: #ffd633;
            box-shadow: 0 0 0 2px rgba(255, 214, 51, 0.3);
        }
        
        .error-message { 
            color: #ff6b6b;
            background-color: rgba(255, 107, 107, 0.1);
            border-left: 4px solid #ff6b6b;
            padding: 10px 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            font-size: 0.9em;
        }
        
        .btn {
            background-color: #ffd633;
            color: #1a1f2e;
            border: none;
            padding: 12px;
            width: 100%;
            font-size: 16px;
            font-weight: bold;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
            transition: background-color 0.2s ease;
        }
        .btn:hover {
            background-color: #e6bf2e;
        }
        
        .forgot-password {
            text-align: right;
            margin: 10px 0 20px;
        }
        
        .forgot-password a {
            color: #ffd633;
            text-decoration: none;
            font-size: 0.9em;
        }
        .forgot-password a:hover {
            text-decoration: underline;
        }

        .portal-title {
            font-size: 40px; 
            font-weight: bold;
            position: relative;
            left: 50px; 
            margin-bottom: 20px;
            color: #1c2231;
        }
        
        .portal-description {
            font-size: 15px; 
            line-height: 1.6;
            color: #1c2231;
            position: relative;
            left: 30px;
            margin-bottom: 40px;
        }
            
        .signup-btn-corner {
            position: absolute;
            top: 20px;
            right: 20px;
            padding: 10px 20px;
            background-color: #1c2231;
            color: #fcd535;
            border: none;
            border-radius: 5px;
            font-weight: bold;
            cursor: pointer;
            z-index: 10;
            transition: all 0.3s ease;
        }
        .signup-btn-corner:hover {
            background-color: #2a3042;
            transform: scale(1.05);
        }

         .home-btn {
            display: inline-block;
            padding: 12px 35px; 
            background: #1c2231; 
            border: none;
            border-radius: 25px;
            color: #fcd535; 
            text-decoration: none;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s;
            align-self: flex-start; 
            margin-left: 30px; 
        }
        .home-btn:hover {
            background-color: #2a3042;
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
        }
        
        /* Modal styles */
        .modal {
            position: fixed;
            top: 0; 
            left: 0;
            display: none; 
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.6); 
            z-index: 1000; 
            justify-content: center; 
            align-items: flex-start; 
            padding-top: 8vh; 
            overflow-y: auto; 
        }

        .modal-content {
            position: relative;
            background-color: #1a1f2e;
            margin: 0 auto 5vh auto; 
            padding: 30px 35px; 
            border-radius: 8px;
            width: 90%; 
            max-width: 550px; 
            color: white;
            max-height: 85vh; 
            overflow-y: auto; 
            box-shadow: 0 5px 25px rgba(0,0,0,0.3);
        }
        .modal-content h2 {
            text-align: center;
            margin-bottom: 25px;
            color: #ffd633;
        }

        .close {
            position: absolute; 
            top: 15px;
            right: 20px;
            color: #ffd633;
            font-size: 32px; 
            font-weight: bold;
            cursor: pointer;
            transition: color 0.2s;
        }
        .close:hover {
            color: #fff;
        }

        .error-container { 
            background-color: rgba(255, 107, 107, 0.1);
            border-left: 4px solid #ff6b6b;
            padding: 12px 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .error-container .error { 
            color: #ffc2c2; 
            margin: 6px 0;
            font-size: 0.9em;
        }

        .success-message { 
            background-color: rgba(76, 175, 80, 0.15); 
            border-left: 4px solid #4CAF50;
            padding: 12px 15px;
            margin-bottom: 20px;
            color: #a5d6a7; 
            border-radius: 4px;
            font-size: 0.95em;
        }
        .modal .btn-primary { 
            margin-top: 25px; 
        }

        .form-group small {
            display: block;
            margin-top: 6px;
            color: #999; 
            font-size: 0.8em; 
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-section">
            <img src="images/logo2.png" alt="System Logo" class="logo">
            
            <h1>Admin Login</h1>
            <p class="subtitle">Access administrative controls and system management for EPMS.</p>
            
            <?php if (!empty($login_err)) { ?>
                <div class="error-message"><?php echo htmlspecialchars($login_err); ?></div>
            <?php } ?>
            
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label for="login_admin_id_form">Admin ID</label>
                    <input type="text" id="login_admin_id_form" name="admin_id" class="form-control" placeholder="Enter your admin ID" value="<?php echo htmlspecialchars($admin_code_login_input); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="login_password_form">Password</label>
                    <input type="password" id="login_password_form" name="password" class="form-control" placeholder="Enter your password" required>
                </div>
                
                <div class="forgot-password">
                    <a href="forgot_password.php">Forgot Password?</a>
                </div>
                
                <button type="submit" class="btn" name="login">Login</button>
            </form>
        </div>
        
        <div class="info-section">
            <button id="signupBtnCorner" class="signup-btn-corner">Sign Up Admin</button>
            
            <h1 class="portal-title">ADMIN PORTAL</h1>
            <p class="portal-description">
                Welcome to the administrative portal. Manage employee accounts, process payments, configure 
                system settings, and oversee all aspects of the Employment Payment Management System.
            </p>
            <a href="index.php" class="home-btn">Home</a>
        </div>
    </div>
    
    <div id="signupModal" class="modal">
        <div class="modal-content">
            <span class="close">×</span>
            <h2>Register New Admin</h2>
            
            <?php if (!empty($errors)): ?>
                <div class="error-container">
                    <?php foreach ($errors as $error_item): ?>
                        <p class="error"><?php echo htmlspecialchars($error_item); ?></p>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <?php if (!empty($success_message)): ?>
                <div class="success-message">
                    <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>
            
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="reg_full_name">Full Name</label>
                    <input type="text" id="reg_full_name" name="full_name" class="form-control" value="<?php echo htmlspecialchars($fullName_reg); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_email">Email Address</label>
                    <input type="email" id="reg_email" name="email" class="form-control" value="<?php echo htmlspecialchars($email_reg); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_phone">Phone Number (Optional)</label>
                    <input type="tel" id="reg_phone" name="phone" class="form-control" value="<?php echo htmlspecialchars($phone_reg); ?>">
                </div>
                
                <div class="form-group">
                    <label for="reg_admin_id">Admin ID</label>
                    <input type="text" id="reg_admin_id" name="admin_id" class="form-control" value="<?php echo htmlspecialchars($adminCode_reg_form); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_password">Password</label>
                    <input type="password" id="reg_password" name="password" class="form-control" required>
                    <small>Must be at least 8 characters long.</small>
                </div>
                
                <div class="form-group">
                    <label for="reg_confirm_password">Confirm Password</label>
                    <input type="password" id="reg_confirm_password" name="confirm_password" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="reg_role">Admin Role</label>
                    <select id="reg_role" name="role" class="form-control" required>
                        <option value="">Select Role</option>
                        <option value="Super Admin" <?php if($role_reg == 'Super Admin') echo 'selected'; ?>>Super Admin</option>
                        <option value="Manager" <?php if($role_reg == 'Manager') echo 'selected'; ?>>Manager</option>
                        <option value="Payroll Admin" <?php if($role_reg == 'Payroll Admin') echo 'selected'; ?>>Payroll Admin</option>
                        <option value="HR Admin" <?php if($role_reg == 'HR Admin') echo 'selected'; ?>>HR Admin</option>
                        <option value="Admin" <?php if($role_reg == 'Admin' || empty($role_reg)) echo 'selected'; ?>>Admin</option>
                    </select>
                </div>
                
                <button type="submit" name="register" class="btn btn-primary">Register Admin</button>
            </form>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var modal = document.getElementById('signupModal');
        var btnOpenModal = document.getElementById('signupBtnCorner'); 
        var spanCloseModal = modal.querySelector('.close');

        if (btnOpenModal) {
            btnOpenModal.onclick = function(e) {
                e.preventDefault();
                modal.style.display = 'flex'; 
            }
        }

        if (spanCloseModal) {
            spanCloseModal.onclick = function() {
                modal.style.display = 'none';
            }
        }

        window.onclick = function(event) {
            if (event.target == modal) { 
                modal.style.display = 'none';
            }
        }
        
        <?php if ((!empty($errors) || !empty($success_message)) && isset($_POST["register"])): ?>
        if (modal) {
            modal.style.display = 'flex';
        }
        <?php endif; ?>
    });
    </script>
</body>
</html>