<?php
// Include database connection
require_once 'database.php';

// Function to create tables with error handling
function createTable($conn, $tableName, $createTableSQL) {
    $checkTable = mysqli_query($conn, "SHOW TABLES LIKE '" . mysqli_real_escape_string($conn, $tableName) . "'");
    
    if (!$checkTable) {
        echo "Error checking for table $tableName: " . mysqli_error($conn) . "<br>";
        return false;
    }

    if (mysqli_num_rows($checkTable) == 0) {
        echo "Creating table: $tableName... ";
        if (mysqli_query($conn, $createTableSQL)) {
            echo "SUCCESS<br>";
            return true;
        } else {
            echo "FAILED: " . mysqli_error($conn) . "<br>";
            return false;
        }
    } else {
        echo "Table $tableName already exists.<br>";
        return true;
    }
}

// --- LOOKUP TABLES (3NF: Separate reference data) ---

// Departments lookup table
$departmentsTableSQL = "CREATE TABLE IF NOT EXISTS departments (
    dept_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL UNIQUE,
    dept_code VARCHAR(10) UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Job Titles lookup table
$jobTitlesTableSQL = "CREATE TABLE IF NOT EXISTS job_titles (
    job_title_id INT AUTO_INCREMENT PRIMARY KEY,
    title_name VARCHAR(100) NOT NULL UNIQUE,
    title_code VARCHAR(20),
    dept_id INT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Pay Frequency lookup table
$payFrequencyTableSQL = "CREATE TABLE IF NOT EXISTS pay_frequencies (
    freq_id INT AUTO_INCREMENT PRIMARY KEY,
    frequency_name VARCHAR(50) NOT NULL UNIQUE,
    frequency_code VARCHAR(10) NOT NULL UNIQUE,
    days_per_period INT NOT NULL,
    periods_per_year INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Benefit Types lookup table
$benefitTypesTableSQL = "CREATE TABLE IF NOT EXISTS benefit_types (
    benefit_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL UNIQUE,
    type_code VARCHAR(20) NOT NULL UNIQUE,
    description TEXT,
    is_mandatory BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Leave Types lookup table
$leaveTypesTableSQL = "CREATE TABLE IF NOT EXISTS leave_types (
    leave_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL UNIQUE,
    type_code VARCHAR(10) NOT NULL UNIQUE,
    max_days_per_year INT DEFAULT NULL,
    is_paid BOOLEAN DEFAULT TRUE,
    requires_approval BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Request Types lookup table
$requestTypesTableSQL = "CREATE TABLE IF NOT EXISTS request_types (
    request_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL UNIQUE,
    type_code VARCHAR(20) NOT NULL UNIQUE,
    description TEXT,
    requires_approval BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// --- CORE ENTITY TABLES ---

// Admins table (normalized)
$adminTableSQL = "CREATE TABLE IF NOT EXISTS admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_code VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'Admin',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Employees table (core information only)
$employeesTableSQL = "CREATE TABLE IF NOT EXISTS employees (
    emp_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_code VARCHAR(50) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(15),
    hire_date DATE NOT NULL,
    dept_id INT,
    job_title_id INT,
    password VARCHAR(255) NOT NULL,
    qr_code VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL,
    FOREIGN KEY (job_title_id) REFERENCES job_titles(job_title_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Employee Salary Details (normalized)
$employeeSalaryDetailsTableSQL = "CREATE TABLE IF NOT EXISTS employee_salary_details (
    salary_detail_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    base_salary DECIMAL(12,2) DEFAULT 0.00,
    hourly_rate DECIMAL(10,2) DEFAULT 0.00,
    freq_id INT NOT NULL,
    effective_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    is_current BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    FOREIGN KEY (freq_id) REFERENCES pay_frequencies(freq_id),
    INDEX idx_emp_current (emp_id, is_current),
    INDEX idx_effective_date (effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Employee Benefits (normalized - one record per benefit type per employee)
$employeeBenefitsTableSQL = "CREATE TABLE IF NOT EXISTS employee_benefits (
    benefit_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    benefit_type_id INT NOT NULL,
    id_number VARCHAR(50),
    contribution_amount DECIMAL(10,2) DEFAULT 0.00,
    effective_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    FOREIGN KEY (benefit_type_id) REFERENCES benefit_types(benefit_type_id),
    UNIQUE KEY uk_emp_benefit_type (emp_id, benefit_type_id, effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Attendance table (normalized)
$attendanceTableSQL = "CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    check_in DATETIME,
    check_out DATETIME,
    expected_check_in TIME DEFAULT '09:00:00',
    expected_check_out TIME DEFAULT '17:00:00',
    status ENUM('Present', 'Absent', 'Leave', 'Half-Day', 'Weekend', 'Holiday') NOT NULL DEFAULT 'Absent',
    worked_hours DECIMAL(5,2) DEFAULT 0.00,
    tardiness_minutes INT DEFAULT 0,
    overtime_minutes INT DEFAULT 0,
    notes TEXT,
    location_latitude DECIMAL(10,7),
    location_longitude DECIMAL(10,7),
    ip_address VARCHAR(45),
    device_info VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    UNIQUE KEY uk_emp_date (emp_id, attendance_date),
    INDEX idx_attendance_date (attendance_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Salary Calculations (normalized)
$salaryCalculationsTableSQL = "CREATE TABLE IF NOT EXISTS salary_calculations (
    calculation_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    salary_detail_id INT,
    pay_period_start_date DATE NOT NULL,
    pay_period_end_date DATE NOT NULL,
    base_salary_component DECIMAL(12,2) NOT NULL,
    hourly_rate_at_calculation DECIMAL(10,2) NOT NULL,
    working_days_in_period INT DEFAULT 0,
    total_worked_hours DECIMAL(10,2) DEFAULT 0.00,
    regular_hours_worked DECIMAL(10,2) DEFAULT 0.00,
    overtime_hours_worked DECIMAL(10,2) DEFAULT 0.00,
    regular_earnings DECIMAL(12,2) DEFAULT 0.00,
    overtime_earnings DECIMAL(12,2) DEFAULT 0.00,
    gross_earnings DECIMAL(12,2) NOT NULL,
    total_deductions DECIMAL(12,2) DEFAULT 0.00,
    total_allowances DECIMAL(12,2) DEFAULT 0.00,
    net_salary DECIMAL(12,2) NOT NULL,
    payment_status ENUM('Pending', 'Processing', 'Paid', 'Failed') DEFAULT 'Pending',
    payment_date DATE,
    notes TEXT,
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    calculated_by_admin_id INT,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    FOREIGN KEY (salary_detail_id) REFERENCES employee_salary_details(salary_detail_id) ON DELETE SET NULL,
    FOREIGN KEY (calculated_by_admin_id) REFERENCES admins(admin_id) ON DELETE SET NULL,
    UNIQUE KEY uk_emp_pay_period (emp_id, pay_period_start_date, pay_period_end_date),
    INDEX idx_pay_period (pay_period_start_date, pay_period_end_date),
    INDEX idx_payment_status (payment_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Salary Calculation Deductions (normalized)
$salaryCalculationDeductionsTableSQL = "CREATE TABLE IF NOT EXISTS salary_calculation_deductions (
    deduction_id INT AUTO_INCREMENT PRIMARY KEY,
    calculation_id INT NOT NULL,
    deduction_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    notes VARCHAR(255),
    FOREIGN KEY (calculation_id) REFERENCES salary_calculations(calculation_id) ON DELETE CASCADE,
    INDEX idx_calculation (calculation_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Salary Calculation Allowances (normalized)
$salaryCalculationAllowancesTableSQL = "CREATE TABLE IF NOT EXISTS salary_calculation_allowances (
    allowance_id INT AUTO_INCREMENT PRIMARY KEY,
    calculation_id INT NOT NULL,
    allowance_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    notes VARCHAR(255),
    FOREIGN KEY (calculation_id) REFERENCES salary_calculations(calculation_id) ON DELETE CASCADE,
    INDEX idx_calculation (calculation_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Leave Management (normalized)
$leaveManagementTableSQL = "CREATE TABLE IF NOT EXISTS leave_management (
    leave_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    number_of_days DECIMAL(4,1) NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Cancelled') DEFAULT 'Pending',
    reason TEXT,
    admin_comments TEXT,
    applied_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    action_by_admin_id INT,
    action_date DATETIME,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(leave_type_id),
    FOREIGN KEY (action_by_admin_id) REFERENCES admins(admin_id) ON DELETE SET NULL,
    INDEX idx_emp_dates (emp_id, start_date, end_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Employee Requests (normalized)
$employeeRequestsTableSQL = "CREATE TABLE IF NOT EXISTS employee_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    request_type_id INT NOT NULL,
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('Pending', 'In Progress', 'Resolved', 'Rejected', 'Closed') DEFAULT 'Pending',
    priority ENUM('Low', 'Medium', 'High', 'Urgent') DEFAULT 'Medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_by_admin_id INT,
    resolution_details TEXT,
    resolved_at DATETIME,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE,
    FOREIGN KEY (request_type_id) REFERENCES request_types(request_type_id),
    FOREIGN KEY (resolved_by_admin_id) REFERENCES admins(admin_id) ON DELETE SET NULL,
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Admin Activities Log (normalized)
$adminActivitiesTableSQL = "CREATE TABLE IF NOT EXISTS admin_activities_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    activity_type VARCHAR(100) NOT NULL,
    target_entity_type VARCHAR(50),
    target_entity_id INT,
    description TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(admin_id) ON DELETE CASCADE,
    INDEX idx_admin_activity (admin_id, created_at),
    INDEX idx_entity (target_entity_type, target_entity_id),
    INDEX idx_activity_type (activity_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// --- INITIAL DATA INSERTION ---

// Insert default departments
$insertDepartmentsSQL = "INSERT IGNORE INTO departments (dept_name, dept_code) VALUES 
    ('Administration', 'ADMIN'),
    ('Finance', 'FIN'),
    ('Human Resources', 'HR'),
    ('Information Technology', 'IT'),
    ('Marketing', 'MKT'),
    ('Operations', 'OPS'),
    ('Research and Development', 'RND'),
    ('Sales', 'SALES')";

// Insert default pay frequencies
$insertPayFrequenciesSQL = "INSERT IGNORE INTO pay_frequencies (frequency_name, frequency_code, days_per_period, periods_per_year) VALUES 
    ('Monthly', 'MONTHLY', 30, 12),
    ('Bi-Weekly', 'BIWEEKLY', 14, 26),
    ('Weekly', 'WEEKLY', 7, 52),
    ('Hourly', 'HOURLY', 1, 365)";

// Insert default benefit types
$insertBenefitTypesSQL = "INSERT IGNORE INTO benefit_types (type_name, type_code, is_mandatory) VALUES 
    ('Social Security System', 'SSS', TRUE),
    ('Pag-IBIG Fund', 'PAGIBIG', TRUE),
    ('PhilHealth', 'PHILHEALTH', TRUE),
    ('Tax Identification Number', 'TIN', TRUE),
    ('Health Insurance', 'HEALTH', FALSE),
    ('Life Insurance', 'LIFE', FALSE)";

// Insert default leave types
$insertLeaveTypesSQL = "INSERT IGNORE INTO leave_types (type_name, type_code, max_days_per_year, is_paid) VALUES 
    ('Casual Leave', 'CASUAL', 15, TRUE),
    ('Sick Leave', 'SICK', 15, TRUE),
    ('Earned Leave', 'EARNED', 30, TRUE),
    ('Unpaid Leave', 'UNPAID', NULL, FALSE),
    ('Vacation Leave', 'VACATION', 15, TRUE),
    ('Maternity Leave', 'MATERNITY', 105, TRUE),
    ('Paternity Leave', 'PATERNITY', 7, TRUE)";

// Insert default request types
$insertRequestTypesSQL = "INSERT IGNORE INTO request_types (type_name, type_code) VALUES 
    ('Document Request', 'DOC_REQ'),
    ('Information Update', 'INFO_UPD'),
    ('Equipment Request', 'EQUIP_REQ'),
    ('IT Support', 'IT_SUPP'),
    ('Payroll Inquiry', 'PAY_INQ'),
    ('Benefits Inquiry', 'BEN_INQ'),
    ('General Inquiry', 'GEN_INQ')";

// --- TABLE CREATION EXECUTION ---

echo "<h2>EPMS 3NF Database Creation Process</h2>";

if (!$conn) {
    die("<h3>Database connection failed. Cannot create tables.</h3>");
}

$tablesToCreate = [
    // Lookup tables first (for foreign key dependencies)
    ['departments', $departmentsTableSQL],
    ['job_titles', $jobTitlesTableSQL],
    ['pay_frequencies', $payFrequencyTableSQL],
    ['benefit_types', $benefitTypesTableSQL],
    ['leave_types', $leaveTypesTableSQL],
    ['request_types', $requestTypesTableSQL],
    
    // Core entity tables
    ['admins', $adminTableSQL],
    ['employees', $employeesTableSQL],
    ['employee_salary_details', $employeeSalaryDetailsTableSQL],
    ['employee_benefits', $employeeBenefitsTableSQL],
    ['attendance', $attendanceTableSQL],
    ['salary_calculations', $salaryCalculationsTableSQL],
    ['salary_calculation_deductions', $salaryCalculationDeductionsTableSQL],
    ['salary_calculation_allowances', $salaryCalculationAllowancesTableSQL],
    ['leave_management', $leaveManagementTableSQL],
    ['employee_requests', $employeeRequestsTableSQL],
    ['admin_activities_log', $adminActivitiesTableSQL]
];

$allSuccessful = true;
foreach ($tablesToCreate as $tableInfo) {
    $tableName = $tableInfo[0];
    $sql = $tableInfo[1];
    if (!createTable($conn, $tableName, $sql)) {
        $allSuccessful = false;
    }
}

// Insert initial data
if ($allSuccessful) {
    echo "<br><h3>Inserting initial lookup data...</h3>";
    
    $initialDataQueries = [
        $insertDepartmentsSQL,
        $insertPayFrequenciesSQL,
        $insertBenefitTypesSQL,
        $insertLeaveTypesSQL,
        $insertRequestTypesSQL
    ];
    
    foreach ($initialDataQueries as $query) {
        if (!mysqli_query($conn, $query)) {
            echo "Error inserting initial data: " . mysqli_error($conn) . "<br>";
            $allSuccessful = false;
        }
    }
}

if ($allSuccessful) {
    echo "<h3>✅ All tables created successfully and initial data inserted!</h3>";
    echo "<p>Database is now in 3rd Normal Form (3NF) with:</p>";
    echo "<ul>";
    echo "<li>✅ Eliminated repeating groups</li>";
    echo "<li>✅ Removed partial dependencies</li>";
    echo "<li>✅ Eliminated transitive dependencies</li>";
    echo "<li>✅ Proper lookup tables for reference data</li>";
    echo "<li>✅ Optimized indexes for better performance</li>";
    echo "</ul>";
} else {
    echo "<h3>❌ Some tables could not be created. Please check errors above.</h3>";
}

?>