<?php
// Start session (if not already started)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}

// Include database connection
require_once 'database.php'; 
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Critical: Database connection failed or $conn is not a mysqli object in edit_employee.php.");
    die("A critical database error occurred. Please contact support or check server logs.");
}

// Include admin functions (this should now contain getActiveDepartments and getOrCreateJobTitleId)
if (file_exists('admin_functions.php')) {
    require_once 'admin_functions.php';
} else {
    error_log("Critical: admin_functions.php not found, but required by edit_employee.php.");
    die("A required system file (admin_functions.php) is missing. Please contact support.");
}


$error = ''; 
$success_message_edit = ''; 

// CHECK 1: Employee ID from GET
if (!isset($_GET['emp_id']) || empty(trim($_GET['emp_id']))) {
    die("No employee ID provided or ID is empty.");
}

$emp_id_get = trim($_GET['emp_id']);

// CHECK 2: Validate emp_id
if (!filter_var($emp_id_get, FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]])) {
    die("Invalid employee ID format provided.");
}
$emp_id_clean = (int)$emp_id_get;


// --- Fetch Employee Core Details, Latest Salary, Department, Job Title ---
// (SQL and fetch logic remains the same as your last correct version for edit_employee.php)
$sql_fetch_employee = "SELECT e.*, 
                         d.dept_name, jt.title_name,
                         esd.base_salary, esd.hourly_rate, esd.freq_id, esd.effective_date as salary_effective_date
                  FROM employees e
                  LEFT JOIN departments d ON e.dept_id = d.dept_id
                  LEFT JOIN job_titles jt ON e.job_title_id = jt.job_title_id
                  LEFT JOIN (
                      SELECT esd_inner.* 
                      FROM employee_salary_details esd_inner
                      WHERE esd_inner.emp_id = ? AND esd_inner.is_current = TRUE
                      ORDER BY esd_inner.effective_date DESC, esd_inner.salary_detail_id DESC 
                      LIMIT 1
                  ) esd ON e.emp_id = esd.emp_id
                  WHERE e.emp_id = ?";

$stmt_fetch_employee = mysqli_prepare($conn, $sql_fetch_employee);
if(!$stmt_fetch_employee) {
    die("Prepare failed for fetching employee: " . mysqli_error($conn));
}
mysqli_stmt_bind_param($stmt_fetch_employee, "ii", $emp_id_clean, $emp_id_clean);
mysqli_stmt_execute($stmt_fetch_employee);
$result_fetch_employee = mysqli_stmt_get_result($stmt_fetch_employee);

if (!$result_fetch_employee) die("Error fetching employee data: " . mysqli_error($conn));
if (mysqli_num_rows($result_fetch_employee) == 0) die("Employee not found with ID: " . htmlspecialchars($emp_id_get));

$employee = mysqli_fetch_assoc($result_fetch_employee);
mysqli_stmt_close($stmt_fetch_employee);


// --- Fetch Employee's Current Benefits (3NF) ---
$employee_benefits_list = [];
$sql_get_benefits = "SELECT eb.benefit_id, eb.benefit_type_id, bt.type_name, bt.type_code, 
                            eb.id_number, eb.contribution_amount, eb.effective_date AS benefit_effective_date, eb.notes, eb.is_active as benefit_is_active
                     FROM employee_benefits eb
                     JOIN benefit_types bt ON eb.benefit_type_id = bt.benefit_type_id
                     WHERE eb.emp_id = ? AND eb.is_active = TRUE AND bt.is_active = TRUE 
                     ORDER BY bt.type_name";
$stmt_get_benefits = mysqli_prepare($conn, $sql_get_benefits);
if ($stmt_get_benefits) {
    mysqli_stmt_bind_param($stmt_get_benefits, "i", $emp_id_clean);
    mysqli_stmt_execute($stmt_get_benefits);
    $result_benefits = mysqli_stmt_get_result($stmt_get_benefits);
    while ($benefit_row = mysqli_fetch_assoc($result_benefits)) {
        $employee_benefits_list[] = $benefit_row;
    }
    mysqli_stmt_close($stmt_get_benefits);
} else {
    error_log("Error preparing to fetch employee benefits: " . mysqli_error($conn));
}


// --- Fetch lists for dropdowns ---
// THIS IS LINE 101 (or around it, depending on exact copy-paste) WHERE THE ERROR OCCURRED
$departmentsList_edit = getActiveDepartments($conn); // Now calls function from admin_functions.php

$payFrequenciesList_edit = [];
$pf_sql = "SELECT freq_id, frequency_name FROM pay_frequencies WHERE is_active = TRUE ORDER BY frequency_name";
$pf_res = mysqli_query($conn, $pf_sql);
if($pf_res) {
    while($pf_row = mysqli_fetch_assoc($pf_res)) $payFrequenciesList_edit[] = $pf_row;
    mysqli_free_result($pf_res);
}

$all_benefit_types_list = [];
$bt_sql = "SELECT benefit_type_id, type_name, type_code FROM benefit_types WHERE is_active = TRUE ORDER BY type_name";
$bt_res = mysqli_query($conn, $bt_sql);
if($bt_res){
    while($bt_r = mysqli_fetch_assoc($bt_res)) $all_benefit_types_list[] = $bt_r;
    mysqli_free_result($bt_res);
}


// Handle form submission for UPDATE
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_employee'])) {
    // ... (The entire POST handling block from your previous correct version of edit_employee.php)
    // This block should use getOrCreateJobTitleId which is also now in admin_functions.php
    $first_name = trim($_POST['first_name']);
    $last_name = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone'] ?? '');
    $hire_date = trim($_POST['hire_date']);
    $department_id_form = trim($_POST['department_id']);
    $job_title_name_form = trim($_POST['job_title_name']); 
    $is_active_form = isset($_POST['is_active']) ? 1 : 0;

    $base_salary_form = filter_var($_POST['base_salary'] ?? 0, FILTER_VALIDATE_FLOAT);
    $hourly_rate_form = filter_var($_POST['hourly_rate'] ?? 0, FILTER_VALIDATE_FLOAT);
    $freq_id_form = filter_var($_POST['freq_id'] ?? null, FILTER_VALIDATE_INT);
    $salary_effective_date_form = !empty($_POST['salary_effective_date']) ? trim($_POST['salary_effective_date']) : date('Y-m-d');

    $edit_errors = [];
    if (empty($first_name)) $edit_errors[] = "First name is required.";
    // ... (other validations)

    if (empty($edit_errors)) {
        mysqli_begin_transaction($conn);
        try {
            $actual_job_title_id_form = getOrCreateJobTitleId($conn, $job_title_name_form); 
            if ($actual_job_title_id_form === false) throw new Exception("Could not process job title.");

            $update_employee_sql = "UPDATE employees SET
                first_name = ?, last_name = ?, email = ?, phone = ?,
                hire_date = ?, dept_id = ?, job_title_id = ?, is_active = ?,
                updated_at = NOW()
            WHERE emp_id = ?";
            $stmt_update_emp = mysqli_prepare($conn, $update_employee_sql);
            mysqli_stmt_bind_param($stmt_update_emp, "sssssiisi", 
                $first_name, $last_name, $email, $phone, 
                $hire_date, $department_id_form, $actual_job_title_id_form, $is_active_form,
                $emp_id_clean);
            if (!mysqli_stmt_execute($stmt_update_emp)) throw new Exception("Error updating employee: " . mysqli_stmt_error($stmt_update_emp));
            mysqli_stmt_close($stmt_update_emp);

            // Salary Update
            $deactivate_old_salary_sql = "UPDATE employee_salary_details SET is_current = FALSE, end_date = ? 
                                          WHERE emp_id = ? AND is_current = TRUE AND effective_date < ?";
            $stmt_deactivate = mysqli_prepare($conn, $deactivate_old_salary_sql);
            $prev_day_effective = date('Y-m-d', strtotime($salary_effective_date_form . ' -1 day'));
            mysqli_stmt_bind_param($stmt_deactivate, "sis", $prev_day_effective, $emp_id_clean, $salary_effective_date_form);
            mysqli_stmt_execute($stmt_deactivate); 
            mysqli_stmt_close($stmt_deactivate);
            
            $insert_new_salary_sql = "INSERT INTO employee_salary_details
                (emp_id, base_salary, hourly_rate, freq_id, effective_date, is_current, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, TRUE, NOW(), NOW())";
            $stmt_salary = mysqli_prepare($conn, $insert_new_salary_sql);
            mysqli_stmt_bind_param($stmt_salary, "iddis", 
                $emp_id_clean, $base_salary_form, $hourly_rate_form, $freq_id_form, $salary_effective_date_form);
            if (!mysqli_stmt_execute($stmt_salary)) throw new Exception("Error saving salary: " . mysqli_stmt_error($stmt_salary));
            mysqli_stmt_close($stmt_salary);

            // Benefits Update
            if (isset($_POST['benefits']) && is_array($_POST['benefits'])) {
                foreach ($_POST['benefits'] as $idx => $benefit_data) {
                    $db_benefit_id_from_form = filter_var($benefit_data['benefit_id'] ?? null, FILTER_VALIDATE_INT);
                    $id_number_form = trim($benefit_data['id_number'] ?? '');
                    $contribution_form = isset($benefit_data['contribution_amount']) ? filter_var($benefit_data['contribution_amount'], FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE) : null;
                    $benefit_eff_date_form = trim($benefit_data['benefit_effective_date'] ?? '');
                    $benefit_notes_form = trim($benefit_data['notes'] ?? '');
                    $benefit_is_active_form = isset($benefit_data['is_active']) ? 1 : 0;

                    if ($db_benefit_id_from_form) { 
                        $update_benefit_sql = "UPDATE employee_benefits SET 
                                                   id_number = ?, contribution_amount = ?, effective_date = ?, notes = ?, is_active = ?,
                                                   updated_at = NOW()
                                               WHERE benefit_id = ? AND emp_id = ?";
                        $stmt_upd_ben = mysqli_prepare($conn, $update_benefit_sql);
                        if (!$stmt_upd_ben) throw new Exception("Prepare benefit update failed: ".mysqli_error($conn));
                        mysqli_stmt_bind_param($stmt_upd_ben, "sdssiii", 
                            $id_number_form, $contribution_form, $benefit_eff_date_form, $benefit_notes_form, $benefit_is_active_form,
                            $db_benefit_id_from_form, $emp_id_clean
                        );
                        if (!mysqli_stmt_execute($stmt_upd_ben)) throw new Exception("Exec benefit update for ID $db_benefit_id_from_form: ".mysqli_stmt_error($stmt_upd_ben));
                        mysqli_stmt_close($stmt_upd_ben);
                    }
                }
            }

            if (isset($_POST['new_benefit']) && !empty($_POST['new_benefit']['benefit_type_id'])) {
                $new_benefit_type_id = filter_var($_POST['new_benefit']['benefit_type_id'], FILTER_VALIDATE_INT);
                $new_id_number = trim($_POST['new_benefit']['id_number'] ?? '');
                $new_contribution = isset($_POST['new_benefit']['contribution_amount']) ? filter_var($_POST['new_benefit']['contribution_amount'], FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE) : 0.00;
                $new_eff_date = !empty($_POST['new_benefit']['benefit_effective_date']) ? trim($_POST['new_benefit']['benefit_effective_date']) : date('Y-m-d');
                $new_notes = trim($_POST['new_benefit']['notes'] ?? '');
                
                if ($new_benefit_type_id) {
                    $insert_new_ben_sql = "INSERT INTO employee_benefits 
                                            (emp_id, benefit_type_id, id_number, contribution_amount, effective_date, notes, is_active, created_at, updated_at)
                                           VALUES (?, ?, ?, ?, ?, ?, TRUE, NOW(), NOW())";
                    $stmt_ins_ben = mysqli_prepare($conn, $insert_new_ben_sql);
                    if (!$stmt_ins_ben) throw new Exception("Prepare new benefit insert failed: ".mysqli_error($conn));
                    mysqli_stmt_bind_param($stmt_ins_ben, "iisdss",
                        $emp_id_clean, $new_benefit_type_id, $new_id_number, $new_contribution, $new_eff_date, $new_notes
                    );
                    if (!mysqli_stmt_execute($stmt_ins_ben)) {
                        if(mysqli_errno($conn) == 1062) {
                             throw new Exception("Failed to add new benefit: This benefit type for this effective date might already exist.");
                        } else {
                            throw new Exception("Exec new benefit insert failed: ".mysqli_stmt_error($stmt_ins_ben));
                        }
                    }
                    mysqli_stmt_close($stmt_ins_ben);
                }
            }

            mysqli_commit($conn);
            $success_message_edit = "Employee details updated successfully!";
            if (function_exists('logAdminActivity')) {
                logAdminActivity($_SESSION['admin_id'], 'Employee Updated', "Updated details for employee ID: $emp_id_clean", 'Employee', $emp_id_clean);
            }
            
            // Re-fetch data to display updated values
            $stmt_refetch_emp_after_update = mysqli_prepare($conn, $sql_fetch_employee); // Use the same SELECT query
            mysqli_stmt_bind_param($stmt_refetch_emp_after_update, "ii", $emp_id_clean, $emp_id_clean);
            mysqli_stmt_execute($stmt_refetch_emp_after_update);
            $result_refetch_emp_after_update = mysqli_stmt_get_result($stmt_refetch_emp_after_update);
            $employee = mysqli_fetch_assoc($result_refetch_emp_after_update); 
            mysqli_stmt_close($stmt_refetch_emp_after_update);

            $employee_benefits_list = []; 
            $stmt_refetch_benefits_after_update = mysqli_prepare($conn, $sql_get_benefits);
            mysqli_stmt_bind_param($stmt_refetch_benefits_after_update, "i", $emp_id_clean);
            mysqli_stmt_execute($stmt_refetch_benefits_after_update);
            $result_refetch_benefits_after_update = mysqli_stmt_get_result($stmt_refetch_benefits_after_update);
            while ($benefit_row_refetch_after = mysqli_fetch_assoc($result_refetch_benefits_after_update)) {
                $employee_benefits_list[] = $benefit_row_refetch_after;
            }
            mysqli_stmt_close($stmt_refetch_benefits_after_update);

        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "Update failed: " . $e->getMessage();
        }
    } else {
        $error = "Please correct the following errors:<ul>";
        foreach($edit_errors as $e_err) $error .= "<li>".htmlspecialchars($e_err)."</li>";
        $error .= "</ul>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<!-- ... (Your HTML part remains the same as the last full code response for edit_employee.php) ... -->
<!-- Make sure the names of form fields (esp. for benefits) in HTML match what the PHP POST handling expects -->
<head>
    <meta charset="UTF-8">
    <title>Edit Employee - <?php echo htmlspecialchars($employee['first_name'] ?? '') . ' ' . htmlspecialchars($employee['last_name'] ?? ''); ?> - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; background-color: #f4f6f9; margin: 0; display: flex; min-height:100vh; }
        .sidebar { width: 250px; background-color: #2c3e50; color: white; padding: 20px; height: 100vh; position: fixed; left: 0; top: 0; box-sizing: border-box; display:flex; flex-direction:column; }
        .sidebar .logo-container { text-align:center; margin-bottom:20px;}
        .sidebar .logo-img { width:80px; height:80px; border-radius:50%; border:2px solid #f0c14b;}
        .sidebar .system-name { color: #f0c14b; text-align:center; font-size:0.9em; margin-top:5px; line-height:1.2;}
        .sidebar .nav-menu { list-style:none; padding:0; margin-top:20px; flex-grow:1;}
        .sidebar .nav-item a { color: #ecf0f1; text-decoration: none; display: flex; align-items:center; padding: 12px 15px; border-radius: 4px; transition: background-color 0.2s ease, padding-left 0.2s ease; }
        .sidebar .nav-item a:hover { background-color: #34495e; color: #f0c14b; }
        .sidebar .nav-item a i.fas { margin-right: 10px; width:20px; text-align:center; color:#f0c14b;}
        .sidebar .nav-item.logout { margin-top:auto; border-top:1px solid #34495e;}

        .main-content { margin-left: 250px; width: calc(100% - 250px); padding: 25px; box-sizing: border-box; }
        .main-content > h1 { color: #2c3e50; border-bottom: 2px solid #f0c14b; padding-bottom: 10px; margin-top: 0; margin-bottom: 25px; font-size:1.8rem; }
        .form-section { background-color: white; padding: 25px; margin-bottom: 25px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .form-section h2 { color: #34495e; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px; margin-top: 0; margin-bottom: 20px; font-size:1.4rem; }
        .form-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(300px, 1fr)); gap:20px;}
        .form-group { margin-bottom: 18px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 600; color: #555; font-size:0.9rem; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size:1rem; transition: border-color 0.2s ease; }
        .form-group input:focus, .form-group select:focus, .form-group textarea:focus { border-color: #f0c14b; outline: none; box-shadow: 0 0 0 2px rgba(240, 193, 75, 0.2); }
        .form-actions { display: flex; gap: 15px; margin-top: 25px; }
        .btn { padding: 10px 22px; border: none; border-radius: 5px; cursor: pointer; font-size: 1rem; font-weight:500; transition: all 0.2s ease; text-decoration:none; display:inline-flex; align-items:center; }
        .btn i.fas { margin-right:8px;}
        .btn-save { background-color: #27ae60; color: white; } .btn-save:hover { background-color: #229954; }
        .btn-cancel { background-color: #7f8c8d; color: white; } .btn-cancel:hover { background-color: #6c7a7b; }
        .message-banner { padding: 15px; border-radius: 5px; margin-bottom: 20px; border-left-width:5px; border-left-style:solid; }
        .success_message_edit { background-color: #e8f5e9; color: #2e7d32; border-color: #4caf50;}
        .error_message_edit { background-color: #ffebee; color: #c62828; border-color: #d32f2f;}
        .error_message_edit ul { margin:0; padding-left:20px;}
        .benefit-entry { border: 1px solid #eee; padding: 15px; margin-bottom: 15px; border-radius: 5px; }
        .benefit-entry h4 { margin-top:0; color: #3498db; }
        .add-benefit-section { border-top: 2px dashed #f0c14b; padding-top:20px; margin-top:20px; }
        .add-benefit-section h4 { margin-top:0; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo-container">
             <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img">
             <div class="system-name">Employment Payment<br>Management System</div>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="adminHome.php"><i class="fas fa-home"></i> Admin Home</a></li>
            <li class="nav-item"><a href="employee_details.php"><i class="fas fa-users"></i> Employee Details</a></li>
            <li class="nav-item"><a href="add_employee.php"><i class="fas fa-user-plus"></i> Add Employee</a></li>
            <li class="nav-item logout"><a href="adminLogin.php?logout=1"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>

    <div class="main-content">
        <h1>Edit Employee: <?php echo htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']); ?></h1>
        
        <?php if (!empty($error)): ?>
            <div class="message-banner error_message_edit"><?php echo $error; ?></div>
        <?php endif; ?>
        <?php if (!empty($success_message_edit)): ?>
            <div class="message-banner success_message_edit"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message_edit); ?></div>
        <?php endif; ?>

        <form method="POST" action="edit_employee.php?emp_id=<?php echo htmlspecialchars($emp_id_get); ?>">
            <input type="hidden" name="update_employee" value="1">
            
            <div class="form-section">
                <h2>Personal & Employment Information</h2>
                <div class="form-grid">
                    <div class="form-group"><label for="first_name">First Name</label><input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($employee['first_name'] ?? ''); ?>" required></div>
                    <div class="form-group"><label for="last_name">Last Name</label><input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($employee['last_name'] ?? ''); ?>" required></div>
                    <div class="form-group"><label for="email">Email</label><input type="email" id="email" name="email" value="<?php echo htmlspecialchars($employee['email'] ?? ''); ?>" required></div>
                    <div class="form-group"><label for="phone">Phone</label><input type="text" id="phone" name="phone" value="<?php echo htmlspecialchars($employee['phone'] ?? ''); ?>"></div>
                    <div class="form-group"><label for="hire_date">Hire Date</label><input type="date" id="hire_date" name="hire_date" value="<?php echo htmlspecialchars($employee['hire_date'] ?? ''); ?>" required></div>
                    <div class="form-group">
                        <label for="department_id">Department</label>
                        <select id="department_id" name="department_id" required>
                            <option value="">Select Department</option>
                            <?php foreach ($departmentsList_edit as $dept): ?>
                                <option value="<?php echo htmlspecialchars($dept['dept_id']); ?>" <?php echo (isset($employee['dept_id']) && $employee['dept_id'] == $dept['dept_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($dept['dept_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="job_title_name">Job Title</label>
                        <input type="text" id="job_title_name" name="job_title_name" value="<?php echo htmlspecialchars($employee['title_name'] ?? ''); ?>" required>
                    </div>
                     <div class="form-group">
                        <label for="is_active">Status</label>
                        <select id="is_active" name="is_active">
                            <option value="1" <?php echo ($employee['is_active'] ?? 1) == 1 ? 'selected' : ''; ?>>Active</option>
                            <option value="0" <?php echo ($employee['is_active'] ?? 1) == 0 ? 'selected' : ''; ?>>Inactive</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="form-section">
                <h2>Salary Information</h2>
                 <div class="form-grid">
                    <div class="form-group"><label for="base_salary">Base Salary</label><input type="number" step="0.01" id="base_salary" name="base_salary" value="<?php echo htmlspecialchars($employee['base_salary'] ?? '0.00'); ?>" required></div>
                    <div class="form-group"><label for="hourly_rate">Hourly Rate</label><input type="number" step="0.01" id="hourly_rate" name="hourly_rate" value="<?php echo htmlspecialchars($employee['hourly_rate'] ?? '0.00'); ?>" required></div>
                    <div class="form-group">
                        <label for="freq_id">Pay Frequency</label>
                        <select id="freq_id" name="freq_id" required>
                            <option value="">Select Pay Frequency</option>
                            <?php foreach ($payFrequenciesList_edit as $pf): ?>
                                <option value="<?php echo htmlspecialchars($pf['freq_id']); ?>" <?php echo (isset($employee['freq_id']) && $employee['freq_id'] == $pf['freq_id']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($pf['frequency_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group"><label for="salary_effective_date">Salary Effective Date</label><input type="date" id="salary_effective_date" name="salary_effective_date" value="<?php echo htmlspecialchars($employee['salary_effective_date'] ?? date('Y-m-d')); ?>" required></div>
                </div>
            </div>
            
            <div class="form-section">
                <h2>Benefits Management</h2>
                <div id="existing-benefits-container">
                    <?php if (!empty($employee_benefits_list)): ?>
                        <?php foreach ($employee_benefits_list as $idx => $benefit): ?>
                            <div class="benefit-entry" id="benefit-entry-<?php echo htmlspecialchars($benefit['benefit_id']); ?>">
                                <h4><?php echo htmlspecialchars($benefit['type_name']); ?> (Code: <?php echo htmlspecialchars($benefit['type_code']); ?>)</h4>
                                <input type="hidden" name="benefits[<?php echo $idx; ?>][benefit_id]" value="<?php echo htmlspecialchars($benefit['benefit_id']); ?>">
                                <input type="hidden" name="benefits[<?php echo $idx; ?>][benefit_type_id]" value="<?php echo htmlspecialchars($benefit['benefit_type_id']); ?>">
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label for="benefit_id_number_<?php echo $idx; ?>">ID Number:</label>
                                        <input type="text" id="benefit_id_number_<?php echo $idx; ?>" name="benefits[<?php echo $idx; ?>][id_number]" value="<?php echo htmlspecialchars($benefit['id_number'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="benefit_contrib_<?php echo $idx; ?>">Contribution Amount:</label>
                                        <input type="number" step="0.01" id="benefit_contrib_<?php echo $idx; ?>" name="benefits[<?php echo $idx; ?>][contribution_amount]" value="<?php echo htmlspecialchars($benefit['contribution_amount'] ?? '0.00'); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="benefit_eff_date_<?php echo $idx; ?>">Effective Date:</label>
                                        <input type="date" id="benefit_eff_date_<?php echo $idx; ?>" name="benefits[<?php echo $idx; ?>][benefit_effective_date]" value="<?php echo htmlspecialchars($benefit['benefit_effective_date'] ?? date('Y-m-d')); ?>">
                                    </div>
                                     <div class="form-group">
                                        <label for="benefit_is_active_<?php echo $idx; ?>">Active:</label>
                                        <select id="benefit_is_active_<?php echo $idx; ?>" name="benefits[<?php echo $idx; ?>][is_active]">
                                            <option value="1" <?php echo ($benefit['benefit_is_active'] ?? 1) == 1 ? 'selected' : ''; ?>>Yes</option>
                                            <option value="0" <?php echo ($benefit['benefit_is_active'] ?? 1) == 0 ? 'selected' : ''; ?>>No</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="benefit_notes_<?php echo $idx; ?>">Notes:</label>
                                    <textarea id="benefit_notes_<?php echo $idx; ?>" name="benefits[<?php echo $idx; ?>][notes]" rows="2"><?php echo htmlspecialchars($benefit['notes'] ?? ''); ?></textarea>
                                </div>
                                <hr style="margin-top:10px; margin-bottom:10px;">
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No active benefits currently assigned to this employee. You can add new ones below.</p>
                    <?php endif; ?>
                </div>

                <div class="add-benefit-section">
                    <h4>Add New Benefit</h4>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="new_benefit_type_id">Benefit Type:</label>
                            <select id="new_benefit_type_id" name="new_benefit[benefit_type_id]">
                                <option value="">-- Select New Benefit Type --</option>
                                <?php foreach ($all_benefit_types_list as $bt_new): ?>
                                    <option value="<?php echo htmlspecialchars($bt_new['benefit_type_id']); ?>">
                                        <?php echo htmlspecialchars($bt_new['type_name']); ?> (<?php echo htmlspecialchars($bt_new['type_code']); ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group"><label for="new_benefit_id_number">ID Number:</label><input type="text" id="new_benefit_id_number" name="new_benefit[id_number]"></div>
                        <div class="form-group"><label for="new_benefit_contribution">Contribution Amount:</label><input type="number" step="0.01" id="new_benefit_contribution" name="new_benefit[contribution_amount]" value="0.00"></div>
                        <div class="form-group"><label for="new_benefit_effective_date">Effective Date:</label><input type="date" id="new_benefit_effective_date" name="new_benefit[benefit_effective_date]" value="<?php echo date('Y-m-d'); ?>"></div>
                    </div>
                     <div class="form-group">
                        <label for="new_benefit_notes">Notes:</label>
                        <textarea id="new_benefit_notes" name="new_benefit[notes]" rows="2"></textarea>
                    </div>
                </div>
            </div>

            <div class="form-actions">
                <button type="submit" name="update_employee" class="btn btn-save"><i class="fas fa-save"></i> Save Changes</button>
                <a href="employee_details.php" class="btn btn-cancel"><i class="fas fa-times"></i> Cancel & Back to List</a>
            </div>
        </form>
    </div>
</body>
</html>