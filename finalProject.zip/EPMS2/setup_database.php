<?php
// Enhanced EPMS Database Setup Script
// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start output buffering for better control
ob_start();

// Set content type and charset
header('Content-Type: text/html; charset=utf-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EPMS Database Setup</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #f0c14b 0%, #e6b800 100%);
            padding: 30px;
            text-align: center;
            color: #333;
        }
        .header h1 {
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }
        .header p {
            margin: 10px 0 0 0;
            opacity: 0.8;
        }
        .content {
            padding: 30px;
        }
        .progress-bar {
            width: 100%;
            height: 20px;
            background-color: #f0f0f0;
            border-radius: 10px;
            overflow: hidden;
            margin: 20px 0;
        }
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, #4CAF50, #45a049);
            width: 0%;
            transition: width 0.3s ease;
        }
        .step {
            margin: 15px 0;
            padding: 15px;
            border-left: 4px solid #ddd;
            background: #f9f9f9;
            border-radius: 0 8px 8px 0;
        }
        .step.success {
            border-left-color: #4CAF50;
            background: #f0f8f0;
        }
        .step.error {
            border-left-color: #f44336;
            background: #fff0f0;
        }
        .step.processing {
            border-left-color: #2196F3;
            background: #f0f7ff;
        }
        .success-message {
            background: linear-gradient(135deg, #4CAF50, #45a049);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
        }
        .error-message {
            background: linear-gradient(135deg, #f44336, #d32f2f);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin: 20px 0;
            text-align: center;
        }
        .action-buttons {
            text-align: center;
            margin-top: 30px;
        }
        .btn {
            display: inline-block;
            padding: 12px 30px;
            margin: 0 10px;
            background: linear-gradient(135deg, #f0c14b, #e6b800);
            color: #333;
            text-decoration: none;
            border-radius: 25px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .btn-secondary {
            background: linear-gradient(135deg, #6c757d, #5a6268);
            color: white;
        }
        .info-box {
            background: #e3f2fd;
            border: 1px solid #2196F3;
            border-radius: 8px;
            padding: 15px;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏢 EPMS Database Setup</h1>
            <p>Employee Payroll Management System - Database Initialization</p>
        </div>
        
        <div class="content">
            <div class="info-box">
                <strong>📋 Setup Process:</strong> This will create a normalized 3NF database structure with lookup tables, core entities, and proper relationships for the EPMS system.
            </div>
            
            <div class="progress-bar">
                <div class="progress-fill" id="progressFill"></div>
            </div>
            
            <div id="setupSteps">
                <?php
                $steps = [
                    'Checking database connection...',
                    'Creating lookup tables...',
                    'Creating core entity tables...',
                    'Setting up relationships...',
                    'Inserting initial data...',
                    'Finalizing setup...'
                ];
                
                foreach ($steps as $index => $step) {
                    echo "<div class='step' id='step{$index}'>{$step}</div>";
                }
                ?>
            </div>
            
            <?php
            // Flush output to show progress
            ob_flush();
            flush();
            
            // Start the actual database setup process
            $setupSuccess = true;
            $errorMessages = [];
            
            try {
                // Step 1: Check database connection
                echo "<script>document.getElementById('step0').className = 'step processing';</script>";
                ob_flush(); flush();
                
                // Include database connection (without auto table creation)
                require_once 'database.php';
                
                if (!$conn) {
                    throw new Exception("Database connection failed. Please check your database configuration.");
                }
                
                echo "<script>document.getElementById('step0').className = 'step success';</script>";
                echo "<script>document.getElementById('progressFill').style.width = '16%';</script>";
                ob_flush(); flush();
                
                // Step 2-6: Execute table creation manually
                echo "<script>document.getElementById('step1').className = 'step processing';</script>";
                ob_flush(); flush();
                
                // Capture output from create_epms_tables.php
                ob_start();
                
                // Manually include the table creation without conflicts
                include 'create_epms_tables.php';
                
                $tableCreationOutput = ob_get_clean();
                
                // Check if table creation was successful
                if (strpos($tableCreationOutput, '✅ All tables created successfully') !== false) {
                    echo "<script>";
                    for ($i = 1; $i <= 5; $i++) {
                        echo "document.getElementById('step{$i}').className = 'step success';";
                        echo "document.getElementById('progressFill').style.width = '" . (16 + $i * 16) . "%';";
                    }
                    echo "</script>";
                    
                    echo "<div class='success-message'>";
                    echo "<h3>🎉 Database Setup Completed Successfully!</h3>";
                    echo "<p>All tables have been created and initial data has been inserted.</p>";
                    echo "<p>Your EPMS system is now ready to use!</p>";
                    echo "</div>";
                    
                    // Show detailed output in a collapsible section
                    echo "<details style='margin: 20px 0;'>";
                    echo "<summary style='cursor: pointer; font-weight: bold;'>📊 View Detailed Setup Log</summary>";
                    echo "<div style='background: #f5f5f5; padding: 15px; border-radius: 5px; margin-top: 10px; font-family: monospace; font-size: 12px;'>";
                    echo $tableCreationOutput;
                    echo "</div>";
                    echo "</details>";
                    
                } else {
                    throw new Exception("Table creation failed. Check the detailed log below.");
                }
                
            } catch (Exception $e) {
                $setupSuccess = false;
                $errorMessages[] = $e->getMessage();
                
                echo "<div class='error-message'>";
                echo "<h3>❌ Setup Failed</h3>";
                echo "<p>" . htmlspecialchars($e->getMessage()) . "</p>";
                echo "</div>";
                
                if (isset($tableCreationOutput)) {
                    echo "<details style='margin: 20px 0;'>";
                    echo "<summary style='cursor: pointer; font-weight: bold;'>🔍 View Error Details</summary>";
                    echo "<div style='background: #fff5f5; padding: 15px; border-radius: 5px; margin-top: 10px; font-family: monospace; font-size: 12px;'>";
                    echo $tableCreationOutput;
                    echo "</div>";
                    echo "</details>";
                }
            }
            ?>
            
            <div class="action-buttons">
                <?php if ($setupSuccess): ?>
                    <a href="index.php" class="btn">🚀 Go to Login Page</a>
                    <a href="adminLogin.php" class="btn btn-secondary">👨‍💼 Admin Login</a>
                <?php else: ?>
                    <button onclick="location.reload()" class="btn">🔄 Retry Setup</button>
                    <a href="database.php" class="btn btn-secondary">🔧 Check Database Config</a>
                <?php endif; ?>
            </div>
            
            <div class="info-box" style="margin-top: 30px;">
                <strong>📝 Next Steps:</strong>
                <ul style="margin: 10px 0; padding-left: 20px;">
                    <li>Access the admin panel to create your first admin account</li>
                    <li>Add departments and job titles through the admin interface</li>
                    <li>Start adding employees to the system</li>
                    <li>Configure payroll settings and benefit types</li>
                </ul>
            </div>
        </div>
    </div>
    
    <script>
        // Auto-scroll to bottom during setup
        window.scrollTo(0, document.body.scrollHeight);
    </script>
</body>
</html>