<?php
session_start();
require_once 'database.php'; // Ensures $conn is initialized
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Critical: Database connection failed in update_employee_details.php.");
    die("A critical database error occurred. Please contact support.");
}

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header("Location: employeeLogin.php"); // Assuming employee login page
    exit();
}

$success_message = '';
$error_message = '';
$emp_id = (int)$_SESSION['employee_id'];

// --- Fetch current employee core details ---
$query_emp = "SELECT emp_id, first_name, last_name, email, phone FROM employees WHERE emp_id = ?";
$stmt_emp = mysqli_prepare($conn, $query_emp);
if (!$stmt_emp) { die("Prepare failed (employee fetch): " . mysqli_error($conn)); }
mysqli_stmt_bind_param($stmt_emp, "i", $emp_id);
mysqli_stmt_execute($stmt_emp);
$result_emp = mysqli_stmt_get_result($stmt_emp);
$employee_data = mysqli_fetch_assoc($result_emp);
mysqli_stmt_close($stmt_emp);

if (!$employee_data) {
    // Should not happen if session is valid, but good to check
    session_destroy();
    header("Location: employeeLogin.php?error=invalid_session");
    exit();
}

// --- Fetch Employee's Current Benefits (3NF) ---
$employee_benefits_list = [];
$sql_get_benefits = "SELECT eb.benefit_id, eb.benefit_type_id, bt.type_name, bt.type_code, 
                            eb.id_number, eb.contribution_amount, eb.effective_date AS benefit_effective_date, eb.notes 
                     FROM employee_benefits eb
                     JOIN benefit_types bt ON eb.benefit_type_id = bt.benefit_type_id
                     WHERE eb.emp_id = ? AND eb.is_active = TRUE AND bt.is_active = TRUE
                     ORDER BY bt.type_name";
$stmt_get_benefits = mysqli_prepare($conn, $sql_get_benefits);
if ($stmt_get_benefits) {
    mysqli_stmt_bind_param($stmt_get_benefits, "i", $emp_id);
    mysqli_stmt_execute($stmt_get_benefits);
    $result_benefits = mysqli_stmt_get_result($stmt_get_benefits);
    while ($benefit_row = mysqli_fetch_assoc($result_benefits)) {
        $employee_benefits_list[$benefit_row['benefit_type_id']] = $benefit_row; // Key by type_id for easy access
    }
    mysqli_stmt_close($stmt_get_benefits);
} else {
    error_log("Error preparing to fetch employee benefits: " . mysqli_error($conn));
}

// Fetch all available benefit_types for adding new ones (if employee can add new types)
$all_benefit_types_list = [];
$bt_sql = "SELECT benefit_type_id, type_name, type_code FROM benefit_types WHERE is_active = TRUE ORDER BY type_name";
$bt_res = mysqli_query($conn, $bt_sql);
if($bt_res){
    while($bt_r = mysqli_fetch_assoc($bt_res)) $all_benefit_types_list[] = $bt_r;
    mysqli_free_result($bt_res);
}


// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email_form = trim($_POST['email']);
    $phone_form = trim($_POST['phone'] ?? '');

    // Validate inputs
    $form_errors = [];
    if (empty($email_form) || !filter_var($email_form, FILTER_VALIDATE_EMAIL)) {
        $form_errors[] = "A valid email address is required.";
    }
    // Add more validation for phone if needed

    if (empty($form_errors)) {
        mysqli_begin_transaction($conn);
        try {
            // Update employee personal details
            $update_emp_sql = "UPDATE employees SET email = ?, phone = ?, updated_at = NOW() WHERE emp_id = ?";
            $stmt_update_personal = mysqli_prepare($conn, $update_emp_sql);
            if (!$stmt_update_personal) throw new Exception("Prepare failed (update personal): " . mysqli_error($conn));
            mysqli_stmt_bind_param($stmt_update_personal, "ssi", $email_form, $phone_form, $emp_id);
            if (!mysqli_stmt_execute($stmt_update_personal)) throw new Exception("Execute failed (update personal): " . mysqli_stmt_error($stmt_update_personal));
            mysqli_stmt_close($stmt_update_personal);

            // Process benefits
            // This assumes a structure like: <input name="benefits[benefit_type_id_here][id_number]" ...>
            if (isset($_POST['benefits']) && is_array($_POST['benefits'])) {
                foreach ($_POST['benefits'] as $benefit_type_id_form => $benefit_data_form) {
                    $type_id = (int)$benefit_type_id_form;
                    $id_number_val = trim($benefit_data_form['id_number'] ?? '');
                    // Optional: contribution amount, effective date, notes if editable by employee
                    // $contribution_val = isset($benefit_data_form['contribution_amount']) ? filter_var($benefit_data_form['contribution_amount'], FILTER_VALIDATE_FLOAT, FILTER_NULL_ON_FAILURE) : null;
                    // $effective_date_val = trim($benefit_data_form['benefit_effective_date'] ?? date('Y-m-d'));

                    if (empty($id_number_val)) { // If ID number is cleared, consider deactivating or deleting
                        // For simplicity, let's assume clearing means deactivating if it exists
                        // Or if an employee cannot "remove" a mandatory benefit, then skip update if empty.
                        // $sql_deactivate_benefit = "UPDATE employee_benefits SET is_active = FALSE, updated_at = NOW() WHERE emp_id = ? AND benefit_type_id = ?";
                        // ... execute this ...
                        continue; // Skip if no ID number provided for an existing type
                    }

                    // Check if this benefit_type_id already exists for the employee
                    $current_benefit_for_type = $employee_benefits_list[$type_id] ?? null;

                    if ($current_benefit_for_type) { // Existing benefit for this type, so UPDATE
                        if ($current_benefit_for_type['id_number'] != $id_number_val /* || other fields changed */) {
                            $sql_update_benefit = "UPDATE employee_benefits SET id_number = ?, updated_at = NOW() 
                                                   WHERE emp_id = ? AND benefit_type_id = ? AND benefit_id = ?"; // Use benefit_id for specific record
                            $stmt_benefit_update = mysqli_prepare($conn, $sql_update_benefit);
                            if (!$stmt_benefit_update) throw new Exception("Prepare failed (benefit update): ".mysqli_error($conn));
                            mysqli_stmt_bind_param($stmt_benefit_update, "siii", $id_number_val, $emp_id, $type_id, $current_benefit_for_type['benefit_id']);
                            if(!mysqli_stmt_execute($stmt_benefit_update)) throw new Exception("Execute failed (benefit update): ".mysqli_stmt_error($stmt_benefit_update));
                            mysqli_stmt_close($stmt_benefit_update);
                        }
                    } else { // New benefit type for this employee, so INSERT
                        $sql_insert_benefit = "INSERT INTO employee_benefits 
                                               (emp_id, benefit_type_id, id_number, effective_date, is_active, created_at, updated_at) 
                                               VALUES (?, ?, ?, CURDATE(), TRUE, NOW(), NOW())"; // Default effective_date to today
                        $stmt_benefit_insert = mysqli_prepare($conn, $sql_insert_benefit);
                         if (!$stmt_benefit_insert) throw new Exception("Prepare failed (benefit insert): ".mysqli_error($conn));
                        mysqli_stmt_bind_param($stmt_benefit_insert, "iis", $emp_id, $type_id, $id_number_val);
                        if(!mysqli_stmt_execute($stmt_benefit_insert)) {
                             if(mysqli_errno($conn) == 1062) { // Unique constraint
                                throw new Exception("Failed to add benefit: A benefit of this type already exists.");
                             } else {
                                throw new Exception("Execute failed (benefit insert): ".mysqli_stmt_error($stmt_benefit_insert));
                             }
                        }
                        mysqli_stmt_close($stmt_benefit_insert);
                    }
                }
            }

            mysqli_commit($conn);
            $success_message = "Your details have been updated successfully!";
            
            // Re-fetch data to display updated values
            $stmt_emp_refetch = mysqli_prepare($conn, $query_emp);
            mysqli_stmt_bind_param($stmt_emp_refetch, "i", $emp_id);
            mysqli_stmt_execute($stmt_emp_refetch);
            $result_emp_refetch = mysqli_stmt_get_result($stmt_emp_refetch);
            $employee_data = mysqli_fetch_assoc($result_emp_refetch);
            mysqli_stmt_close($stmt_emp_refetch);

            $employee_benefits_list = []; // Clear and re-fetch
            $stmt_get_benefits_refetch = mysqli_prepare($conn, $sql_get_benefits);
            mysqli_stmt_bind_param($stmt_get_benefits_refetch, "i", $emp_id);
            mysqli_stmt_execute($stmt_get_benefits_refetch);
            $result_benefits_refetch = mysqli_stmt_get_result($stmt_get_benefits_refetch);
            while ($benefit_row_refetch = mysqli_fetch_assoc($result_benefits_refetch)) {
                $employee_benefits_list[$benefit_row_refetch['benefit_type_id']] = $benefit_row_refetch;
            }
            mysqli_stmt_close($stmt_get_benefits_refetch);

        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error_message = "Error updating details: " . $e->getMessage();
        }
    } else {
        $error_message = "Please correct the following errors: <ul>";
        foreach($form_errors as $fe) $error_message .= "<li>".htmlspecialchars($fe)."</li>";
        $error_message .= "</ul>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Your Details - EPMS</title>
    <!-- <link rel="stylesheet" href="css/style.css"> -->
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 20px; background-color: #f4f6f9; color: #333; }
        .container { max-width: 800px; margin: 20px auto; padding: 0; } /* Removed padding from container itself */
        .update-form { background-color: white; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .update-form h2 { text-align:center; color: #333; margin-top:0; margin-bottom:25px; font-size:1.8rem; }
        .form-section { margin-bottom: 30px; padding-bottom:20px; border-bottom: 1px solid #eee; }
        .form-section:last-of-type { margin-bottom:20px; border-bottom:none; padding-bottom:0;}
        .form-section h3 { margin-top: 0; color: #555; font-size:1.3rem; margin-bottom:20px; }
        .form-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(250px, 1fr)); gap:20px;}
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 600; font-size:0.9rem; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing:border-box; font-size:1rem; }
        .form-control:focus { border-color: #f0c14b; outline:none; box-shadow: 0 0 0 2px rgba(240,193,75,0.2);}
        .btn { padding: 10px 20px; border:none; border-radius:4px; cursor:pointer; font-size:1rem; font-weight:500; text-decoration:none; display:inline-flex; align-items:center; transition: background-color 0.2s;}
        .btn i { margin-right:8px;}
        .btn-update { background-color: #28a745; color: white; } .btn-update:hover { background-color: #218838; }
        .btn-secondary { background-color: #6c757d; color:white; } .btn-secondary:hover { background-color:#5a6268; }
        .form-actions { display:flex; justify-content:flex-end; gap:10px; margin-top:25px;}
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; border-left-width:5px; border-left-style:solid; }
        .alert-success { background-color: #e8f5e9; color: #155724; border-color: #4caf50; }
        .alert-danger { background-color: #f8d7da; color: #721c24; border-color: #dc3545; }
        .alert-danger ul { margin:0; padding-left:20px; list-style:disc;}
    </style>
</head>
<body>
    <div class="container">
        <div class="update-form">
            <h2><i class="fas fa-user-edit"></i> Update Your Details</h2>
            
            <?php if ($success_message): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></div>
            <?php endif; ?>
            
            <?php if ($error_message): ?>
                <div class="alert alert-danger"><?php echo $error_message; /* Contains HTML for list */ ?></div>
            <?php endif; ?>
            
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-section">
                    <h3>Personal Information</h3>
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="emp_id_display">Employee ID:</label>
                            <input type="text" id="emp_id_display" class="form-control" 
                                   value="<?php echo htmlspecialchars($employee_data['emp_id']); ?>" readonly disabled>
                        </div>
                        <div class="form-group">
                            <label for="name_display">Name:</label>
                            <input type="text" id="name_display" class="form-control" 
                                   value="<?php echo htmlspecialchars(trim($employee_data['first_name'] . ' ' . $employee_data['last_name'])); ?>" readonly disabled>
                        </div>
                        <div class="form-group">
                            <label for="email">Email Address:</label>
                            <input type="email" id="email" name="email" class="form-control" 
                                   value="<?php echo htmlspecialchars($employee_data['email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number:</label>
                            <input type="tel" id="phone" name="phone" class="form-control" 
                                   value="<?php echo htmlspecialchars($employee_data['phone'] ?? ''); ?>">
                        </div>
                    </div>
                </div>
                
                <div class="form-section">
                    <h3>Government Benefits Information</h3>
                    <p style="font-size:0.85em; color:#777; margin-bottom:15px;">Update your ID numbers for the following benefits. Contributions are managed by HR/Payroll.</p>
                    <?php foreach ($all_benefit_types_list as $benefit_type): 
                        $current_emp_benefit = $employee_benefits_list[$benefit_type['benefit_type_id']] ?? null;
                    ?>
                        <div class="form-group">
                            <label for="benefit_<?php echo htmlspecialchars($benefit_type['type_code']); ?>">
                                <?php echo htmlspecialchars($benefit_type['type_name']); ?> Number:
                            </label>
                            <input type="text" 
                                   id="benefit_<?php echo htmlspecialchars($benefit_type['type_code']); ?>" 
                                   name="benefits[<?php echo htmlspecialchars($benefit_type['benefit_type_id']); ?>][id_number]" 
                                   class="form-control" 
                                   value="<?php echo htmlspecialchars($current_emp_benefit['id_number'] ?? ''); ?>"
                                   placeholder="Enter your <?php echo htmlspecialchars($benefit_type['type_name']); ?> ID">
                            <!-- If you want to allow editing other fields like contribution_amount by employee (less common): -->
                            <!-- 
                            <input type="hidden" name="benefits[<?php //echo htmlspecialchars($benefit_type['benefit_type_id']); ?>][benefit_id]" value="<?php //echo htmlspecialchars($current_emp_benefit['benefit_id'] ?? ''); ?>">
                            <label for="benefit_contrib_<?php //echo htmlspecialchars($benefit_type['type_code']); ?>">Contribution:</label>
                            <input type="number" step="0.01" name="benefits[<?php //echo htmlspecialchars($benefit_type['benefit_type_id']); ?>][contribution_amount]" value="<?php //echo htmlspecialchars($current_emp_benefit['contribution_amount'] ?? '0.00'); ?>">
                            -->
                        </div>
                    <?php endforeach; ?>
                </div>
                
                <div class="form-actions">
                    <a href="employeeHome.php" class="btn btn-secondary"><i class="fas fa-times"></i> Cancel</a>
                    <button type="submit" class="btn btn-update"><i class="fas fa-save"></i> Update Details</button>
                </div>
            </form>
        </div>
    </div>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
</body>
</html>