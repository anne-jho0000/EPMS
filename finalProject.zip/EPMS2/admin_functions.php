<?php
// admin_functions.php

// Ensure database.php is included (which sets up $conn)
// This is important if any function here is called from a script 
// that hasn't already included database.php
if (!isset($conn) && file_exists('database.php')) {
    require_once 'database.php';
} elseif (!isset($conn)) {
    error_log("admin_functions.php: Database connection \$conn not found. Critical error.");
    // For a library file like this, it might be better to let calling scripts handle
    // the absence of $conn rather than dying here, but the functions will fail.
    // The instanceof mysqli checks within each function will handle it gracefully.
}


/**
 * Log an admin activity into the admin_activities_log table.
 * (Code for logAdminActivity, getRecentAdminActivities, getAllAdminActivities, updateAdminLastLogin
 *  remains the same as the previously corrected version of admin_functions.php - I'll include them for completeness)
 */
function logAdminActivity($admin_id, $activity_type, $description, $target_entity_type = null, $target_entity_id = null) {
    global $conn; 
    if (!$conn || !($conn instanceof mysqli)) { 
        error_log("logAdminActivity: Database connection is not available or invalid.");
        return false;
    }
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? null;
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? null;
    $sql = "INSERT INTO admin_activities_log (admin_id, activity_type, target_entity_type, target_entity_id, description, ip_address, user_agent, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) { error_log("logAdminActivity prepare failed: " . mysqli_error($conn)); return false; }
    mysqli_stmt_bind_param($stmt, "isssiss", $admin_id, $activity_type, $target_entity_type, $target_entity_id, $description, $ip_address, $user_agent);
    if (mysqli_stmt_execute($stmt)) { mysqli_stmt_close($stmt); return true; } 
    else { error_log("logAdminActivity execute failed: " . mysqli_stmt_error($stmt)); mysqli_stmt_close($stmt); return false; }
}

function getRecentAdminActivities($limit = 5) {
    global $conn;
    if (!$conn || !($conn instanceof mysqli)) { error_log("getRecentAdminActivities: DB connection invalid."); return false; }
    $sql = "SELECT aal.log_id, aal.activity_type, aal.description, aal.target_entity_type, aal.target_entity_id, aal.created_at, ad.full_name as admin_name
            FROM admin_activities_log aal JOIN admins ad ON aal.admin_id = ad.admin_id
            WHERE aal.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) ORDER BY aal.created_at DESC LIMIT ?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) { error_log("getRecentAdminActivities prepare failed: " . mysqli_error($conn)); return false; }
    mysqli_stmt_bind_param($stmt, "i", $limit);
    if (mysqli_stmt_execute($stmt)) {
        $result = mysqli_stmt_get_result($stmt); $activities = [];
        if ($result) { while ($row = mysqli_fetch_assoc($result)) { $activities[] = $row; } mysqli_free_result($result); }
        mysqli_stmt_close($stmt); return $activities;
    } else { error_log("getRecentAdminActivities execute failed: " . mysqli_stmt_error($stmt)); mysqli_stmt_close($stmt); return false; }
}

function getAllAdminActivities($page = 1, $perPage = 10) {
    global $conn;
    if (!$conn || !($conn instanceof mysqli)) { error_log("getAllAdminActivities: DB connection invalid."); return false; }
    $page = max(1, (int)$page); $perPage = max(1, (int)$perPage); $offset = ($page - 1) * $perPage;
    $countSql = "SELECT COUNT(*) as total FROM admin_activities_log";
    $countResult = mysqli_query($conn, $countSql);
    if (!$countResult) { error_log("getAllAdminActivities count query failed: " . mysqli_error($conn)); return false; }
    $totalCountRow = mysqli_fetch_assoc($countResult); $totalCount = $totalCountRow ? $totalCountRow['total'] : 0;
    mysqli_free_result($countResult);
    $sql = "SELECT aal.log_id, aal.activity_type, aal.description, aal.target_entity_type, aal.target_entity_id, aal.ip_address, aal.user_agent, aal.created_at, ad.full_name as admin_name
            FROM admin_activities_log aal JOIN admins ad ON aal.admin_id = ad.admin_id
            ORDER BY aal.created_at DESC LIMIT ?, ?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) { error_log("getAllAdminActivities prepare failed: " . mysqli_error($conn)); return false; }
    mysqli_stmt_bind_param($stmt, "ii", $offset, $perPage);
    if (mysqli_stmt_execute($stmt)) {
        $result = mysqli_stmt_get_result($stmt); $activities = [];
        if ($result) { while ($row = mysqli_fetch_assoc($result)) { $activities[] = $row; } mysqli_free_result($result); }
        mysqli_stmt_close($stmt);
        return ['activities' => $activities, 'total' => $totalCount, 'page' => $page, 'perPage' => $perPage, 'totalPages' => ($perPage > 0) ? ceil($totalCount / $perPage) : 0];
    } else { error_log("getAllAdminActivities execute failed: " . mysqli_stmt_error($stmt)); mysqli_stmt_close($stmt); return false; }
}

function updateAdminLastLogin($admin_id) {
    global $conn;
    if (!$conn || !($conn instanceof mysqli)) { error_log("updateAdminLastLogin: DB connection invalid."); return false; }
    $check_column_sql = "SELECT 1 FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'admins' AND column_name = 'last_login'";
    $col_res = mysqli_query($conn, $check_column_sql);
    if ($col_res && mysqli_num_rows($col_res) > 0) {
        mysqli_free_result($col_res);
        $sql = "UPDATE admins SET last_login = NOW() WHERE admin_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) { error_log("updateAdminLastLogin prepare failed: " . mysqli_error($conn)); return false; }
        mysqli_stmt_bind_param($stmt, "i", $admin_id);
        if (mysqli_stmt_execute($stmt)) { mysqli_stmt_close($stmt); return true; } 
        else { error_log("updateAdminLastLogin execute failed: " . mysqli_stmt_error($stmt)); mysqli_stmt_close($stmt); return false; }
    } else { if ($col_res) mysqli_free_result($col_res); return true; }
}


// --- ADDED HELPER FUNCTIONS FOR add_employee.php and edit_employee.php ---
if (!function_exists('getActiveDepartments')) {
    /** 
     * @param mysqli $db_conn The database connection object
     * @return array
     */
    function getActiveDepartments($db_conn) {
        $departments = [];
        if (!$db_conn || !($db_conn instanceof mysqli)) {
            error_log("getActiveDepartments: Invalid database connection provided.");
            return $departments;
        }
        $sql = "SELECT dept_id, dept_name FROM departments WHERE is_active = TRUE ORDER BY dept_name ASC";
        $result = mysqli_query($db_conn, $sql);
        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $departments[] = $row;
            }
            mysqli_free_result($result);
        } else {
            error_log("Error fetching departments in admin_functions: " . mysqli_error($db_conn));
        }
        return $departments;
    }
}

if (!function_exists('getOrCreateJobTitleId')) {
    /** 
     * @param mysqli $db_conn The database connection object
     * @param string $titleName The name of the job title
     * @return int|false The job_title_id or false on error
     */
    function getOrCreateJobTitleId($db_conn, $titleName) {
        if (!$db_conn || !($db_conn instanceof mysqli)) {
            error_log("getOrCreateJobTitleId: Invalid database connection provided.");
            return false;
        }
        if (empty($titleName)) { // Check if $titleName itself is empty before trim
            error_log("getOrCreateJobTitleId: Empty titleName initially provided.");
            return false;
        }
        $titleNameClean = trim($titleName);
        if (empty($titleNameClean)) { // Check again after trim
             error_log("getOrCreateJobTitleId: Cleaned titleName is empty.");
            return false;
        }

        // Check if job title exists
        $checkSql = "SELECT job_title_id FROM job_titles WHERE title_name = ?";
        $stmtCheck = mysqli_prepare($db_conn, $checkSql);
        if (!$stmtCheck) {
            error_log("getOrCreateJobTitleId - Prepare check failed: " . mysqli_error($db_conn));
            return false;
        }
        mysqli_stmt_bind_param($stmtCheck, "s", $titleNameClean);
        if (!mysqli_stmt_execute($stmtCheck)) {
            error_log("getOrCreateJobTitleId - Execute check failed: " . mysqli_stmt_error($stmtCheck));
            mysqli_stmt_close($stmtCheck);
            return false;
        }
        $resultCheck = mysqli_stmt_get_result($stmtCheck);
        $existingTitle = mysqli_fetch_assoc($resultCheck);
        mysqli_stmt_close($stmtCheck);

        if ($existingTitle) {
            return (int)$existingTitle['job_title_id'];
        } else {
            // Job title does not exist, create it
            $deptIdForNewTitle = null; 
            $insertSql = "INSERT INTO job_titles (title_name, dept_id, is_active, created_at) VALUES (?, ?, TRUE, NOW())";
            $stmtInsert = mysqli_prepare($db_conn, $insertSql);
            if (!$stmtInsert) {
                error_log("getOrCreateJobTitleId - Prepare insert failed: " . mysqli_error($db_conn));
                return false;
            }
            mysqli_stmt_bind_param($stmtInsert, "si", $titleNameClean, $deptIdForNewTitle); 
            if (mysqli_stmt_execute($stmtInsert)) {
                $newId = mysqli_insert_id($db_conn);
                mysqli_stmt_close($stmtInsert);
                return (int)$newId;
            } else {
                error_log("getOrCreateJobTitleId - Execute insert failed: " . mysqli_stmt_error($stmtInsert) . " for title: " . $titleNameClean);
                mysqli_stmt_close($stmtInsert);
                return false;
            }
        }
    }
}
?>