<?php
session_start();

// Include database connection
require_once 'database.php';
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Critical: Database connection failed in viewPayroll.php.");
    die("A critical database error occurred. Please contact support.");
}

// Check if employee is logged in (assuming this page is for employees)
if (!isset($_SESSION['employee_id'])) {
    header("Location: employeeLogin.php"); // Or your main employee login page
    exit();
}

$emp_id = (int)$_SESSION['employee_id'];
$employee = null; // Initialize
$salary_records_list = []; // Initialize
$filtered_salary_record = null; // Initialize

// Fetch basic employee details for display
$query_emp = "SELECT e.emp_id, e.first_name, e.last_name, d.dept_name, jt.title_name 
              FROM employees e
              LEFT JOIN departments d ON e.dept_id = d.dept_id
              LEFT JOIN job_titles jt ON e.job_title_id = jt.job_title_id
              WHERE e.emp_id = ?";
$stmt_emp = mysqli_prepare($conn, $query_emp);
if ($stmt_emp) {
    mysqli_stmt_bind_param($stmt_emp, "i", $emp_id);
    mysqli_stmt_execute($stmt_emp);
    $result_emp = mysqli_stmt_get_result($stmt_emp);
    $employee = mysqli_fetch_assoc($result_emp);
    mysqli_stmt_close($stmt_emp);
} else {
    error_log("Failed to prepare employee fetch query: " . mysqli_error($conn));
}

if (!$employee) { // If employee data couldn't be fetched
    // Potentially log out or show an error
    error_log("Could not fetch employee data for emp_id: " . $emp_id);
    // For simplicity, we'll allow the page to load but some info might be missing.
    $employee = ['first_name' => 'Employee', 'last_name' => '', 'dept_name' => 'N/A', 'title_name' => 'N/A', 'emp_id' => $emp_id];
}


// Get all salary calculation records for the employee, ordered by pay period
$sql_all_records = "SELECT *, 
                        YEAR(pay_period_start_date) as record_year, 
                        MONTH(pay_period_start_date) as record_month 
                    FROM salary_calculations 
                    WHERE emp_id = ? 
                    ORDER BY pay_period_start_date DESC";
$stmt_all_records = mysqli_prepare($conn, $sql_all_records);
if ($stmt_all_records) { // This is where your line 26 error likely occurred
    mysqli_stmt_bind_param($stmt_all_records, "i", $emp_id);
    mysqli_stmt_execute($stmt_all_records);
    $result_all_records = mysqli_stmt_get_result($stmt_all_records);
    if ($result_all_records) {
        while($row = mysqli_fetch_assoc($result_all_records)) {
            $salary_records_list[] = $row;
        }
        mysqli_free_result($result_all_records);
    } else {
        error_log("Failed to get result for all salary records: " . mysqli_stmt_error($stmt_all_records));
    }
    mysqli_stmt_close($stmt_all_records);
} else {
    error_log("Failed to prepare query for all salary records: " . mysqli_error($conn));
}


// Get current month and year for default filter
$current_month_num = date('n'); // Numeric month without leading zero
$current_year_val = date('Y');

// Handle filter submission from GET request
$filter_month_val = isset($_GET['month']) ? (int)$_GET['month'] : $current_month_num;
$filter_year_val = isset($_GET['year']) ? (int)$_GET['year'] : $current_year_val;

// Get filtered salary record for the selected month and year
$filtered_sql_query = "SELECT * FROM salary_calculations 
                       WHERE emp_id = ? 
                       AND MONTH(pay_period_start_date) = ? 
                       AND YEAR(pay_period_start_date) = ?
                       ORDER BY pay_period_start_date DESC LIMIT 1"; // Get the latest for that month if multiple
$stmt_filtered = mysqli_prepare($conn, $filtered_sql_query);
if ($stmt_filtered) {
    mysqli_stmt_bind_param($stmt_filtered, "iii", $emp_id, $filter_month_val, $filter_year_val);
    mysqli_stmt_execute($stmt_filtered);
    $result_filtered = mysqli_stmt_get_result($stmt_filtered);
    if ($result_filtered) {
        $filtered_salary_record = mysqli_fetch_assoc($result_filtered);
        mysqli_free_result($result_filtered);
    } else {
        error_log("Failed to get result for filtered salary record: " . mysqli_stmt_error($stmt_filtered));
    }
    mysqli_stmt_close($stmt_filtered);
} else {
    error_log("Failed to prepare query for filtered salary record: " . mysqli_error($conn));
}


// Month names array for display
$month_names_map = [
    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Payroll - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root { /* CSS Variables */
            --primary-color: #f0c14b; /* EPMS Yellow */
            --secondary-color: #3a3a3a; /* Dark Gray */
            --light-gray: #f4f6f9;
            --white: #ffffff;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --text-dark: #34495e;
            --border-color: #dee2e6;
        }
        body { font-family: 'Arial', sans-serif; margin: 0; background-color: var(--light-gray); color:var(--text-dark); line-height:1.6; }
        .top-header { background-color: var(--secondary-color); color: white; padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .logo-area { display: flex; align-items: center; }
        .logo-img-header { width: 50px; height: 50px; border-radius: 50%; border: 2px solid var(--primary-color); margin-right: 15px; }
        .system-brand h1 { font-size: 1.1em; margin:0; color: var(--primary-color); text-transform:uppercase; letter-spacing:1px;}
        .system-brand p { font-size: 0.8em; margin:0; color: #ccc; }
        .nav-link-back { background-color: var(--primary-color); color: var(--secondary-color); padding: 8px 15px; border-radius: 5px; text-decoration: none; font-weight: bold; display:inline-flex; align-items:center; }
        .nav-link-back i { margin-right: 5px; }
        .nav-link-back:hover { background-color: #e0b030; }

        .main-container { max-width: 900px; margin: 30px auto; padding: 25px; background-color: var(--white); border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .page-heading { text-align: center; font-size: 2rem; color: var(--text-dark); margin-bottom: 25px; }
        
        .filter-section { display: flex; flex-wrap: wrap; gap: 15px; margin-bottom: 30px; padding: 20px; background-color: #fdfdfd; border:1px solid var(--border-color); border-radius: 8px; align-items:flex-end; }
        .filter-group { flex: 1; min-width: 200px; }
        .filter-group label { display: block; margin-bottom: 8px; font-weight: 600; color: var(--secondary-color); }
        .filter-select { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; font-size: 1rem; }
        .btn-filter { padding: 10px 20px; background-color: var(--primary-color); color: var(--secondary-color); border: none; border-radius: 4px; cursor: pointer; font-weight: bold; transition: background-color 0.2s; font-size: 1rem; }
        .btn-filter:hover { background-color: #e0b030; }
        
        .payslip-display { margin-top: 30px; border: 1px solid var(--border-color); border-radius: 8px; overflow: hidden; background-color:var(--white); }
        .payslip-title { background-color: var(--primary-color); color: var(--secondary-color); padding: 15px; text-align: center; font-weight: bold; font-size: 1.3rem; }
        .payslip-content { padding: 25px; }
        .employee-details-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px 20px; margin-bottom: 25px; padding-bottom: 20px; border-bottom: 1px dashed #eee; }
        .detail-block strong { font-weight: 600; color: #555; display:block; font-size:0.9em; margin-bottom:3px;}
        .detail-block span { font-size: 1rem; }
        
        .salary-breakdown { margin-bottom: 25px; }
        .salary-breakdown h4 { font-size:1.2rem; color:var(--text-dark); margin-bottom:15px; border-bottom:1px solid #eee; padding-bottom:8px;}
        .breakdown-item { display: flex; justify-content: space-between; padding: 8px 0; font-size:1rem; border-bottom:1px solid #f9f9f9;}
        .breakdown-item:last-child{border-bottom:none;}
        .breakdown-item .label { color: #555; }
        .breakdown-item .value { font-weight: 600; }
        .net-pay-total { display: flex; justify-content: space-between; padding: 15px 0; margin-top:15px; border-top:2px solid var(--secondary-color); font-size:1.3rem; font-weight:bold; }
        .net-pay-total .value { color:var(--success-color); }

        .no-record-message { text-align: center; padding: 40px 20px; color: #777; background-color:#f9f9f9; border-radius:5px; }
        .no-record-message i { font-size: 2.5rem; color: #ccc; margin-bottom: 15px; display:block; }
        
        .print-button-area { text-align: center; margin-top: 25px; }
        .btn-print { background-color: var(--secondary-color); color:white; }
        .btn-print:hover { background-color: #555; }

        .history-section { margin-top: 40px; }
        .history-section h3 { text-align:center; font-size:1.5rem; margin-bottom:20px; padding-bottom:10px; border-bottom:2px solid var(--primary-color);}
        .history-table { width: 100%; border-collapse: collapse; font-size:0.9rem; }
        .history-table th, .history-table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        .history-table th { background-color: #e9ecef; font-weight: 600; }
        .history-table tr:nth-child(even) { background-color: #f8f9fa; }
        .status-badge { padding: .3em .6em; font-size: 0.8em; font-weight: 700; border-radius: .25rem; color:#fff; }
        .status-Pending { background-color: var(--warning-color); color:var(--text-dark); }
        .status-Paid { background-color: var(--success-color); }
        .status-Processing { background-color: var(--info-color); }
        .status-Failed { background-color: var(--danger-color); }
        
        @media print {
            body { background-color: white; padding:0; margin:0;}
            .top-header, .nav-link-back, .filter-section, .btn-print, .history-section, .main-container > .page-heading { display: none !important; }
            .main-container { box-shadow: none; margin: 0; padding: 0; max-width:100%;}
            .payslip-display { border: none; margin-top:0; }
            .payslip-title { background-color: #eee !important; color:black !important; font-size:1.5rem;} /* Ensure print styles are simple */
            @page { margin: 20mm; }
        }
    </style>
</head>
<body>
    <div class="top-header">
        <div class="logo-area">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img-header">
            <div class="system-brand">
                <h1>EPMS</h1>
                <p>Employee Payroll</p>
            </div>
        </div>
        <a href="employeeHome.php" class="nav-link-back"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </div>
    
    <div class="main-container">
        <h1 class="page-heading">My Payroll Information</h1>
        
        <form method="GET" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="filter-section">
            <div class="filter-group">
                <label for="month">Month:</label>
                <select id="month" name="month" class="filter-select">
                    <?php foreach ($month_names_map as $num => $name): ?>
                        <option value="<?php echo $num; ?>" <?php echo ($filter_month_val == $num) ? 'selected' : ''; ?>>
                            <?php echo $name; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="filter-group">
                <label for="year">Year:</label>
                <select id="year" name="year" class="filter-select">
                    <?php for ($y_option = date('Y'); $y_option >= date('Y') - 5; $y_option--): ?>
                        <option value="<?php echo $y_option; ?>" <?php echo ($filter_year_val == $y_option) ? 'selected' : ''; ?>>
                            <?php echo $y_option; ?>
                        </option>
                    <?php endfor; ?>
                </select>
            </div>
            <button type="submit" class="btn-filter"><i class="fas fa-filter"></i> View Payslip</button>
        </form>
        
        <div class="payslip-display">
            <div class="payslip-title">
                Payslip for <?php echo htmlspecialchars($month_names_map[$filter_month_val] ?? 'N/A'); ?> <?php echo htmlspecialchars($filter_year_val); ?>
            </div>
            <div class="payslip-content">
                <?php if ($filtered_salary_record): ?>
                    <div class="employee-details-grid">
                        <div class="detail-block"><strong>Employee ID:</strong> <span><?php echo htmlspecialchars($employee['emp_id']); ?></span></div>
                        <div class="detail-block"><strong>Name:</strong> <span><?php echo htmlspecialchars(trim($employee['first_name'] . ' ' . $employee['last_name'])); ?></span></div>
                        <div class="detail-block"><strong>Department:</strong> <span><?php echo htmlspecialchars($employee['dept_name'] ?? 'N/A'); ?></span></div>
                        <div class="detail-block"><strong>Position:</strong> <span><?php echo htmlspecialchars($employee['title_name'] ?? 'N/A'); ?></span></div>
                        <div class="detail-block"><strong>Pay Period:</strong> <span><?php echo date('M d, Y', strtotime($filtered_salary_record['pay_period_start_date'])) . " - " . date('M d, Y', strtotime($filtered_salary_record['pay_period_end_date'])); ?></span></div>
                    </div>
                    
                    <div class="salary-breakdown">
                        <h4>Earnings & Deductions</h4>
                        <div class="breakdown-item"><span class="label">Base Salary Component:</span> <span class="value">₱<?php echo number_format($filtered_salary_record['base_salary_component'], 2); ?></span></div>
                        <div class="breakdown-item"><span class="label">Regular Earnings (from hours):</span> <span class="value">₱<?php echo number_format($filtered_salary_record['regular_earnings'], 2); ?></span></div>
                        <div class="breakdown-item"><span class="label">Overtime Earnings:</span> <span class="value">₱<?php echo number_format($filtered_salary_record['overtime_earnings'], 2); ?></span></div>
                        <div class="breakdown-item"><span class="label">Total Allowances:</span> <span class="value">₱<?php echo number_format($filtered_salary_record['total_allowances'], 2); ?></span></div>
                        <hr style="margin: 10px 0;">
                        <div class="breakdown-item" style="font-weight:bold;"><span class="label">Gross Earnings:</span> <span class="value">₱<?php echo number_format($filtered_salary_record['gross_earnings'], 2); ?></span></div>
                        <div class="breakdown-item"><span class="label">Total Deductions:</span> <span class="value" style="color:var(--danger-color);">- ₱<?php echo number_format($filtered_salary_record['total_deductions'], 2); ?></span></div>
                    </div>
                    
                    <div class="net-pay-total">
                        <span class="label">Net Salary Payable:</span> 
                        <span class="value">₱<?php echo number_format($filtered_salary_record['net_salary'], 2); ?></span>
                    </div>
                    <div class="print-button-area">
                        <button class="btn btn-print" onclick="window.print()"><i class="fas fa-print"></i> Print This Payslip</button>
                    </div>
                <?php else: ?>
                    <div class="no-record-message">
                        <i class="fas fa-exclamation-circle"></i>
                        <p>No salary record found for <?php echo htmlspecialchars($month_names_map[$filter_month_val] ?? 'N/A'); ?> <?php echo htmlspecialchars($filter_year_val); ?>.</p>
                        <p><small>If you believe this is an error, please contact HR or your administrator.</small></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <div class="history-section">
            <h3>Salary History</h3>
            <?php if (!empty($salary_records_list)): ?>
                <table class="history-table">
                    <thead>
                        <tr>
                            <th>Pay Period Start</th>
                            <th>Pay Period End</th>
                            <th>Gross Earnings</th>
                            <th>Net Salary</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($salary_records_list as $record_item): ?>
                            <tr>
                                <td><?php echo date('M d, Y', strtotime($record_item['pay_period_start_date'])); ?></td>
                                <td><?php echo date('M d, Y', strtotime($record_item['pay_period_end_date'])); ?></td>
                                <td>₱<?php echo number_format($record_item['gross_earnings'], 2); ?></td>
                                <td>₱<?php echo number_format($record_item['net_salary'], 2); ?></td>
                                <td><span class="status-badge status-<?php echo htmlspecialchars(str_replace(' ', '', $record_item['payment_status'])); ?>"><?php echo htmlspecialchars($record_item['payment_status']); ?></span></td>
                                <td>
                                    <a href="?month=<?php echo date('n', strtotime($record_item['pay_period_start_date'])); ?>&year=<?php echo date('Y', strtotime($record_item['pay_period_start_date'])); ?>" class="btn-scanner btn-filter" style="padding:5px 10px; font-size:0.8em;">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-record-message" style="background:none;">No salary history found.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

<?php
if (isset($conn) && $conn instanceof mysqli) {
    mysqli_close($conn);
}
?>