<?php
// Start session FIRST
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Include database connection file
require_once 'database.php';
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Critical: Database connection failed in employeeHome.php.");
    die("A critical database error occurred. Please contact support.");
}

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header("Location: employeeLogin.php"); // Assuming this is your employee login page
    exit();
}

$employeeId = (int)$_SESSION['employee_id']; // Cast to int
$employeeData = null; // Initialize

// Get employee details from database (first_name, last_name, and job title name)
$stmt_emp = $conn->prepare("SELECT e.first_name, e.last_name, jt.title_name 
                            FROM employees e 
                            LEFT JOIN job_titles jt ON e.job_title_id = jt.job_title_id
                            WHERE e.emp_id = ?");
if ($stmt_emp) {
    $stmt_emp->bind_param("i", $employeeId);
    $stmt_emp->execute();
    $result_emp = $stmt_emp->get_result();
    if ($result_emp->num_rows > 0) {
        $employeeData = $result_emp->fetch_assoc();
        // Construct full name for display
        $employeeData['full_name'] = trim(($employeeData['first_name'] ?? '') . ' ' . ($employeeData['last_name'] ?? ''));
        $employeeData['position'] = $employeeData['title_name'] ?? 'Staff'; // Use title_name as position
    }
    $stmt_emp->close();
} else {
    error_log("Prepare failed for fetching employee data: " . $conn->error);
}

if (!$employeeData) {
    // Handle the case when employee data is not found (e.g., session tampering or DB issue)
    error_log("Employee data not found for emp_id: " . $employeeId . " in employeeHome.php. Destroying session.");
    session_destroy();
    header("Location: employeeLogin.php?error=invalid_session_data");
    exit();
}

// --- Get attendance data for current month ---
$attendanceRate = 0; 
$currentMonth = date('m'); // e.g., '03'
$currentMonthNumeric = date('n'); // e.g., 3
$currentYear = date('Y');

$checkAttendanceQuery = "SHOW TABLES LIKE 'attendance'";
$attendanceTableResult = $conn->query($checkAttendanceQuery);

if ($attendanceTableResult && $attendanceTableResult->num_rows > 0) {
    // Query to get total entries and present days for the current month
    $attendanceQuery = $conn->prepare("SELECT 
                                          COUNT(DISTINCT attendance_date) as total_recorded_days, 
                                          SUM(CASE WHEN status = 'Present' THEN 1 ELSE 0 END) as present_days
                                       FROM attendance
                                       WHERE emp_id = ? AND MONTH(attendance_date) = ? AND YEAR(attendance_date) = ?");
    
    if ($attendanceQuery) {
        $attendanceQuery->bind_param("iii", $employeeId, $currentMonthNumeric, $currentYear);
        $attendanceQuery->execute();
        $attendanceResult = $attendanceQuery->get_result();
        $attendanceData = $attendanceResult->fetch_assoc();
        $attendanceQuery->close();
        
        // For rate, it's better to compare against expected work days, but this is based on recorded days
        $totalRecordedDays = $attendanceData && isset($attendanceData['total_recorded_days']) ? (int)$attendanceData['total_recorded_days'] : 0;
        $presentDays = $attendanceData && isset($attendanceData['present_days']) ? (int)$attendanceData['present_days'] : 0;
        
        // A more accurate 'total_days' would be the number of working days in the month so far.
        // For simplicity now, if there are recorded days, we use that.
        $attendanceRate = $totalRecordedDays > 0 ? ($presentDays / $totalRecordedDays) * 100 : 0;
    } else {
        error_log('Prepare failed for attendance query: ' . $conn->error);
    }
} else {
    error_log('Table attendance does not exist in database');
}

// --- Get leave balance ---
$leaveBalance = 0; 
$totalAnnualLeave = 30; // Assuming 30 days of leave per year (make this configurable)

$leaveQuery = $conn->prepare("SELECT SUM(number_of_days) as used_leave_days 
                              FROM leave_management 
                              WHERE emp_id = ? AND status = 'Approved' AND YEAR(start_date) = ?");
if ($leaveQuery) {
    $leaveQuery->bind_param("is", $employeeId, $currentYear); // Year is string for YEAR()
    $leaveQuery->execute();
    $leaveResult = $leaveQuery->get_result();
    $leaveData = $leaveResult->fetch_assoc();
    $leaveQuery->close();
    
    $usedLeaveDays = $leaveData && isset($leaveData['used_leave_days']) ? (float)$leaveData['used_leave_days'] : 0;
    $leaveBalance = $totalAnnualLeave - $usedLeaveDays;
} else {
    error_log('Prepare failed for leave calculation: ' . $conn->error);
}

// --- Get pending GENERAL requests (from employee_requests table) ---
$pendingGeneralRequests = 0; 
$requestQuery = $conn->prepare("SELECT COUNT(*) as pending_count FROM employee_requests 
                                WHERE emp_id = ? AND status = 'Pending'");
if ($requestQuery) {
    $requestQuery->bind_param("i", $employeeId);
    $requestQuery->execute();
    $requestResult = $requestQuery->get_result();
    $requestData = $requestResult->fetch_assoc();
    $requestQuery->close();
    $pendingGeneralRequests = $requestData['pending_count'] ?? 0;
} else {
    error_log('Prepare failed for pending general requests: ' . $conn->error);
}


// --- Get calendar data for current month ---
$calendarData = []; 
if ($attendanceTableResult && $attendanceTableResult->num_rows > 0) { // Re-check if table exists
    $calendarQuery = $conn->prepare("SELECT attendance_date, status FROM attendance 
                                     WHERE emp_id = ? AND MONTH(attendance_date) = ? AND YEAR(attendance_date) = ?");
    if ($calendarQuery) {
        $calendarQuery->bind_param("iii", $employeeId, $currentMonthNumeric, $currentYear);
        $calendarQuery->execute();
        $calendarResult = $calendarQuery->get_result();
        while ($row = $calendarResult->fetch_assoc()) {
            $dayOfMonth = date('j', strtotime($row['attendance_date'])); // Day of the month (1-31)
            $calendarData[$dayOfMonth] = strtolower($row['status']); // Store status, e.g., 'present', 'absent'
        }
        $calendarQuery->close();
    } else {
        error_log('Prepare failed for calendar query: ' . $conn->error);
    }
}
$monthNameForCalendar = date('F', mktime(0, 0, 0, $currentMonthNumeric, 1, $currentYear));

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EPMS Employee Portal - <?php echo htmlspecialchars($employeeData['full_name']); ?></title>
    <!-- <link rel="stylesheet" href="css/style.css"> IF YOU HAVE A CENTRAL CSS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <style>
    /* Using the CSS from your employeeHome.php provided in the prompt - Minor adjustments for clarity */
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    body { background-color: #f5f5f5; color: #333; min-height: 100vh; }
    .container { display: flex; min-height: 100vh; }
    .sidebar { width: 250px; background-color: #333; color: #fff; display: flex; flex-direction: column; position: fixed; height: 100vh; overflow-y: auto; }
    .logo-container { padding: 20px; display: flex; flex-direction: column; align-items: center; background-color: #444; text-align: center; }
    .logo-container img { width: 70px; height: auto; margin-bottom: 10px; border-radius:50%; border:2px solid #FFD700;}
    .company-name h3 { font-size: 14px; font-weight: 500; margin-bottom: 5px; line-height: 1.2; color:#FFD700; }
    .company-name h2 { font-size: 18px; color: #FFD700; font-weight: 700; display:none; /* EPMS can be part of h3 */ }
    .profile-section { padding: 20px; border-bottom: 1px solid #444; position: relative; }
    .profile-highlight { position: absolute; top: 10px; left: 0; background-color: #FFD700; color: #333; padding: 5px 10px; border-radius: 0 20px 20px 0; font-size: 13px; font-weight: 600; }
    .profile-section h2 { margin-top: 20px; font-size: 1.1rem; margin-bottom: 5px; color: #FFD700; } /* Adjusted font size */
    .profile-section p { color: #ccc; font-size: 0.9rem; } /* Adjusted font size */
    .main-nav { padding: 10px 0; flex-grow: 1; }
    .main-nav ul { list-style-type: none; padding-left:0; }
    .main-nav li { padding: 0; margin-bottom: 2px; /* Reduced margin */ }
    .main-nav a { display: flex; align-items: center; padding: 10px 20px; /* Adjusted padding */ color: #ccc; text-decoration: none; transition: all 0.3s; font-size:0.95rem;}
    .main-nav a:hover { background-color: #4a4a4a; color: #FFD700; }
    .main-nav li.active a { background-color: #555; color: #FFD700; border-left: 4px solid #FFD700; padding-left:16px; }
    .main-nav i.fas { margin-right: 12px; width: 20px; text-align: center; } /* Targeted FontAwesome */
    .main-content { flex: 1; margin-left: 250px; padding: 25px; }
    header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; padding: 0 10px; }
    header h1 { font-size: 1.8rem; color: #444; } /* Adjusted font size */
    .new-request-btn .btn { background-color: #FFD700; color: #333; border: none; padding: 10px 18px; border-radius: 5px; cursor: pointer; font-weight: 600; text-decoration: none; display: inline-flex; align-items: center; transition: all 0.3s; }
    .new-request-btn .btn:hover { background-color: #E5C100; }
    .new-request-btn .btn i { margin-right: 8px; }
    .dashboard-tiles { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px; }
    .tile { background-color: #fff; border-radius: 8px; padding: 25px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 3px 10px rgba(0,0,0,0.07); position: relative; overflow: hidden; }
    .tile-content { z-index: 1; }
    .tile h2 { font-size: 1rem; margin-bottom: 8px; color: #555; font-weight:600; } /* Adjusted */
    .tile-value { font-size: 2.2rem; font-weight: 700; margin-bottom: 5px; color: #333; } /* Adjusted */
    .tile-label { font-size: 0.85rem; color: #28a745; } /* Adjusted */
    .tile-icon { width: 50px; height: 50px; border-radius: 50%; display: flex; justify-content: center; align-items: center; font-size: 1.5rem; z-index: 1; } /* Adjusted */
    .user-icon { background-color: rgba(255, 215, 0, 0.15); color: #FFD700; }
    .calendar-icon { background-color: rgba(66, 139, 202, 0.15); color: #428bca; }
    .clock-icon { background-color: rgba(255,152,0, 0.15); color: #ff9800; } /* Changed color */
    .calendar-section { background-color: #fff; border-radius: 8px; padding: 25px; box-shadow: 0 3px 10px rgba(0,0,0,0.07); }
    .calendar-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }
    .calendar-header h2 { font-size: 1.3rem; color: #555; } /* Adjusted */
    .view-history { color: #428bca; text-decoration: none; font-size:0.9rem; }
    .view-history:hover { text-decoration: underline; }
    .calendar { width: 100%; border-collapse: collapse; margin-bottom: 15px; }
    .calendar th, .calendar td { text-align: center; padding: 8px; width: 14.28%; font-size:0.9rem;} /* Adjusted */
    .calendar th { font-weight: 600; color: #555; }
    .calendar td { border: 1px solid #f0f0f0; height: 60px; vertical-align: middle; font-weight: 500; position:relative;} /* Adjusted height */
    .calendar td.current-day { background-color: #FFD700 !important; color: #333 !important; font-weight: bold; border:1px solid #e0b030;}
    .calendar td.status-present { background-color: #e8f5e9; color:#2e7d32; }
    .calendar td.status-absent { background-color: #ffebee; color:#c62828; }
    .calendar td.status-leave { background-color: #e1f5fe; color:#0277bd;}
    .calendar td.status-half-day { background-image: linear-gradient(45deg, #e8f5e9 50%, #fff3e0 50%); color:#e65100; } /* Example for half-day */
    .calendar-legend { display: flex; justify-content: center; gap: 15px; margin-top: 15px; flex-wrap:wrap; }
    .legend-item { display: flex; align-items: center; font-size: 0.85rem; color: #555; }
    .legend-mark { width: 10px; height: 10px; margin-right: 6px; display: inline-block; border-radius: 50%; }
    .legend-mark.present { background-color: #28a745; }
    .legend-mark.absent { background-color: #dc3545; }
    .legend-mark.leave { background-color: #17a2b8; }
    .legend-mark.half-day { background-color: #ffc107; }
    @media (max-width: 992px) { .dashboard-tiles { grid-template-columns: 1fr; } }
    @media (max-width: 768px) { .container { flex-direction: column; } .sidebar { width: 100%; height: auto; position: relative; } .main-content { margin-left: 0; } .calendar th, .calendar td { padding: 5px; height:45px;} header {flex-direction:column; gap:10px;} }
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
            <div class="logo-container">
                <img src="images/epms(logo).jpg" alt="EPMS Logo"> <!-- Ensure path to logo is correct -->
                <div class="company-name">
                    <h3>Employment Payment<br>Management System</h3>
                </div>
            </div>
            <div class="profile-section">
                <div class="profile-highlight">Employee</div>
                <h2><?php echo htmlspecialchars($employeeData['full_name']); ?></h2>
                <p><?php echo htmlspecialchars($employeeData['position']); ?></p>
            </div>
            <nav class="main-nav">
                <ul>
                    <li class="active"><a href="employeeHome.php"><i class="fas fa-home"></i> Employee Home</a></li>
                    <li><a href="attendance_scanner.php"><i class="fas fa-qrcode"></i> Scan QR / Log</a></li> <!-- Changed Icon & Text -->
                    <li><a href="update_employee_details.php"><i class="fas fa-user-edit"></i> Update My Details</a></li>
                    <li><a href="employee_request.php"><i class="fas fa-clipboard-list"></i> My Requests</a></li>
                    <li><a href="viewPayroll.php"><i class="fas fa-money-bill-wave"></i> View My Payroll</a></li>
                    <li><a href="employeeLogin.php?logout=1"><i class="fas fa-sign-out-alt"></i> Sign Out</a></li> <!-- Correct logout link -->
                </ul>
            </nav>
        </div>
        
        <div class="main-content">
            <header>
                <h1>Employee Portal</h1>
                <div class="new-request-btn">
                    <a href="employee_request.php" class="btn"> <!-- FIX: Point to employee_request.php -->
                        <i class="fas fa-plus"></i> New Request
                    </a>
                </div>
            </header>
            
            <div class="dashboard-tiles">
                <div class="tile">
                    <div class="tile-content">
                        <h2>Attendance Rate</h2>
                        <div class="tile-value"><?php echo number_format($attendanceRate, 1); ?>%</div>
                        <div class="tile-label">This month</div>
                    </div>
                    <div class="tile-icon user-icon"><i class="fas fa-user-check"></i></div>
                </div>
                <div class="tile">
                    <div class="tile-content">
                        <h2>Leave Balance</h2>
                        <div class="tile-value"><?php echo $leaveBalance; ?></div>
                        <div class="tile-label">Days remaining</div>
                    </div>
                    <div class="tile-icon calendar-icon"><i class="fas fa-calendar-alt"></i></div>
                </div>
                <div class="tile">
                    <div class="tile-content">
                        <h2>Pending Requests</h2>
                        <div class="tile-value"><?php echo $pendingGeneralRequests; ?></div> <!-- FIX: Use correct variable -->
                        <div class="tile-label">Waiting for approval</div>
                    </div>
                    <div class="tile-icon clock-icon"><i class="fas fa-hourglass-half"></i></div> <!-- Changed icon -->
                </div>
            </div>
            
            <div class="calendar-section">
                <div class="calendar-header">
                    <h2><?php echo htmlspecialchars($monthNameForCalendar . ' ' . $currentYear); ?> Attendance</h2>
                    <a href="attendanceHistory.php" class="view-history">View Full History</a> <!-- Make sure attendanceHistory.php exists -->
                </div>
                <table class="calendar">
                    <thead><tr><th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th></tr></thead>
                    <tbody>
                        <?php
                        $firstDayOfMonthTimestamp = mktime(0, 0, 0, $currentMonthNumeric, 1, $currentYear);
                        $daysInCurrentMonth = date('t', $firstDayOfMonthTimestamp);
                        $dayOfWeekOfFirstDay = date('w', $firstDayOfMonthTimestamp); // 0 (Sun) to 6 (Sat)
                        
                        $dayCounter = 1;
                        echo "<tr>";
                        for ($i = 0; $i < $dayOfWeekOfFirstDay; $i++) echo "<td></td>"; // Empty cells before first day

                        while ($dayCounter <= $daysInCurrentMonth) {
                            if ($dayOfWeekOfFirstDay % 7 == 0 && $dayOfWeekOfFirstDay != 0) echo "</tr><tr>"; // New row every 7 days

                            $cellClassOutput = "";
                            $currentDayString = date('Y-m-d', mktime(0,0,0, $currentMonthNumeric, $dayCounter, $currentYear));
                            if ($currentDayString == date('Y-m-d')) $cellClassOutput .= " current-day";
                            if (isset($calendarData[$dayCounter])) $cellClassOutput .= " status-" . htmlspecialchars($calendarData[$dayCounter]);
                            
                            echo "<td class='{$cellClassOutput}'>{$dayCounter}</td>";
                            $dayCounter++;
                            $dayOfWeekOfFirstDay++;
                        }
                        while ($dayOfWeekOfFirstDay % 7 != 0) { echo "<td></td>"; $dayOfWeekOfFirstDay++; } // Fill remaining cells in last row
                        echo "</tr>";
                        ?>
                    </tbody>
                </table>
                <div class="calendar-legend">
                    <div class="legend-item"><span class="legend-mark present"></span> Present</div>
                    <div class="legend-item"><span class="legend-mark absent"></span> Absent</div>
                    <div class="legend-item"><span class="legend-mark leave"></span> Leave</div>
                    <div class="legend-item"><span class="legend-mark half-day"></span> Half-Day</div>
                </div>
            </div>
        </div>
    </div>
    <!-- <script src="js/script.js"></script> IF YOU HAVE A JS FILE -->
</body>
</html>