<?php
// salary_calculation.php

// Enable error reporting for debugging (disable or configure for production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is an admin
if (!isset($_SESSION['admin_id'])) {
    header('Location: adminLogin.php?error=unauthorized');
    exit;
}

// Include database configuration
require_once 'database.php'; // Assumes this defines class Database and/or $conn

class SalaryCalculator {
    private $db_conn_oop; 

    public function __construct() {
        try {
            // This assumes database.php defines a class Database with a getConnection method
            // or you might just use the global $conn if database.php sets it up procedurally.
            // For consistency with the provided code, I'll keep the OOP approach here.
            $database = new Database(); 
            $this->db_conn_oop = $database->getConnection();
            if (!$this->db_conn_oop) {
                throw new Exception("Failed to establish database connection within SalaryCalculator.");
            }
        } catch (Exception $e) {
            error_log("SalaryCalculator DB Connection Error: " . $e->getMessage());
            // Provide a user-friendly message, avoid exposing raw DB errors to frontend
            throw new Exception("Salary Calculator could not initialize. Please contact support.");
        }
    }

    public function calculateMonthlySalary($employee_id, $month, $year) {
        try {
            if (!$this->db_conn_oop) {
                throw new Exception("Database connection not available in SalaryCalculator.");
            }

            // Get current salary details for the employee for the given period
            // Effective date must be on or before the pay period end date
            // is_current flag is used to pick the active salary record
            $payPeriodEndDateForSalary = date('Y-m-t', strtotime("$year-$month-01"));

            $empSalaryQuery = 
                "SELECT e.emp_id, esd.base_salary, esd.hourly_rate, esd.salary_detail_id, pf.frequency_name
                 FROM employees e
                 JOIN employee_salary_details esd ON e.emp_id = esd.emp_id
                 JOIN pay_frequencies pf ON esd.freq_id = pf.freq_id
                 WHERE e.emp_id = ? AND e.is_active = TRUE 
                 AND esd.effective_date <= ? 
                 AND (esd.end_date IS NULL OR esd.end_date >= ?) -- Ensures salary record is valid for the period start
                 AND esd.is_current = TRUE
                 ORDER BY esd.effective_date DESC, esd.salary_detail_id DESC 
                 LIMIT 1";
            
            $empCheck = $this->db_conn_oop->prepare($empSalaryQuery);
            if (!$empCheck) {
                throw new Exception("Failed to prepare employee salary details query: " . $this->db_conn_oop->error);
            }
            // Bind payPeriodEndDateForSalary twice for effective_date and end_date check
            $payPeriodStartDateForSalary = date('Y-m-01', strtotime("$year-$month-01"));
            $empCheck->bind_param("iss", $employee_id, $payPeriodEndDateForSalary, $payPeriodStartDateForSalary);
            $empCheck->execute();
            $empResult = $empCheck->get_result();
            
            if ($empResult->num_rows === 0) {
                throw new Exception("Active employee ID $employee_id not found OR no current salary details are configured for the period $month/$year. Check employee records and salary effective/end dates.");
            }
            
            $employee_salary_info = $empResult->fetch_assoc();
            $base_salary_monthly_component = floatval($employee_salary_info['base_salary'] ?? 0); 
            $hourly_rate = floatval($employee_salary_info['hourly_rate'] ?? 0); 
            $salary_detail_id_fk = $employee_salary_info['salary_detail_id'] ?? null;
            $pay_frequency = $employee_salary_info['frequency_name'] ?? 'Unknown';
            $empCheck->close();

            // Fetch attendance for the month
            // Ensure check_in and check_out are not null for worked_hours calculation
            $attendanceQuery = 
                "SELECT 
                    COUNT(DISTINCT attendance_date) as working_days_present,
                    COALESCE(SUM(worked_hours), 0) as total_hours,
                    COALESCE(SUM(CASE WHEN status = 'Present' THEN tardiness_minutes ELSE 0 END), 0) as total_tardiness_minutes,
                    COALESCE(SUM(CASE WHEN status = 'Present' THEN overtime_minutes ELSE 0 END), 0) as total_overtime_minutes
                FROM attendance 
                WHERE 
                    emp_id = ? AND
                    YEAR(attendance_date) = ? AND
                    MONTH(attendance_date) = ? AND
                    status = 'Present'"; // Consider only 'Present' days for these calculations
            
            $stmtAtt = $this->db_conn_oop->prepare($attendanceQuery);
            if (!$stmtAtt) throw new Exception("Failed to prepare attendance query: " . $this->db_conn_oop->error);
            $stmtAtt->bind_param("iii", $employee_id, $year, $month);
            if (!$stmtAtt->execute()) throw new Exception("Failed to execute attendance query: " . $stmtAtt->error);
            
            $attendanceResult = $stmtAtt->get_result();
            $attendance_data = $attendanceResult->fetch_assoc();
            $stmtAtt->close();

            $working_days_present = intval($attendance_data['working_days_present'] ?? 0);
            $total_worked_hours_from_att = floatval($attendance_data['total_hours'] ?? 0);
            // Overtime calculation should be based on expected hours vs actual hours
            // This calculation logic can be quite complex depending on company policy
            // For simplicity, let's assume:
            // Regular hours = 8 per day.
            // Overtime = hours worked beyond (working_days_present * 8) if total_worked_hours_from_att is greater.
            // Or use the overtime_minutes directly if your attendance system calculates it accurately.

            $expected_regular_hours_for_worked_days = $working_days_present * 8; // Assuming 8 hours/day
            $regular_hours_worked = min($total_worked_hours_from_att, $expected_regular_hours_for_worked_days);
            $overtime_hours_worked = max(0, $total_worked_hours_from_att - $regular_hours_worked);
            
            // Earnings calculation
            // If salary is purely monthly, hourly calculations are for overtime or specific cases.
            // The current model has both base_salary (assumed monthly component) and hourly_rate.
            // Let's assume:
            // 1. Base salary is paid if employee meets minimum criteria (e.g., present for most days).
            // 2. Hourly rate is used for calculating earnings from hours worked IF base_salary is 0 OR pay_frequency is 'Hourly'.
            // 3. Overtime is always calculated using hourly_rate.

            $regular_earnings_from_hours = $regular_hours_worked * $hourly_rate;
            
            // If pay_frequency is Monthly, base_salary_monthly_component is the primary earning.
            // If pay_frequency is Hourly, earnings are based on hours.
            // This logic needs to be robust based on how `base_salary` and `hourly_rate` are used for different `pay_frequencies`.
            // For now, let's assume `base_salary_monthly_component` is a fixed part for monthly, and hourly rates apply for hours.
            // A more common model: if monthly, `base_salary / (days_in_month * 8)` might be implicit hourly rate for deductions etc.

            $overtime_rate_multiplier = 1.5; // Standard overtime multiplier
            $overtime_earnings = $overtime_hours_worked * ($hourly_rate * $overtime_rate_multiplier);
            
            // Gross Earnings
            // If monthly, base_salary + overtime. If hourly, (total_hours * hourly_rate) + overtime.
            // The current calculation is: $gross_earnings = $base_salary_monthly_component + $regular_earnings_from_hours (potentially double counting if base is for same hours) + $overtime_earnings;
            // Let's adjust:
            if (strtolower($pay_frequency) === 'monthly') {
                $gross_earnings = $base_salary_monthly_component + $overtime_earnings; // Assuming base covers regular work
            } else { // Hourly, Bi-Weekly, Weekly based on hours
                $gross_earnings = $regular_earnings_from_hours + $overtime_earnings;
            }

            // Deductions (Example: 10% of gross - placeholder, should be itemized from employee_benefits or tax rules)
            $total_deductions = $gross_earnings * 0.10; 
            // Allowances (Placeholder - would come from another table or settings)
            $total_allowances = 0.00; 

            $net_salary = $gross_earnings + $total_allowances - $total_deductions;

            $salary_data_to_save = [
                'emp_id' => $employee_id,
                'salary_detail_id' => $salary_detail_id_fk,
                'pay_period_start_date' => date('Y-m-01', strtotime("$year-$month-01")),
                'pay_period_end_date' => $payPeriodEndDateForSalary,
                'base_salary_component' => $base_salary_monthly_component, 
                'hourly_rate_at_calculation' => $hourly_rate,
                'working_days_in_period' => $working_days_present, // Days actually worked with 'Present' status
                'total_worked_hours' => $total_worked_hours_from_att,
                'regular_hours_worked' => $regular_hours_worked,
                'overtime_hours_worked' => $overtime_hours_worked,
                'regular_earnings' => ($pay_frequency === 'Monthly') ? $base_salary_monthly_component : $regular_earnings_from_hours, // Clarified regular earnings source
                'overtime_earnings' => $overtime_earnings,
                'total_allowances' => $total_allowances,
                'gross_earnings' => $gross_earnings, 
                'total_deductions' => $total_deductions,
                'net_salary' => $net_salary,
                'calculated_by_admin_id' => $_SESSION['admin_id'] ?? null
            ];
            $this->saveSalaryRecord($salary_data_to_save); 
            
            // Data to return to frontend
            return [
                'emp_id' => $employee_id, 'month' => $month, 'year' => $year, 'pay_frequency' => $pay_frequency,
                'working_days_present' => $working_days_present, 'total_hours_worked' => $total_worked_hours_from_att,
                'base_salary_monthly_component' => $base_salary_monthly_component, 'hourly_rate_used' => $hourly_rate, 
                'regular_hours_component' => $regular_hours_worked, 'overtime_hours_component' => $overtime_hours_worked,
                'regular_earnings_display' => ($pay_frequency === 'Monthly') ? $base_salary_monthly_component : $regular_earnings_from_hours,
                'overtime_earnings_display' => $overtime_earnings, 
                'total_allowances_display' => $total_allowances,
                'gross_earnings_display' => $gross_earnings,
                'total_deductions_display' => $total_deductions, 
                'net_salary_display' => $net_salary
            ];
        } catch (Exception $e) {
            error_log("Error in calculateMonthlySalary for emp_id $employee_id, $month/$year: " . $e->getMessage() . "\nStack Trace:\n" . $e->getTraceAsString());
            throw $e; // Re-throw to be caught by the POST handler
        }
    }

    public function saveSalaryRecord($salary_data) {
        try {
            // Check if a record for this employee and pay period already exists
            $checkStmt = $this->db_conn_oop->prepare(
                "SELECT calculation_id FROM salary_calculations WHERE emp_id = ? AND pay_period_start_date = ? AND pay_period_end_date = ?"
            );
            if (!$checkStmt) throw new Exception("Prepare check query failed: " . $this->db_conn_oop->error);
            $checkStmt->bind_param("iss", $salary_data['emp_id'], $salary_data['pay_period_start_date'], $salary_data['pay_period_end_date']);
            $checkStmt->execute();
            $existingRecord = $checkStmt->get_result();
            $calculation_id_to_update = null;
            if ($existingRecord->num_rows > 0) {
                $record = $existingRecord->fetch_assoc();
                $calculation_id_to_update = $record['calculation_id'];
            }
            $checkStmt->close();

            if ($calculation_id_to_update) { // Update existing record
                $stmt = $this->db_conn_oop->prepare("
                    UPDATE salary_calculations 
                    SET salary_detail_id = ?, base_salary_component = ?, hourly_rate_at_calculation = ?, 
                        working_days_in_period = ?, total_worked_hours = ?, regular_hours_worked = ?, overtime_hours_worked = ?, 
                        regular_earnings = ?, overtime_earnings = ?, total_allowances = ?, gross_earnings = ?, total_deductions = ?, net_salary = ?, 
                        payment_status = 'Pending', calculated_at = CURRENT_TIMESTAMP, calculated_by_admin_id = ?
                    WHERE calculation_id = ?
                ");
                if (!$stmt) throw new Exception("Prepare update query failed: " . $this->db_conn_oop->error);
                $stmt->bind_param("iddidd ddd ddddsii", // Matched types to schema
                    $salary_data['salary_detail_id'], $salary_data['base_salary_component'], $salary_data['hourly_rate_at_calculation'],
                    $salary_data['working_days_in_period'], $salary_data['total_worked_hours'],
                    $salary_data['regular_hours_worked'], $salary_data['overtime_hours_worked'],
                    $salary_data['regular_earnings'], $salary_data['overtime_earnings'],
                    $salary_data['total_allowances'], $salary_data['gross_earnings'], 
                    $salary_data['total_deductions'], $salary_data['net_salary'],
                    $salary_data['calculated_by_admin_id'], $calculation_id_to_update
                );
            } else { // Insert new record
                $stmt = $this->db_conn_oop->prepare("
                    INSERT INTO salary_calculations 
                    (emp_id, salary_detail_id, pay_period_start_date, pay_period_end_date, 
                     base_salary_component, hourly_rate_at_calculation, working_days_in_period, total_worked_hours, 
                     regular_hours_worked, overtime_hours_worked, regular_earnings, overtime_earnings,
                     total_allowances, gross_earnings, total_deductions, net_salary, payment_status, calculated_by_admin_id) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)
                ");
                if (!$stmt) throw new Exception("Prepare insert query failed: " . $this->db_conn_oop->error);
                $stmt->bind_param("iisssddidd ddd dddsi", // Matched types to schema
                    $salary_data['emp_id'], $salary_data['salary_detail_id'],
                    $salary_data['pay_period_start_date'], $salary_data['pay_period_end_date'],
                    $salary_data['base_salary_component'], $salary_data['hourly_rate_at_calculation'],
                    $salary_data['working_days_in_period'], $salary_data['total_worked_hours'],
                    $salary_data['regular_hours_worked'], $salary_data['overtime_hours_worked'],
                    $salary_data['regular_earnings'], $salary_data['overtime_earnings'],
                    $salary_data['total_allowances'], $salary_data['gross_earnings'], 
                    $salary_data['total_deductions'], $salary_data['net_salary'],
                    $salary_data['calculated_by_admin_id']
                );
            }
            if (!$stmt->execute()) {
                 throw new Exception("Execute salary save query failed: " . $stmt->error . " (Query: " . $stmt->sqlstate . ")");
            }
            $stmt->close();
            return true;
        } catch (Exception $e) {
            error_log("Error in saveSalaryRecord: " . $e->getMessage() . "\nData: " . json_encode($salary_data) . "\nTrace:\n" . $e->getTraceAsString());
            throw new Exception("Error saving salary record. Details: " . $e->getMessage());
        }
    }

    public function formatPeso($amount) {
        return "₱" . number_format(floatval($amount), 2);
    }
}

// Handle POST request for salary calculation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'calculate_salary') {
    header('Content-Type: application/json'); 
    $response = ['success' => false, 'error' => 'An unknown error occurred.']; // Default response
    try {
        if (!isset($_POST['emp_id']) || empty($_POST['emp_id']) || !isset($_POST['month']) || !isset($_POST['year'])) {
            throw new Exception("Employee, month, or year not selected or missing.");
        }
        $employee_id_post = intval($_POST['emp_id']);
        $month_post = intval($_POST['month']);
        $year_post = intval($_POST['year']);

        if ($employee_id_post <= 0) throw new Exception("Invalid employee selected.");
        if ($month_post < 1 || $month_post > 12) throw new Exception("Invalid month selected.");
        if ($year_post < 2000 || $year_post > date("Y") + 10) throw new Exception("Invalid year selected.");

        $calculator = new SalaryCalculator();
        $result_data = $calculator->calculateMonthlySalary($employee_id_post, $month_post, $year_post);

        // Format values for display
        $formatted_result = $result_data; 
        $formatted_result['base_salary_monthly_component_formatted'] = $calculator->formatPeso($result_data['base_salary_monthly_component']);
        $formatted_result['hourly_rate_used_formatted'] = $calculator->formatPeso($result_data['hourly_rate_used']);
        $formatted_result['regular_earnings_display_formatted'] = $calculator->formatPeso($result_data['regular_earnings_display']); 
        $formatted_result['overtime_earnings_display_formatted'] = $calculator->formatPeso($result_data['overtime_earnings_display']); 
        $formatted_result['total_allowances_display_formatted'] = $calculator->formatPeso($result_data['total_allowances_display']);
        $formatted_result['gross_earnings_display_formatted'] = $calculator->formatPeso($result_data['gross_earnings_display']);
        $formatted_result['total_deductions_display_formatted'] = $calculator->formatPeso($result_data['total_deductions_display']);
        $formatted_result['net_salary_display_formatted'] = $calculator->formatPeso($result_data['net_salary_display']);
        
        $response = ['success' => true, 'data' => $formatted_result, 'message' => 'Salary calculated and saved successfully.'];
    } catch (Exception $e) {
        error_log("Salary Calculation POST Error: " . $e->getMessage() . " - Input: emp_id=" . ($_POST['emp_id'] ?? 'N/A') . ", month=" . ($_POST['month'] ?? 'N/A') . ", year=" . ($_POST['year'] ?? 'N/A') . "\nTrace:\n" . $e->getTraceAsString());
        $response['error'] = "Calculation Failed: " . $e->getMessage();
    }
    echo json_encode($response);
    exit; 
}

// --- HTML Part Starts Here ---
$employees_list = []; 
// Use the global $conn if Database class instantiation fails or is not the primary connection method
$db_connection_for_dropdown = null;
if (class_exists('Database')) {
    try {
        $db_obj = new Database();
        $db_connection_for_dropdown = $db_obj->getConnection();
    } catch (Exception $e) {
        error_log("Failed to get DB connection via Database class for dropdown: " . $e->getMessage());
    }
}
if (!$db_connection_for_dropdown && isset($conn)) {
    $db_connection_for_dropdown = $conn; // Fallback to global $conn
}


if ($db_connection_for_dropdown) { 
    // Fetch active employees who have salary details AND at least one attendance record for the current year
    $current_year_for_att_check = date("Y");
    $emp_query_sql = "SELECT DISTINCT e.emp_id, e.first_name, e.last_name 
                      FROM employees e
                      INNER JOIN employee_salary_details esd ON e.emp_id = esd.emp_id AND esd.is_current = TRUE
                      INNER JOIN attendance a ON e.emp_id = a.emp_id AND YEAR(a.attendance_date) >= ($current_year_for_att_check - 1) -- Check attendance for current or previous year
                      WHERE e.is_active = TRUE
                      ORDER BY e.first_name, e.last_name";
    $emp_query_result = mysqli_query($db_connection_for_dropdown, $emp_query_sql);
    if ($emp_query_result) {
        while ($emp_row = mysqli_fetch_assoc($emp_query_result)) {
            $employees_list[] = $emp_row;
        }
        mysqli_free_result($emp_query_result);
    } else {
        error_log("Failed to fetch employees for dropdown: " . mysqli_error($db_connection_for_dropdown));
    }
} else {
    error_log("Database connection not available for fetching employees dropdown in salary_calculation.php.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Calculation - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root { /* CSS Variables */
            --primary-color: #FFD700; --secondary-color: #333; --accent-color: #555;
            --success-color: #28a745; --danger-color: #dc3545; --text-light: #fff;
            --text-dark: #333; --light-bg: #f8f9fa; --white-bg: #fff;
            --border-color: #dee2e6;
        }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background-color: var(--light-bg); color: var(--text-dark); }
        .header-bar { background-color: var(--secondary-color); color: var(--text-light); padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .header-bar h2 { margin: 0; font-size: 1.6rem; }
        .logo-container { display: flex; align-items: center; }
        .logo { width: 50px; height: 50px; border-radius:50%; border:2px solid var(--primary-color); }
        .admin-badge { background-color: var(--primary-color); color: var(--secondary-color); font-size: 0.8rem; padding: 4px 10px; border-radius: 12px; margin-left: 12px; font-weight: bold; }
        
        .container-main { max-width: 900px; margin: 25px auto; padding: 25px; background-color: var(--white-bg); border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24); }
        .page-title { margin-bottom: 25px; text-align: center; color: var(--secondary-color); font-size:1.8rem; }
        
        .nav-button { background-color: var(--success-color); color: white; text-decoration: none; padding: 10px 18px; border-radius: 5px; display: inline-flex; align-items:center; font-weight: 500; margin-bottom: 25px; transition: background-color 0.2s; }
        .nav-button i { margin-right: 8px; }
        .nav-button:hover { background-color: #1e7e34; }

        .form-calc-container { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 30px; padding:20px; background-color:#fdfdfd; border:1px solid var(--border-color); border-radius: 5px;}
        .form-group { flex: 1; min-width: 220px; }
        .form-group label { display:block; margin-bottom:6px; font-weight:500; font-size:0.9rem;}
        .form-control, .month-select { width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 4px; font-size: 1rem; box-sizing: border-box; background-color: var(--white-bg); }
        
        .btn-submit-calc { padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; transition: background-color 0.2s; font-size: 1rem; background-color: var(--primary-color); color: var(--text-dark); display:flex; align-items:center; justify-content:center; gap:8px;}
        .btn-submit-calc:hover { background-color: #e0c000; }
        .form-actions { text-align: center; margin-top:10px; }

        .result-container { margin-top: 30px; padding: 25px; border-radius: 8px; background-color: var(--white-bg); border:1px solid var(--border-color); display: none; }
        .result-container.show { display: block; animation: fadeIn 0.5s; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        .result-title { color: var(--secondary-color); margin-top: 0; border-bottom: 2px solid var(--primary-color); padding-bottom: 10px; font-size:1.5rem; }
        .result-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px; margin-top:15px; } 
        .result-item { padding:10px; background-color:#f8f9fa; border-radius:4px; border-left:3px solid var(--primary-color); } 
        .result-label { font-weight: 600; margin-bottom: 4px; color: var(--accent-color); font-size:0.85em; text-transform:uppercase; } 
        .result-value { font-size: 1.05em; color:var(--text-dark); } 
        .total-salary-display { font-size: 1.6em; font-weight: bold; color: var(--success-color); margin-top: 25px; text-align: right; padding-top:15px; border-top:1px dashed var(--border-color); }
        .total-salary-display span { font-size:0.7em; color:var(--accent-color); display:block; margin-bottom:-5px;}
        
        .error-message-box { color: var(--danger-color); padding: 12px; background-color: #f8d7da; border:1px solid #f5c6cb; border-radius: 4px; margin-top: 20px; display: none; text-align: center; font-size:0.95rem;}
        @media (max-width: 768px) { .form-calc-container { flex-direction: column; } .form-group { width: 100%; } }
    </style>
</head>
<body>
    <div class="header-bar">
        <h2>Salary Calculation <span class="admin-badge">Admin Panel</span></h2>
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo"> 
        </div>
    </div>

    <div class="container-main">
        <a href="adminHome.php" class="nav-button">
            <i class="fas fa-arrow-left"></i> Back to Admin Dashboard
        </a>
        
        <h1 class="page-title">Employee Salary Calculator</h1>
        
        <form id="salaryForm">
            <input type="hidden" name="action" value="calculate_salary"> 
            <div class="form-calc-container">
                <div class="form-group">
                    <label for="emp_id">Select Employee:</label>
                    <select id="emp_id" name="emp_id" class="form-control" required>
                        <option value="">-- Choose an Employee --</option>
                        <?php if (!empty($employees_list)): ?>
                            <?php foreach ($employees_list as $employee_item): ?>
                                <option value="<?php echo htmlspecialchars($employee_item['emp_id']); ?>">
                                    <?php echo htmlspecialchars(trim($employee_item['first_name'] . ' ' . $employee_item['last_name']) . ' (ID: ' . $employee_item['emp_id'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <option value="" disabled>No employees eligible for salary calculation found.</option> 
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="month">Select Month:</label>
                    <select id="month" name="month" class="month-select form-control" required>
                        <?php 
                        $currentMonth = date('n');
                        for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo $m; ?>" <?php echo ($currentMonth == $m) ? 'selected' : ''; ?>>
                                <?php echo date('F', mktime(0, 0, 0, $m, 10)); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="year">Enter Year:</label>
                    <input type="number" id="year" name="year" class="form-control" value="<?php echo date('Y'); ?>" min="2000" max="<?php echo date('Y') + 5; ?>" required>
                </div>
            </div>
            
            <div class="form-actions">
                <button type="submit" class="btn-submit-calc">
                    <i class="fas fa-calculator"></i> Calculate & Save Salary
                </button>
            </div>
        </form>

        <div id="error-message-box" class="error-message-box"></div>

        <div id="salaryResult" class="result-container">
            <h3 class="result-title">Calculated Salary Details</h3>
            <div class="result-grid">
                <div class="result-item"><div class="result-label">Employee ID:</div><div id="result-emp-id" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Pay Period:</div><div id="result-period" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Pay Frequency:</div><div id="result-pay-frequency" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Working Days (Present):</div><div id="result-days-present" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Total Hours Worked (Present):</div><div id="result-total-hours" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Base Salary Component:</div><div id="result-base-salary" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Hourly Rate Used:</div><div id="result-hourly-rate" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Regular Hours Component:</div><div id="result-regular-hours" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Regular Earnings:</div><div id="result-regular-earnings" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Overtime Hours Component:</div><div id="result-overtime-hours" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Overtime Earnings:</div><div id="result-overtime-earnings" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Total Allowances:</div><div id="result-total-allowances" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Gross Earnings:</div><div id="result-gross-earnings" class="result-value"></div></div> 
                <div class="result-item"><div class="result-label">Total Deductions:</div><div id="result-total-deductions" class="result-value"></div></div>
            </div>
            <div class="total-salary-display">
                <span>Net Salary Payable</span> <div id="result-net-salary"></div>
            </div>
             <p style="font-size:0.8em; text-align:center; margin-top:15px; color:var(--accent-color);">This calculation has been saved. You can view payslips or make adjustments in the respective sections.</p>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const salaryForm = document.getElementById('salaryForm');
        const errorMsgEl = document.getElementById('error-message-box');
        const resultContainerEl = document.getElementById('salaryResult');

        salaryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            errorMsgEl.style.display = 'none';
            errorMsgEl.textContent = ''; 
            resultContainerEl.classList.remove('show');
            
            let formData = new FormData(this);
            const submitButton = this.querySelector('button[type="submit"]');
            const originalButtonText = submitButton.innerHTML;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Calculating...';
            submitButton.disabled = true;
            
            fetch('<?php echo basename($_SERVER["PHP_SELF"]); ?>', { 
                method: 'POST',
                body: formData
            })
            .then(response => {
                submitButton.innerHTML = originalButtonText;
                submitButton.disabled = false;
                if (!response.ok) { // Handles HTTP errors (4xx, 5xx)
                    return response.json().catch(() => response.text()).then(errData => {
                        let errorDetail = `Server Error: ${response.status} ${response.statusText}.`;
                        if (typeof errData === 'string' && errData.trim() !== '') {
                            const strippedError = errData.replace(/<[^>]*>?/gm, '').trim(); // Remove HTML
                            errorDetail += ` Details: ${strippedError.substring(0,300)}`;
                        } else if (errData && errData.error) {
                            errorDetail += ` Details: ${errData.error}`;
                        }
                        throw new Error(errorDetail);
                    });
                }
                return response.json(); // Assumes server always returns JSON
            })
            .then(data => {
                if (data.error) {
                    errorMsgEl.textContent = data.error;
                    errorMsgEl.style.display = 'block';
                } else if (data.success && data.data) {
                    const salary = data.data;
                    const monthNames = ["", "January", "February", "March", "April", "May", "June", 
                                       "July", "August", "September", "October", "November", "December"];
                    
                    document.getElementById('result-emp-id').textContent = salary.emp_id;
                    document.getElementById('result-period').textContent = `${monthNames[parseInt(salary.month)]} ${salary.year}`;
                    document.getElementById('result-pay-frequency').textContent = salary.pay_frequency || 'N/A';
                    document.getElementById('result-days-present').textContent = salary.working_days_present;
                    document.getElementById('result-total-hours').textContent = `${parseFloat(salary.total_hours_worked || 0).toFixed(2)} hours`;
                    document.getElementById('result-base-salary').textContent = salary.base_salary_monthly_component_formatted;
                    document.getElementById('result-hourly-rate').textContent = salary.hourly_rate_used_formatted;
                    document.getElementById('result-regular-hours').textContent = `${parseFloat(salary.regular_hours_component || 0).toFixed(2)} hours`;
                    document.getElementById('result-regular-earnings').textContent = salary.regular_earnings_display_formatted;
                    document.getElementById('result-overtime-hours').textContent = `${parseFloat(salary.overtime_hours_component || 0).toFixed(2)} hours`;
                    document.getElementById('result-overtime-earnings').textContent = salary.overtime_earnings_display_formatted;
                    document.getElementById('result-total-allowances').textContent = salary.total_allowances_display_formatted;
                    document.getElementById('result-gross-earnings').textContent = salary.gross_earnings_display_formatted; 
                    document.getElementById('result-total-deductions').textContent = salary.total_deductions_display_formatted;
                    document.getElementById('result-net-salary').textContent = salary.net_salary_display_formatted;
                    
                    resultContainerEl.classList.add('show');
                    resultContainerEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                } else {
                    errorMsgEl.textContent = (data && data.message) ? data.message : 'An unexpected response format was received. Please check server logs.';
                    errorMsgEl.style.display = 'block';
                }
            })
            .catch(error => {
                console.error('Fetch Error:', error);
                submitButton.innerHTML = originalButtonText;
                submitButton.disabled = false;
                errorMsgEl.textContent = 'Client-side Error: ' + error.message + '. Please check browser console and server logs for more details.';
                errorMsgEl.style.display = 'block';
            });
        });
    });
    </script>
</body>
</html>