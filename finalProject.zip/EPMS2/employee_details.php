<?php
// Start session (if not already started)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}

// Include database connection
require_once 'database.php';
if (!$conn || !($conn instanceof mysqli)) {
    // If $conn is not a valid mysqli object, something went wrong in database.php
    // Log this critical error and stop execution or show a friendly error page.
    error_log("Critical: Database connection failed or $conn is not a mysqli object in add_employee.php.");
    die("A critical database error occurred. Please contact support or check server logs.");
}

$error_message = '';
$success_message = ''; // For deletion success

// Handle delete request
if (isset($_GET['delete'])) {
    $emp_id_to_delete = mysqli_real_escape_string($conn, $_GET['delete']);
    
    // Prepare delete SQL (employees table has ON DELETE CASCADE for related tables)
    $delete_sql = "DELETE FROM employees WHERE emp_id = ?";
    $stmt_delete = mysqli_prepare($conn, $delete_sql);

    if ($stmt_delete) {
        mysqli_stmt_bind_param($stmt_delete, "i", $emp_id_to_delete);
        if (mysqli_stmt_execute($stmt_delete)) {
            // Log admin activity for deletion
            if (function_exists('logAdminActivity') && isset($_SESSION['admin_id'])) {
                // Fetch employee name before deletion for logging if needed, or just use ID
                // For simplicity, just log with ID if name is already gone or too complex to fetch here
                logAdminActivity($_SESSION['admin_id'], 'Employee Deleted', "Deleted employee with ID: $emp_id_to_delete", 'Employee', $emp_id_to_delete);
            }
            header("Location: employee_details.php?deleted=success");
            exit();
        } else {
            $error_message = "Error deleting employee: " . mysqli_stmt_error($stmt_delete);
        }
        mysqli_stmt_close($stmt_delete);
    } else {
        $error_message = "Error preparing delete statement: " . mysqli_error($conn);
    }
}

if (isset($_GET['deleted']) && $_GET['deleted'] == 'success') {
    $success_message = "Employee deleted successfully!";
}


// Fetch employee details
// We need to get current salary details and join for department and job title names.
// Benefits will be fetched in a loop per employee for clarity or via a more complex query if performance is an issue.
$sql = "SELECT e.emp_id, e.emp_code, e.first_name, e.last_name, e.email, e.phone, e.hire_date, e.is_active,
               d.dept_name, 
               jt.title_name,
               esd.base_salary, esd.hourly_rate, pf.frequency_name as pay_frequency
        FROM employees e
        LEFT JOIN departments d ON e.dept_id = d.dept_id
        LEFT JOIN job_titles jt ON e.job_title_id = jt.job_title_id
        LEFT JOIN (
            SELECT esd_inner.* 
            FROM employee_salary_details esd_inner
            INNER JOIN (
                SELECT emp_id, MAX(effective_date) as max_effective_date
                FROM employee_salary_details
                WHERE effective_date <= CURDATE() AND (end_date IS NULL OR end_date >= CURDATE()) AND is_current = TRUE
                GROUP BY emp_id
            ) latest_esd ON esd_inner.emp_id = latest_esd.emp_id AND esd_inner.effective_date = latest_esd.max_effective_date
            WHERE esd_inner.is_current = TRUE 
        ) esd ON e.emp_id = esd.emp_id
        LEFT JOIN pay_frequencies pf ON esd.freq_id = pf.freq_id
        ORDER BY e.emp_id DESC";

$result_employees = mysqli_query($conn, $sql);

if (!$result_employees) {
    $error_message = "Error fetching employee data: " . mysqli_error($conn);
    // For fatal error on page: die("Query failed: " . mysqli_error($conn));
}

// Function to fetch benefits for a specific employee
function getEmployeeBenefits($conn, $emp_id) {
    $benefits = [];
    $sql_benefits = "SELECT bt.type_name, eb.id_number, eb.contribution_amount 
                     FROM employee_benefits eb
                     JOIN benefit_types bt ON eb.benefit_type_id = bt.benefit_type_id
                     WHERE eb.emp_id = ? AND eb.is_active = TRUE AND bt.is_active = TRUE
                     ORDER BY bt.type_name";
    $stmt_benefits = mysqli_prepare($conn, $sql_benefits);
    if ($stmt_benefits) {
        mysqli_stmt_bind_param($stmt_benefits, "i", $emp_id);
        mysqli_stmt_execute($stmt_benefits);
        $res_benefits = mysqli_stmt_get_result($stmt_benefits);
        while ($row = mysqli_fetch_assoc($res_benefits)) {
            $benefits[] = $row;
        }
        mysqli_stmt_close($stmt_benefits);
    }
    return $benefits;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Details - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background: linear-gradient(135deg,rgb(234, 227, 102) 0%,rgb(162, 137, 75) 100%);
            min-height: 100vh;
            padding-top: 20px; /* Add padding to avoid content under potential fixed header */
            padding-bottom: 20px;
        }
        .container {
            max-width: 1300px; /* Increased width for more columns */
            margin: 0 auto;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
            overflow: hidden; /* Important for table responsiveness or shadow containment */
        }
        
        /* Header Styles */
        .header {
            background: linear-gradient(135deg, #4a5568 0%, #2d3748 100%);
            color: white;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .logo-section {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .logo {
            width: 50px;
            height: 50px;
            border-radius: 8px;
            object-fit: cover;
            border: 2px solid #ffd700;
        }
        
        .header h1 {
            margin: 0;
            font-size: 22px; /* Adjusted */
            font-weight: 600;
            color: #ffd700;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3); /* Simplified shadow */
        }
        
        .header-buttons {
            display: flex;
            gap: 10px; /* Adjusted gap */
            align-items: center;
        }
        
        .header-btn { /* Generic class for header buttons */
            color: white;
            padding: 10px 20px; /* Adjusted padding */
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
            border: none; /* Removed border by default */
            font-size: 14px; /* Standardized font size */
        }
        .add-employee-btn {
            background: linear-gradient(135deg, #48bb78 0%, #38a169 100%);
        }
        .add-employee-btn:hover {
            background: linear-gradient(135deg, #38a169 0%, #2f855a 100%);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(72, 187, 120, 0.3);
        }
        
        .back-btn {
            background: linear-gradient(135deg, #ed8936 0%, #dd6b20 100%);
        }
        .back-btn:hover {
            background: linear-gradient(135deg, #dd6b20 0%, #c05621 100%);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(237, 137, 54, 0.3);
        }
        
        /* Content Styles */
        .content {
            padding: 20px; /* Adjusted padding */
            overflow-x: auto; /* For table responsiveness */
        }
        
        .message-banner { /* Generic for success/error */
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            border-left: 4px solid;
            font-weight: 500;
        }
        .success-message {
            background: linear-gradient(135deg, #c6f6d5 0%, #9ae6b4 100%);
            color: #22543d;
            border-color: #38a169;
        }
        .error-message {
            background-color: #fed7d7; /* Light red */
            color: #c53030; /* Dark red */
            border-color: #e53e3e; /* Red */
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            border-radius: 8px;
            overflow: hidden; /* For rounded corners on table */
            box-shadow: 0 4px 6px rgba(0,0,0,0.05); /* Softer shadow */
        }
        
        th, td {
            padding: 12px 10px; /* Adjusted padding */
            text-align: left;
            border-bottom: 1px solid #e2e8f0;
            font-size: 14px; /* Standardized font size */
        }
        
        th {
            background: linear-gradient(135deg, #edf2f7 0%, #e2e8f0 100%); /* Lighter header */
            color: #2d3748; /* Darker text for contrast */
            font-weight: 600;
            text-transform: uppercase;
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        
        tr:nth-child(even) {
            background-color: #fdfdfe; /* Very light for subtlety */
        }
        
        tr:hover {
            background-color: #f0f4f8; /* Subtle hover */
        }
        
        .action-btn { /* Generic for edit/delete */
            padding: 7px 14px; /* Adjusted */
            margin: 2px;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 12px;
            font-weight: 500;
            transition: all 0.2s ease; /* Faster transition */
        }
        
        .edit-btn {
            background: linear-gradient(135deg, #63b3ed 0%, #4299e1 100%); /* Brighter blue */
            color: white;
        }
        .edit-btn:hover {
            background: linear-gradient(135deg, #4299e1 0%, #3182ce 100%);
            box-shadow: 0 2px 6px rgba(66, 153, 225, 0.3); /* Softer shadow */
        }
        
        .delete-btn {
            background: linear-gradient(135deg, #fc8181 0%, #f56565 100%); /* Brighter red */
            color: white;
        }
        .delete-btn:hover {
            background: linear-gradient(135deg, #f56565 0%, #e53e3e 100%);
            box-shadow: 0 2px 6px rgba(245, 101, 101, 0.3);
        }
        
        .no-data {
            text-align: center;
            color: #718096;
            font-style: italic;
            padding: 30px; /* Reduced padding */
        }
        
        .benefits-info {
            font-size: 11px;
            color: #4a5568;
            line-height: 1.4;
            max-width: 200px; /* Limit width for better layout */
            white-space: normal; /* Allow wrapping */
        }
        .status-active { color: green; font-weight: bold; }
        .status-inactive { color: red; font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="logo-section">
                <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
                <h1>Employee Details</h1>
            </div>
            <div class="header-buttons">
                <a href="add_employee.php" class="header-btn add-employee-btn"><i class="fas fa-user-plus"></i> Add Employee</a>
                <a href="adminHome.php" class="header-btn back-btn"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
            </div>
        </div>
        
        <div class="content">
            <?php if (!empty($success_message)): ?>
                <div class="message-banner success-message">
                    <i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?>
                </div>
            <?php endif; ?>
            <?php if (!empty($error_message) && $result_employees): // Only show general error if not related to fetching employees ?>
                <div class="message-banner error-message">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Department</th>
                        <th>Job Title</th>
                        <th>Hire Date</th>
                        <th>Salary (Base)</th>
                        <th>Pay Freq.</th>
                        <th>Benefits</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result_employees && mysqli_num_rows($result_employees) > 0): ?>
                        <?php while($row = mysqli_fetch_assoc($result_employees)): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['emp_id']); ?></td>
                                <td><?php echo htmlspecialchars($row['emp_code'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['phone'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($row['dept_name'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($row['title_name'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars(date('M d, Y', strtotime($row['hire_date']))); ?></td>
                                <td><?php echo $row['base_salary'] ? '₱' . number_format($row['base_salary'], 2) : 'N/A'; ?></td>
                                <td><?php echo htmlspecialchars($row['pay_frequency'] ?? 'N/A'); ?></td>
                                <td class="benefits-info">
                                    <?php 
                                    $employee_benefits = getEmployeeBenefits($conn, $row['emp_id']);
                                    if (!empty($employee_benefits)) {
                                        foreach ($employee_benefits as $benefit) {
                                            echo htmlspecialchars($benefit['type_name']) . ": " . htmlspecialchars($benefit['id_number'] ?? 'N/A') . "<br>";
                                        }
                                    } else {
                                        echo "<em>No active benefits</em>";
                                    }
                                    ?>
                                </td>
                                <td class="<?php echo $row['is_active'] ? 'status-active' : 'status-inactive'; ?>">
                                    <?php echo $row['is_active'] ? 'Active' : 'Inactive'; ?>
                                </td>
                                <td>
                                    <a href="edit_employee.php?emp_id=<?php echo $row['emp_id']; ?>" class="action-btn edit-btn" title="Edit"><i class="fas fa-edit"></i></a>
                                    <button onclick="confirmDelete('<?php echo $row['emp_id']; ?>')" class="action-btn delete-btn" title="Delete"><i class="fas fa-trash-alt"></i></button>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php elseif (!$error_message): // Show no employees found only if there wasn't a query error ?>
                        <tr>
                            <td colspan="13" class="no-data">No employees found.</td>
                        </tr>
                    <?php endif; ?>
                     <?php if ($error_message && !$result_employees): // Show specific error if fetching employees failed ?>
                        <tr>
                            <td colspan="13" class="no-data error-message" style="text-align:center;">
                                <i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error_message); ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        function confirmDelete(empId) {
            if (confirm('Are you sure you want to delete employee ID ' + empId + '? This action cannot be undone and will remove all related data.')) {
                window.location.href = 'employee_details.php?delete=' + empId;
            }
        }
    </script>
</body>
</html>