<?php
// Start session for user authentication
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in
    header("Location: adminLogin.php");
    exit();
}

// Include database connection and admin functions
require_once 'database.php'; // Ensures $conn is available
if (!$conn || !($conn instanceof mysqli)) {
    // Critical error: database connection failed.
    error_log("Database connection failed in activities.php");
    die("A critical database error occurred. Please try again later or contact support.");
}

if (file_exists('admin_functions.php')) {
    require_once 'admin_functions.php';
} else {
    // Define dummy functions if admin_functions.php is missing to avoid fatal errors
    if (!function_exists('initAdminActivitySystem')) { function initAdminActivitySystem() { /* do nothing */ } }
    if (!function_exists('getAllAdminActivities')) { 
        function getAllAdminActivities($page = 1, $perPage = 10) { // Match signature
            return ['activities' => [], 'totalPages' => 0, 'total' => 0, 'page' => $page, 'perPage' => $perPage]; // Return expected structure
        } 
    }
}


// Initialize admin activity system (if function exists and is needed)
// This function can be removed if admin_activities_log is created by create_tables.php
if (function_exists('initAdminActivitySystem')) {
    initAdminActivitySystem();
}

// Fetch admin information
$admin_id_session = $_SESSION['admin_id']; // Use a different variable name
$admin_user_data = null; // Initialize to null
$query_admin_info = "SELECT admin_id, full_name, role FROM admins WHERE admin_id = ?"; // Be specific with columns
$stmt_admin_info = $conn->prepare($query_admin_info); // OOP style

if ($stmt_admin_info) {
    $stmt_admin_info->bind_param("i", $admin_id_session); // Corrected type to "i" for admin_id
    if ($stmt_admin_info->execute()) {
        $result_admin_info = $stmt_admin_info->get_result();
        if ($result_admin_info) {
            $admin_user_data = $result_admin_info->fetch_assoc(); // Store fetched data
            $result_admin_info->free();
        } else {
            error_log("Fetching admin info get_result failed: " . $stmt_admin_info->error);
        }
    } else {
        error_log("Fetching admin info execute failed: " . $stmt_admin_info->error);
    }
    $stmt_admin_info->close();
} else {
    error_log("Failed to prepare admin info query: " . $conn->error);
}


// Get all admin activities
$all_activities_array = []; // Initialize as empty array for data
$pagination_data = ['totalPages' => 0, 'currentPage' => 1, 'totalItems' => 0]; // For pagination details

if (function_exists('getAllAdminActivities')) {
    // Assuming getAllAdminActivities now correctly fetches from admin_activities_log
    // and handles pagination, returning an array like:
    // ['activities' => [...], 'total' => X, 'page' => Y, 'perPage' => Z, 'totalPages' => W]
    $page_from_get = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $activities_result_data = getAllAdminActivities($page_from_get, 10); // 10 items per page

    if ($activities_result_data && isset($activities_result_data['activities'])) {
        $all_activities_array = $activities_result_data['activities'];
        $pagination_data['totalPages'] = $activities_result_data['totalPages'];
        $pagination_data['currentPage'] = $activities_result_data['page'];
        $pagination_data['totalItems'] = $activities_result_data['total'];
    } else {
        error_log("getAllAdminActivities did not return expected structure or failed. Using fallback.");
        // Fallback logic below will be triggered if $all_activities_array remains empty
    }
} else {
    error_log("getAllAdminActivities function does not exist. Fallback logic will be used.");
}

// If $all_activities_array is still empty (e.g., function failed or doesn't exist), try the very manual fallback.
// This fallback is generally not ideal as it loads ALL activities into memory for pagination.
// The admin_functions.php version of getAllAdminActivities should handle DB-side pagination.
if (empty($all_activities_array)) {
    error_log("Using manual fallback query in activities.php as primary fetch failed or yielded no data.");
    // Fallback query - THIS SHOULD ALIGN WITH YOUR 3NF SCHEMA for admin_activities_log
    // The UNION query you had is for a different kind of aggregated feed.
    // For "Admin Activities", we should primarily query the admin_activities_log table.
    $fallback_query_sql = "
        SELECT 
            aal.log_id, 
            aal.activity_type, 
            aal.description,  
            a.full_name,  -- This is admin_name
            aal.created_at,
            aal.target_entity_type,
            aal.target_entity_id,
            'admin_log_fallback' as source 
        FROM admin_activities_log aal
        JOIN admins a ON aal.admin_id = a.admin_id
        ORDER BY aal.created_at DESC"; // No LIMIT here if PHP handles pagination

    $all_activities_result_fallback = $conn->query($fallback_query_sql);
    if (!$all_activities_result_fallback) {
        error_log("All activities fallback query failed: " . $conn->error); // Corrected to $conn->error
        // $all_activities_array remains empty
    } else {
        while ($row = $all_activities_result_fallback->fetch_assoc()) {
            $all_activities_array[] = $row;
        }
        $all_activities_result_fallback->free();
        
        // Manual pagination for the fallback result
        $items_per_page_fallback = 10;
        $current_page_fallback = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $total_activities_fallback = count($all_activities_array);
        $pagination_data['totalPages'] = ceil($total_activities_fallback / $items_per_page_fallback);
        $pagination_data['currentPage'] = $current_page_fallback;
        $pagination_data['totalItems'] = $total_activities_fallback;
        $start_index_fallback = ($current_page_fallback - 1) * $items_per_page_fallback;
        $all_activities_array = array_slice($all_activities_array, $start_index_fallback, $items_per_page_fallback);
    }
}

// Helper function to format time elapsed (Corrected version)
function time_elapsed_string($datetime_str, $full = false) {
    if (empty($datetime_str)) {
        return 'unknown time';
    }
    try {
        $now = new DateTime();
        $ago = new DateTime($datetime_str);
        $diff = $now->diff($ago); // $diff is a DateInterval object

        // Calculate weeks from the 'd' (days) component of the interval
        // Note: $diff->d is the day part of the interval, not total days if interval > 1 month.
        // For precise "weeks ago" over longer periods, $diff->days (total days) is better.
        // However, the original logic implies breaking down $diff->d.
        $calculated_weeks = 0;
        $days_for_week_calc = $diff->d; // Use the day component

        if ($days_for_week_calc >= 7) {
            $calculated_weeks = floor($days_for_week_calc / 7);
            $remaining_days_after_weeks = $days_for_week_calc % 7;
        } else {
            $remaining_days_after_weeks = $days_for_week_calc;
        }
        
        $string_parts = [];
        if ($diff->y) $string_parts[] = $diff->y . ' year' . ($diff->y > 1 ? 's' : '');
        if ($diff->m) $string_parts[] = $diff->m . ' month' . ($diff->m > 1 ? 's' : '');
        if ($calculated_weeks) $string_parts[] = $calculated_weeks . ' week' . ($calculated_weeks > 1 ? 's' : '');
        if ($remaining_days_after_weeks) $string_parts[] = $remaining_days_after_weeks . ' day' . ($remaining_days_after_weeks > 1 ? 's' : '');
        if (empty($string_parts)) { // If less than a day, show hours/minutes/seconds
            if ($diff->h) $string_parts[] = $diff->h . ' hour' . ($diff->h > 1 ? 's' : '');
            if ($diff->i) $string_parts[] = $diff->i . ' minute' . ($diff->i > 1 ? 's' : '');
            if ($diff->s) $string_parts[] = $diff->s . ' second' . ($diff->s > 1 ? 's' : '');
        }
        
        if (empty($string_parts)) {
            return 'just now';
        }

        if (!$full) {
            $string_parts = array_slice($string_parts, 0, 1); // Get the largest unit
        }
        
        return implode(', ', $string_parts) . ' ago';

    } catch (Exception $e) {
        error_log("Error in time_elapsed_string for datetime '{$datetime_str}': " . $e->getMessage());
        return 'invalid date';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Activities - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Using CSS from your admin_activities.php provided in the prompt */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Arial', sans-serif; }
        body { display: flex; min-height: 100vh; }
        .sidebar { width: 250px; background-color: #333; color: white; padding-top: 20px; display:flex; flex-direction:column; }
        .logo-container { text-align: center; padding: 10px; margin-bottom: 20px; }
        .logo-img { width: 100px; height: 100px; object-fit: contain; }
        .system-name { text-align: center; font-size: 14px; margin-top: 15px; color: #f0c14b; line-height:1.3; }
        .admin-profile { text-align: center; padding: 20px 0; border-top: 1px solid #444; border-bottom: 1px solid #444; margin: 20px 0; }
        .profile-img { display: inline-block; padding: 8px 15px; background-color: #f0c14b; border-radius: 20px; font-weight: bold; color: #333; }
        .admin-name { margin-top: 10px; font-weight: bold; }
        .admin-role { font-size: 12px; color: #ccc; }
        .nav-menu { list-style: none; padding-left:0; flex-grow:1; } /* Added padding-left:0 */
        .nav-item { padding: 0; /* Remove padding here, add to nav-link */ transition: all 0.3s; }
        .nav-link { color: white; text-decoration: none; display: flex; align-items: center; padding: 15px 20px; /* Padding on the link itself */ }
        .nav-item:hover .nav-link, .nav-item.active .nav-link { background-color: #444; }
        .nav-item.active .nav-link { border-left: 4px solid #f0c14b; padding-left: 16px; /* Adjust for border */ }
        .nav-item i.fas { margin-right: 10px; color: #f0c14b; width:20px; text-align:center;} /* Specific to FontAwesome */
        .content { flex: 1; background-color: #f5f5f5; }
        .header { background-color: white; padding: 20px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .page-title { font-size: 24px; color: #333; }
        .back-btn { background-color: #f0c14b; color: #333; border: none; padding: 10px 20px; border-radius: 4px; font-weight: bold; cursor: pointer; display: flex; align-items: center; text-decoration: none; }
        .back-btn i.fas { margin-right: 5px; } /* Specific to FontAwesome */
        .activities-content { padding: 20px; }
        .activities-container { background-color: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .activities-header { margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px; display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap;}
        .activities-title { font-size: 20px; color: #333; margin-bottom:10px; /* Added for wrap */ }
        .activity-item { display: flex; align-items: center; padding: 15px 0; border-bottom: 1px solid #eee; }
        .activity-item:last-child { border-bottom: none; }
        .activity-icon { width: 40px; height: 40px; background-color: rgba(240, 193, 75, 0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #f0c14b; margin-right: 15px; flex-shrink:0; }
        .activity-details { flex: 1; min-width:0; } /* Added min-width */
        .activity-main-title { font-weight: bold; margin-bottom: 5px; color:#333; } /* Renamed for clarity */
        .activity-full-description { color: #777; font-size: 14px; white-space:normal; word-break:break-word; } /* Renamed for clarity */
        .activity-time { color: #999; font-size: 12px; text-align: right; min-width: 120px; padding-left:10px; white-space:nowrap;}
        .activity-date { font-weight: bold; padding: 10px 0; color: #555; background-color: #f9f9f9; margin: 15px -20px; /* Extend to container edges */ padding-left: 20px; border-left: 3px solid #f0c14b; }
        .filter-container { display: flex; gap: 10px; margin-bottom: 10px; /* Adjusted */ flex-wrap:wrap;}
        .filter-select { padding: 8px; border: 1px solid #ddd; border-radius: 4px; flex-grow: 1; min-width:150px; margin-bottom:5px;}
        .filter-btn { background-color: #f0c14b; color: #333; border: none; padding: 9px 15px; border-radius: 4px; cursor: pointer; height:fit-content; margin-bottom:5px;}
        .pagination { display: flex; justify-content: center; margin-top: 20px; padding-left:0; list-style:none;}
        .pagination a, .pagination span { color: #333; padding: 8px 12px; text-decoration: none; border: 1px solid #ddd; margin: 0 3px; border-radius:4px; }
        .pagination a.active, .pagination span.active { background-color: #f0c14b; color: white; border-color: #f0c14b; }
        .pagination a:hover:not(.active) { background-color: #f5f5f5; }
        .no-activities {text-align: center; padding: 20px; color: #777;}
        .nav-item.logout { margin-top: auto; border-top: 1px solid #444;} /* For logout button */

    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img">
            <div class="system-name">
                Employment Payment<br>Management System<br>EPMS
            </div>
        </div>
        <div class="admin-profile">
            <div class="profile-img">Admin</div> <!-- Changed from button for consistency with adminHome -->
            <div class="admin-name"><?php echo htmlspecialchars($admin_user_data['full_name'] ?? $_SESSION['admin_name'] ?? 'Admin User'); ?></div>
            <div class="admin-role"><?php echo htmlspecialchars($admin_user_data['role'] ?? $_SESSION['admin_role'] ?? 'Administrator'); ?></div>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="adminHome.php" class="nav-link"><i class="fas fa-home"></i> Admin Home</a></li>
            <li class="nav-item"><a href="employee_details.php" class="nav-link"><i class="fas fa-users"></i> Employee Details</a></li>
            <li class="nav-item"><a href="view_attendance.php" class="nav-link"><i class="fas fa-clipboard-check"></i> Attendance</a></li>
            <li class="nav-item"><a href="salary_calculation.php" class="nav-link"><i class="fas fa-calculator"></i> Salary Calculation</a></li>
            <li class="nav-item"><a href="admin_requests.php" class="nav-link"><i class="fas fa-bell"></i> Employee Requests</a></li>
            <li class="nav-item active"><a href="admin_activities.php" class="nav-link"><i class="fas fa-history"></i> Admin Activities</a></li>
            <li class="nav-item"><a href="admin_settings.php" class="nav-link"><i class="fas fa-cog"></i> Settings</a></li>
            <li class="nav-item logout"><a href="adminLogin.php?logout=1" class="nav-link"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    
    <div class="content">
        <div class="header">
            <h1 class="page-title">Admin System Activities</h1>
            <a href="adminHome.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <div class="activities-content">
            <div class="activities-container">
                <div class="activities-header">
                    <h2 class="activities-title">Activity Log</h2>
                    <div class="filter-container">
                        <select class="filter-select" id="activity-type-filter">
                            <option value="">All Activity Types</option>
                            <?php 
                            $unique_types_from_data = [];
                            if (is_array($all_activities_array)) { // Use the paginated data for type options if primary fetch worked
                                foreach($all_activities_array as $act_item) {
                                    if(isset($act_item['activity_type'])) $unique_types_from_data[$act_item['activity_type']] = 1;
                                }
                            }
                            $predefined_types_list = ['Employee Added', 'Salary Processed', 'Employee Request', 'Admin Registration', 'Login', 'Failed Login', 'Request Responded', 'Employee Deleted', 'Employee Updated', 'Admin Action'];
                            foreach($predefined_types_list as $ptype_item) $unique_types_from_data[$ptype_item] = 1;
                            ksort($unique_types_from_data);

                            foreach (array_keys($unique_types_from_data) as $type_option_item): ?>
                                <option value="<?php echo htmlspecialchars($type_option_item); ?>"><?php echo htmlspecialchars(ucwords(str_replace(array('_', '-'), ' ', $type_option_item))); ?></option>
                            <?php endforeach; ?>
                        </select>
                        
                        <select class="filter-select" id="activity-date-filter">
                            <option value="">All Dates</option>
                            <option value="today">Today</option>
                            <option value="yesterday">Yesterday</option>
                            <option value="week">This Week</option>
                            <option value="month">This Month</option>
                        </select>
                        <button class="filter-btn" id="filter-activities-apply-btn">Filter</button>
                    </div>
                </div>
                
                <div id="activity-list-items-container">
                <?php 
                $current_display_date_header = '';
                
                if (!empty($all_activities_array) && is_array($all_activities_array)) {
                    foreach ($all_activities_array as $activity_item) {
                        $activity_item_created_at = $activity_item['created_at'] ?? null;
                        $activity_item_date_for_grouping = $activity_item_created_at ? date('Y-m-d', strtotime($activity_item_created_at)) : 'Unknown';
                        
                        if ($activity_item_date_for_grouping != $current_display_date_header) {
                            $current_display_date_header = $activity_item_date_for_grouping;
                            echo '<div class="activity-date">' . ($activity_item_created_at ? date('F j, Y', strtotime($activity_item_created_at)) : 'Activities from Unknown Date') . '</div>';
                        }
                        
                        $time_ago_display = $activity_item_created_at ? time_elapsed_string($activity_item_created_at) : "unknown time";
                        $time_formatted_display = $activity_item_created_at ? date('h:i A', strtotime($activity_item_created_at)) : "unknown time";
                        
                        $activity_item_type = $activity_item['activity_type'] ?? 'Unknown Activity';
                        $actor_display_name = $activity_item['full_name'] ?? ($activity_item['admin_name'] ?? 'System');
                        $details_item_desc = $activity_item['details'] ?? ($activity_item['description'] ?? 'No details.');
                        if(isset($activity_item['target_entity_type']) && $activity_item['target_entity_type'] !== null){
                            $details_item_desc .= " (Target: " . htmlspecialchars($activity_item['target_entity_type']);
                            if(isset($activity_item['target_entity_id']) && $activity_item['target_entity_id'] !== null){
                                $details_item_desc .= " ID: " . htmlspecialchars($activity_item['target_entity_id']);
                            }
                             $details_item_desc .= ")";
                        }

                        $icon_fa_class = "fas fa-info-circle"; 
                        if (stripos($activity_item_type, 'add') !== false || stripos($activity_item_type, 'create') !== false) $icon_fa_class = "fas fa-plus-circle";
                        else if (stripos($activity_item_type, 'update') !== false || stripos($activity_item_type, 'edit') !== false) $icon_fa_class = "fas fa-edit";
                        else if (stripos($activity_item_type, 'delete') !== false || stripos($activity_item_type, 'remove') !== false) $icon_fa_class = "fas fa-trash-alt";
                        else if (stripos($activity_item_type, 'login') !== false) $icon_fa_class = "fas fa-sign-in-alt";
                        else if (stripos($activity_item_type, 'salary') !== false) $icon_fa_class = "fas fa-money-check-alt";
                        else if (stripos($activity_item_type, 'request') !== false) $icon_fa_class = "fas fa-file-alt";
                ?>
                <div class="activity-item" data-type="<?php echo htmlspecialchars($activity_item_type); ?>" data-date="<?php echo $activity_item_date_for_grouping; ?>">
                    <div class="activity-icon">
                        <i class="<?php echo $icon_fa_class; ?>"></i>
                    </div>
                    <div class="activity-details">
                        <div class="activity-main-title"><?php echo htmlspecialchars(ucwords(str_replace(array('_', '-'), ' ', $activity_item_type))); ?></div>
                        <div class="activity-full-description">
                            By: <?php echo htmlspecialchars($actor_display_name); ?> - <?php echo htmlspecialchars($details_item_desc); ?>
                        </div>
                    </div>
                    <div class="activity-time">
                        <div><?php echo $time_formatted_display; ?></div>
                        <div><?php echo $time_ago_display; ?></div>
                    </div>
                </div>
                <?php
                    }
                    
                    // Display pagination (using $pagination_data from PHP)
                    if ($pagination_data['totalPages'] > 1) {
                        echo '<div class="pagination">';
                        if ($pagination_data['currentPage'] > 1) {
                             echo '<a href="?page=' . ($pagination_data['currentPage'] - 1) . constructFilterQueryString() . '">« Prev</a>';
                        }
                        
                        $start_loop_page = max(1, $pagination_data['currentPage'] - 2);
                        $end_loop_page = min($pagination_data['totalPages'], $pagination_data['currentPage'] + 2);

                        if ($start_loop_page > 1) echo '<a href="?page=1' . constructFilterQueryString() . '">1</a>' . ($start_loop_page > 2 ? '<span>...</span>' : '');

                        for ($i_page = $start_loop_page; $i_page <= $end_loop_page; $i_page++) {
                            echo '<a href="?page=' . $i_page . constructFilterQueryString() . '"' . ($pagination_data['currentPage'] == $i_page ? ' class="active"' : '') . '>' . $i_page . '</a>';
                        }

                        if ($end_loop_page < $pagination_data['totalPages']) echo ($end_loop_page < $pagination_data['totalPages'] - 1 ? '<span>...</span>' : '') . '<a href="?page=' . $pagination_data['totalPages'] . constructFilterQueryString() . '">' . $pagination_data['totalPages'] . '</a>';

                        if ($pagination_data['currentPage'] < $pagination_data['totalPages']) {
                            echo '<a href="?page=' . ($pagination_data['currentPage'] + 1) . constructFilterQueryString() . '">Next »</a>';
                        }
                        echo '</div>';
                    }
                } else {
                    echo '<div class="no-activities">No activities found.</div>';
                }

                // Helper function to append existing filters to pagination links
                function constructFilterQueryString() {
                    $filter_query_string = "";
                    if (!empty($_GET['activity_type_filter'])) {
                        $filter_query_string .= "&activity_type_filter=" . urlencode($_GET['activity_type_filter']);
                    }
                    if (!empty($_GET['activity_date_filter'])) {
                        $filter_query_string .= "&activity_date_filter=" . urlencode($_GET['activity_date_filter']);
                    }
                    return $filter_query_string;
                }
                ?>
                </div> <!-- End #activity-list-items-container -->
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const filterBtnApply = document.getElementById('filter-activities-apply-btn');
        const activityTypeSelectFilter = document.getElementById('activity-type-filter');
        const activityDateSelectFilter = document.getElementById('activity-date-filter');
        
        // Function to redirect with filter parameters
        function applyAndRedirectFilters() {
            const selectedType = activityTypeSelectFilter.value;
            const selectedDateRange = activityDateSelectFilter.value;
            
            let url = 'admin_activities.php?page=1'; // Reset to page 1 on new filter
            if (selectedType) {
                url += '&activity_type_filter=' + encodeURIComponent(selectedType);
            }
            if (selectedDateRange) {
                url += '&activity_date_filter=' + encodeURIComponent(selectedDateRange);
            }
            window.location.href = url;
        }

        if (filterBtnApply) {
            filterBtnApply.addEventListener('click', applyAndRedirectFilters);
        }

        // Set select values based on URL parameters if they exist
        const urlParams = new URLSearchParams(window.location.search);
        const typeParam = urlParams.get('activity_type_filter');
        const dateParam = urlParams.get('activity_date_filter');

        if (typeParam && activityTypeSelectFilter) {
            activityTypeSelectFilter.value = typeParam;
        }
        if (dateParam && activityDateSelectFilter) {
            activityDateSelectFilter.value = dateParam;
        }

        // The client-side filtering JS you had is good for dynamic filtering without page reload,
        // but the getAllAdminActivities function now handles pagination, which implies server-side data fetching per page.
        // If you want client-side filtering on the *current page's data*, you can keep it,
        // but for filtering the entire dataset, server-side filtering (like what applyAndRedirectFilters does) is needed.
        // For simplicity with server-side pagination, I'm relying on the redirect.
        // If you want to implement client-side filtering on the CURRENTLY displayed paginated results, 
        // the JS you had before could be adapted here.
    });
    </script>
</body>
</html>