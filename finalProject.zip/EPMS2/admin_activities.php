<?php
// Start session for user authentication
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}

// Include database connection and admin functions
require_once 'database.php'; // Ensures $conn is available
if (!$conn || !($conn instanceof mysqli)) { die("Database connection failed in admin_activities.php"); }

if (file_exists('admin_functions.php')) {
    require_once 'admin_functions.php';
} else {
    // Define dummy functions if admin_functions.php is missing to avoid fatal errors
    if (!function_exists('initAdminActivitySystem')) { function initAdminActivitySystem() { /* do nothing */ } }
    if (!function_exists('getAllAdminActivities')) { function getAllAdminActivities() { return false; } }
}


// Initialize admin activity system (if function exists and is needed)
if (function_exists('initAdminActivitySystem')) {
    initAdminActivitySystem();
}

// Fetch admin information
$admin_id_session = $_SESSION['admin_id']; // Use a different variable name to avoid conflict
$admin = null; // Initialize to null
$query_admin_info = "SELECT full_name, role FROM admins WHERE admin_id = ?"; // Corrected query
$stmt_admin_info = $conn->prepare($query_admin_info); // Use $conn->prepare

if ($stmt_admin_info) {
    $stmt_admin_info->bind_param("i", $admin_id_session); // Assuming admin_id is integer
    $stmt_admin_info->execute();
    $result_admin_info = $stmt_admin_info->get_result();
    if ($result_admin_info) {
        $admin = $result_admin_info->fetch_assoc();
        $result_admin_info->free();
    }
    $stmt_admin_info->close();
} else {
    error_log("Failed to prepare admin info query: " . $conn->error);
}


// Get all admin activities
$all_activities_data = []; // Initialize as empty array
$using_fallback_query = false;

if (function_exists('getAllAdminActivities')) {
    $activities_result_from_function = getAllAdminActivities(); // Assuming this function now uses pagination internally or fetches all
    if ($activities_result_from_function !== false && is_array($activities_result_from_function)) {
        // If getAllAdminActivities returns pagination data, extract the activities array
        $all_activities_data = isset($activities_result_from_function['activities']) ? $activities_result_from_function['activities'] : $activities_result_from_function;
    } else {
        error_log("getAllAdminActivities returned false or invalid data. Attempting fallback.");
        $using_fallback_query = true;
    }
} else {
    error_log("getAllAdminActivities function does not exist. Using fallback query.");
    $using_fallback_query = true;
}


if ($using_fallback_query || empty($all_activities_data)) {
    // Fallback query - ensure table and column names match your 3NF schema
    // This query needs significant updates to match your 'admin_activities_log' and other 3NF tables.
    // The original fallback was very different.
    $fallback_query_sql = "
    SELECT 
        aal.log_id, 
        aal.activity_type, 
        aal.description AS details,  -- Map description to details for consistency with old structure
        a.full_name, 
        aal.created_at,
        aal.target_entity_type,
        aal.target_entity_id,
        'admin_log' as source -- Indicate source
    FROM admin_activities_log aal
    JOIN admins a ON aal.admin_id = a.admin_id
    ORDER BY aal.created_at DESC"; // Fetch all, pagination will be applied in PHP

    $all_activities_result_fallback = $conn->query($fallback_query_sql);
    if (!$all_activities_result_fallback) {
        error_log("All activities fallback query failed: " . $conn->error);
        $all_activities_data = []; // Ensure it's an array
    } else {
        $all_activities_data = []; // Reset before populating
        while ($row = $all_activities_result_fallback->fetch_assoc()) {
            $all_activities_data[] = $row;
        }
        $all_activities_result_fallback->free();
    }
}


// Helper function to format time elapsed
function time_elapsed_string($datetime_str, $full = false) {
    if (empty($datetime_str)) {
        return 'unknown time';
    }
    try {
        $now = new DateTime();
        $ago = new DateTime($datetime_str);
        $diff = $now->diff($ago); // $diff is a DateInterval object

        // Calculate weeks and store in a separate variable
        $weeks = floor($diff->d / 7); // Calculate weeks from total days in interval
        
        // Calculate remaining days after accounting for full weeks
        $remaining_days = $diff->d % 7; // Use modulo operator for remaining days

        // $diff->d is the total number of days in the interval *if it's less than a month*
        // or the day component if the interval spans months/years.
        // The DateInterval object's 'days' property (lowercase) gives the total number of days.
        // Let's use $diff->days for a more robust calculation of weeks if the interval can be very long.
        // However, your original code was using $diff->d, which implies you are interested in the
        // day component after larger units (months, years) are considered by the `diff` method.
        // The original logic for calculating weeks from $diff->d and then adjusting $diff->d was for display.
        // We'll stick to that intent but use local variables.

        // We will use the calculated $weeks and $remaining_days for constructing the string.
        // The $diff object itself will retain its original d, m, y, h, i, s properties from the diff.

        $string_parts = array(
            'y' => $diff->y ? ($diff->y . ' year' . ($diff->y > 1 ? 's' : '')) : null,
            'm' => $diff->m ? ($diff->m . ' month' . ($diff->m > 1 ? 's' : '')) : null,
            // Use our calculated $weeks
            'w' => $weeks ? ($weeks . ' week' . ($weeks > 1 ? 's' : '')) : null,
            // Use our calculated $remaining_days
            'd' => $remaining_days ? ($remaining_days . ' day' . ($remaining_days > 1 ? 's' : '')) : null,
            'h' => $diff->h ? ($diff->h . ' hour' . ($diff->h > 1 ? 's' : '')) : null,
            'i' => $diff->i ? ($diff->i . ' minute' . ($diff->i > 1 ? 's' : '')) : null,
            's' => $diff->s ? ($diff->s . ' second' . ($diff->s > 1 ? 's' : '')) : null,
        );
        
        // Filter out null (zero) values
        $string_parts = array_filter($string_parts);
        
        if (empty($string_parts)) {
            return 'just now';
        }

        if (!$full) {
            $string_parts = array_slice($string_parts, 0, 1);
        }
        
        return implode(', ', $string_parts) . ' ago';

    } catch (Exception $e) {
        error_log("Error in time_elapsed_string for datetime '{$datetime_str}': " . $e->getMessage());
        return 'invalid date';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Activities - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Using CSS from your admin_activities.php provided in the prompt */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Arial', sans-serif; }
        body { display: flex; min-height: 100vh; }
        .sidebar { width: 250px; background-color: #333; color: white; padding-top: 20px; }
        .logo-container { text-align: center; padding: 10px; margin-bottom: 20px; }
        .logo-img { width: 100px; height: 100px; object-fit: contain; }
        .system-name { text-align: center; font-size: 14px; margin-top: 15px; color: #f0c14b; }
        .admin-profile { text-align: center; padding: 20px 0; border-top: 1px solid #444; border-bottom: 1px solid #444; margin: 20px 0; }
        .profile-img { display: inline-block; padding: 8px 15px; background-color: #f0c14b; border-radius: 20px; font-weight: bold; color: #333; }
        .admin-name { margin-top: 10px; font-weight: bold; }
        .admin-role { font-size: 12px; color: #ccc; }
        .nav-menu { list-style: none; padding-left:0;}
        .nav-item { padding: 15px 20px; transition: all 0.3s; }
        .nav-item:hover, .nav-item.active { background-color: #444; border-left: 4px solid #f0c14b; }
        .nav-item i { margin-right: 10px; color: #f0c14b; }
        .nav-link { color: white; text-decoration: none; display: flex; align-items: center; }
        .content { flex: 1; background-color: #f5f5f5; }
        .header { background-color: white; padding: 20px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .page-title { font-size: 24px; color: #333; }
        .back-btn { background-color: #f0c14b; color: #333; border: none; padding: 10px 20px; border-radius: 4px; font-weight: bold; cursor: pointer; display: flex; align-items: center; text-decoration: none; }
        .back-btn i { margin-right: 5px; }
        .activities-content { padding: 20px; }
        .activities-container { background-color: white; border-radius: 8px; padding: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .activities-header { margin-bottom: 20px; border-bottom: 1px solid #eee; padding-bottom: 15px; }
        .activities-title { font-size: 20px; color: #333; }
        .activity-item { display: flex; align-items: center; padding: 15px 0; border-bottom: 1px solid #eee; }
        .activity-item:last-child { border-bottom: none; }
        .activity-icon { width: 40px; height: 40px; background-color: rgba(240, 193, 75, 0.2); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #f0c14b; margin-right: 15px; }
        .activity-details { flex: 1; }
        .activity-title { font-weight: bold; margin-bottom: 5px; } /* Changed from class to direct style target */
        .activity-description { color: #777; font-size: 14px; } /* Changed from class to direct style target */
        .activity-time { color: #999; font-size: 12px; text-align: right; min-width: 100px; }
        .activity-date { font-weight: bold; padding: 10px 0; color: #555; background-color: #f9f9f9; margin: 15px 0; padding-left: 10px; border-left: 3px solid #f0c14b; }
        .filter-container { display: flex; gap: 10px; margin-bottom: 20px; }
        .filter-select { padding: 8px; border: 1px solid #ddd; border-radius: 4px; flex: 1; }
        .filter-btn { background-color: #f0c14b; color: #333; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; }
        .pagination { display: flex; justify-content: center; margin-top: 20px; }
        .pagination a { color: #333; padding: 8px 12px; text-decoration: none; border: 1px solid #ddd; margin: 0 5px; }
        .pagination a.active { background-color: #f0c14b; color: white; border-color: #f0c14b; }
        .pagination a:hover:not(.active) { background-color: #f5f5f5; }
        .no-activities {text-align: center; padding: 20px; color: #777;}
    </style>
    <!-- JavaScript is included in the body for filter functionality -->
</head>
<body>
    <div class="sidebar">
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img">
            <div class="system-name">
                Employment Payment<br>Management System<br>EPMS
            </div>
        </div>
        <div class="admin-profile">
            <button class="profile-img">Admin</button> <!-- Changed back to button as per original -->
            <div class="admin-name"><?php echo htmlspecialchars($admin['full_name'] ?? 'Admin User'); ?></div>
            <div class="admin-role"><?php echo htmlspecialchars($admin['role'] ?? 'Admin'); ?></div>
        </div>
        <ul class="nav-menu">
            <li class="nav-item"><a href="adminHome.php" class="nav-link"><i class="fas fa-home"></i> Admin Home</a></li>
            <li class="nav-item"><a href="employee_details.php" class="nav-link"><i class="fas fa-users"></i> Employee Details</a></li>
            <li class="nav-item"><a href="view_attendance.php" class="nav-link"><i class="fas fa-clipboard-check"></i> Attendance</a></li>
            <li class="nav-item"><a href="salary_calculation.php" class="nav-link"><i class="fas fa-calculator"></i> Salary Calculation</a></li>
            <li class="nav-item"><a href="admin_requests.php" class="nav-link"><i class="fas fa-bell"></i> Employee Requests</a></li>
            <li class="nav-item active"><a href="admin_activities.php" class="nav-link"><i class="fas fa-history"></i> Admin Activities</a></li>
            <li class="nav-item"><a href="admin_settings.php" class="nav-link"><i class="fas fa-cog"></i> Settings</a></li>
            <li class="nav-item" style="margin-top: auto; border-top: 1px solid #444;"><a href="adminLogin.php?logout=1" class="nav-link"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    
    <div class="content">
        <div class="header">
            <h1 class="page-title">Admin Activities</h1>
            <a href="adminHome.php" class="back-btn">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>
        
        <div class="activities-content">
            <div class="activities-container">
                <div class="activities-header">
                    <h2 class="activities-title">All System Activities</h2>
                    <div class="filter-container">
                        <select class="filter-select" id="activity-type">
                            <option value="">All Activity Types</option>
                            <?php 
                            // Dynamically populate types from fetched activities if possible, or use a predefined list
                            $unique_types = [];
                            if (is_array($all_activities_data)) {
                                foreach($all_activities_data as $act) {
                                    if(isset($act['activity_type'])) $unique_types[$act['activity_type']] = 1;
                                }
                            }
                            // Add common predefined types if dynamic list is short or empty
                            $predefined_types = ['Employee Added', 'Salary Processed', 'Employee Request', 'Admin Registration', 'Login', 'Failed Login', 'Request Responded', 'Employee Deleted', 'Employee Updated'];
                            foreach($predefined_types as $ptype) $unique_types[$ptype] = 1;
                            ksort($unique_types); // Sort alphabetically

                            foreach (array_keys($unique_types) as $type_option): ?>
                                <option value="<?php echo htmlspecialchars($type_option); ?>"><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $type_option))); ?></option>
                            <?php endforeach; ?>
                        </select>
                        
                        <select class="filter-select" id="activity-date">
                            <option value="">All Dates</option>
                            <option value="today">Today</option>
                            <option value="yesterday">Yesterday</option>
                            <option value="week">This Week</option>
                            <option value="month">This Month</option>
                        </select>
                        <button class="filter-btn" id="filter-activities-btn">Filter</button> <!-- Changed ID -->
                    </div>
                </div>
                
                <div id="activity-list-container"> <!-- Wrapper for items to be filtered -->
                <?php 
                $current_group_date = ''; // For grouping by date
                $items_per_page = 10;
                $current_page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                
                if (!empty($all_activities_data) && is_array($all_activities_data)) {
                    $total_activities = count($all_activities_data);
                    $total_pages = ceil($total_activities / $items_per_page);
                    $start_index = ($current_page - 1) * $items_per_page;
                    $paginated_activities = array_slice($all_activities_data, $start_index, $items_per_page);
                    
                    if (empty($paginated_activities) && $current_page > 1) { // Handle case where page is out of bounds after filtering
                         echo '<div class="no-activities">No activities found for this page. Try page 1.</div>';
                    } elseif (empty($paginated_activities)) {
                         echo '<div class="no-activities">No activities found.</div>';
                    }

                    foreach ($paginated_activities as $activity) {
                        $activity_created_at = $activity['created_at'] ?? null;
                        $activity_date_display = $activity_created_at ? date('Y-m-d', strtotime($activity_created_at)) : 'Unknown Date';
                        
                        if ($activity_date_display != $current_group_date) {
                            $current_group_date = $activity_date_display;
                            echo '<div class="activity-date">' . ($activity_created_at ? date('F j, Y', strtotime($activity_created_at)) : 'Unknown Date') . '</div>';
                        }
                        
                        $time_ago = $activity_created_at ? time_elapsed_string($activity_created_at) : "unknown time";
                        $time_formatted = $activity_created_at ? date('h:i A', strtotime($activity_created_at)) : "unknown time";
                        
                        $activity_type = $activity['activity_type'] ?? 'Unknown Activity';
                        $actor_name = $activity['full_name'] ?? ($activity['admin_name'] ?? 'System/Unknown');
                        $details_desc = $activity['details'] ?? ($activity['description'] ?? '');
                        if(isset($activity['target_entity_type']) && isset($activity['target_entity_id'])){
                            $details_desc .= " (Target: " . htmlspecialchars($activity['target_entity_type']) . " ID: " . htmlspecialchars($activity['target_entity_id']) . ")";
                        }


                        $icon_class = "fas fa-info-circle"; // Default icon
                        if (stripos($activity_type, 'add') !== false || stripos($activity_type, 'create') !== false) $icon_class = "fas fa-plus-circle";
                        else if (stripos($activity_type, 'update') !== false || stripos($activity_type, 'edit') !== false) $icon_class = "fas fa-edit";
                        else if (stripos($activity_type, 'delete') !== false || stripos($activity_type, 'remove') !== false) $icon_class = "fas fa-trash-alt";
                        else if (stripos($activity_type, 'login') !== false) $icon_class = "fas fa-sign-in-alt";
                        else if (stripos($activity_type, 'salary') !== false) $icon_class = "fas fa-money-check-alt";
                        else if (stripos($activity_type, 'request') !== false) $icon_class = "fas fa-file-alt";
                        
                ?>
                <div class="activity-item" data-type="<?php echo htmlspecialchars($activity_type); ?>" data-date="<?php echo $activity_date_display; ?>">
                    <div class="activity-icon">
                        <i class="<?php echo $icon_class; ?>"></i>
                    </div>
                    <div class="activity-details">
                        <div class="activity-title"><?php echo htmlspecialchars(ucwords(str_replace('_', ' ', $activity_type))); ?></div>
                        <div class="activity-description">
                            <?php echo htmlspecialchars($actor_name); ?>: <?php echo htmlspecialchars($details_desc); ?>
                        </div>
                    </div>
                    <div class="activity-time">
                        <div><?php echo $time_formatted; ?></div>
                        <div><?php echo $time_ago; ?></div>
                    </div>
                </div>
                <?php
                    }
                    
                    if ($total_pages > 1) {
                        echo '<div class="pagination">';
                        if ($current_page > 1) echo '<a href="?page=' . ($current_page - 1) . '">« Prev</a>';
                        
                        $start_loop = max(1, $current_page - 2);
                        $end_loop = min($total_pages, $current_page + 2);

                        if ($start_loop > 1) echo '<a href="?page=1">1</a>' . ($start_loop > 2 ? '<span>...</span>' : '');

                        for ($i = $start_loop; $i <= $end_loop; $i++) {
                            echo '<a href="?page=' . $i . '"' . ($current_page == $i ? ' class="active"' : '') . '>' . $i . '</a>';
                        }

                        if ($end_loop < $total_pages) echo ($end_loop < $total_pages - 1 ? '<span>...</span>' : '') . '<a href="?page=' . $total_pages . '">' . $total_pages . '</a>';

                        if ($current_page < $total_pages) echo '<a href="?page=' . ($current_page + 1) . '">Next »</a>';
                        echo '</div>';
                    }
                } else {
                    echo '<div class="no-activities">No activities found matching criteria or no activities logged.</div>';
                }
                ?>
                </div> <!-- End #activity-list-container -->
            </div>
        </div>
    </div>
    
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const filterBtn = document.getElementById('filter-activities-btn');
        const activityTypeSelect = document.getElementById('activity-type');
        const activityDateSelect = document.getElementById('activity-date');
        const activityListContainer = document.getElementById('activity-list-container');

        function applyFilters() {
            const selectedType = activityTypeSelect.value;
            const selectedDateRange = activityDateSelect.value;
            
            const allItems = activityListContainer.querySelectorAll('.activity-item');
            const dateHeaders = activityListContainer.querySelectorAll('.activity-date');

            allItems.forEach(function(activity) {
                let showActivity = true;
                const activityType = activity.dataset.type;
                const activityDateStr = activity.dataset.date; // YYYY-MM-DD

                // Filter by type
                if (selectedType && activityType !== selectedType) {
                    showActivity = false;
                }
                
                // Filter by date range
                if (selectedDateRange && showActivity) {
                    const activityTimestamp = new Date(activityDateStr).getTime();
                    const today = new Date();
                    today.setHours(0, 0, 0, 0); // Start of today

                    let rangeStart, rangeEnd;
                    rangeEnd = new Date(today); 
                    rangeEnd.setDate(rangeEnd.getDate() + 1); // End of today (exclusive)


                    switch(selectedDateRange) {
                        case 'today':
                            rangeStart = new Date(today);
                            break;
                        case 'yesterday':
                            rangeStart = new Date(today);
                            rangeStart.setDate(today.getDate() - 1);
                            rangeEnd = new Date(today); // End of yesterday is start of today
                            break;
                        case 'week':
                            rangeStart = new Date(today);
                            rangeStart.setDate(today.getDate() - today.getDay()); // Start of current week (Sunday)
                            break;
                        case 'month':
                            rangeStart = new Date(today.getFullYear(), today.getMonth(), 1); // Start of current month
                            break;
                        default: // 'All Dates'
                            rangeStart = null; 
                            rangeEnd = null;
                    }
                    if(rangeStart && rangeEnd){
                         showActivity = (activityTimestamp >= rangeStart.getTime() && activityTimestamp < rangeEnd.getTime());
                    } else if (rangeStart) { // For week and month, rangeEnd is effectively 'now'
                         showActivity = (activityTimestamp >= rangeStart.getTime());
                    }
                }
                activity.style.display = showActivity ? 'flex' : 'none';
            });

            // Update date headers visibility
            dateHeaders.forEach(function(header) {
                let nextSibling = header.nextElementSibling;
                let hasVisibleActivitiesUnderHeader = false;
                while (nextSibling) {
                    if (nextSibling.classList.contains('activity-date')) {
                        break; // Stop when we hit the next date group
                    }
                    if (nextSibling.classList.contains('activity-item') && nextSibling.style.display !== 'none') {
                        hasVisibleActivitiesUnderHeader = true;
                        break;
                    }
                    nextSibling = nextSibling.nextElementSibling;
                }
                header.style.display = hasVisibleActivitiesUnderHeader ? 'block' : 'none';
            });
        }

        if (filterBtn) {
            filterBtn.addEventListener('click', applyFilters);
        }
        
        // Apply filters on page load if any filter is pre-selected (e.g. from URL params)
        // applyFilters(); // Uncomment if you want to filter on load based on select values
    });
    </script>
</body>
</html>