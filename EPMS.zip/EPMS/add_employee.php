<?php
// Include database connection
require_once 'database.php';

// Initialize variables to store form data and errors
$firstName = $lastName = $email = $phone = $hireDate = $jobTitle = $department = "";
$errors = [];
$successMessage = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate first name
    if (empty($_POST["first_name"])) {
        $errors[] = "First name is required";
    } else {
        $firstName = mysqli_real_escape_string($conn, trim($_POST["first_name"]));
    }
    
    // Validate last name
    if (empty($_POST["last_name"])) {
        $errors[] = "Last name is required";
    } else {
        $lastName = mysqli_real_escape_string($conn, trim($_POST["last_name"]));
    }
    
    // Validate email
    if (empty($_POST["email"])) {
        $errors[] = "Email address is required";
    } else {
        $email = mysqli_real_escape_string($conn, trim($_POST["email"]));
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = "Invalid email format";
        }
    }
    
    // Phone (optional)
    if (!empty($_POST["phone"])) {
        $phone = mysqli_real_escape_string($conn, trim($_POST["phone"]));
    }
    
    // Validate hire date
    if (empty($_POST["hire_date"])) {
        $errors[] = "Hire date is required";
    } else {
        $hireDate = mysqli_real_escape_string($conn, trim($_POST["hire_date"]));
    }
    
    // Validate job title
    if (empty($_POST["job_title"])) {
        $errors[] = "Job title is required";
    } else {
        $jobTitle = mysqli_real_escape_string($conn, trim($_POST["job_title"]));
    }
    
    // Validate department
    if (empty($_POST["department"]) || $_POST["department"] == "-- Select Department --") {
        $errors[] = "Department selection is required";
    } else {
        $department = mysqli_real_escape_string($conn, trim($_POST["department"]));
    }

    // Validate Employee ID (Username)
    if (empty($_POST["emp_id"])) {
        $errors[] = "Employee ID is required";
    } else {
        $emp_id = mysqli_real_escape_string($conn, trim($_POST["emp_id"]));
        
        // Check if employee ID already exists
        $checkEmpId = "SELECT emp_id FROM employee_login WHERE emp_id = '$emp_id'";
        $result = mysqli_query($conn, $checkEmpId);
        if (mysqli_num_rows($result) > 0) {
            $errors[] = "Employee ID already exists. Please choose a different ID.";
        }
    }
    // Validate password
    if (empty($_POST["password"])) {
        $errors[] = "Password is required";
    } else {
        $password = $_POST["password"];
        // Check if password meets requirements (e.g., minimum length)
        if (strlen($password) < 8) {
            $errors[] = "Password must be at least 8 characters long";
        }
    }

    
  // If no validation errors, insert data into database
  if (empty($errors)) {
    // Start transaction
    mysqli_begin_transaction($conn);
    
    try {
        // Prepare the SQL statement for employees table
        $sql = "INSERT INTO employees (first_name, last_name, email, phone, hire_date, job_title, department)
               VALUES ('$firstName', '$lastName', '$email', '$phone', '$hireDate', '$jobTitle', '$department')";
        
        // Execute the query
        if (mysqli_query($conn, $sql)) {
            // Get the auto-generated employee ID
            $employee_id = mysqli_insert_id($conn);
            
            // Hash the password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert into employee_login table
            $loginSql = "INSERT INTO employee_login (emp_id, password, employee_id)
                       VALUES ('$emp_id', '$hashed_password', $employee_id)";
                       
            if (mysqli_query($conn, $loginSql)) {
                // Commit transaction
                mysqli_commit($conn);
                $successMessage = "New employee successfully added with login credentials";
                
                // Reset form fields
                $firstName = $lastName = $email = $phone = $hireDate = $jobTitle = $department = $emp_id = "";
            } else {
                // Rollback if login creation fails
                mysqli_rollback($conn);
                $errors[] = "Error creating login credentials: " . mysqli_error($conn);
            }
        } else {
            // Rollback if employee creation fails
            mysqli_rollback($conn);
            $errors[] = "Error adding employee: " . mysqli_error($conn);
        }
    } catch (Exception $e) {
        // Rollback on any exception
        mysqli_rollback($conn);
        $errors[] = "Transaction failed: " . $e->getMessage();
    }
}
}

// Get departments for dropdown
function getDepartments() {
    return [
        "Administration",
        "Finance",
        "Human Resources",
        "Information Technology",
        "Marketing",
        "Operations",
        "Research and Development",
        "Sales"
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Employee - EPMS</title>
    <style>
        :root {
            --primary-color: #ffde59; /* Yellow from logo */
            --secondary-color: #5e5e5e; /* Dark gray from logo */
            --lighter-gray: #f0f0f0;
            --white: #ffffff;
            --error: #d32f2f;
            --success: #388e3c;
        }
        
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color: var(--lighter-gray);
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            position: relative;
        }
        
        .back-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .back-button:hover {
            background-color: var(--primary-color);
            color: var(--secondary-color);
        }
        
        .header {
            text-align: center;
            margin-bottom: 30px;
            padding-top: 20px;
        }
        
        .logo {
            max-width: 150px;
            height: auto;
            margin-bottom: 15px;
        }
        
        h1 {
            color: var(--secondary-color);
            margin-top: 0;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            color: var(--secondary-color);
            font-weight: bold;
        }
        
        input, select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
        }
        
        .required:after {
            content: " *";
            color: var(--error);
        }
        
        .btn-submit {
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 12px 20px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn-submit:hover {
            background-color: var(--primary-color);
            color: var(--secondary-color);
        }
        
        .error-message {
            color: var(--error);
            padding: 10px;
            background-color: rgba(211, 47, 47, 0.1);
            border-radius: 4px;
            margin-bottom: 20px;
        }
        
        .success-message {
            color: var(--success);
            padding: 10px;
            background-color: rgba(56, 142, 60, 0.1);
            border-radius: 4px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="adminHome.php" class="back-button">Back to Admin Home</a>
        
        <div class="header">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
            <h1>Add New Employee</h1>
        </div>
        
        <?php if (!empty($errors)): ?>
            <div class="error-message">
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo $error; ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($successMessage)): ?>
            <div class="success-message">
                <?php echo $successMessage; ?>
            </div>
        <?php endif; ?>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="first_name" class="required">First Name</label>
                <input type="text" id="first_name" name="first_name" value="<?php echo $firstName; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="last_name" class="required">Last Name</label>
                <input type="text" id="last_name" name="last_name" value="<?php echo $lastName; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="email" class="required">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo $email; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" value="<?php echo $phone; ?>">
            </div>
            
            <div class="form-group">
                <label for="hire_date" class="required">Hire Date</label>
                <input type="date" id="hire_date" name="hire_date" value="<?php echo $hireDate; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="job_title" class="required">Job Title</label>
                <input type="text" id="job_title" name="job_title" value="<?php echo $jobTitle; ?>" required>
            </div>
            
            <div class="form-group">
                <label for="department" class="required">Department</label>
                <select id="department" name="department" required>
                    <option value="" <?php echo empty($department) ? 'selected' : ''; ?>>-- Select Department --</option>
                    <?php foreach (getDepartments() as $dept): ?>
                        <option value="<?php echo $dept; ?>" <?php echo $department == $dept ? 'selected' : ''; ?>>
                            <?php echo $dept; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <!-- Add these fields after Department field -->
<div class="form-group">
  <label for="emp_id">Username (Employee ID) <span class="required">*</span></label>
  <input type="text" id="emp_id" name="emp_id" class="form-control" required>
</div>

<div class="form-group">
  <label for="password">Password <span class="required">*</span></label>
  <input type="password" id="password" name="password" class="form-control" required>
  <small class="form-text text-muted">Password must be at least 8 characters long and include numbers and special characters.</small>
</div>


            <div class="form-group">
                <button type="submit" class="btn-submit">Add Employee</button>
            </div>
        </form>
    </div>
</body>
</html>