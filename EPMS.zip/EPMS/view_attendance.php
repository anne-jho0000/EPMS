<?php
// Include database connection
require_once 'database.php';

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables
$employeeFilter = "";
$dateFilter = "";
$statusFilter = "";

// Get employee list for dropdown
$employeeQuery = "SELECT emp_id, first_name, last_name FROM employees ORDER BY last_name, first_name";
$employeeResult = mysqli_query($conn, $employeeQuery);

// Process filters if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST['employee_id'])) {
        $employeeFilter = mysqli_real_escape_string($conn, $_POST['employee_id']);
    }
    
    if (!empty($_POST['date'])) {
        $dateFilter = mysqli_real_escape_string($conn, $_POST['date']);
    }
    
    if (!empty($_POST['status']) && $_POST['status'] != 'all') {
        $statusFilter = mysqli_real_escape_string($conn, $_POST['status']);
    }
}

// Build the query with filters
$query = "SELECT a.*, e.first_name, e.last_name 
          FROM attendance a
          JOIN employees e ON a.employee_id = e.emp_id
          WHERE 1=1";

if (!empty($employeeFilter)) {
    $query .= " AND a.employee_id = '$employeeFilter'";
}

if (!empty($dateFilter)) {
    $query .= " AND a.date = '$dateFilter'";
}

if (!empty($statusFilter)) {
    $query .= " AND a.status = '$statusFilter'";
}

$query .= " ORDER BY a.date DESC, e.last_name, e.first_name";
$result = mysqli_query($conn, $query);

// Function to calculate tardiness and overtime
function calculateTime($actualTime, $expectedTime) {
    if (empty($actualTime) || empty($expectedTime)) {
        return 0;
    }
    
    $actual = strtotime($actualTime);
    $expected = strtotime($expectedTime);
    
    // Calculate difference in minutes
    return round(abs($actual - $expected) / 60);
}

// Function to format time for display
function formatTime($time) {
    return $time ? date('h:i A', strtotime($time)) : '-';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Attendance - EPMS</title>
    <style>
        :root {
            --primary-color: #ffde59; /* Yellow from logo */
            --secondary-color: #5e5e5e; /* Dark gray from logo */
            --lighter-gray: #f0f0f0;
            --white: #ffffff;
            --border-color: #ddd;
        }
        
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            background-color:rgb(224, 224, 218);
            
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background-color: var(--white);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            position: relative;
        }
        
        .back-button {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
            transition: all 0.3s;
        }
        
        .back-button:hover {
            background-color: var(--primary-color);
            color: var(--secondary-color);
        }
        
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 30px;
            padding-top: 10px;
        }
        
        .logo {
            max-width: 150px;
            height: auto;
            margin-bottom: 15px;
        }
        
        h1 {
            color: var(--secondary-color);
            margin: 0;
        }
        
        .filter-form {
            background-color: var(--lighter-gray);
            padding: 15px;
            border-radius: 6px;
            margin-bottom: 20px;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            align-items: flex-end;
        }
        
        .form-group {
            flex: 1;
            min-width: 200px;
        }
        
        label {
            display: block;
            margin-bottom: 5px;
            color: var(--secondary-color);
            font-weight: bold;
            font-size: 14px;
        }
        
        input, select {
            width: 100%;
            padding: 8px 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 14px;
        }
        
        .btn {
            background-color: var(--secondary-color);
            color: var(--white);
            border: none;
            padding: 9px 15px;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: all 0.3s;
        }
        
        .btn:hover {
            background-color: var(--primary-color);
            color: var(--secondary-color);
        }
        
        .table-container {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid var(--border-color);
            text-align: left;
        }
        
        th {
            background-color: var(--secondary-color);
            color: var(--white);
            font-weight: bold;
        }
        
        tr:nth-child(even) {
            background-color: var(--lighter-gray);
        }
        
        tr:hover {
            background-color: #e6e6e6;
        }
        
        .present {
            color: #388e3c;
            font-weight: bold;
        }
        
        .absent {
            color: #d32f2f;
            font-weight: bold;
        }
        
        .leave {
            color: #1976d2;
            font-weight: bold;
        }
        
        .half-day {
            color: #ff9800;
            font-weight: bold;
        }
        
        .no-records {
            text-align: center;
            padding: 20px;
            font-style: italic;
            color: var(--secondary-color);
        }
    </style>
</head>
<body>
    <div class="container">
        <a href="adminHome.php" class="back-button">Back to Admin Home</a>
        
        <div class="header">
            <div >
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
            </div>
            <h1>Employee Attendance</h1>
        </div>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="filter-form">
            <div class="form-group">
                <label for="employee_id">Employee</label>
                <select id="employee_id" name="employee_id">
                    <option value="">All Employees</option>
                    <?php while ($employee = mysqli_fetch_assoc($employeeResult)): ?>
                        <option value="<?php echo $employee['emp_id']; ?>" <?php echo ($employeeFilter == $employee['emp_id']) ? 'selected' : ''; ?>>
                            <?php echo $employee['last_name'] . ', ' . $employee['first_name']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="date">Date</label>
                <input type="date" id="date" name="date" value="<?php echo $dateFilter; ?>">
            </div>
            
            <div class="form-group">
                <label for="status">Status</label>
                <select id="status" name="status">
                    <option value="all">All Statuses</option>
                    <option value="present" <?php echo ($statusFilter == 'present') ? 'selected' : ''; ?>>Present</option>
                    <option value="absent" <?php echo ($statusFilter == 'absent') ? 'selected' : ''; ?>>Absent</option>
                    <option value="leave" <?php echo ($statusFilter == 'leave') ? 'selected' : ''; ?>>Leave</option>
                    <option value="half-day" <?php echo ($statusFilter == 'half-day') ? 'selected' : ''; ?>>Half Day</option>
                </select>
            </div>
            
            <button type="submit" class="btn">Filter</button>
            <a href="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="btn" style="background-color: #888;">Reset</a>
        </form>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Employee</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th>Expected In</th>
                        <th>Expected Out</th>
                        <th>Tardiness</th>
                        <th>Overtime</th>
                        <th>Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td><?php echo $row['last_name'] . ', ' . $row['first_name']; ?></td>
                                <td><?php echo date('M d, Y', strtotime($row['date'])); ?></td>
                                <td class="<?php echo $row['status']; ?>"><?php echo ucfirst($row['status']); ?></td>
                                <td><?php echo formatTime($row['check_in']); ?></td>
                                <td><?php echo formatTime($row['check_out']); ?></td>
                                <td><?php echo formatTime($row['expected_check_in']); ?></td>
                                <td><?php echo formatTime($row['expected_check_out']); ?></td>
                                <td><?php echo $row['tardiness'] . ' min'; ?></td>
                                <td><?php echo $row['overtime'] . ' min'; ?></td>
                                <td><?php echo $row['notes']; ?></td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="10" class="no-records">No attendance records found</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>