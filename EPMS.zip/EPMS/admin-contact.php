<?php
// Include database connection
require_once 'database.php';

// Initialize variables for form data and error messages
$name = $email = $message = '';
$nameErr = $emailErr = $messageErr = '';
$formSubmitted = false;

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate name
    if (empty($_POST['name'])) {
        $nameErr = 'Name is required';
    } else {
        $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_SPECIAL_CHARS);
    }
    
    // Validate email
    if (empty($_POST['email'])) {
        $emailErr = 'Email is required';
    } else {
        $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $emailErr = 'Invalid email format';
        }
    }
    
    // Validate message
    if (empty($_POST['message'])) {
        $messageErr = 'Message is required';
    } else {
        $message = filter_input(INPUT_POST, 'message', FILTER_SANITIZE_SPECIAL_CHARS);
    }
    
    // If no errors, process the form
    if (empty($nameErr) && empty($emailErr) && empty($messageErr)) {
        // Check if table exists, create if it doesn't
        $checkTable = mysqli_query($conn, "SHOW TABLES LIKE 'admin_contacts'");
        if (mysqli_num_rows($checkTable) == 0) {
            $createTable = "CREATE TABLE admin_contacts (
                id INT(11) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(100) NOT NULL,
                email VARCHAR(100) NOT NULL,
                message TEXT NOT NULL,
                status ENUM('pending', 'in_progress', 'resolved') DEFAULT 'pending',
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP
            )";
            
            if (!mysqli_query($conn, $createTable)) {
                die("Error creating table: " . mysqli_error($conn));
            }
        }
        
        // Prepare SQL statement using mysqli_real_escape_string for security
        $safe_name = mysqli_real_escape_string($conn, $name);
        $safe_email = mysqli_real_escape_string($conn, $email);
        $safe_message = mysqli_real_escape_string($conn, $message);
        
        $sql = "INSERT INTO admin_contacts (name, email, message, created_at) 
                VALUES ('$safe_name', '$safe_email', '$safe_message', NOW())";
        
        if (mysqli_query($conn, $sql)) {
            $formSubmitted = true;
            
            // Send email notification to admin (optional)
            $adminEmail = "admin@example.com";
            $subject = "New Contact Request - EPMS System";
            $emailBody = "A new contact request has been submitted:\n\n";
            $emailBody .= "Name: $name\n";
            $emailBody .= "Email: $email\n";
            $emailBody .= "Message: $message\n";
            
            // Send email (uncomment to enable)
            // mail($adminEmail, $subject, $emailBody);
            
            // Reset form fields after successful submission
            $name = $email = $message = '';
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Admin - EPMS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #1a1a24;
            color: #fff;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 600px;
            margin: 40px auto;
            padding: 20px;
        }
        h1 {
            font-size: 28px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input, textarea {
            width: 100%;
            padding: 12px;
            border-radius: 8px;
            border: none;
            background-color: #2c2c3a;
            color: #fff;
            font-size: 16px;
        }
        textarea {
            min-height: 150px;
        }
        .error {
            color: #ffaa00;
            font-size: 14px;
            margin-top: 5px;
        }
        .btn {
            background-color: #ffcb52;
            color: #1a1a24;
            border: none;
            padding: 12px 20px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 25px;
            cursor: pointer;
            width: 100%;
        }
        .btn:hover {
            background-color: #ffd76b;
        }
        .success-message {
            background-color: rgba(46, 125, 50, 0.2);
            border: 1px solid #2e7d32;
            color: #a5d6a7;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .back-link {
            display: block;
            margin-top: 20px;
            color: #ffcb52;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Contact Admin</h1>
        
        <?php if ($formSubmitted): ?>
            <div class="success-message">
                <p>Your request has been submitted successfully. An administrator will contact you shortly.</p>
            </div>
        <?php endif; ?>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" value="<?php echo $name; ?>">
                <span class="error"><?php echo $nameErr; ?></span>
            </div>
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo $email; ?>">
                <span class="error"><?php echo $emailErr; ?></span>
            </div>
            
            <div class="form-group">
                <label for="message">Message</label>
                <textarea id="message" name="message" placeholder="Please explain your issue with logging in and provide any details that might help identify your account."><?php echo $message; ?></textarea>
                <span class="error"><?php echo $messageErr; ?></span>
            </div>
            
            <button type="submit" class="btn">Submit Request</button>
        </form>
        
        <a href="index.php" class="back-link">← Back to Login</a>
    </div>
</body>
</html>