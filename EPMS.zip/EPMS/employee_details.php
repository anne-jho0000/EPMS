<?php
// employee_details.php - Employee management page for admins
session_start();


// Database connection
include "database.php";

// Initialize variables
$success_message = $error_message = "";
$first_name = $last_name = $email = $phone = $job_title = $department = $salary = "";
$username = $password = "";

// Process form submissions
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Handle Add/Edit Employee
    if (isset($_POST["save_employee"])) {
        // Get form data
        $employee_id = isset($_POST["employee_id"]) ? trim($_POST["employee_id"]) : null;
        $first_name = trim($_POST["first_name"]);
        $last_name = trim($_POST["last_name"]);
        $email = trim($_POST["email"]);
        $phone = trim($_POST["phone"]);
        $hire_date = trim($_POST["hire_date"]);
        $job_title = trim($_POST["job_title"]);
        $department = trim($_POST["department"]);
        $salary = trim($_POST["salary"]);
        $username = empty($_POST["username"]) ? "EMP" . rand(1000, 9999) : trim($_POST["username"]);
        $password = empty($_POST["password"]) ? substr(md5(rand()), 0, 8) : trim($_POST["password"]);
        
        // Validate required fields
        if (empty($first_name) || empty($last_name) || empty($email) || empty($job_title)) {
            $error_message = "Please fill in all required fields.";
        } else {
            // Check if this is an update or new record
            if ($employee_id) {
                // Update existing employee
                $query = "UPDATE employees SET 
                    first_name = ?, last_name = ?, email = ?, phone = ?, 
                    hire_date = ?, job_title = ?, department = ?, salary = ?";
                
                // Only update password if provided
                if (!empty($_POST["password"])) {
                    $query .= ", password = ?";
                    $stmt = $conn->prepare($query . " WHERE id = ?");
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $stmt->bind_param("sssssssssi", $first_name, $last_name, $email, $phone, 
                                    $hire_date, $job_title, $department, $salary, 
                                    $hashed_password, $employee_id);
                } else {
                    $stmt = $conn->prepare($query . " WHERE id = ?");
                    $stmt->bind_param("ssssssssi", $first_name, $last_name, $email, $phone, 
                                    $hire_date, $job_title, $department, $salary, $employee_id);
                }
                
                if ($stmt->execute()) {
                    $success_message = "Employee updated successfully!";
                } else {
                    $error_message = "Error updating employee: " . $conn->error;
                }
            } else {
                // Add new employee
                $query = "INSERT INTO employees (first_name, last_name, email, phone, hire_date, 
                            job_title, department, salary, username, password) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($query);
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt->bind_param("ssssssssss", $first_name, $last_name, $email, $phone, 
                                $hire_date, $job_title, $department, $salary, 
                                $username, $hashed_password);
                
                if ($stmt->execute()) {
                    $success_message = "Employee added successfully! Username: $username, Password: $password";
                    // Clear form fields after successful addition
                    $first_name = $last_name = $email = $phone = $job_title = $department = $salary = "";
                } else {
                    $error_message = "Error adding employee: " . $conn->error;
                }
            }
            $stmt->close();
        }
    }
    
    // Handle Delete Employee
    if (isset($_POST["delete_employee"])) {
        $employee_id = $_POST["employee_id"];
        $stmt = $conn->prepare("DELETE FROM employees WHERE id = ?");
        $stmt->bind_param("i", $employee_id);
        
        if ($stmt->execute()) {
            $success_message = "Employee deleted successfully!";
        } else {
            $error_message = "Error deleting employee: " . $conn->error;
        }
        $stmt->close();
    }
    
    // Handle Reset Password
    if (isset($_POST["reset_password"])) {
        $employee_id = $_POST["employee_id"];
        $new_password = substr(md5(rand()), 0, 8); // Generate random password
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("UPDATE employees SET password = ? WHERE id = ?");
        $stmt->bind_param("si", $hashed_password, $employee_id);
        
        if ($stmt->execute()) {
            $success_message = "Password reset successfully! New password: $new_password";
        } else {
            $error_message = "Error resetting password: " . $conn->error;
        }
        $stmt->close();
    }
}

// Get employee to edit if ID is provided
if (isset($_GET["edit"]) && is_numeric($_GET["edit"])) {
    $employee_id = $_GET["edit"];
    $stmt = $conn->prepare("SELECT * FROM employees WHERE id = ?");
    $stmt->bind_param("i", $employee_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows == 1) {
        $employee = $result->fetch_assoc();
        $first_name = $employee["first_name"];
        $last_name = $employee["last_name"];
        $email = $employee["email"];
        $phone = $employee["phone"];
        $hire_date = $employee["hire_date"];
        $job_title = $employee["job_title"];
        $department = $employee["department"];
        $salary = $employee["salary"];
        $username = $employee["username"];
    }
    $stmt->close();
}

// Fetch all employees for the list
$employees = [];
$query = "SELECT * FROM employees ORDER BY id DESC";
$result = $conn->query($query);
if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $employees[] = $row;
    }
}

    // Get employee ID from URL parameter
if(isset($_GET['id'])) {
    $emp_id = $_GET['id'];
    
    // Fetch employee details
    $emp_query = "SELECT * FROM employees WHERE emp_id = ?";
    $stmt = mysqli_prepare($conn, $emp_query);
    mysqli_stmt_bind_param($stmt, "i", $emp_id);
    mysqli_stmt_execute($stmt);
    $emp_result = mysqli_stmt_get_result($stmt);
    $employee = mysqli_fetch_assoc($emp_result);
    
    // Fetch employee benefits
    $benefits_query = "SELECT * FROM employee_benefits WHERE emp_id = ?";
    $stmt = mysqli_prepare($conn, $benefits_query);
    mysqli_stmt_bind_param($stmt, "i", $emp_id);
    mysqli_stmt_execute($stmt);
    $benefits_result = mysqli_stmt_get_result($stmt);
    $benefits = mysqli_fetch_assoc($benefits_result);


    
    // Check if employee exists
    if(!$employee) {
        echo "Employee not found";
        exit();
    }
} else {
    echo "Employee ID not provided";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Details - EPMS</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        .sidebar {
            background-color: #343a40;
            color: white;
            min-height: 100vh;
        }
        .system-name {
            color: #ffc107;
            padding: 20px 15px;
            text-align: center;
        }
        .card {
            margin-bottom: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .employee-form {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
        }
        .actions-column {
            width: 150px;
        }
        .required-field::after {
            content: "*";
            color: red;
            margin-left: 3px;
        }
        .nav-link.active {
            background-color: #ffc107 !important;
            color: #343a40 !important;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Left sidebar - Keeping the existing sidebar structure -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-3">
                    <div class="system-name mb-4">
                        <img src="logo.png" alt="EPMS Logo" class="mb-2" style="max-width: 100px;">
                        <h5>Employment Payment Management System</h5>
                        <p>EPMS</p>
                    </div>
                    
                    <div class="text-center mb-4">
                        <button class="btn btn-warning mb-2">Admin Profile</button>
                        <h5 class="mb-0">Admin User</h5>
                        <small>HR Admin</small>
                    </div>
                    
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                            <a class="nav-link text-white" href="admin_home.php">
                                <i class="fas fa-home mr-2"></i> Admin Home
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link text-white active" href="employee_details.php">
                                <i class="fas fa-users mr-2"></i> Employee Details
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link text-white" href="attendance.php">
                                <i class="fas fa-calendar-check mr-2"></i> Attendance
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link text-white" href="salary_calculation.php">
                                <i class="fas fa-calculator mr-2"></i> Salary Calculation
                            </a>
                        </li>
                        <li class="nav-item mb-2">
                            <a class="nav-link text-white" href="employee_requests.php">
                                <i class="fas fa-clipboard-list mr-2"></i> Employee Requests
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-white" href="logout.php">
                                <i class="fas fa-sign-out-alt mr-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
            
            <!-- Main content area -->
            <div class="col-md-9 col-lg-10 ml-sm-auto px-4 py-3">
                <h2 class="mb-4">Employee Details</h2>
                
                <?php if (!empty($success_message)): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <?php echo $success_message; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($error_message)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error_message; ?>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                <?php endif; ?>
                
                <!-- Employee Form Card -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">
                            <?php echo isset($_GET["edit"]) ? "Edit Employee" : "Add New Employee"; ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <form action="employee_details.php" method="post" class="employee-form">
                            <?php if(isset($_GET["edit"])): ?>
                                <input type="hidden" name="employee_id" value="<?php echo $_GET["edit"]; ?>">
                            <?php endif; ?>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-field">First Name</label>
                                        <input type="text" name="first_name" class="form-control" value="<?php echo $first_name; ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-field">Last Name</label>
                                        <input type="text" name="last_name" class="form-control" value="<?php echo $last_name; ?>" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-field">Email</label>
                                        <input type="email" name="email" class="form-control" value="<?php echo $email; ?>" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Phone</label>
                                        <input type="text" name="phone" class="form-control" value="<?php echo $phone; ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Hire Date</label>
                                        <input type="date" name="hire_date" class="form-control" value="<?php echo $hire_date; ?>">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="required-field">Job Title</label>
                                        <input type="text" name="job_title" class="form-control" value="<?php echo $job_title; ?>" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Department</label>
                                        <select name="department" class="form-control">
                                            <option value="">-- Select Department --</option>
                                            <option value="HR" <?php if($department == "HR") echo "selected"; ?>>HR</option>
                                            <option value="Finance" <?php if($department == "Finance") echo "selected"; ?>>Finance</option>
                                            <option value="IT" <?php if($department == "IT") echo "selected"; ?>>IT</option>
                                            <option value="Marketing" <?php if($department == "Marketing") echo "selected"; ?>>Marketing</option>
                                            <option value="Operations" <?php if($department == "Operations") echo "selected"; ?>>Operations</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Salary</label>
                                        <input type="number" name="salary" class="form-control" value="<?php echo $salary; ?>">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Username (Employee ID)</label>
                                        <input type="text" name="username" class="form-control" value="<?php echo $username; ?>" <?php echo isset($_GET["edit"]) ? "readonly" : ""; ?> placeholder="<?php echo !isset($_GET["edit"]) ? "Leave blank for auto-generation" : ""; ?>">
                                        <?php if(!isset($_GET["edit"])): ?>
                                            <small class="form-text text-muted">Leave blank to auto-generate employee ID as username</small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="text" name="password" class="form-control" placeholder="<?php echo !isset($_GET["edit"]) ? "Leave blank for auto-generation" : "Enter new password or leave blank"; ?>">
                                        <small class="form-text text-muted">
                                            <?php echo isset($_GET["edit"]) ? "Leave blank to keep current password" : "Leave blank to auto-generate password"; ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mt-3">
                                <button type="submit" name="save_employee" class="btn btn-primary">
                                    <i class="fas fa-save mr-1"></i> <?php echo isset($_GET["edit"]) ? "Update Employee" : "Add Employee"; ?>
                                </button>
                                <?php if(isset($_GET["edit"])): ?>
                                    <a href="employee_details.php" class="btn btn-secondary ml-2">
                                        <i class="fas fa-times mr-1"></i> Cancel
                                    </a>
                                <?php endif; ?>
                            </div>
                        </form>
                        <div class="benefits-info">
        <h2>Benefits Information</h2>
        <?php if($benefits): ?>
            <table>
                <tr>
                    <th>SSS Number</th>
                    <td><?php echo $benefits['sss_number']; ?></td>
                    <th>SSS Contribution</th>
                    <td><?php echo $benefits['sss_contribution']; ?></td>
                </tr>
                <tr>
                    <th>Pag-IBIG Number</th>
                    <td><?php echo $benefits['pagibig_number']; ?></td>
                    <th>Pag-IBIG Contribution</th>
                    <td><?php echo $benefits['pagibig_contribution']; ?></td>
                </tr>
                <tr>
                    <th>PhilHealth Number</th>
                    <td><?php echo $benefits['philhealth_number']; ?></td>
                    <th>PhilHealth Contribution</th>
                    <td><?php echo $benefits['philhealth_contribution']; ?></td>
                </tr>
                <tr>
                    <th>TIN Number</th>
                    <td><?php echo $benefits['tin_number']; ?></td>
                    <th>Tax Contribution</th>
                    <td><?php echo $benefits['tax_contribution']; ?></td>
                </tr>
                <tr>
                    <th>Other Benefits</th>
                    <td colspan="3"><?php echo $benefits['other_benefits']; ?></td>
                </tr>
            </table>
        <?php else: ?>
            <p>No benefits information found for this employee.</p>
            <a href="add_benefits.php?emp_id=<?php echo $emp_id; ?>">Add Benefits Information</a>
        <?php endif; ?>
    </div>
    
    <div class="actions">
        <?php if($benefits): ?>
            <a href="edit_benefits.php?emp_id=<?php echo $emp_id; ?>">Edit Benefits</a>
        <?php endif; ?>
        <a href="employee_list.php">Back to Employee List</a>
    </div>
                    </div>
                </div>
                
                <!-- Employee List Card -->
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Employee List</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Phone</th>
                                        <th>Job Title</th>
                                        <th>Department</th>
                                        <th>Username</th>
                                        <th class="actions-column">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if (empty($employees)): ?>
                                        <tr>
                                            <td colspan="8" class="text-center">No employees found.</td>
                                        </tr>
                                    <?php else: ?>
                                        <?php foreach ($employees as $emp): ?>
                                            <tr>
                                                <td><?php echo $emp["id"]; ?></td>
                                                <td><?php echo $emp["first_name"] . " " . $emp["last_name"]; ?></td>
                                                <td><?php echo $emp["email"]; ?></td>
                                                <td><?php echo $emp["phone"]; ?></td>
                                                <td><?php echo $emp["job_title"]; ?></td>
                                                <td><?php echo $emp["department"]; ?></td>
                                                <td><?php echo $emp["username"]; ?></td>
                                                <td>
                                                    <div class="btn-group">
                                                        <a href="employee_details.php?edit=<?php echo $emp["id"]; ?>" class="btn btn-sm btn-info">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#deleteModal<?php echo $emp["id"]; ?>">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                        <button type="button" class="btn btn-sm btn-warning" data-toggle="modal" data-target="#resetModal<?php echo $emp["id"]; ?>">
                                                            <i class="fas fa-key"></i>
                                                        </button>
                                                    </div>
                                                    
                                                    <!-- Delete Confirmation Modal -->
                                                    <div class="modal fade" id="deleteModal<?php echo $emp["id"]; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Confirm Delete</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    Are you sure you want to delete employee: <strong><?php echo $emp["first_name"] . " " . $emp["last_name"]; ?></strong>?
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <form action="employee_details.php" method="post">
                                                                        <input type="hidden" name="employee_id" value="<?php echo $emp["id"]; ?>">
                                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                                        <button type="submit" name="delete_employee" class="btn btn-danger">Delete</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    
                                                    <!-- Reset Password Modal -->
                                                    <div class="modal fade" id="resetModal<?php echo $emp["id"]; ?>" tabindex="-1" role="dialog" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                            <div class="modal-content">
                                                                <div class="modal-header">
                                                                    <h5 class="modal-title">Reset Password</h5>
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                        <span aria-hidden="true">&times;</span>
                                                                    </button>
                                                                </div>
                                                                <div class="modal-body">
                                                                    Are you sure you want to reset the password for <strong><?php echo $emp["first_name"] . " " . $emp["last_name"]; ?></strong>?
                                                                    <p class="mt-2 text-danger">This will generate a new random password.</p>
                                                                </div>
                                                                <div class="modal-footer">
                                                                    <form action="employee_details.php" method="post">
                                                                        <input type="hidden" name="employee_id" value="<?php echo $emp["id"]; ?>">
                                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                                        <button type="submit" name="reset_password" class="btn btn-warning">Reset Password</button>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>