<?php
// Include your existing database connection file
require_once 'database.php';

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Connected successfully to epms_db database<br>";

// SQL to create attendance table with overtime and tardiness fields
$sql = "CREATE TABLE IF NOT EXISTS attendance (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    employee_id INT(11) NOT NULL,
    date DATE NOT NULL,
    status ENUM('present', 'absent', 'leave', 'half-day') NOT NULL DEFAULT 'absent',
    check_in TIME NULL DEFAULT NULL,
    check_out TIME NULL DEFAULT NULL,
    expected_check_in TIME DEFAULT '09:00:00',
    expected_check_out TIME DEFAULT '17:00:00',
    tardiness INT DEFAULT 0 COMMENT 'Minutes late (calculated field)',
    overtime INT DEFAULT 0 COMMENT 'Minutes of overtime (calculated field)',
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_attendance (employee_id, date)
)";

if (mysqli_query($conn, $sql)) {
    echo "Table 'attendance' created successfully<br>";
} else {
    echo "Error creating table: " . mysqli_error($conn) . "<br>";
}

// Create trigger for automatic tardiness calculation
$tardiness_trigger = "
CREATE TRIGGER IF NOT EXISTS calculate_tardiness
BEFORE INSERT ON attendance
FOR EACH ROW
BEGIN
    IF NEW.status = 'present' AND NEW.check_in IS NOT NULL AND NEW.expected_check_in IS NOT NULL AND NEW.check_in > NEW.expected_check_in THEN
        SET NEW.tardiness = TIMESTAMPDIFF(MINUTE, NEW.expected_check_in, NEW.check_in);
    ELSE
        SET NEW.tardiness = 0;
    END IF;
END;
";

// Create trigger for automatic overtime calculation
$overtime_trigger = "
CREATE TRIGGER IF NOT EXISTS calculate_overtime
BEFORE INSERT ON attendance
FOR EACH ROW
BEGIN
    IF NEW.status = 'present' AND NEW.check_out IS NOT NULL AND NEW.expected_check_out IS NOT NULL AND NEW.check_out > NEW.expected_check_out THEN
        SET NEW.overtime = TIMESTAMPDIFF(MINUTE, NEW.expected_check_out, NEW.check_out);
    ELSE
        SET NEW.overtime = 0;
    END IF;
END;
";

// Create update triggers for when attendance records are modified
$tardiness_update_trigger = "
CREATE TRIGGER IF NOT EXISTS update_tardiness
BEFORE UPDATE ON attendance
FOR EACH ROW
BEGIN
    IF NEW.status = 'present' AND NEW.check_in IS NOT NULL AND NEW.expected_check_in IS NOT NULL AND NEW.check_in > NEW.expected_check_in THEN
        SET NEW.tardiness = TIMESTAMPDIFF(MINUTE, NEW.expected_check_in, NEW.check_in);
    ELSE
        SET NEW.tardiness = 0;
    END IF;
END;
";

$overtime_update_trigger = "
CREATE TRIGGER IF NOT EXISTS update_overtime
BEFORE UPDATE ON attendance
FOR EACH ROW
BEGIN
    IF NEW.status = 'present' AND NEW.check_out IS NOT NULL AND NEW.expected_check_out IS NOT NULL AND NEW.check_out > NEW.expected_check_out THEN
        SET NEW.overtime = TIMESTAMPDIFF(MINUTE, NEW.expected_check_out, NEW.check_out);
    ELSE
        SET NEW.overtime = 0;
    END IF;
END;
";

// Apply trigger creations
if (mysqli_query($conn, $tardiness_trigger)) {
    echo "Tardiness calculation trigger created successfully<br>";
} else {
    echo "Error creating tardiness trigger: " . mysqli_error($conn) . "<br>";
}

if (mysqli_query($conn, $overtime_trigger)) {
    echo "Overtime calculation trigger created successfully<br>";
} else {
    echo "Error creating overtime trigger: " . mysqli_error($conn) . "<br>";
}

if (mysqli_query($conn, $tardiness_update_trigger)) {
    echo "Tardiness update trigger created successfully<br>";
} else {
    echo "Error creating tardiness update trigger: " . mysqli_error($conn) . "<br>";
}

if (mysqli_query($conn, $overtime_update_trigger)) {
    echo "Overtime update trigger created successfully<br>";
} else {
    echo "Error creating overtime update trigger: " . mysqli_error($conn) . "<br>";
}

// Insert sample data with varying check-in/check-out times to demonstrate calculations
$today = date('Y-m-d');
$yesterday = date('Y-m-d', strtotime('-1 day'));

// Get actual employee IDs from your employee table
$employeeQuery = "SELECT id FROM employees LIMIT 5";
$employeeResult = mysqli_query($conn, $employeeQuery);

if ($employeeResult && mysqli_num_rows($employeeResult) > 0) {
    $sampleEmployees = [];
    while ($row = mysqli_fetch_assoc($employeeResult)) {
        $sampleEmployees[] = $row['id'];
    }
} else {
    // Fallback to sample IDs if no employees found
    $sampleEmployees = [1, 2, 3, 4, 5];
    echo "No employees found in database, using sample IDs<br>";
}

// Insert records with varying tardiness and overtime
$insertCount = 0;
$insertError = false;

foreach ($sampleEmployees as $empId) {
    // Today's attendance - mix of on-time, late, and early leaving
    $status = ($empId % 3 != 0) ? 'present' : 'absent';
    
    // Employee 1: On time, with overtime
    if ($empId == 1 && $status == 'present') {
        $check_in = '09:00:00';
        $check_out = '18:30:00'; // 1.5 hours overtime
    } 
    // Employee 2: Late arrival, normal departure
    else if ($empId == 2 && $status == 'present') {
        $check_in = '09:20:00'; // 20 minutes late
        $check_out = '17:00:00';
    }
    // Others: random variations
    else if ($status == 'present') {
        // Random lateness between 0-30 minutes
        $late_minutes = rand(0, 30);
        $check_in = date('H:i:s', strtotime('09:00:00') + ($late_minutes * 60));
        
        // Random overtime between 0-60 minutes
        $overtime_minutes = rand(0, 60);
        $check_out = date('H:i:s', strtotime('17:00:00') + ($overtime_minutes * 60));
    } else {
        $check_in = NULL;
        $check_out = NULL;
    }
    
    $expected_in = '09:00:00';
    $expected_out = '17:00:00';
    
    $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO attendance 
                                  (employee_id, date, status, check_in, check_out, expected_check_in, expected_check_out) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "issssss", $empId, $today, $status, $check_in, $check_out, $expected_in, $expected_out);
        if (mysqli_stmt_execute($stmt)) {
            $insertCount++;
        } else {
            $insertError = true;
            echo "Error inserting record: " . mysqli_stmt_error($stmt) . "<br>";
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Prepare failed: " . mysqli_error($conn) . "<br>";
    }
    
    // Yesterday's attendance
    $status = ($empId != 3) ? 'present' : 'leave';
    
    if ($status == 'present') {
        // Random variations for yesterday
        $late_minutes = rand(0, 45); // Some more extreme lateness
        $check_in = date('H:i:s', strtotime('09:00:00') + ($late_minutes * 60));
        
        $overtime_minutes = rand(0, 90); // Some more extreme overtime
        $check_out = date('H:i:s', strtotime('17:00:00') + ($overtime_minutes * 60));
    } else {
        $check_in = NULL;
        $check_out = NULL;
    }
    
    $stmt = mysqli_prepare($conn, "INSERT IGNORE INTO attendance 
                                  (employee_id, date, status, check_in, check_out, expected_check_in, expected_check_out) 
                                  VALUES (?, ?, ?, ?, ?, ?, ?)");
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "issssss", $empId, $yesterday, $status, $check_in, $check_out, $expected_in, $expected_out);
        if (mysqli_stmt_execute($stmt)) {
            $insertCount++;
        } else {
            $insertError = true;
            echo "Error inserting record: " . mysqli_stmt_error($stmt) . "<br>";
        }
        mysqli_stmt_close($stmt);
    } else {
        echo "Prepare failed: " . mysqli_error($conn) . "<br>";
    }
}

if (!$insertError) {
    echo "Successfully inserted $insertCount sample attendance records<br>";
}

// Display some sample calculations to verify
$query = "SELECT employee_id, date, check_in, expected_check_in, tardiness, check_out, expected_check_out, overtime 
          FROM attendance 
          WHERE status = 'present' 
          ORDER BY date DESC, employee_id ASC";

$result = mysqli_query($conn, $query);

if ($result && mysqli_num_rows($result) > 0) {
    echo "<br>Sample attendance records with calculations:<br>";
    echo "<table border='1'>";
    echo "<tr><th>Employee</th><th>Date</th><th>Check In</th><th>Expected In</th><th>Tardiness (min)</th>
          <th>Check Out</th><th>Expected Out</th><th>Overtime (min)</th></tr>";
    
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['employee_id'] . "</td>";
        echo "<td>" . $row['date'] . "</td>";
        echo "<td>" . $row['check_in'] . "</td>";
        echo "<td>" . $row['expected_check_in'] . "</td>";
        echo "<td>" . $row['tardiness'] . "</td>";
        echo "<td>" . $row['check_out'] . "</td>";
        echo "<td>" . $row['expected_check_out'] . "</td>";
        echo "<td>" . $row['overtime'] . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
} else {
    echo "No records found or error in query: " . mysqli_error($conn) . "<br>";
}

// Function to check if the table was created correctly
$result = mysqli_query($conn, "DESCRIBE attendance");
if ($result) {
    echo "<br>Updated attendance table structure:<br>";
    echo "<pre>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo $row['Field'] . " - " . $row['Type'] . "\n";
    }
    echo "</pre>";
} else {
    echo "Could not retrieve table structure: " . mysqli_error($conn) . "<br>";
}

echo "Creation process completed. The adminHome.php should now work correctly with overtime and tardiness tracking.";
?>