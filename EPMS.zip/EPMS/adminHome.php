<?php
// Start session for user authentication
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    // Redirect to login page if not logged in
    header("Location: adminLogin.php");
    exit();
}

// Include database connection
require_once 'database.php';

// Fetch admin information
$admin_id = $_SESSION['admin_id'];
$query = "SELECT * FROM admins WHERE admin_id = ?";
$stmt = mysqli_prepare($conn, $query);
if (!$stmt) {
    echo "Prepare failed: " . mysqli_error($conn);
    exit;
}
mysqli_stmt_bind_param($stmt, "s", $param);
if (!mysqli_stmt_execute($stmt)) {
    echo "Execute failed: " . mysqli_stmt_error($stmt);
    exit;
}
$result = mysqli_stmt_get_result($stmt);
if (!$result) {
    echo "Getting result failed: " . mysqli_stmt_error($stmt);
    exit;
}
$admin = mysqli_fetch_assoc($result);

// Get total employee count
$query = "SELECT COUNT(*) as total FROM employees";
$result = mysqli_query($conn, $query);
if (!$result) {
    echo "Database query failed: " . mysqli_error($conn);
    exit;
}
$row = mysqli_fetch_assoc($result);

// Get new employees this month
$query = "SELECT COUNT(*) as new_employees FROM employees WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())";
$result = mysqli_query($conn, $query);
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $new_employees = isset($row['new_employees']) ? $row['new_employees'] : 0;
} else {
    // Handle the error - query failed
    $new_employees = 0; // Set a default value
   
}
// Get attendance for today
$today = date('Y-m-d');
$query = "SELECT COUNT(*) as present FROM attendance WHERE date = ? AND status = 'present'";
$stmt = mysqli_prepare($conn, $query);
if ($stmt === false) {
    die("Prepare failed: " . mysqli_error($conn) . " SQL: " . $query);
}
mysqli_stmt_bind_param($stmt, "s", $today);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$row = mysqli_fetch_assoc($result);
$present_today = $row['present'];

// Get total employees count
$query = "SELECT COUNT(*) as total FROM employees";
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $total_employees = $row['total'];
} else {
    $total_employees = 0; // Fallback value
}
// Calculate attendance percentage
$attendance_percentage = ($total_employees > 0) ? round(($present_today / $total_employees) * 100, 1) : 0;

// Get pending requests
$query = "SELECT COUNT(*) as pending FROM employee_requests WHERE status = 'pending'";
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $pending_requests = $row['pending'];
} else {
    $pending_requests = 0; // Fallback value
    // Optionally log the error
    error_log("Database query failed: " . mysqli_error($conn));
}

// Get new requests today
$query = "SELECT COUNT(*) as new_today FROM employee_requests WHERE DATE(created_at) = CURRENT_DATE() AND status = 'pending'";
$result = mysqli_query($conn, $query);
if ($result) {
    $row = mysqli_fetch_assoc($result);
    $new_today = isset($row['new_today']) ? $row['new_today'] : 0;
} else {
    // Handle the error - query failed
    $new_today = 0; // Set a default value
    error_log("Query failed: " . mysqli_error($conn)); // Log the error
}
// Get recent activities
$query = "SELECT * FROM (
    SELECT 'New Employee Added' as activity_type, full_name, department, created_at, NULL as request_type, NULL as details
    FROM employees
    WHERE created_at IS NOT NULL
    
    UNION ALL
    
    SELECT 'Salary Processed' as activity_type, NULL as full_name, NULL as department, processed_date as created_at, NULL as request_type, month as details
    FROM salary_payments
    WHERE processed_date IS NOT NULL
    
    UNION ALL
    
    SELECT 'Leave Request' as activity_type, employee_name as full_name, NULL as department, created_at, 'leave' as request_type, days as details
    FROM employee_requests
    WHERE request_type = 'leave'
    
    UNION ALL
    
    SELECT 'Profile Updated' as activity_type, full_name, NULL as department, updated_at as created_at, NULL as request_type, NULL as details
    FROM employees
    WHERE updated_at IS NOT NULL
) AS activities
ORDER BY created_at DESC
LIMIT 4";

$recent_activities = mysqli_query($conn, $query);
if (!$recent_activities) {
    error_log("Recent activities query failed: " . mysqli_error($conn));
    // Create an empty result set or set to false
    // This is to prevent fatal errors when using mysqli_num_rows later
    $recent_activities = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Arial', sans-serif;
        }
        
        body {
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background-color: #333;
            color: white;
            padding-top: 20px;
        }
        
        .logo-container {
            text-align: center;
            padding: 10px;
            margin-bottom: 20px;
        }
        
        .logo-img {
            width: 100px;
            height: 100px;
            object-fit: contain;
        }
        
        .system-name {
            text-align: center;
            font-size: 14px;
            margin-top: 15px;
            color: #f0c14b;
        }
        
        .admin-profile {
            text-align: center;
            padding: 20px 0;
            border-top: 1px solid #444;
            border-bottom: 1px solid #444;
            margin: 20px 0;
        }
        
        .profile-img {
            display: inline-block;
            padding: 8px 15px;
            background-color: #f0c14b;
            border-radius: 20px;
            font-weight: bold;
            color: #333;
        }
        
        .admin-name {
            margin-top: 10px;
            font-weight: bold;
        }
        
        .admin-role {
            font-size: 12px;
            color: #ccc;
        }
        
        .nav-menu {
            list-style: none;
        }
        
        .nav-item {
            padding: 15px 20px;
            transition: all 0.3s;
        }
        
        .nav-item:hover, .nav-item.active {
            background-color: #444;
            border-left: 4px solid #f0c14b;
        }
        
        .nav-item i {
            margin-right: 10px;
            color: #f0c14b;
        }
        
        .nav-link {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
        }
        
        .content {
            flex: 1;
            background-color: #f5f5f5;
        }
        
        .header {
            background-color: white;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .dashboard-title {
            font-size: 24px;
            color: #333;
        }
        
        .add-btn {
            background-color: #f0c14b;
            color: #333;
            border: none;
            padding: 10px 20px;
            border-radius: 4px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            align-items: center;
        }
        
        .add-btn i {
            margin-right: 5px;
        }
        
        .dashboard-content {
            padding: 20px;
        }
        
        .stats-container {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            flex: 1;
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            position: relative;
        }
        
        .stat-icon {
            position: absolute;
            top: 20px;
            right: 20px;
            width: 40px;
            height: 40px;
            background-color: rgba(240, 193, 75, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #f0c14b;
        }
        
        .stat-title {
            color: #777;
            font-size: 16px;
            margin-bottom: 10px;
        }
        
        .stat-value {
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .stat-detail {
            font-size: 12px;
            color: #4CAF50;
        }
        
        .activities-container {
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .activities-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .activities-title {
            font-size: 18px;
            color: #333;
        }
        
        .view-all {
            color: #777;
            text-decoration: none;
        }
        
        .activity-item {
            display: flex;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .activity-item:last-child {
            border-bottom: none;
        }
        
        .activity-icon {
            width: 40px;
            height: 40px;
            background-color: rgba(240, 193, 75, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #f0c14b;
            margin-right: 15px;
        }
        
        .activity-details {
            flex: 1;
        }
        
        .activity-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .activity-description {
            color: #777;
            font-size: 14px;
        }
        
        .activity-time {
            color: #999;
            font-size: 12px;
            text-align: right;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img">
            <div class="system-name">
                Employment Payment<br>Management System<br>EPMS
            </div>
        </div>
        
        <div class="admin-profile">
            <div class="profile-img">Admin Profile</div>
            <div class="admin-name"><?php echo htmlspecialchars(isset($admin) && isset($admin['full_name']) ? $admin['full_name'] : 'Admin User'); ?></div>
            <div class="admin-role">HR Admin</div>
        </div>
        
        <ul class="nav-menu">
            <li class="nav-item active">
                <a href="adminHome.php" class="nav-link">
                    <i class="fas fa-home"></i> Admin Home
                </a>
            </li>
            <li class="nav-item">
                <a href="employee_details.php" class="nav-link">
                    <i class="fas fa-users"></i> Employee Details
                </a>
            </li>
            <li class="nav-item">
                <a href="view_attendance.php" class="nav-link">
                    <i class="fas fa-clipboard-check"></i> Attendance
                </a>
            </li>
            <li class="nav-item">
                <a href="salaryCalculation.php" class="nav-link">
                    <i class="fas fa-calculator"></i> Salary Calculation
                </a>
            </li>
            <li class="nav-item">
                <a href="employeeRequests.php" class="nav-link">
                    <i class="fas fa-bell"></i> Employee Requests
                </a>
            </li>
            <li class="nav-item">
                <a href="index.php" class="nav-link">
                    <i class="fas fa-sign-out-alt"></i> Logout
                </a>
            </li>
        </ul>
    </div>
    
    <div class="content">
        <div class="header">
            <h1 class="dashboard-title">Admin Dashboard</h1>
            <button class="add-btn" onclick="location.href='add_employee.php'">
                <i class="fas fa-plus"></i> Add Employee
            </button>
        </div>
        
        <div class="dashboard-content">
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-users"></i>
                    </div>
                    <div class="stat-title">Total Employees</div>
                    <div class="stat-value"><?php echo $total_employees; ?></div>
                    <div class="stat-detail">+<?php echo $new_employees; ?> this month</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clipboard-check"></i>
                    </div>
                    <div class="stat-title">Present Today</div>
                    <div class="stat-value"><?php echo $present_today; ?></div>
                    <div class="stat-detail"><?php echo $attendance_percentage; ?>% attendance</div>
                </div>
                
                <div class="stat-card">
                    <div class="stat-icon">
                        <i class="fas fa-clock"></i>
                    </div>
                    <div class="stat-title">Pending Requests</div>
                    <div class="stat-value"><?php echo $pending_requests; ?></div>
                    <div class="stat-detail"><?php echo $new_today; ?> new today</div>
                </div>
            </div>
            
            <div class="activities-container">
                <div class="activities-header">
                    <h2 class="activities-title">Recent Activity</h2>
                    <a href="activities.php" class="view-all">View All</a>
                </div>
                
                <?php 
                if ($recent_activities && mysqli_num_rows($recent_activities) > 0) {
                    while ($activity = mysqli_fetch_assoc($recent_activities)) {
                        $icon_class = "";
                        
                        // Added safety check for 'created_at' field
                        if (isset($activity['created_at'])) {
                            $time_ago = time_elapsed_string($activity['created_at']);
                        } else {
                            $time_ago = "unknown time";
                        }
                        
                        if (isset($activity['activity_type'])) {
                            // Set icon based on activity type
                            switch ($activity['activity_type']) {
                                case 'New Employee Added':
                                    $icon_class = "fas fa-user-plus";
                                    $full_name = isset($activity['full_name']) ? $activity['full_name'] : 'Someone';
                                    $department = isset($activity['department']) ? $activity['department'] : 'a department';
                                    $description = htmlspecialchars($full_name) . " was added to the " . htmlspecialchars($department) . " team";
                                    break;
                                case 'Salary Processed':
                                    $icon_class = "fas fa-money-check-alt";
                                    $details = isset($activity['details']) ? $activity['details'] : '';
                                    $description = htmlspecialchars($details) . " salaries have been processed";
                                    break;
                                case 'Leave Request':
                                    $icon_class = "fas fa-calendar-alt";
                                    $full_name = isset($activity['full_name']) ? $activity['full_name'] : 'Someone';
                                    $details = isset($activity['details']) ? $activity['details'] : '';
                                    $description = htmlspecialchars($full_name) . " requested " . htmlspecialchars($details) . " days of annual leave";
                                    break;
                                case 'Profile Updated':
                                    $icon_class = "fas fa-user-edit";
                                    $full_name = isset($activity['full_name']) ? $activity['full_name'] : 'Someone';
                                    $description = htmlspecialchars($full_name) . " updated his contact information";
                                    break;
                                default:
                                    $icon_class = "fas fa-bell";
                                    $description = "Activity recorded";
                            }
                        } else {
                            $icon_class = "fas fa-bell";
                            $description = "Unknown activity";
                        }
                ?>
                <div class="activity-item">
                    <div class="activity-icon">
                        <i class="<?php echo $icon_class; ?>"></i>
                    </div>
                    <div class="activity-details">
                        <div class="activity-title"><?php echo htmlspecialchars($activity['activity_type']); ?></div>
                        <div class="activity-description"><?php echo $description; ?></div>
                    </div>
                    <div class="activity-time"><?php echo $time_ago; ?></div>
                </div>
                <?php
                    }
                } else {
                    echo '<div class="activity-item"><div class="activity-description">No recent activities found.</div></div>';
                }
                ?>
            </div>
        </div>
    </div>

    <script>
        // Optional JavaScript for enhanced UI interactions
    </script>
</body>
</html>

<?php
// Helper function to calculate time elapsed
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $diff->w = floor($diff->d / 7);
    $diff->d -= $diff->w * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>