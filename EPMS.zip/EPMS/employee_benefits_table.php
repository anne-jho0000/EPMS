<?php
// Include database connection
require_once 'database.php';

// SQL to create employee benefits table
$sql = "CREATE TABLE IF NOT EXISTS employee_benefits (
    benefit_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    emp_id INT(11) NOT NULL,
    sss_number VARCHAR(20),
    sss_contribution DECIMAL(10,2) DEFAULT 0.00,
    pagibig_number VARCHAR(20),
    pagibig_contribution DECIMAL(10,2) DEFAULT 0.00,
    philhealth_number VARCHAR(20),
    philhealth_contribution DECIMAL(10,2) DEFAULT 0.00, 
    tin_number VARCHAR(20),
    tax_contribution DECIMAL(10,2) DEFAULT 0.00,
    other_benefits TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

// Execute query
if (mysqli_query($conn, $sql)) {
    echo "Employee benefits table created successfully!";
} else {
    echo "Error creating benefits table: " . mysqli_error($conn);
}

// Close connection
mysqli_close($conn);
?>