<?php
// Start session
session_start();

// Include database connection
require_once 'database.php';

// Initialize variables
$error_message = "";

// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login"])) {
    // Get and validate form data
    $employee_id = filter_input(INPUT_POST, "employee_id", FILTER_SANITIZE_SPECIAL_CHARS);
    $password = $_POST["password"]; // Don't sanitize password before verification

    // Check if fields are empty
    if (empty($employee_id) || empty($password)) {
        $error_message = "Please enter both employee ID and password.";
    } else {
        // Prepare SQL statement to prevent SQL injection
        $query = "SELECT * FROM employees WHERE employee_id = ?";
        $stmt = mysqli_prepare($conn, $query);
        
        if (!$stmt) {
            $error_message = "Database error: " . mysqli_error($conn);
        } else {
            mysqli_stmt_bind_param($stmt, "s", $employee_id);
            
            // Execute the query
            if (!mysqli_stmt_execute($stmt)) {
                $error_message = "Execute failed: " . mysqli_stmt_error($stmt);
            } else {
                $result = mysqli_stmt_get_result($stmt);
                
                if (!$result) {
                    $error_message = "Getting result failed: " . mysqli_stmt_error($stmt);
                } else {
                    // Check if employee exists
                    if (mysqli_num_rows($result) == 1) {
                        $employee = mysqli_fetch_assoc($result);
                        
                        // Verify password (assuming passwords are hashed)
                        if (password_verify($password, $employee["password"])) {
                            // Password is correct, start a new session
                            $_SESSION["loggedin"] = true;
                            $_SESSION["id"] = $employee["id"];
                            $_SESSION["employee_id"] = $employee["employee_id"];
                            $_SESSION["full_name"] = $employee["full_name"];
                            
                            // Redirect to index page
                            header("location: employeeHome.php");
                            exit;
                        } else {
                            // Password is not valid
                            $error_message = "Invalid employee ID or password.";
                        }
                    } else {
                        // Employee ID doesn't exist
                        $error_message = "Invalid employee ID or password.";
                    }
                }
            }
            
            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Login - EPMS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #1e2633;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .login-container {
            background-color: #0e1521;
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(255, 216, 77, 0.2);
            width: 100%;
            max-width: 900px;
            overflow: hidden;
            display: flex;
            position: relative;;
        }
        .login-container::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(255, 216, 77, 0.4);
            pointer-events: none;
        }

        .login-form {
            flex: 1;
            padding: 40px;
            color: white;
        }
        
        .login-info {
            flex: 1;
            background: linear-gradient(135deg, #ffd84d 0%, #ffc107 100%);
            color: #333;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            clip-path: polygon(10% 0, 100% 0, 100% 100%, 0 100%);
        }
        
        .logo img {
            width: 100px;
            margin-bottom: 30px;
        }
        
        h1 {
            font-size: 2rem;
            margin-bottom: 10px;
            color: white;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        label {
            display: block;
            color: #fff;
            margin-bottom: 8px;
            font-weight: bold;
        }
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #ccc;
        }
        
        input[type="text"],
        input[type="password"] {
            width: 100%;
            padding: 15px;
            background-color: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 25px;
            color: #fff;
            font-size: 16px;
            padding-left: 45px;
        }
        
        input[type="text"]::placeholder,
        input[type="password"]::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        
        input:focus {
            border-color: #ffd84d;
            outline: none;
            box-shadow: 0 0 0 2px rgba(255, 216, 77, 0.3);
        }
        
        .input-icon {
            position: absolute;
            left: 20px;
            top: 15px;
            color: #f0c14b;
        }
        
        .forgot-password {
            text-align: right;
            margin-bottom: 25px;
        }
        
        .forgot-password a {
            color: #f0c14b;
            text-decoration: none;
        }
        
        .login-btn {
            width: 100%;
            padding: 15px;
            background-color: #f0c14b;
            border: none;
            border-radius: 25px;
            color: #333;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .login-btn:hover {
            background-color: #e0b346;
        }
        
        .register-link {
            margin-top: 25px;
            text-align: center;
            color: #fff;
        }
        
        .register-link a {
            color: #f0c14b;
            text-decoration: none;
            font-weight: bold;
        }
        
        .welcome-text {
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .welcome-text h2 {
            font-size: 36px;
            margin-bottom: 20px;
            color: #333;
        }
        
        .welcome-text p {
            font-size: 16px;
            line-height: 1.6;
            color: #333;
        }
        
        .welcome-image {
            text-align: center;
            margin: 30px 0;
        }
        
        .welcome-image img {
            max-width: 120px;
        }
        
        .home-btn {
            display: inline-block;
            padding: 12px 40px;
            background: linear-gradient(to right, #f0c14b, #daa520);
            border: none;
            border-radius: 25px;
            color: #333;
            text-decoration: none;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s;
        }
        
        .home-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 10px rgba(0, 0, 0, 0.2);
        }
        
        .system-name {
            text-align: center;
            margin-top: 25px;
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
        }
        
        .error-message {
            background-color: rgba(255, 0, 0, 0.1);
            color: #ff6b6b;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            border-left: 4px solid #ff6b6b;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <div class="login-form">
            <div class="logo">
                <img src="images/logo2.png" alt="EPMS Logo">
            </div>
            
            <h1>Login</h1>
            
            <?php if (!empty($error_message)): ?>
                <div class="error-message">
                    <?php echo $error_message; ?>
                </div>
            <?php endif; ?>
            
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                    <label for="employeeId">Employee ID</label>
                    <div class="input-container">
                        <span class="input-icon">👤</span>
                        <input type="text" id="employeeId" name="employeeId" placeholder="Enter your employee ID" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <div class="input-container">
                        <span class="input-icon">🔒</span>
                        <input type="password" id="password" name="password" placeholder="Enter your password" required>
                    </div>
                </div>
                
                <div class="forgot-password">
                    <a href="forgot_password.php">Forgot Password?</a>
                </div>
                
                <button type="submit" class="login-btn" name="login">Login</button>
            
            
            <div class="register-link">
                Don't have an account? <a href="admin-contact.php">Contact Admin</a>
            </div>
            
            <div class="system-name">
                Employment Payment Management System (EPMS)
            </div>
            </form>
        </div>
        
        <div class="login-info">
            <div class="welcome-text">
                <h2>WELCOME BACK!</h2>
                <p>Log in to access your Employment Payment Management System dashboard. Track payments, manage accounts, and view your employment records.</p>
            </div>
            
            <div class="welcome-image">
                <div style="background-color: #333; width: 120px; height: 70px; margin: 0 auto; border-radius: 5px; display: flex; flex-direction: column; justify-content: center; align-items: center;">
                    <div style="width: 30px; height: 30px; background-color: #f0c14b; border-radius: 50%;"></div>
                    <div style="width: 60px; height: 4px; background-color: #f0c14b; margin-top: 10px;"></div>
                    <div style="width: 60px; height: 4px; background-color: #f0c14b; margin-top: 5px;"></div>
                </div>
            </div>
            
            <div style="text-align: center;">
                <a href="index.php" class="home-btn">Home</a>
            </div>
        </div>
    </div>
</body>
</html>