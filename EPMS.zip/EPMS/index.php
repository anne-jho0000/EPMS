<?php
// Include database connection
require_once 'database.php';

// Initialize variables
$message = '';
$page_title = 'Employment Payment Management System';

// Function to sanitize input data
function sanitize_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    if($conn) {
        $data = mysqli_real_escape_string($conn, $data);
    }
    return $data;
}

// Handle form submissions if any
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(isset($_POST['contact_form'])) {
        // Process contact form
        $name = sanitize_input($_POST['name']);
        $email = sanitize_input($_POST['email']);
        $message_content = sanitize_input($_POST['message']);
        
        if($conn) {
            $sql = "INSERT INTO contact_messages (name, email, message, submission_date) 
                    VALUES ('$name', '$email', '$message_content', NOW())";
            
            if(mysqli_query($conn, $sql)) {
                $message = "Thank you for contacting us. We'll get back to you soon!";
            } else {
                $message = "Error: " . mysqli_error($conn);
            }
        } else {
            $message = "Database connection error. Please try again later.";
        }
    }
}

        // Default features if database query fails or table is empty
        $features = [
            [
                'icon' => '💰', 
                'title' => 'Automated Payroll Processing',
                'description' => 'Calculate salaries, taxes, and deductions automatically with real-time accuracy.'
            ],
            [
                'icon' => '📊', 
                'title' => 'Financial Reports & Insights',
                'description' => 'Generate detailed reports to track payroll history, employee payments, and tax documentation.'
            ],
            [
                'icon' => '⌛', 
                'title' => 'Attendance Tracking',
                'description' => 'Seamlessly integrate attendance records with payroll using QR code scanning.'
            ],
            [
                'icon' => '🔒', 
                'title' => 'Secure Role-Based Access',
                'description' => 'Protect sensitive data with encrypted storage and controlled user permissions.'
            ],
            [
                'icon' => '👤', 
                'title' => 'Employee Self-Service Portal',
                'description' => 'Enable employees to view payslips, track attendance, and update personal details.'
            ]
        ];

// Track page visit (if connected to database)
if($conn) {
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $user_agent = $_SERVER['HTTP_USER_AGENT'];
    $page = 'landing_page';
    
    $sql = "INSERT INTO page_visits (ip_address, user_agent, page, visit_date) 
            VALUES ('$ip_address', '$user_agent', '$page', NOW())";
    mysqli_query($conn, $sql);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employment Payment Management System (EPMS)</title>
    <link rel="stylesheet" href="css/styles.css">
    <!-- You can add more CSS frameworks or libraries here -->
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="logo">
            <img src="images/epms(logo).jpg" alt="EPMS Logo">
            
        </div>
        <button class="nav-toggle" id="navToggle">☰</button>
        <nav class="nav-links" id="navLinks">
            <a href="#">Home</a>
            <a href="about.html">About</a>
            <a href="#features">Features</a>
            <a href="#support">Support</a>
        </nav>
        <div class="login-buttons">
            <button class="login-btn employee-btn" id="employeeLoginBtn" onclick="location.href='employeeLogin.php';">
                Employee Login
            </button>
            
            <button class="login-btn admin-btn" id="adminLoginBtn" onclick="location.href='adminLogin.php';">Admin Login</button>
        </div>
    </header>

    <!-- Main Banner -->
    <section class="hero">
            <img src="assets/images/epms(logo).jpg" alt="EPMS Logo" class="hero-logo">
            <h1 style="font-family: Georgia, serif;  font-size: 35px; color: #333;">Employment Payment Management System</h1>
            <p style="font-family: Comic Sans MS, cursive;">Streamline your payroll processing, manage employee compensation, and ensure timely payments with our comprehensive EPMS solution.</p>
            <a href="about.html" class="cta-button">Learn More</a>
        </section>

        <section id="features" class="features">
        <div class="container">
            <h2 class="section-title">Key Features</h2>
            <div class="features-grid">
                <?php foreach($features as $feature): ?>
                <div class="feature-card">
                    <div class="feature-icon"><?php echo $feature['icon']; ?></div>
                    <h3><?php echo $feature['title']; ?></h3>
                    <p><?php echo $feature['description']; ?></p>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

   <!-- Contact Section -->
<section id="support" class="contact-section">
    <div class="container">
        <div class="contact-wrapper">
            <!-- Assistance Header -->
            <div class="assistance-header">
                <h2>Need Assistance?</h2>
                <p>We're here to help! Reach out to us through the following channels:</p>
            </div>
            
            <!-- Contact Info -->
            <div class="contact-info">
                <h3>Contact Us</h3>
                
                <div class="contact-details">
                    <div class="contact-item">
                        <span class="contact-label">Email:</span>
                        <span class="contact-value">joromaraog@my.cspc.edu.ph</span>
                    </div>
                    
                    <div class="contact-item">
                        <span class="contact-label">Live Chat:</span>
                        <span class="contact-value">Available Mon - Fri, 8 AM - 6 PM</span>
                    </div>
                    
                    <div class="contact-item">
                        <span class="contact-label">Office Hours:</span>
                        <span class="contact-value">Mon - Fri, 8 AM - 6 PM</span>
                    </div>
                </div>
            </div>
            
            <!-- Contact Form (Optional) -->
            <?php if(!empty($message)): ?>
                <div class="message"><?php echo $message; ?></div>
            <?php endif; ?>
            
            <div class="contact-form">
                <h3>Send us a message</h3>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <input type="hidden" name="contact_form" value="1">
                    
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Message</label>
                        <textarea id="message" name="message" rows="4" required></textarea>
                    </div>
                    
                    <button type="submit" class="btn submit-btn">Send Message</button>
                </form>
            </div>
        </div>
    </div>
</section>

    <!-- Footer -->
    <footer>
        <div class="footer">
            <div class="footer-content">
                <div class="footer-logo">
                    <img src="images/epms(logo).jpg" alt="EPMS Logo">
                    <p>Employment Payment Management Systems</p>
                </div>
                
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <ul>
                    <a href="#">Home</a>
                    <a href="about.html">About</a>
                    <a href="#features">Features</a>
                    <a href="#support">Support</a>
                    <li><a href="privacy.php">Privacy Policy</a></li>
                    </ul>
                </div>
                
                <div class="footer-contact">
                    <h4>Contact Us</h4>
                    <p>Email: joromaraog@my.cspc.edu.ph</p>
                    <p>Phone: 09108038359</p>
                </div>
            </div>
            
            <div class="copyright">
                <p>&copy; <?php echo date("Y"); ?> Employment Payment Management System. All Rights Reserved.</p>
            </div>
        </div>
    </footer>

    <!-- JavaScript -->
    <script src="js/script.js"></script>
</body>
</html>