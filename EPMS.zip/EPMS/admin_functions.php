<?php
// Include database connection if not already included
if (!function_exists('mysqli_connect') && file_exists('database.php')) {
    require_once 'database.php';
}

/**
 * Initialize the admin activity tracking system
 */
function initAdminActivitySystem() {
    global $conn;
    
    // Check if admin_activities table exists
    $result = mysqli_query($conn, "SHOW TABLES LIKE 'admin_activities'");
    if (mysqli_num_rows($result) == 0) {
        // Table doesn't exist, create it
        $sql = "CREATE TABLE admin_activities (
            activity_id INT AUTO_INCREMENT PRIMARY KEY,
            admin_id VARCHAR(50) NOT NULL,
            activity_type VARCHAR(50) NOT NULL,
            description TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        mysqli_query($conn, $sql);
    }
}

/**
 * Log an admin activity
 * 
 * @param string $admin_id The admin ID
 * @param string $admin_name The admin name (optional)
 * @param string $activity_type The type of activity
 * @param string $description A description of the activity
 * @return bool True if successful, false otherwise
 */
function logAdminActivity($admin_id, $admin_name = '', $activity_type = '', $description = '') {
    global $conn;
    
    // Handle different parameter orders
    if (func_num_args() == 3) {
        // Old format: logAdminActivity($admin_id, $activity_type, $description)
        $description = $activity_type;
        $activity_type = $admin_name;
        $admin_name = '';
    }
    
    $admin_id = mysqli_real_escape_string($conn, $admin_id);
    $activity_type = mysqli_real_escape_string($conn, $activity_type);
    $description = mysqli_real_escape_string($conn, $description);
    
    // Check if admin_activity_log table exists
    $check_table = mysqli_query($conn, "SHOW TABLES LIKE 'admin_activity_log'");
    
    if (mysqli_num_rows($check_table) > 0) {
        // Use admin_activity_log table
        $sql = "INSERT INTO admin_activity_log (admin_id, admin_name, action_type, action_details) 
                VALUES ('$admin_id', '$admin_name', '$activity_type', '$description')";
    } else {
        // Fallback to admin_activities table
        $sql = "INSERT INTO admin_activities (admin_id, activity_type, description) 
                VALUES ('$admin_id', '$activity_type', '$description')";
    }
    
    return mysqli_query($conn, $sql);
}

/**
 * Get recent admin activities
 * 
 * @param int $limit Number of activities to return
 * @return array|false Array of activities or false on failure
 */
function getRecentAdminActivities($limit = 5) {
    global $conn;
    
    // Check if admin_activity_log table exists
    $check_table = mysqli_query($conn, "SHOW TABLES LIKE 'admin_activity_log'");
    
    if (mysqli_num_rows($check_table) > 0) {
        // Use admin_activity_log table
        $sql = "SELECT * FROM admin_activity_log 
                WHERE action_time >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                ORDER BY action_time DESC 
                LIMIT ?";
                
        try {
            $stmt = mysqli_prepare($conn, $sql);
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "i", $limit);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                
                if ($result) {
                    $activities = [];
                    while ($row = mysqli_fetch_assoc($result)) {
                        $activities[] = $row;
                    }
                    mysqli_free_result($result);
                    return $activities;
                }
            }
        } catch (Exception $e) {
            error_log("Error getting recent admin activities from admin_activity_log: " . $e->getMessage());
        }
    } else {
        // Fallback to admin_activities table
        $sql = "SELECT 
                activity_id, 
                admin_id, 
                activity_type as action_type, 
                description as action_details, 
                created_at as action_time,
                (SELECT full_name FROM admins WHERE admin_id = a.admin_id) as admin_name
                FROM admin_activities a
                WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
                ORDER BY created_at DESC 
                LIMIT ?";
                
        try {
            $stmt = mysqli_prepare($conn, $sql);
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "i", $limit);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                
                if ($result) {
                    $activities = [];
                    while ($row = mysqli_fetch_assoc($result)) {
                        $activities[] = $row;
                    }
                    mysqli_free_result($result);
                    return $activities;
                }
            }
        } catch (Exception $e) {
            error_log("Error getting recent admin activities from admin_activities: " . $e->getMessage());
        }
    }
    
    return false;
}

/**
 * Get all admin activities with pagination
 * 
 * @param int $page The page number
 * @param int $perPage The number of activities per page
 * @return array An array containing activities and pagination info
 */
function getAllAdminActivities($page = 1, $perPage = 10) {
    global $conn;
    
    $page = max(1, (int)$page); // Ensure page is at least 1
    $perPage = (int)$perPage; // Ensure perPage is an integer
    $offset = ($page - 1) * $perPage;
    
    // Get total count
    $countSql = "SELECT COUNT(*) as total FROM admin_activities";
    $countResult = mysqli_query($conn, $countSql);
    $totalCount = mysqli_fetch_assoc($countResult)['total'];
    
    // Get activities for current page
    $sql = "SELECT a.activity_id, a.admin_id, a.activity_type, a.description, a.created_at, 
                   adm.full_name as admin_name
            FROM admin_activities a
            JOIN admins adm ON a.admin_id = adm.admin_id
            ORDER BY a.created_at DESC
            LIMIT $offset, $perPage";
    
    $result = mysqli_query($conn, $sql);
    
    $activities = [];
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $activities[] = $row;
        }
    }
    
    return [
        'activities' => $activities,
        'total' => $totalCount,
        'page' => $page,
        'perPage' => $perPage,
        'totalPages' => ceil($totalCount / $perPage)
    ];
}

/**
 * Update admin's last login timestamp
 * 
 * @param int $admin_id The ID of the admin
 * @return bool True on success, false on failure
 */
function updateAdminLastLogin($admin_id) {
    global $conn;
    
    $current_time = date('Y-m-d H:i:s');
    $query = "UPDATE admins SET last_login = ? WHERE id = ?";
    
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        error_log("Prepare failed in updateAdminLastLogin: " . mysqli_error($conn));
        return false;
    }
    
    mysqli_stmt_bind_param($stmt, "si", $current_time, $admin_id);
    
    if (!mysqli_stmt_execute($stmt)) {
        error_log("Execute failed in updateAdminLastLogin: " . mysqli_stmt_error($stmt));
        mysqli_stmt_close($stmt);
        return false;
    }
    
    mysqli_stmt_close($stmt);
    return true;
}
?>