<?php
// Start session
session_start();

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header("Location: index.php");
    exit();
}

// Include database connection
require_once 'database.php';

$success_message = '';
$error_message = '';

// Get employee information
$emp_id = $_SESSION['employee_id'];
$query = "SELECT * FROM employees WHERE emp_id = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "i", $emp_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$employee = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    $request_type = mysqli_real_escape_string($conn, $_POST['request_type']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    
    // Insert request into database
    $sql = "INSERT INTO employee_requests (emp_id, request_type, subject, description, status) 
            VALUES (?, ?, ?, ?, 'Pending')";
    
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "isss", $emp_id, $request_type, $subject, $description);
    
    if (mysqli_stmt_execute($stmt)) {
        $success_message = "Your request has been submitted successfully!";
    } else {
        $error_message = "Error: " . mysqli_error($conn);
    }
}

// Get employee's previous requests
$sql = "SELECT * FROM employee_requests WHERE emp_id = ? ORDER BY request_date DESC";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $emp_id);
mysqli_stmt_execute($stmt);
$requests = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Requests - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #FFD700;
            --secondary-color: #333;
            --accent-color: #444;
            --success-color: #4CAF50;
            --danger-color: #f44336;
            --warning-color: #ff9800;
            --text-light: #fff;
            --text-dark: #333;
            --light-bg: #f5f5f5;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }
        
        .header {
            background-color: var(--secondary-color);
            color: var(--text-light);
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .header h2 {
            margin: 0;
            font-size: 1.5rem;
        }
        
        .logo-container {
            display: flex;
            align-items: center;
        }
        
        .logo {
            width: 80px;
            height: auto;
        }
        
        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .page-title {
            margin-bottom: 30px;
            text-align: center;
            color: var(--secondary-color);
        }
        
        .back-btn {
            background-color: var(--success-color);
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            display: inline-block;
            font-weight: bold;
            margin-bottom: 20px;
        }
        
        .back-btn:hover {
            opacity: 0.9;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #dff0d8;
            color: #3c763d;
            border: 1px solid #d6e9c6;
        }
        
        .alert-danger {
            background-color: #f2dede;
            color: #a94442;
            border: 1px solid #ebccd1;
        }
        
        .form-container {
            margin-bottom: 40px;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 8px;
        }
        
        .form-title {
            margin-top: 0;
            margin-bottom: 20px;
            color: var(--secondary-color);
            border-bottom: 2px solid var(--primary-color);
            padding-bottom: 10px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        textarea.form-control {
            min-height: 100px;
            resize: vertical;
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: opacity 0.3s;
            font-size: 16px;
        }
        
        .btn:hover {
            opacity: 0.9;
        }
        
        .btn-primary {
            background-color: var(--primary-color);
            color: var(--text-dark);
        }
        
        .btn-secondary {
            background-color: var(--secondary-color);
            color: var(--text-light);
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        
        th {
            background-color: var(--primary-color);
            color: var(--text-dark);
            font-weight: bold;
        }
        
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        
        tr:hover {
            background-color: #f1f1f1;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-align: center;
        }
        
        .status-pending {
            background-color: var(--warning-color);
            color: white;
        }
        
        .status-approved {
            background-color: var(--success-color);
            color: white;
        }
        
        .status-rejected {
            background-color: var(--danger-color);
            color: white;
        }
        
        .request-details {
            margin-top: 10px;
            padding: 10px;
            background-color: #f9f9f9;
            border-radius: 4px;
            display: none;
        }
        
        .request-response {
            margin-top: 10px;
            padding: 10px;
            background-color: #e9f7ef;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Employee Requests</h2>
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
        </div>
    </div>

    <div class="container">
        <a href="employeeHome.php" class="back-btn">
            <i class="fas fa-arrow-left"></i> Back to Dashboard
        </a>
        
        <h1 class="page-title">Request Management</h1>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <div class="form-container">
            <h3 class="form-title">Submit a New Request</h3>
            
            <form method="POST" action="">
                <div class="form-group">
                    <label for="request_type">Request Type:</label>
                    <select id="request_type" name="request_type" class="form-control" required>
                        <option value="">Select Request Type</option>
                        <option value="Leave">Leave Request</option>
                        <option value="Document">Document Request</option>
                        <option value="Salary">Salary Inquiry</option>
                        <option value="Equipment">Equipment Request</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="subject">Subject:</label>
                    <input type="text" id="subject" name="subject" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" class="form-control" required></textarea>
                </div>
                
                <div style="text-align: right;">
                    <button type="submit" name="submit_request" class="btn btn-primary">
                        <i class="fas fa-paper-plane"></i> Submit Request
                    </button>
                </div>
            </form>
        </div>
        
        <h3 class="form-title">Your Previous Requests</h3>
        
        <?php if (mysqli_num_rows($requests) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Request ID</th>
                        <th>Type</th>
                        <th>Subject</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($requests)): ?>
                        <tr>
                            <td><?php echo $row['request_id']; ?></td>
                            <td><?php echo $row['request_type']; ?></td>
                            <td><?php echo $row['subject']; ?></td>
                            <td><?php echo date('M d, Y', strtotime($row['request_date'])); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo strtolower($row['status']); ?>">
                                    <?php echo $row['status']; ?>
                                </span>
                            </td>
                            <td>
                                <button class="btn btn-secondary view-details" data-id="<?php echo $row['request_id']; ?>">
                                    <i class="fas fa-eye"></i> View
                                </button>
                                
                                <div id="details-<?php echo $row['request_id']; ?>" class="request-details">
                                    <p><strong>Description:</strong> <?php echo nl2br($row['description']); ?></p>
                                    
                                    <?php if (!empty($row['response'])): ?>
                                        <div class="request-response">
                                            <p><strong>Response:</strong> <?php echo nl2br($row['response']); ?></p>
                                            <p><small>Responded on: <?php echo date('M d, Y H:i', strtotime($row['response_date'])); ?></small></p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>You haven't submitted any requests yet.</p>
        <?php endif; ?>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Toggle request details
        const viewButtons = document.querySelectorAll('.view-details');
        
        viewButtons.forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.getAttribute('data-id');
                const detailsDiv = document.getElementById('details-' + requestId);
                
                if (detailsDiv.style.display === 'block') {
                    detailsDiv.style.display = 'none';
                    this.innerHTML = '<i class="fas fa-eye"></i> View';
                } else {
                    detailsDiv.style.display = 'block';
                    this.innerHTML = '<i class="fas fa-eye-slash"></i> Hide';
                }
            });
        });
    });
    </script>
</body>
</html>

<?php
// Close connection
mysqli_close($conn);
?>