<?php
// Start session (if not already started)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}
// Include database connection
require_once 'database.php';
if (!$conn || !($conn instanceof mysqli)) {
    // If $conn is not a valid mysqli object, something went wrong in database.php
    // Log this critical error and stop execution or show a friendly error page.
    error_log("Critical: Database connection failed or $conn is not a mysqli object in add_employee.php.");
    die("A critical database error occurred. Please contact support or check server logs.");
}

// Initialize filter variables
$filter_employee_id = isset($_GET['employee_id']) ? mysqli_real_escape_string($conn, $_GET['employee_id']) : '';
$filter_date_val = isset($_GET['attendance_date']) ? mysqli_real_escape_string($conn, $_GET['attendance_date']) : '';
$filter_status_val = isset($_GET['status']) ? mysqli_real_escape_string($conn, $_GET['status']) : '';

// Construct the base query
$sql = "SELECT a.attendance_id, a.emp_id, a.attendance_date, a.check_in, a.check_out, 
               a.expected_check_in, a.expected_check_out, a.status, 
               a.worked_hours, a.tardiness_minutes, a.overtime_minutes, a.notes,
               e.first_name, e.last_name 
        FROM attendance a 
        LEFT JOIN employees e ON a.emp_id = e.emp_id 
        WHERE 1=1"; // Base condition

// Add filter conditions using prepared statements for security and correctness
$params = [];
$types = "";

if (!empty($filter_employee_id)) {
    $sql .= " AND a.emp_id = ?";
    $params[] = $filter_employee_id;
    $types .= "i";
}
if (!empty($filter_date_val)) {
    $sql .= " AND a.attendance_date = ?"; // attendance_date is DATE type
    $params[] = $filter_date_val;
    $types .= "s";
}
if (!empty($filter_status_val)) {
    $sql .= " AND a.status = ?";
    $params[] = $filter_status_val;
    $types .= "s";
}

// Add ORDER BY clause to show latest records first
$sql .= " ORDER BY a.attendance_date DESC, a.check_in DESC";

// Prepare and execute the query
$stmt = mysqli_prepare($conn, $sql);
if ($stmt) {
    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }
    mysqli_stmt_execute($stmt);
    $result_attendance = mysqli_stmt_get_result($stmt);
    if ($result_attendance === false) {
        // Log error, don't die on page
        error_log("Attendance query execution failed: " . mysqli_stmt_error($stmt));
        $query_error_message = "Could not retrieve attendance records due to a database error.";
    }
    mysqli_stmt_close($stmt);
} else {
    // Log error, don't die on page
    error_log("Attendance query preparation failed: " . mysqli_error($conn));
    $query_error_message = "Could not prepare to retrieve attendance records.";
}


// Fetch employees for dropdown
$employees_for_filter = [];
$emp_query_for_filter = mysqli_query($conn, "SELECT emp_id, first_name, last_name FROM employees WHERE is_active = TRUE ORDER BY first_name, last_name");
if ($emp_query_for_filter) {
    while ($emp_filter_row = mysqli_fetch_assoc($emp_query_for_filter)) {
        $employees_for_filter[] = $emp_filter_row;
    }
    mysqli_free_result($emp_query_for_filter);
}

// Attendance statuses from ENUM definition (or a lookup table if it were more complex)
$attendance_statuses = ['Present', 'Absent', 'Leave', 'Half-Day', 'Weekend', 'Holiday'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Attendance Records - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root {
            --primary-color: #FFD700; /* Gold */
            --secondary-color: #333; /* Dark Gray */
            --accent-color: #555;
            --success-color: #28a745; /* Green */
            --info-color: #17a2b8; /* Teal */
            --text-light: #fff;
            --text-dark: #333;
            --light-bg: #f8f9fa;
            --white-bg: #fff;
            --border-color: #dee2e6;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: var(--light-bg);
            color: var(--text-dark);
        }
        
        .header-bar {
            background-color: var(--secondary-color);
            color: var(--text-light);
            padding: 15px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .header-bar h2 { margin: 0; font-size: 1.6rem; }
        .logo-container { display: flex; align-items: center; }
        .logo { width: 50px; height: 50px; border-radius:50%; border:2px solid var(--primary-color);}
        
        .container-main {
            max-width: 1300px; /* Wider for more columns */
            margin: 25px auto;
            padding: 25px;
            background-color: var(--white-bg);
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);
        }
        
        .page-header-controls {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .page-header-controls h1 { font-size: 1.8rem; color: var(--secondary-color); margin:0; }
        
        .nav-button {
            background-color: var(--info-color);
            color: white;
            text-decoration: none;
            padding: 10px 18px;
            border-radius: 5px;
            display: inline-flex;
            align-items: center;
            font-weight: 500;
            transition: background-color 0.2s;
        }
        .nav-button i { margin-right: 8px; }
        .nav-button:hover { background-color: #138496; }
        
        .filter-section {
            margin-bottom: 25px;
            padding: 20px;
            background-color: #fdfdfd;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            display: flex;
            gap: 15px;
            align-items: center;
            flex-wrap: wrap;
        }
        .filter-section label { font-weight:500; margin-right:5px; font-size:0.9rem;}
        .filter-section select, .filter-section input[type="date"] {
            padding: 9px 12px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            font-size: 0.95rem;
            min-width:180px;
        }
        .btn-filter, .btn-reset {
            padding: 9px 18px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
            transition: background-color 0.2s;
            font-size: 0.95rem;
            display: inline-flex;
            align-items: center;
        }
        .btn-filter i, .btn-reset i { margin-right: 6px;}
        .btn-filter { background-color: var(--primary-color); color: var(--text-dark); }
        .btn-filter:hover { background-color: #e0c000; }
        .btn-reset { background-color: var(--accent-color); color: var(--text-light); }
        .btn-reset:hover { background-color: #444; }

        .table-responsive-wrapper { overflow-x: auto; }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid var(--border-color);
            padding: 10px 12px;
            text-align: left;
            font-size: 0.88rem; /* Slightly smaller for more data */
            white-space: nowrap; /* Prevent wrapping for most cells */
        }
        th {
            background-color: #e9ecef;
            color: var(--secondary-color);
            font-weight: 600;
            position: sticky; top: 0; /* Sticky header for scrolling */
            z-index:10;
        }
        td.notes-cell { white-space: normal; min-width:150px; max-width:250px; } /* Allow notes to wrap */
        tr:nth-child(even) { background-color: #f8f9fa; }
        
        .status-Present { color: green; font-weight:bold; }
        .status-Absent { color: red; font-weight:bold; }
        .status-Leave { color: #ff7f50; font-weight:bold; } /* Coral */
        .status-Half-Day { color: #17a2b8; font-weight:bold; } /* Teal */
        .status-Weekend, .status-Holiday { color: #6c757d; font-weight:bold; } /* Gray */

        .no-records { text-align:center; padding:20px; font-style:italic; color:var(--accent-color); }
        .query-error-msg { background-color: #f8d7da; color: #721c24; border-color: #f5c6cb; padding:15px; border-radius:5px; text-align:center; margin-bottom:20px;}

    </style>
</head>
<body>
    <div class="header-bar">
        <h2>Employee Attendance Records</h2>
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
        </div>
    </div>

    <div class="container-main">
        <div class="page-header-controls">
            <h1>Attendance Overview</h1>
            <a href="adminHome.php" class="nav-button">
                <i class="fas fa-arrow-left"></i> Back to Dashboard
            </a>
        </div>

        <form method="GET" action="view_attendance.php" class="filter-section">
            <div>
                <label for="employee_id_filter">Employee:</label>
                <select name="employee_id" id="employee_id_filter">
                    <option value="">All Employees</option>
                    <?php foreach ($employees_for_filter as $emp_filter): ?>
                        <option value="<?php echo htmlspecialchars($emp_filter['emp_id']); ?>" 
                                <?php echo ($emp_filter['emp_id'] == $filter_employee_id) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($emp_filter['first_name'] . ' ' . $emp_filter['last_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div>
                <label for="attendance_date_filter">Date:</label>
                <input type="date" name="attendance_date" id="attendance_date_filter" value="<?php echo htmlspecialchars($filter_date_val); ?>">
            </div>

            <div>
                <label for="status_filter">Status:</label>
                <select name="status" id="status_filter">
                    <option value="">All Statuses</option>
                    <?php foreach ($attendance_statuses as $status_option): ?>
                        <option value="<?php echo htmlspecialchars($status_option); ?>" 
                                <?php echo ($status_option == $filter_status_val) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars(ucwords(str_replace('-', ' ', $status_option))); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <button type="submit" class="btn-filter">
                <i class="fas fa-filter"></i> Filter
            </button>
            <button type="button" onclick="window.location.href='view_attendance.php'" class="btn-reset">
                <i class="fas fa-undo"></i> Reset
            </button>
        </form>

        <?php if (isset($query_error_message)): ?>
            <div class="query-error-msg"><?php echo htmlspecialchars($query_error_message); ?></div>
        <?php endif; ?>

        <div class="table-responsive-wrapper">
            <table>
                <thead>
                    <tr>
                        <th>Emp. ID</th>
                        <th>Employee Name</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Check In</th>
                        <th>Check Out</th>
                        <th>Expected In</th>
                        <th>Expected Out</th>
                        <th>Worked (hrs)</th>
                        <th>Tardiness (min)</th>
                        <th>Overtime (min)</th>
                        <th class="notes-cell">Notes</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    if (isset($result_attendance) && $result_attendance && mysqli_num_rows($result_attendance) > 0) {
                        while ($row = mysqli_fetch_assoc($result_attendance)) {
                            $employee_name = htmlspecialchars(trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? 'N/A')));
                            $status_class = 'status-' . str_replace(' ', '-', htmlspecialchars($row['status'] ?? ''));


                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($row['emp_id'] ?? 'N/A') . "</td>";
                            echo "<td>" . $employee_name . "</td>";
                            echo "<td>" . htmlspecialchars(date('M d, Y', strtotime($row['attendance_date'] ?? ''))) . "</td>";
                            echo "<td class='{$status_class}'>" . htmlspecialchars($row['status'] ?? '') . "</td>";
                            echo "<td>" . ($row['check_in'] ? htmlspecialchars(date('h:i A', strtotime($row['check_in']))) : 'N/A') . "</td>";
                            echo "<td>" . ($row['check_out'] ? htmlspecialchars(date('h:i A', strtotime($row['check_out']))) : 'N/A') . "</td>";
                            echo "<td>" . ($row['expected_check_in'] ? htmlspecialchars(date('h:i A', strtotime($row['expected_check_in']))) : 'N/A') . "</td>";
                            echo "<td>" . ($row['expected_check_out'] ? htmlspecialchars(date('h:i A', strtotime($row['expected_check_out']))) : 'N/A') . "</td>";
                            echo "<td>" . htmlspecialchars(number_format(floatval($row['worked_hours'] ?? 0), 2)) . "</td>";
                            echo "<td>" . htmlspecialchars($row['tardiness_minutes'] ?? '0') . "</td>";
                            echo "<td>" . htmlspecialchars($row['overtime_minutes'] ?? '0') . "</td>";
                            echo "<td class='notes-cell'>" . nl2br(htmlspecialchars($row['notes'] ?? '')) . "</td>";
                            echo "</tr>";
                        }
                    } elseif (!isset($query_error_message)) { // Only show "No records" if there wasn't a query error
                        echo "<tr><td colspan='12' class='no-records'>No attendance records found matching your criteria.</td></tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

<?php
// Close the connection
if (isset($conn) && $conn instanceof mysqli) {
    mysqli_close($conn);
}
?>