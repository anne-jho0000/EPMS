<?php
// admin_settings.php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}

require_once __DIR__ . '/config.php'; // For any global constants if needed
require_once __DIR__ . '/database.php'; // For $conn
if (!$conn) {
    // Critical error: database connection failed.
    // You might want to display a user-friendly error page or die.
    die("Fatal Error: Could not connect to the database. Please check server logs or contact support.");
}

$admin_id = $_SESSION['admin_id'];
$success_message = '';
$error_message = '';

// --- Helper function to get/update app settings ---
function get_app_setting($db_conn, $setting_name, $default_value = '') {
    $stmt = $db_conn->prepare("SELECT setting_value FROM app_settings WHERE setting_name = ?");
    if ($stmt) {
        $stmt->bind_param("s", $setting_name);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($row = $result->fetch_assoc()) {
            $stmt->close();
            return $row['setting_value'];
        }
        $stmt->close();
    }
    return $default_value;
}

function update_app_setting($db_conn, $setting_name, $setting_value) {
    // Using INSERT ... ON DUPLICATE KEY UPDATE to handle both new and existing settings
    $stmt = $db_conn->prepare("INSERT INTO app_settings (setting_name, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)");
    if ($stmt) {
        $stmt->bind_param("ss", $setting_name, $setting_value);
        if ($stmt->execute()) {
            $stmt->close();
            return true;
        }
        $error = $stmt->error;
        $stmt->close();
        error_log("Failed to update app setting '$setting_name': " . $error);
        return false;
    }
    error_log("Failed to prepare statement for app setting '$setting_name': " . $db_conn->error);
    return false;
}

// --- Handle Form Submissions ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_general_settings'])) {
        $site_name_post = trim($_POST['site_name'] ?? '');
        if (empty($site_name_post)) {
            $error_message = "Site Name cannot be empty.";
        } else {
            if (update_app_setting($conn, 'site_name', $site_name_post)) {
                $success_message = "General settings updated successfully!";
            } else {
                $error_message = "Failed to update site name. Please try again.";
            }
        }
    } elseif (isset($_POST['change_password'])) {
        $current_password = $_POST['current_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';

        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error_message = "All password fields are required.";
        } elseif ($new_password !== $confirm_password) {
            $error_message = "New password and confirm password do not match.";
        } elseif (strlen($new_password) < 6) { // Example: Minimum password length
            $error_message = "New password must be at least 6 characters long.";
        } else {
            // Fetch current admin's hashed password
            $stmt = $conn->prepare("SELECT password FROM admins WHERE admin_id = ?");
            if ($stmt) {
                $stmt->bind_param("i", $admin_id);
                $stmt->execute();
                $result = $stmt->get_result();
                if ($admin_data = $result->fetch_assoc()) {
                    if (password_verify($current_password, $admin_data['password'])) {
                        // Current password is correct, hash and update new password
                        $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
                        $update_stmt = $conn->prepare("UPDATE admins SET password = ? WHERE admin_id = ?");
                        if ($update_stmt) {
                            $update_stmt->bind_param("si", $new_password_hashed, $admin_id);
                            if ($update_stmt->execute()) {
                                $success_message = "Password changed successfully!";
                            } else {
                                $error_message = "Failed to update password. Please try again.";
                                error_log("Password update failed for admin_id $admin_id: " . $update_stmt->error);
                            }
                            $update_stmt->close();
                        } else {
                             $error_message = "Database error (prepare password update).";
                             error_log("Prepare password update failed: " . $conn->error);
                        }
                    } else {
                        $error_message = "Incorrect current password.";
                    }
                } else {
                    $error_message = "Admin account not found."; // Should not happen if logged in
                }
                $stmt->close();
            } else {
                 $error_message = "Database error (prepare fetch admin).";
                 error_log("Prepare fetch admin failed: " . $conn->error);
            }
        }
    }
}

// Fetch current settings for display
$current_site_name = get_app_setting($conn, 'site_name', 'EPMS');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        /* Basic styles - adapt from your existing admin panel CSS if possible */
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background-color: #f4f6f9; color: #333; display: flex; }
        .sidebar { width: 250px; background-color: #2c3e50; color: white; padding-top: 20px; min-height: 100vh; }
        .sidebar .admin-info { text-align: center; padding: 20px; border-bottom: 1px solid #34495e; }
        .sidebar .admin-info h3 { margin: 10px 0 5px; }
        .sidebar .admin-info p { font-size: 0.9em; color: #bdc3c7; margin:0; }
        .sidebar .admin-info .role-badge { background-color: #f0c14b; color: #2c3e50; padding: 3px 8px; border-radius: 10px; font-size: 0.8em; display:inline-block; margin-bottom:10px; }

        .sidebar nav ul { list-style-type: none; padding: 0; margin: 0; }
        .sidebar nav ul li a { display: block; padding: 15px 20px; color: #ecf0f1; text-decoration: none; border-left: 3px solid transparent; }
        .sidebar nav ul li a:hover { background-color: #34495e; }
        .sidebar nav ul li a.active { background-color: #2082c4; border-left-color: #f0c14b; }
        .sidebar nav ul li a i { margin-right: 10px; }
        
        .main-content { flex-grow: 1; padding: 25px; }
        .container-main { max-width: 800px; margin: 0 auto; background-color: #fff; padding: 25px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .page-title { text-align: center; font-size: 1.8rem; color: #333; margin-bottom: 25px; }
        
        .form-section { margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #eee; }
        .form-section h3 { margin-top: 0; color: #34495e; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 5px; font-weight: 500; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size: 1rem; }
        
        .btn { padding: 10px 15px; border: none; border-radius: 4px; cursor: pointer; font-weight: 500; transition: background-color 0.2s; font-size: 0.95rem; }
        .btn-primary { background-color: #3498db; color: white; }
        .btn-primary:hover { background-color: #2980b9; }
        .nav-button { background-color: #28a745; color: white; text-decoration: none; padding: 10px 18px; border-radius: 5px; display: inline-flex; align-items:center; font-weight: 500; margin-bottom: 25px; }
        .nav-button i { margin-right: 8px; }
        .nav-button:hover { background-color: #1e7e34; }
        
        .message { padding: 10px; margin-bottom: 20px; border-radius: 4px; text-align: center; }
        .success-message { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error-message { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
    </style>
</head>
<body>
    <?php
        // Fetch admin name for sidebar (example)
        $admin_name = "Admin User"; // Placeholder
        $admin_role = "Super Admin"; // Placeholder
        $stmt_admin_info = $conn->prepare("SELECT full_name, role FROM admins WHERE admin_id = ?");
        if ($stmt_admin_info) {
            $stmt_admin_info->bind_param("i", $admin_id);
            $stmt_admin_info->execute();
            $res_admin_info = $stmt_admin_info->get_result();
            if ($row_admin_info = $res_admin_info->fetch_assoc()) {
                $admin_name = htmlspecialchars($row_admin_info['full_name']);
                $admin_role = htmlspecialchars($row_admin_info['role']);
            }
            $stmt_admin_info->close();
        }
    ?>
    <div class="sidebar">
        <div class="admin-info">
            <span class="role-badge"><?php echo $admin_role; ?></span>
            <h3><?php echo $admin_name; ?></h3>
             <!-- <p><?php // echo htmlspecialchars($_SESSION['admin_email'] ?? 'admin@example.com'); ?></p> -->
        </div>
        <nav>
            <ul>
                <li><a href="adminHome.php"><i class="fas fa-home"></i> Admin Home</a></li>
                <li><a href="employee_details.php"><i class="fas fa-users-cog"></i> Employee Details</a></li>
                <li><a href="view_attendance.php"><i class="fas fa-calendar-check"></i> Attendance</a></li>
                <li><a href="salary_calculation.php"><i class="fas fa-money-bill-wave"></i> Salary & Payslips</a></li>
                <li><a href="admin_requests.php"><i class="fas fa-bullhorn"></i> Employee Requests</a></li>
                <li><a href="admin_settings.php" class="active"><i class="fas fa-cogs"></i> Settings</a></li>
                <li><a href="index.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
            </ul>
        </nav>
    </div>

    <div class="main-content">
        <a href="adminHome.php" class="nav-button">
            <i class="fas fa-arrow-left"></i> Back to Admin Dashboard
        </a>
        <div class="container-main">
            <h1 class="page-title">Admin Settings</h1>

            <?php if ($success_message): ?>
                <div class="message success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>
            <?php if ($error_message): ?>
                <div class="message error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>

            <div class="form-section">
                <h3>General Settings</h3>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="form-group">
                        <label for="site_name">Site Name / Company Name:</label>
                        <input type="text" id="site_name" name="site_name" class="form-control" 
                               value="<?php echo htmlspecialchars($current_site_name); ?>" required>
                    </div>
                    <button type="submit" name="update_general_settings" class="btn btn-primary">Save General Settings</button>
                </form>
            </div>

            <div class="form-section">
                <h3>Change Your Password</h3>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="form-group">
                        <label for="current_password">Current Password:</label>
                        <input type="password" id="current_password" name="current_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="new_password">New Password:</label>
                        <input type="password" id="new_password" name="new_password" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password:</label>
                        <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
                    </div>
                    <button type="submit" name="change_password" class="btn btn-primary">Change Password</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>