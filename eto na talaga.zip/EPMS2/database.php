<?php
// Database configuration for EPMS
// Set error reporting for debugging (recommended for development)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// --- Database Credentials ---
define('DB_SERVER', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'epms_db');

// --- Configuration for Detailed Errors (Example) ---
if (!defined('DISPLAY_DETAILED_ERRORS')) {
    define('DISPLAY_DETAILED_ERRORS', true); // Default to true for dev
}

$conn = null;

/**
 * Establishes and returns a database connection.
 * Creates the database if it doesn't exist.
 *
 * @return mysqli|false A mysqli connection object on success, or false on failure.
 */
function initializeDatabaseConnection() {
    static $db_connection = null;

    if ($db_connection instanceof mysqli && @mysqli_ping($db_connection)) { // Re-added @ for mysqli_ping
        return $db_connection;
    }

    try {
        $temp_conn = mysqli_connect(DB_SERVER, DB_USER, DB_PASS);
        if (!$temp_conn) {
            throw new Exception("MySQL server connection failed: " . mysqli_connect_error() . " (User: " . DB_USER . ")");
        }

        $dbNameEscaped = mysqli_real_escape_string($temp_conn, DB_NAME);
        $create_db_query = "CREATE DATABASE IF NOT EXISTS `$dbNameEscaped` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
        if (!mysqli_query($temp_conn, $create_db_query)) {
            throw new Exception("Failed to create database '$dbNameEscaped': " . mysqli_error($temp_conn));
        }
        mysqli_close($temp_conn);

        $db_connection = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
        if (!$db_connection) {
            throw new Exception("Database connection failed for '" . DB_NAME . "': " . mysqli_connect_error());
        }

        if (!mysqli_set_charset($db_connection, "utf8mb4")) {
            throw new Exception("Error setting character set utf8mb4: " . mysqli_error($db_connection));
        }
        return $db_connection;

    } catch (Exception $e) {
        error_log("Database Initialization Error: " . $e->getMessage());
        if (defined('DISPLAY_DETAILED_ERRORS') && DISPLAY_DETAILED_ERRORS === true) {
            echo "Database Error: " . htmlentities($e->getMessage());
        }
        return false;
    }
}

$conn = initializeDatabaseConnection();

class Database {
    private $connection;

    public function __construct() {
        global $conn;
        if ($conn instanceof mysqli && @mysqli_ping($conn)) { // Re-added @
            $this->connection = $conn;
        } else {
            $this->connection = initializeDatabaseConnection();
        }
    }

    public function getConnection() {
        if ($this->connection instanceof mysqli && @mysqli_ping($this->connection)) { // Re-added @
            return $this->connection;
        } elseif ($this->connection === false) {
             error_log("Database::getConnection() called but connection was previously failed.");
             return false;
        } else {
             error_log("Database::getConnection() found an invalid or uninitialized connection. Attempting to re-initialize.");
             $this->connection = initializeDatabaseConnection();
             return $this->connection;
        }
    }

    public function isConnected() {
        return ($this->connection instanceof mysqli && @mysqli_ping($this->connection)); // Re-added @
    }

    public function close() {
        global $conn;
        if ($this->connection && $this->connection !== $conn) {
            mysqli_close($this->connection);
            $this->connection = null;
        }
    }

    public function __destruct() {}
}

function tablesExist() {
    global $conn; 
    if (!$conn || !($conn instanceof mysqli)) {
        error_log("tablesExist: No valid database connection available.");
        return false;
    }
    $required_tables = [
        'departments', 'job_titles', 'pay_frequencies', 'benefit_types',
        'leave_types', 'request_types', 'admins', 'employees',
        'employee_salary_details', 'employee_benefits', 'attendance',
        'salary_calculations', 'salary_calculation_deductions', 
        'salary_calculation_allowances', 'leave_management', 
        'employee_requests', 'admin_activities_log'
    ];
    foreach ($required_tables as $table) {
        $escapedTable = mysqli_real_escape_string($conn, $table);
        $result = mysqli_query($conn, "SHOW TABLES LIKE '$escapedTable'");
        if (!$result) {
            error_log("tablesExist: SHOW TABLES query failed for table '$escapedTable': " . mysqli_error($conn));
            return false; 
        }
        if (mysqli_num_rows($result) == 0) {
            mysqli_free_result($result);
            error_log("tablesExist: Required table '$escapedTable' not found.");
            return false; 
        }
        mysqli_free_result($result);
    }
    return true;
}

function getDatabaseStatus() {
    global $conn; 
    $db_name_const = DB_NAME;
    $status = [
        'connection_attempted' => false, 'connected_to_server' => false,
        'database_selected' => false, 'database_exists_on_server' => false,
        'required_tables_exist' => false, 'system_ready' => false, 'error_message' => null
    ];
    $temp_server_conn = @mysqli_connect(DB_SERVER, DB_USER, DB_PASS);
    if ($temp_server_conn) {
        $status['connected_to_server'] = true;
        $dbNameEscaped = mysqli_real_escape_string($temp_server_conn, $db_name_const);
        $res = mysqli_query($temp_server_conn, "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME = '$dbNameEscaped'");
        if ($res && mysqli_num_rows($res) > 0) {
            $status['database_exists_on_server'] = true;
            if($res) mysqli_free_result($res);
        }
        mysqli_close($temp_server_conn);
    } else {
        $status['error_message'] = "Failed to connect to MySQL server: " . mysqli_connect_error();
    }

    if ($conn instanceof mysqli) {
        $status['connection_attempted'] = true;
        $current_db_query = mysqli_query($conn, "SELECT DATABASE()");
        if ($current_db_query) {
            $current_db_row = mysqli_fetch_row($current_db_query);
            if ($current_db_row && $current_db_row[0] === $db_name_const) {
                $status['database_selected'] = true;
            }
            mysqli_free_result($current_db_query);
        }
        if ($status['database_selected'] && $status['database_exists_on_server']) {
            if (tablesExist()) {
                $status['required_tables_exist'] = true;
                $status['system_ready'] = true;
            } else if ($status['error_message'] === null) { 
                $status['error_message'] = "Connected to database, but one or more required tables are missing.";
            }
        } elseif ($status['error_message'] === null && $status['connected_to_server']) {
             $status['error_message'] = "Database '" . $db_name_const . "' could not be selected or does not exist.";
        }
    } elseif ($status['error_message'] === null) { 
        $status['error_message'] = "Global database connection (\$conn) failed to initialize or is not a valid mysqli object.";
    }
    return $status;
}
?>