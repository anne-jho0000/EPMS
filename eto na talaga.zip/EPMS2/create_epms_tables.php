<?php
// create_epms_tables.php

// This global variable will be set to true upon successful completion.
// It's checked by the calling script (setup_database.php).
global $epms_setup_status_from_create_tables;
$epms_setup_status_from_create_tables = false; // Default to false

require_once __DIR__ . '/database.php'; // Use __DIR__ for robust path

if (!$conn || !($conn instanceof mysqli)) {
    // If connection fails here, $epms_setup_status_from_create_tables remains false.
    echo "<h3>FATAL ERROR: Database connection failed. Cannot create tables. Check database.php and DB credentials.</h3><p>Error: " . mysqli_connect_error() . "</p>";
    // No die() here, setup_database.php will catch the state via the global var or its own checks
    return; // Exit this script
}

function createTable($db_conn, $tableName, $createTableSQL) {
    $checkTableQuery = "SHOW TABLES LIKE '" . mysqli_real_escape_string($db_conn, $tableName) . "'";
    $checkTableResult = mysqli_query($db_conn, $checkTableQuery);

    if (!$checkTableResult) {
        echo "<p style='color:red;'>Error checking for table $tableName: " . mysqli_error($db_conn) . "</p>";
        return false;
    }

    if (mysqli_num_rows($checkTableResult) == 0) {
        echo "<p>Creating table: <strong>$tableName</strong>... ";
        if (mysqli_query($db_conn, $createTableSQL)) {
            echo "<span style='color:green;'>SUCCESS</span></p>";
            return true;
        } else {
            echo "<span style='color:red;'>FAILED: " . mysqli_error($db_conn) . "</span></p>";
            echo "<pre>Query: $createTableSQL</pre>";
            return false;
        }
    } else {
        echo "<p>Table <strong>$tableName</strong> already exists. Skipping creation.</p>";
        return true;
    }
}

echo "<h2>EPMS 3rd Normal Form Database Setup Process</h2>";

// --- DEFINE ALL CREATE TABLE SQL STRINGS FIRST ---
$departmentsTableSQL = "CREATE TABLE IF NOT EXISTS departments (
    dept_id INT AUTO_INCREMENT PRIMARY KEY,
    dept_name VARCHAR(100) NOT NULL UNIQUE,
    dept_code VARCHAR(20) UNIQUE,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$jobTitlesTableSQL = "CREATE TABLE IF NOT EXISTS job_titles (
    job_title_id INT AUTO_INCREMENT PRIMARY KEY,
    title_name VARCHAR(100) NOT NULL UNIQUE,
    title_code VARCHAR(20) UNIQUE,
    dept_id INT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$payFrequencyTableSQL = "CREATE TABLE IF NOT EXISTS pay_frequencies (
    freq_id INT AUTO_INCREMENT PRIMARY KEY,
    frequency_name VARCHAR(50) NOT NULL UNIQUE,
    frequency_code VARCHAR(20) NOT NULL UNIQUE,
    days_per_period INT,
    periods_per_year INT,
    is_active BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$benefitTypesTableSQL = "CREATE TABLE IF NOT EXISTS benefit_types (
    benefit_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL UNIQUE,
    type_code VARCHAR(20) NOT NULL UNIQUE,
    description TEXT,
    is_mandatory BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$leaveTypesTableSQL = "CREATE TABLE IF NOT EXISTS leave_types (
    leave_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(50) NOT NULL UNIQUE,
    type_code VARCHAR(20) NOT NULL UNIQUE,
    max_days_per_year DECIMAL(5,1) DEFAULT NULL,
    is_paid BOOLEAN DEFAULT TRUE,
    requires_approval BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$requestTypesTableSQL = "CREATE TABLE IF NOT EXISTS request_types (
    request_type_id INT AUTO_INCREMENT PRIMARY KEY,
    type_name VARCHAR(100) NOT NULL UNIQUE,
    type_code VARCHAR(20) NOT NULL UNIQUE,
    description TEXT,
    requires_approval BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$adminTableSQL = "CREATE TABLE IF NOT EXISTS admins (
    admin_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_code VARCHAR(50) UNIQUE NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'Admin',
    is_active BOOLEAN DEFAULT TRUE,
    last_login DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$employeesTableSQL = "CREATE TABLE IF NOT EXISTS employees (
    emp_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_code VARCHAR(50) UNIQUE NOT NULL,
    username VARCHAR(50) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(20),
    hire_date DATE NOT NULL,
    dept_id INT,
    job_title_id INT,
    password VARCHAR(255) NOT NULL,
    qr_code_data TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (dept_id) REFERENCES departments(dept_id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (job_title_id) REFERENCES job_titles(job_title_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$employeeSalaryDetailsTableSQL = "CREATE TABLE IF NOT EXISTS employee_salary_details (
    salary_detail_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    base_salary DECIMAL(12,2) DEFAULT 0.00,
    hourly_rate DECIMAL(10,2) DEFAULT 0.00,
    freq_id INT NOT NULL,
    effective_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    is_current BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (freq_id) REFERENCES pay_frequencies(freq_id) ON UPDATE CASCADE,
    UNIQUE KEY uk_emp_effective_current (emp_id, effective_date, is_current),
    INDEX idx_emp_current (emp_id, is_current),
    INDEX idx_effective_date (effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$employeeBenefitsTableSQL = "CREATE TABLE IF NOT EXISTS employee_benefits (
    benefit_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    benefit_type_id INT NOT NULL,
    id_number VARCHAR(50) NULL,
    contribution_amount DECIMAL(10,2) DEFAULT 0.00,
    effective_date DATE NOT NULL,
    end_date DATE DEFAULT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (benefit_type_id) REFERENCES benefit_types(benefit_type_id) ON UPDATE CASCADE,
    UNIQUE KEY uk_emp_benefit_type_effective (emp_id, benefit_type_id, effective_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$attendanceTableSQL = "CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    check_in DATETIME NULL,
    check_out DATETIME NULL,
    expected_check_in TIME DEFAULT '09:00:00',
    expected_check_out TIME DEFAULT '17:00:00',
    status ENUM('Present', 'Absent', 'Leave', 'Half-Day', 'Weekend', 'Holiday', 'Official Business') NOT NULL DEFAULT 'Absent',
    worked_hours DECIMAL(5,2) DEFAULT 0.00,
    tardiness_minutes INT DEFAULT 0,
    overtime_minutes INT DEFAULT 0,
    notes TEXT,
    location_latitude DECIMAL(10,7) NULL,
    location_longitude DECIMAL(10,7) NULL,
    ip_address VARCHAR(45) NULL,
    device_info VARCHAR(255) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE KEY uk_emp_date (emp_id, attendance_date),
    INDEX idx_attendance_date (attendance_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$salaryCalculationsTableSQL = "CREATE TABLE IF NOT EXISTS salary_calculations (
    calculation_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    salary_detail_id INT NULL,
    pay_period_start_date DATE NOT NULL,
    pay_period_end_date DATE NOT NULL,
    base_salary_component DECIMAL(12,2) DEFAULT 0.00,
    hourly_rate_at_calculation DECIMAL(10,2) DEFAULT 0.00,
    working_days_in_period INT DEFAULT 0,
    total_worked_hours DECIMAL(10,2) DEFAULT 0.00,
    regular_hours_worked DECIMAL(10,2) DEFAULT 0.00,
    overtime_hours_worked DECIMAL(10,2) DEFAULT 0.00,
    regular_earnings DECIMAL(12,2) DEFAULT 0.00,
    overtime_earnings DECIMAL(12,2) DEFAULT 0.00,
    gross_earnings DECIMAL(12,2) NOT NULL,
    total_deductions DECIMAL(12,2) DEFAULT 0.00,
    total_allowances DECIMAL(12,2) DEFAULT 0.00,
    net_salary DECIMAL(12,2) NOT NULL,
    payment_status ENUM('Pending', 'Processing', 'Paid', 'Failed', 'Cancelled') DEFAULT 'Pending',
    payment_date DATE NULL,
    notes TEXT,
    calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    calculated_by_admin_id INT NULL,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (salary_detail_id) REFERENCES employee_salary_details(salary_detail_id) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (calculated_by_admin_id) REFERENCES admins(admin_id) ON DELETE SET NULL ON UPDATE CASCADE,
    UNIQUE KEY uk_emp_pay_period (emp_id, pay_period_start_date, pay_period_end_date),
    INDEX idx_pay_period (pay_period_start_date, pay_period_end_date),
    INDEX idx_payment_status (payment_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$salaryCalculationDeductionsTableSQL = "CREATE TABLE IF NOT EXISTS salary_calculation_deductions (
    deduction_id INT AUTO_INCREMENT PRIMARY KEY,
    calculation_id INT NOT NULL,
    deduction_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    notes VARCHAR(255) NULL,
    FOREIGN KEY (calculation_id) REFERENCES salary_calculations(calculation_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$salaryCalculationAllowancesTableSQL = "CREATE TABLE IF NOT EXISTS salary_calculation_allowances (
    allowance_id INT AUTO_INCREMENT PRIMARY KEY,
    calculation_id INT NOT NULL,
    allowance_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    notes VARCHAR(255) NULL,
    FOREIGN KEY (calculation_id) REFERENCES salary_calculations(calculation_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$leaveManagementTableSQL = "CREATE TABLE IF NOT EXISTS leave_management (
    leave_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    leave_type_id INT NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    number_of_days DECIMAL(4,1) NOT NULL,
    status ENUM('Pending', 'Approved', 'Rejected', 'Cancelled', 'Taken') DEFAULT 'Pending',
    reason TEXT,
    admin_comments TEXT,
    applied_on TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    action_by_admin_id INT NULL,
    action_date DATETIME NULL,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (leave_type_id) REFERENCES leave_types(leave_type_id) ON UPDATE CASCADE,
    FOREIGN KEY (action_by_admin_id) REFERENCES admins(admin_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_emp_dates (emp_id, start_date, end_date),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$employeeRequestsTableSQL = "CREATE TABLE IF NOT EXISTS employee_requests (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    emp_id INT NOT NULL,
    request_type_id INT NOT NULL,
    subject VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    status ENUM('Pending', 'In Progress', 'Resolved', 'Rejected', 'Closed', 'Forwarded') DEFAULT 'Pending',
    priority ENUM('Low', 'Medium', 'High', 'Urgent') DEFAULT 'Medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_by_admin_id INT NULL,
    resolution_details TEXT,
    resolved_at DATETIME NULL,
    FOREIGN KEY (emp_id) REFERENCES employees(emp_id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (request_type_id) REFERENCES request_types(request_type_id) ON UPDATE CASCADE,
    FOREIGN KEY (resolved_by_admin_id) REFERENCES admins(admin_id) ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

$adminActivitiesTableSQL = "CREATE TABLE IF NOT EXISTS admin_activities_log (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NOT NULL,
    activity_type VARCHAR(100) NOT NULL,
    target_entity_type VARCHAR(50) NULL,
    target_entity_id INT NULL,
    description TEXT,
    ip_address VARCHAR(45) NULL,
    user_agent TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (admin_id) REFERENCES admins(admin_id) ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_admin_activity_time (admin_id, created_at),
    INDEX idx_target_entity (target_entity_type, target_entity_id),
    INDEX idx_activity_type_log (activity_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

// ***** NEW TABLE: app_settings *****
$appSettingsTableSQL = "CREATE TABLE IF NOT EXISTS app_settings (
    setting_id INT AUTO_INCREMENT PRIMARY KEY,
    setting_name VARCHAR(100) NOT NULL UNIQUE,
    setting_value TEXT,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";


// --- DEFINE ALL INITIAL DATA INSERTION SQL STRINGS HERE ---
$insertDepartmentsSQL = "INSERT IGNORE INTO departments (dept_id, dept_name, dept_code) VALUES
    (1, 'Administration', 'ADMIN'), (2, 'Finance', 'FIN'), (3, 'Human Resources', 'HR'),
    (4, 'Information Technology', 'IT'), (5, 'Marketing', 'MKT'), (6, 'Operations', 'OPS'),
    (7, 'Research and Development', 'RND'), (8, 'Sales', 'SALES'), (9, 'Unassigned', 'UNASSIGNED')";

$insertPayFrequenciesSQL = "INSERT IGNORE INTO pay_frequencies (freq_id, frequency_name, frequency_code, days_per_period, periods_per_year) VALUES
    (1, 'Monthly', 'MONTHLY', 30, 12), (2, 'Bi-Weekly', 'BIWEEKLY', 14, 26),
    (3, 'Weekly', 'WEEKLY', 7, 52), (4, 'Hourly', 'HOURLY', 1, 2080)";

$insertBenefitTypesSQL = "INSERT IGNORE INTO benefit_types (benefit_type_id, type_name, type_code, is_mandatory) VALUES
    (1, 'Social Security System', 'SSS', TRUE), (2, 'Pag-IBIG Fund', 'PAGIBIG', TRUE),
    (3, 'PhilHealth', 'PHILHEALTH', TRUE), (4, 'Tax Identification Number', 'TIN', TRUE),
    (5, 'Health Insurance (HMO)', 'HMO', FALSE), (6, 'Life Insurance', 'LIFE', FALSE), (7, '13th Month Pay', '13THPAY', TRUE)";

$insertLeaveTypesSQL = "INSERT IGNORE INTO leave_types (leave_type_id, type_name, type_code, max_days_per_year, is_paid) VALUES
    (1, 'Vacation Leave', 'VL', 15, TRUE), (2, 'Sick Leave', 'SL', 15, TRUE),
    (3, 'Emergency Leave', 'EL', 5, TRUE), (4, 'Maternity Leave', 'ML', 105, TRUE),
    (5, 'Paternity Leave', 'PL', 7, TRUE), (6, 'Unpaid Leave', 'UL', NULL, FALSE),
    (7, 'Bereavement Leave', 'BL', 3, TRUE)";

$insertRequestTypesSQL = "INSERT IGNORE INTO request_types (request_type_id, type_name, type_code, requires_approval) VALUES
    (1, 'Document Request', 'DOC_REQ', TRUE), (2, 'Information Update Request', 'INFO_UPD_REQ', TRUE),
    (3, 'Equipment Request', 'EQUIP_REQ', TRUE), (4, 'IT Support Request', 'IT_SUPP_REQ', FALSE),
    (5, 'Payroll Inquiry', 'PAY_INQ', FALSE), (6, 'Benefits Inquiry', 'BEN_INQ', FALSE),
    (7, 'Leave Application', 'LEAVE_APP', TRUE), (8, 'General Inquiry', 'GEN_INQ', FALSE),
    (9, 'Contact Form Submission', 'CONTACT_GUEST', FALSE)";

// ***** NEW: Insert default app setting *****
$insertAppSettingsSQL = "INSERT IGNORE INTO app_settings (setting_name, setting_value) VALUES ('site_name', 'EPMS - Employee Payroll Management System')";

// ***** NEW: Insert default admin user *****
// Password 'password123' hashed. IMPORTANT: CHANGE THIS PASSWORD AFTER SETUP!
$defaultAdminPasswordHash = '$2y$10$N9yG7mP9c.0U3qJj5fLq5uXkZgL4h.S/9fC.iP8yR6pZzN7bXmQ.a'; // Hash for 'password123'
$insertDefaultAdminSQL = "INSERT IGNORE INTO admins (admin_id, admin_code, full_name, email, password, role, is_active) VALUES 
    (1, 'SUPERADMIN001', 'Super Administrator', 'admin@example.com', '" . $defaultAdminPasswordHash . "', 'Super Admin', TRUE)";


// --- Table Creation Execution ---
$tablesToCreate = [
    ['departments', $departmentsTableSQL], ['job_titles', $jobTitlesTableSQL],
    ['pay_frequencies', $payFrequencyTableSQL], ['benefit_types', $benefitTypesTableSQL],
    ['leave_types', $leaveTypesTableSQL], ['request_types', $requestTypesTableSQL],
    ['admins', $adminTableSQL], ['employees', $employeesTableSQL],
    ['employee_salary_details', $employeeSalaryDetailsTableSQL],
    ['employee_benefits', $employeeBenefitsTableSQL], ['attendance', $attendanceTableSQL],
    ['salary_calculations', $salaryCalculationsTableSQL],
    ['salary_calculation_deductions', $salaryCalculationDeductionsTableSQL],
    ['salary_calculation_allowances', $salaryCalculationAllowancesTableSQL],
    ['leave_management', $leaveManagementTableSQL],
    ['employee_requests', $employeeRequestsTableSQL],
    ['admin_activities_log', $adminActivitiesTableSQL],
    ['app_settings', $appSettingsTableSQL] // ***** ADDED app_settings to creation list *****
];

$allTablesSuccessful = true;
echo "<h3>Table Creation Status:</h3>";
foreach ($tablesToCreate as $tableInfo) {
    if (!createTable($conn, $tableInfo[0], $tableInfo[1])) {
        $allTablesSuccessful = false;
    }
}

$guestEmployeeInsertedSuccessfully = false;
$allInitialDataSuccessful = false;
$defaultAdminInsertedSuccessfully = false; // ***** NEW FLAG *****
$appSettingsInsertedSuccessfully = false; // ***** NEW FLAG *****


if ($allTablesSuccessful) {
    echo "<h3 style='color:green;'>✅ All tables checked/created successfully!</h3>";

    echo "<br><h3>Inserting Initial Lookup Data & Default Settings:</h3>";

    $initialDataQueries = [
        "Departments Data" => $insertDepartmentsSQL,
        "Pay Frequencies Data" => $insertPayFrequenciesSQL,
        "Benefit Types Data" => $insertBenefitTypesSQL,
        "Leave Types Data" => $insertLeaveTypesSQL,
        "Request Types Data" => $insertRequestTypesSQL,
        "App Settings Data" => $insertAppSettingsSQL // ***** ADDED App Settings Data *****
    ];

    $allInitialDataSuccessful = true;
    foreach ($initialDataQueries as $dataName => $query) {
        echo "<p>Inserting <strong>$dataName</strong>... ";
        if (empty($query)) {
            echo "<span style='color:red;'>FAILED: SQL query string for $dataName is empty.</span></p>";
            $allInitialDataSuccessful = false;
            continue;
        }
        if (mysqli_query($conn, $query)) {
            $affected_rows = mysqli_affected_rows($conn);
            if ($affected_rows > 0) {
                echo "<span style='color:green;'>SUCCESS ($affected_rows new rows added)</span></p>";
                 if($dataName == "App Settings Data") $appSettingsInsertedSuccessfully = true; // Mark app settings as successful
            } else {
                $tempTableName = '';
                if($dataName == "Departments Data") $tempTableName = 'departments';
                elseif($dataName == "Pay Frequencies Data") $tempTableName = 'pay_frequencies';
                elseif($dataName == "Benefit Types Data") $tempTableName = 'benefit_types';
                elseif($dataName == "Leave Types Data") $tempTableName = 'leave_types';
                elseif($dataName == "Request Types Data") $tempTableName = 'request_types';
                elseif($dataName == "App Settings Data") $tempTableName = 'app_settings';


                if(!empty($tempTableName)) {
                    $checkResult = mysqli_query($conn, "SELECT 1 FROM $tempTableName LIMIT 1");
                    if ($checkResult && $checkResult->num_rows > 0) {
                        echo "<span style='color:blue;'>SUCCESS (Data likely already exists)</span></p>";
                        if($dataName == "App Settings Data") $appSettingsInsertedSuccessfully = true; // Mark as successful if exists
                    } else if ($checkResult && $checkResult->num_rows == 0) {
                        echo "<span style='color:orange;'>WARNING: No new data added for '$dataName' and table '$tempTableName' appears to be empty. Error: " . mysqli_error($conn) . "</span></p>";
                        $allInitialDataSuccessful = false;
                    } else {
                        echo "<span style='color:red;'>ERROR: Could not verify data in '$tempTableName'. Query error: " . mysqli_error($conn) . "</span></p>";
                        $allInitialDataSuccessful = false;
                    }
                    if ($checkResult) mysqli_free_result($checkResult);
                } else {
                     echo "<span style='color:orange;'>NOTICE (No new data added for $dataName. Could not determine table name to verify.)</span></p>";
                }
            }
        } else {
            echo "<span style='color:red;'>FAILED: " . mysqli_error($conn) . "</span></p>";
            $allInitialDataSuccessful = false;
        }
    }
    // If $allInitialDataSuccessful is true here, it means general lookups were OK.
    // $appSettingsInsertedSuccessfully is specifically for app_settings.

    if ($allInitialDataSuccessful) { // Check general lookup data success first
        echo "<h3 style='color:green;'>✅ Initial lookup data & default settings processed!</h3>";

        // Insert Default Admin (after other initial data is successful)
        echo "<p>Inserting <strong>Default Super Admin User</strong>... ";
        if (mysqli_query($conn, $insertDefaultAdminSQL)) {
            if (mysqli_affected_rows($conn) > 0) {
                echo "<span style='color:green;'>SUCCESS (Default admin created. Email: admin@example.com, Pass: password123)</span></p>";
                $defaultAdminInsertedSuccessfully = true;
            } else {
                // Check if admin_id=1 or email admin@example.com exists
                $checkAdmin = mysqli_query($conn, "SELECT admin_id FROM admins WHERE admin_id = 1 OR email = 'admin@example.com'");
                if ($checkAdmin && mysqli_num_rows($checkAdmin) > 0) {
                    echo "<span style='color:blue;'>SUCCESS (Default admin likely already exists)</span></p>";
                    $defaultAdminInsertedSuccessfully = true;
                } else {
                    echo "<span style='color:orange;'>NOTICE (Default admin might not have been inserted. Error: ".mysqli_error($conn).")</span></p>";
                }
                if($checkAdmin) mysqli_free_result($checkAdmin);
            }
        } else {
            echo "<span style='color:red;'>FAILED: " . mysqli_error($conn) . "</span></p>";
        }


        // Insert Guest Employee (after admin and other initial data)
        echo "<p>Inserting/Verifying <strong>Guest Employee Record (ID: 0) for Contact Form</strong>... ";
        $guestEmpId = 0;
        $defaultDeptIdForGuestSQL = "(SELECT dept_id FROM departments WHERE dept_code = 'UNASSIGNED' LIMIT 1)";
        $defaultJobTitleIdForGuestSQL = "NULL";

        $original_sql_mode = '';
        $sql_mode_res = mysqli_query($conn, "SELECT @@SESSION.sql_mode");
        if ($sql_mode_res && $sql_mode_row = mysqli_fetch_assoc($sql_mode_res)) {
            $original_sql_mode = $sql_mode_row['@@SESSION.sql_mode'];
        }
        if($sql_mode_res) mysqli_free_result($sql_mode_res);

        mysqli_query($conn, "SET SESSION sql_mode = CONCAT(IFNULL(@@SESSION.sql_mode,''), ',NO_AUTO_VALUE_ON_ZERO')");


        $guestEmployeeSQL = "INSERT INTO employees
            (emp_id, emp_code, username, first_name, last_name, email, hire_date, password, is_active, dept_id, job_title_id)
        VALUES
            ($guestEmpId, 'SYS_CONTACT', 'contact_form_user', 'System', 'Contact', 'contact@system.local', CURDATE(), '--DISABLED_NO_LOGIN--', FALSE, $defaultDeptIdForGuestSQL, $defaultJobTitleIdForGuestSQL)
        ON DUPLICATE KEY UPDATE
            emp_code = VALUES(emp_code), username = VALUES(username), first_name = VALUES(first_name), last_name = VALUES(last_name),
            email = VALUES(email), is_active = VALUES(is_active), dept_id = VALUES(dept_id), job_title_id = VALUES(job_title_id), updated_at = NOW()";

        if (mysqli_query($conn, $guestEmployeeSQL)) {
             if (mysqli_affected_rows($conn) > 0) {
                echo "<span style='color:green;'>SUCCESS (Guest employee created/updated)</span></p>";
                $guestEmployeeInsertedSuccessfully = true;
            } elseif (mysqli_warning_count($conn) == 0 && mysqli_affected_rows($conn) == 0) {
                echo "<span style='color:blue;'>SUCCESS (Guest employee ID: $guestEmpId already exists and is up-to-date)</span></p>";
                $guestEmployeeInsertedSuccessfully = true;
            } else {
                $checkGuest = mysqli_query($conn, "SELECT emp_id FROM employees WHERE emp_id = $guestEmpId");
                if ($checkGuest && mysqli_num_rows($checkGuest) > 0) {
                    echo "<span style='color:blue;'>SUCCESS (Guest employee ID: $guestEmpId already exists, warnings: " . mysqli_warning_count($conn) . ")</span></p>";
                    $guestEmployeeInsertedSuccessfully = true;
                } else {
                    echo "<span style='color:orange;'>NOTICE (Guest employee ID: $guestEmpId not inserted. Error: " . mysqli_error($conn) . " Warnings: " . mysqli_warning_count($conn) .")</span></p>";
                    $guestEmployeeInsertedSuccessfully = false; // Explicitly set to false on failure
                }
                 if($checkGuest) mysqli_free_result($checkGuest);
            }
        } else {
            echo "<span style='color:red;'>FAILED to insert/update guest employee (ID: $guestEmpId): " . mysqli_error($conn) . "</span></p>";
            $guestEmployeeInsertedSuccessfully = false; // Explicitly set to false on failure
        }
        if (!empty($original_sql_mode)) {
            mysqli_query($conn, "SET SESSION sql_mode = '$original_sql_mode'");
        } else { // Fallback if original_sql_mode couldn't be fetched (less likely)
            mysqli_query($conn, "SET SESSION sql_mode = REPLACE(IFNULL(@@SESSION.sql_mode,''), ',NO_AUTO_VALUE_ON_ZERO', '')");
        }


    } else {
        echo "<h3 style='color:red;'>❌ Some initial lookup data or settings could not be inserted. Default Admin and Guest Employee setup skipped.</h3>";
    }

    // Determine overall success for the calling script
    if ($allTablesSuccessful && $allInitialDataSuccessful && $guestEmployeeInsertedSuccessfully && $defaultAdminInsertedSuccessfully && $appSettingsInsertedSuccessfully) {
        echo "<hr><h3 style='color:darkblue;'>🚀 Database setup complete! All tables, initial data, default admin, and guest user are ready.</h3>";
        $epms_setup_status_from_create_tables = true;
    } else {
         $missing_items = [];
         if (!$allInitialDataSuccessful) $missing_items[] = "initial lookup data";
         if (!$defaultAdminInsertedSuccessfully) $missing_items[] = "default admin";
         if (!$guestEmployeeInsertedSuccessfully) $missing_items[] = "guest employee";
         if (!$appSettingsInsertedSuccessfully) $missing_items[] = "app settings";

         echo "<hr><h3 style='color:red;'>⚠️ Database setup partially completed. Some steps may have failed. Missing/Failed items: " . implode(", ", $missing_items) . ". (Check messages above).</h3>";
         $epms_setup_status_from_create_tables = false;
    }

} else {
    echo "<h3 style='color:red;'>❌ Database setup FAILED due to table creation errors. Please check messages above.</h3>";
    $epms_setup_status_from_create_tables = false;
}
?>