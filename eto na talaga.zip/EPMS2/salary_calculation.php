<?php
// salary_calculation.php

// Enable error reporting for debugging (disable or configure for production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in and is an admin
if (!isset($_SESSION['admin_id'])) {
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Unauthorized access. Please log in.', 'redirect' => 'adminLogin.php']);
        exit;
    } else {
        header('Location: adminLogin.php?error=unauthorized');
        exit;
    }
}

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';

class SalaryCalculator {
    private $db_conn_oop;

    public function __construct() {
        try {
            $database = new Database();
            $this->db_conn_oop = $database->getConnection();
            if (!$this->db_conn_oop || $this->db_conn_oop->connect_error) {
                throw new Exception("Failed to establish database connection: " . ($this->db_conn_oop ? $this->db_conn_oop->connect_error : "Unknown error"));
            }
        } catch (Exception $e) {
            error_log("SalaryCalculator DB Connection Error: " . $e->getMessage());
            throw new Exception("Salary Calculator could not initialize due to database issues. Please contact support.");
        }
    }

    public function calculateMonthlySalary($employee_id, $month, $year) {
        // Initialize variables
        $base_salary_monthly_component = 0.0; $hourly_rate = 0.0; $salary_detail_id_fk = null;
        $pay_frequency = 'Unknown'; $working_days_present = 0; $total_worked_hours_from_att = 0.0;
        $regular_hours_worked = 0.0; $overtime_hours_worked = 0.0; $regular_earnings = 0.0;
        $overtime_earnings = 0.0; $gross_earnings = 0.0; $total_deductions = 0.0;
        $total_allowances = 0.0; $net_salary = 0.0;
        $employee_name_for_payslip = 'N/A'; // For payslip

        try {
            if (!$this->db_conn_oop) {
                throw new Exception("Database connection not available in SalaryCalculator.");
            }

            $payPeriodEndDateForSalary = date('Y-m-t', strtotime("$year-$month-01"));
            $payPeriodStartDateForSalary = date('Y-m-01', strtotime("$year-$month-01"));

            $empSalaryQuery =
                "SELECT e.emp_id, e.first_name, e.last_name, esd.base_salary, esd.hourly_rate, esd.salary_detail_id, pf.frequency_name
                 FROM employees e
                 JOIN employee_salary_details esd ON e.emp_id = esd.emp_id
                 JOIN pay_frequencies pf ON esd.freq_id = pf.freq_id
                 WHERE e.emp_id = ? AND e.is_active = TRUE
                 AND esd.effective_date <= ?
                 AND (esd.end_date IS NULL OR esd.end_date >= ?)
                 AND esd.is_current = TRUE
                 ORDER BY esd.effective_date DESC, esd.salary_detail_id DESC
                 LIMIT 1";

            $empCheck = $this->db_conn_oop->prepare($empSalaryQuery);
            if (!$empCheck) throw new Exception("Salary Details Prepare Failed: " . $this->db_conn_oop->error);
            $empCheck->bind_param("iss", $employee_id, $payPeriodEndDateForSalary, $payPeriodStartDateForSalary);
            if(!$empCheck->execute()) throw new Exception("Salary Details Execute Failed: " . $empCheck->error);
            $empResult = $empCheck->get_result();

            if ($empResult->num_rows === 0) {
                throw new Exception("No active salary details found for Employee ID $employee_id for the period $month/$year. Ensure salary is configured with `is_current = TRUE` and valid effective/end dates.");
            }

            $employee_salary_info = $empResult->fetch_assoc();
            $employee_name_for_payslip = trim(($employee_salary_info['first_name'] ?? '') . ' ' . ($employee_salary_info['last_name'] ?? ''));
            $base_salary_monthly_component = floatval($employee_salary_info['base_salary'] ?? 0);
            $hourly_rate = floatval($employee_salary_info['hourly_rate'] ?? 0);
            $salary_detail_id_fk = isset($employee_salary_info['salary_detail_id']) ? intval($employee_salary_info['salary_detail_id']) : null;
            $pay_frequency = $employee_salary_info['frequency_name'] ?? 'Unknown';
            $empCheck->close();

            $attendanceQuery =
                "SELECT COUNT(DISTINCT attendance_date) as working_days_present, COALESCE(SUM(worked_hours), 0) as total_hours
                FROM attendance
                WHERE emp_id = ? AND YEAR(attendance_date) = ? AND MONTH(attendance_date) = ? AND status = 'Present'";
            $stmtAtt = $this->db_conn_oop->prepare($attendanceQuery);
            if (!$stmtAtt) throw new Exception("Attendance Prepare Failed: " . $this->db_conn_oop->error);
            $stmtAtt->bind_param("iii", $employee_id, $year, $month);
            if(!$stmtAtt->execute()) throw new Exception("Attendance Execute Failed: " . $stmtAtt->error);
            $attendanceResult = $stmtAtt->get_result();
            $attendance_data = $attendanceResult->fetch_assoc();
            $stmtAtt->close();

            $working_days_present = intval($attendance_data['working_days_present'] ?? 0);
            $total_worked_hours_from_att = floatval($attendance_data['total_hours'] ?? 0);
            $expected_regular_hours_for_worked_days = $working_days_present * 8;
            $regular_hours_worked = min($total_worked_hours_from_att, $expected_regular_hours_for_worked_days);
            $overtime_hours_worked = max(0, $total_worked_hours_from_att - $regular_hours_worked);

            $regular_earnings_from_hours = $regular_hours_worked * $hourly_rate;
            $overtime_rate_multiplier = 1.5;
            $overtime_earnings = $overtime_hours_worked * ($hourly_rate * $overtime_rate_multiplier);

            if (strtolower($pay_frequency) === 'monthly') {
                $regular_earnings = $base_salary_monthly_component;
                $gross_earnings = $base_salary_monthly_component + $overtime_earnings;
            } else {
                $regular_earnings = $regular_earnings_from_hours;
                $gross_earnings = $regular_earnings_from_hours + $overtime_earnings;
            }

            // Placeholder for dynamic deductions and allowances
            $total_deductions = 0.00; $total_allowances = 0.00;
            // Add real SSS, PhilHealth, Pag-IBIG, Tax logic here based on brackets/rules
            // Example SSS (highly simplified)
            $sss_contribution_ee = 0.00;
            if ($gross_earnings >= 4250 && $gross_earnings <= 4749.99) $sss_contribution_ee = 202.50;
            else if ($gross_earnings >= 29750) $sss_contribution_ee = 1350.00;
            // ... (many more brackets needed for accurate SSS) ...
            $total_deductions += $sss_contribution_ee;

            $net_salary = $gross_earnings + $total_allowances - $total_deductions;

            $salary_data_to_save = [
                'emp_id' => $employee_id, 'salary_detail_id' => $salary_detail_id_fk,
                'pay_period_start_date' => $payPeriodStartDateForSalary, 'pay_period_end_date' => $payPeriodEndDateForSalary,
                'base_salary_component' => $base_salary_monthly_component, 'hourly_rate_at_calculation' => $hourly_rate,
                'working_days_in_period' => $working_days_present, 'total_worked_hours' => $total_worked_hours_from_att,
                'regular_hours_worked' => $regular_hours_worked, 'overtime_hours_worked' => $overtime_hours_worked,
                'regular_earnings' => $regular_earnings, 'overtime_earnings' => $overtime_earnings,
                'total_allowances' => $total_allowances, 'gross_earnings' => $gross_earnings,
                'total_deductions' => $total_deductions, 'net_salary' => $net_salary,
                'calculated_by_admin_id' => isset($_SESSION['admin_id']) ? intval($_SESSION['admin_id']) : null
            ];
            $this->saveSalaryRecord($salary_data_to_save);

            return [
                'emp_id' => $employee_id, 'employee_name' => $employee_name_for_payslip,
                'month' => $month, 'year' => $year, 'pay_frequency' => $pay_frequency,
                'working_days_present' => $working_days_present, 'total_hours_worked' => $total_worked_hours_from_att,
                'base_salary_monthly_component' => $base_salary_monthly_component, 'hourly_rate_used' => $hourly_rate,
                'regular_hours_component' => $regular_hours_worked, 'overtime_hours_component' => $overtime_hours_worked,
                'regular_earnings_display' => $regular_earnings, 'overtime_earnings_display' => $overtime_earnings,
                'total_allowances_display' => $total_allowances, 'gross_earnings_display' => $gross_earnings,
                'total_deductions_display' => $total_deductions, 'net_salary_display' => $net_salary
            ];
        } catch (Exception $e) {
            error_log("Error in calculateMonthlySalary for emp_id $employee_id, $month/$year: " . $e->getMessage() . "\nStack Trace:\n" . $e->getTraceAsString());
            throw new Exception("Salary calculation failed: " . $e->getMessage());
        }
    }

    public function saveSalaryRecord($salary_data) {
        try {
            $checkStmt = $this->db_conn_oop->prepare(
                "SELECT calculation_id FROM salary_calculations WHERE emp_id = ? AND pay_period_start_date = ? AND pay_period_end_date = ?"
            );
            if (!$checkStmt) throw new Exception("Save Salary (Check) Prepare Failed: " . $this->db_conn_oop->error);
            $checkStmt->bind_param("iss", $salary_data['emp_id'], $salary_data['pay_period_start_date'], $salary_data['pay_period_end_date']);
            if(!$checkStmt->execute()) throw new Exception("Save Salary (Check) Execute Failed: " . $checkStmt->error);
            $existingRecord = $checkStmt->get_result();
            $calculation_id_to_update = null;
            if ($existingRecord->num_rows > 0) {
                $calculation_id_to_update = $existingRecord->fetch_assoc()['calculation_id'];
            }
            $checkStmt->close();

            $sd_id = isset($salary_data['salary_detail_id']) ? intval($salary_data['salary_detail_id']) : null;
            $base_comp = floatval($salary_data['base_salary_component']); $hr_calc = floatval($salary_data['hourly_rate_at_calculation']);
            $wd_period = intval($salary_data['working_days_in_period']); $tot_wh = floatval($salary_data['total_worked_hours']);
            $reg_wh = floatval($salary_data['regular_hours_worked']); $ot_wh = floatval($salary_data['overtime_hours_worked']);
            $reg_earn = floatval($salary_data['regular_earnings']); $ot_earn = floatval($salary_data['overtime_earnings']);
            $tot_allow = floatval($salary_data['total_allowances']); $gross_earn = floatval($salary_data['gross_earnings']);
            $tot_deduct = floatval($salary_data['total_deductions']); $net_sal = floatval($salary_data['net_salary']);
            $admin_id = isset($salary_data['calculated_by_admin_id']) ? intval($salary_data['calculated_by_admin_id']) : null;

            if ($calculation_id_to_update) {
                $stmt = $this->db_conn_oop->prepare("
                    UPDATE salary_calculations SET salary_detail_id = ?, base_salary_component = ?, hourly_rate_at_calculation = ?,
                        working_days_in_period = ?, total_worked_hours = ?, regular_hours_worked = ?, overtime_hours_worked = ?,
                        regular_earnings = ?, overtime_earnings = ?, total_allowances = ?, gross_earnings = ?, total_deductions = ?, net_salary = ?,
                        payment_status = 'Pending', calculated_at = CURRENT_TIMESTAMP, calculated_by_admin_id = ?
                    WHERE calculation_id = ?");
                if (!$stmt) throw new Exception("Save Salary (Update) Prepare Failed: " . $this->db_conn_oop->error);
                $stmt->bind_param("iddidddddddddii", $sd_id, $base_comp, $hr_calc, $wd_period, $tot_wh, $reg_wh, $ot_wh,
                    $reg_earn, $ot_earn, $tot_allow, $gross_earn, $tot_deduct, $net_sal, $admin_id, $calculation_id_to_update);
            } else {
                $stmt = $this->db_conn_oop->prepare("
                    INSERT INTO salary_calculations (emp_id, salary_detail_id, pay_period_start_date, pay_period_end_date,
                     base_salary_component, hourly_rate_at_calculation, working_days_in_period, total_worked_hours,
                     regular_hours_worked, overtime_hours_worked, regular_earnings, overtime_earnings,
                     total_allowances, gross_earnings, total_deductions, net_salary, payment_status, calculated_by_admin_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending', ?)");
                if (!$stmt) throw new Exception("Save Salary (Insert) Prepare Failed: " . $this->db_conn_oop->error);
                $stmt->bind_param("iisssddiddddddddi", $salary_data['emp_id'], $sd_id, $salary_data['pay_period_start_date'], $salary_data['pay_period_end_date'],
                    $base_comp, $hr_calc, $wd_period, $tot_wh, $reg_wh, $ot_wh, $reg_earn, $ot_earn,
                    $tot_allow, $gross_earn, $tot_deduct, $net_sal, $admin_id);
            }
            if (!$stmt->execute()) throw new Exception("Save Salary Execute Failed: " . $stmt->error . " (SQL State: " . $stmt->sqlstate . ")");
            $stmt->close();
            return true;
        } catch (Exception $e) {
            error_log("Error in saveSalaryRecord: " . $e->getMessage() . "\nData: " . json_encode($salary_data) . "\nTrace:\n" . $e->getTraceAsString());
            throw new Exception("Error saving salary record. Details: " . $e->getMessage());
        }
    }
    public function formatPeso($amount) {
        return "₱" . number_format(floatval($amount), 2);
    }
}

// --- POST Request Handling ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'calculate_salary') {
    ob_start();
    header('Content-Type: application/json');
    $response = ['success' => false, 'error' => 'An unknown error occurred.'];
    try {
        if (!isset($_POST['emp_id']) || empty(trim($_POST['emp_id'])) || !isset($_POST['month']) || !isset($_POST['year'])) {
            throw new Exception("Employee, month, or year not selected or missing.");
        }
        $employee_id_post = intval($_POST['emp_id']); $month_post = intval($_POST['month']); $year_post = intval($_POST['year']);
        if ($employee_id_post <= 0) throw new Exception("Invalid employee selected.");
        if ($month_post < 1 || $month_post > 12) throw new Exception("Invalid month selected.");
        if ($year_post < 2000 || $year_post > date("Y") + 10) throw new Exception("Invalid year selected.");

        $calculator = new SalaryCalculator();
        $result_data = $calculator->calculateMonthlySalary($employee_id_post, $month_post, $year_post);
        $formatted_result = $result_data;
        $js_keys_to_format = ['base_salary_monthly_component', 'hourly_rate_used', 'regular_earnings_display',
            'overtime_earnings_display', 'total_allowances_display', 'gross_earnings_display',
            'total_deductions_display', 'net_salary_display'];
        foreach($js_keys_to_format as $js_key){
            $formatted_result[$js_key.'_formatted'] = $calculator->formatPeso($result_data[$js_key] ?? 0);
        }
        $response = ['success' => true, 'data' => $formatted_result, 'message' => 'Salary calculated and saved successfully.'];
    } catch (Exception $e) {
        error_log("AJAX Salary Calculation POST Error: " . $e->getMessage() . "\nInput: emp_id=" . ($_POST['emp_id'] ?? 'N/A') . ", month=" . ($_POST['month'] ?? 'N/A') . ", year=" . ($_POST['year'] ?? 'N/A') . "\nTrace:\n" . $e->getTraceAsString());
        $response['error'] = "Calculation Failed: " . $e->getMessage();
    }
    $stray_output = ob_get_clean();
    if (!empty($stray_output)) {
        error_log("Stray output detected before JSON response in salary_calculation.php: " . $stray_output);
        if (!$response['error'] && $response['success'] == false) {
             $response['error'] = 'Server-side processing error. Stray output detected. Check logs.';
        }
    }
    echo json_encode($response);
    exit;
}

// --- HTML Part Starts Here ---
$employees_list = []; $user_facing_error_for_page = ''; $db_connection_for_dropdown = null;
try {
    if (class_exists('Database')) {
        $db_obj = new Database(); $db_connection_for_dropdown = $db_obj->getConnection();
        if (!$db_connection_for_dropdown || $db_connection_for_dropdown->connect_error) {
            throw new Exception("DB Class connection failed: " . ($db_connection_for_dropdown ? $db_connection_for_dropdown->connect_error : "Unknown"));
        }
    } elseif (isset($conn) && $conn instanceof mysqli && !$conn->connect_error) {
        $db_connection_for_dropdown = $conn;
    } else {
        throw new Exception("No valid database connection available for page load.");
    }

    if ($db_connection_for_dropdown) {
        $emp_query_sql = "SELECT DISTINCT e.emp_id, e.first_name, e.last_name
                          FROM employees e
                          INNER JOIN employee_salary_details esd ON e.emp_id = esd.emp_id AND esd.is_current = TRUE
                          WHERE e.is_active = TRUE ORDER BY e.first_name, e.last_name";
        $emp_query_result = mysqli_query($db_connection_for_dropdown, $emp_query_sql);
        if ($emp_query_result) {
            while ($emp_row = mysqli_fetch_assoc($emp_query_result)) $employees_list[] = $emp_row;
            mysqli_free_result($emp_query_result);
        } else {
            throw new Exception("Failed to fetch employees for dropdown: " . mysqli_error($db_connection_for_dropdown));
        }
    }
} catch (Exception $e) {
    error_log("Page Load DB/Employee Fetch Error in salary_calculation.php: " . $e->getMessage());
    $user_facing_error_for_page = "Could not load necessary data. Please try again later or contact support.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Salary Calculation - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root { /* CSS Variables */
            --primary-color: #FFD700; --secondary-color: #333; --accent-color: #555;
            --success-color: #28a745; --danger-color: #dc3545; --text-light: #fff;
            --text-dark: #333; --light-bg: #f8f9fa; --white-bg: #fff;
            --border-color: #dee2e6; --print-text-color: #000;
        }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; background-color: var(--light-bg); color: var(--text-dark); }
        .header-bar { background-color: var(--secondary-color); color: var(--text-light); padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .header-bar h2 { margin: 0; font-size: 1.6rem; }
        .logo-container { display: flex; align-items: center; }
        .logo { width: 50px; height: 50px; border-radius:50%; border:2px solid var(--primary-color); }
        .admin-badge { background-color: var(--primary-color); color: var(--secondary-color); font-size: 0.8rem; padding: 4px 10px; border-radius: 12px; margin-left: 12px; font-weight: bold; }

        .container-main { max-width: 900px; margin: 25px auto; padding: 25px; background-color: var(--white-bg); border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24); }
        .page-title { margin-bottom: 25px; text-align: center; color: var(--secondary-color); font-size:1.8rem; }

        .nav-button, .btn-action { background-color: var(--success-color); color: white; text-decoration: none; padding: 10px 18px; border-radius: 5px; display: inline-flex; align-items:center; font-weight: 500; margin-bottom: 25px; transition: background-color 0.2s; border:none; cursor:pointer;}
        .nav-button i, .btn-action i { margin-right: 8px; }
        .nav-button:hover, .btn-action:hover { background-color: #1e7e34; }
        .btn-print { background-color: var(--accent-color); margin-left: 10px; }
        .btn-print:hover { background-color: #444; }


        .form-calc-container { display: flex; flex-wrap: wrap; gap: 20px; margin-bottom: 30px; padding:20px; background-color:#fdfdfd; border:1px solid var(--border-color); border-radius: 5px;}
        .form-group { flex: 1; min-width: 220px; }
        .form-group label { display:block; margin-bottom:6px; font-weight:500; font-size:0.9rem;}
        .form-control, .month-select { width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 4px; font-size: 1rem; box-sizing: border-box; background-color: var(--white-bg); }

        .btn-submit-calc { padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-weight: bold; transition: background-color 0.2s; font-size: 1rem; background-color: var(--primary-color); color: var(--text-dark); display:flex; align-items:center; justify-content:center; gap:8px;}
        .btn-submit-calc:hover { background-color: #e0c000; }
        .btn-submit-calc:disabled { background-color: #ccc; cursor: not-allowed; }
        .form-actions { text-align: center; margin-top:10px; }

        .result-container { margin-top: 30px; padding: 25px; border-radius: 8px; background-color: var(--white-bg); border:1px solid var(--border-color); display: none; }
        .result-container.show { display: block; animation: fadeIn 0.5s; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }

        .payslip-header-print { display: none; text-align: center; margin-bottom: 20px; }
        .print-logo { width: 80px; height: auto; margin-bottom: 10px;}
        .company-details-print { font-size: 0.9em; line-height: 1.4; margin-bottom: 15px; }
        .payslip-title-print { font-size: 1.8em; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 1px; }
        .employee-info-print { text-align: left; margin-bottom: 15px; border-bottom: 1px solid #ccc; padding-bottom: 10px;}
        .employee-info-print div { margin-bottom: 3px; }


        .result-title { color: var(--secondary-color); margin-top: 0; border-bottom: 2px solid var(--primary-color); padding-bottom: 10px; font-size:1.5rem; }
        .result-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 18px; margin-top:15px; }
        .result-item { padding:10px; background-color:#f8f9fa; border-radius:4px; border-left:3px solid var(--primary-color); }
        .result-label { font-weight: 600; margin-bottom: 4px; color: var(--accent-color); font-size:0.85em; text-transform:uppercase; }
        .result-value { font-size: 1.05em; color:var(--text-dark); }
        .total-salary-display { font-size: 1.6em; font-weight: bold; color: var(--success-color); margin-top: 25px; text-align: right; padding-top:15px; border-top:1px dashed var(--border-color); }
        .total-salary-display span { font-size:0.7em; color:var(--accent-color); display:block; margin-bottom:-5px;}
        .print-footer-note { display: none; font-size: 0.8em; text-align: center; margin-top: 30px; font-style: italic; }

        .error-message-box, .info-message-box { padding: 12px; background-color: #f8d7da; border:1px solid #f5c6cb; border-radius: 4px; margin-top: 20px; margin-bottom: 15px; display: none; text-align: center; font-size:0.95rem;}
        .error-message-box {color: var(--danger-color);}
        .info-message-box {color: #0c5460; background-color: #d1ecf1; border-color: #bee5eb;}
        
        @media (max-width: 768px) { .form-calc-container { flex-direction: column; } .form-group { width: 100%; } }

        @media print {
            body * { visibility: hidden; color: var(--print-text-color) !important; background-color: transparent !important; }
            .header-bar, .nav-button, #salaryForm, .form-actions, .page-title,
            #general-message-box, #error-message-box, .btn-action.btn-print,
            .result-container > p:last-child /* Hides the "This calculation has been saved..." paragraph */
             { display: none !important; }

            .result-container, .result-container * { visibility: visible; }
            .result-container {
                position: absolute; left: 0; top: 0; width: 100%;
                margin: 20px; padding: 15px; border: 1px solid #666 !important; box-shadow: none !important;
            }
            .payslip-header-print { display: block !important; }
            .payslip-title-print { border-bottom: 2px solid #333; }
            .result-title { display: none; } /* Hide screen title, use print title */
            .result-grid { grid-template-columns: 1fr 1fr; gap: 10px 20px; } /* Force two columns for print */
            .result-item { border-left: 3px solid #666 !important; background-color: #f9f9f9 !important; padding: 8px; }
            .total-salary-display { border-top: 1px dashed #666 !important; color: var(--print-text-color) !important;}
            .print-footer-note { display: block !important; }
            a[href]:after { content: none !important; } /* Don't show URLs for links */
        }
    </style>
</head>
<body>
    <div class="header-bar">
        <h2>Salary Calculation <span class="admin-badge">Admin Panel</span></h2>
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
        </div>
    </div>

    <div class="container-main">
        <a href="adminHome.php" class="nav-button">
            <i class="fas fa-arrow-left"></i> Back to Admin Dashboard
        </a>

        <h1 class="page-title">Employee Salary Calculator</h1>

        <?php if (!empty($user_facing_error_for_page)): ?>
            <div class="error-message-box" style="display:block;"><?php echo htmlspecialchars($user_facing_error_for_page); ?></div>
        <?php endif; ?>

        <div id="general-message-box" class="info-message-box"></div>

        <form id="salaryForm">
            <input type="hidden" name="action" value="calculate_salary">
            <div class="form-calc-container">
                <div class="form-group">
                    <label for="emp_id">Select Employee:</label>
                    <select id="emp_id" name="emp_id" class="form-control" required <?php echo empty($employees_list) ? 'disabled' : ''; ?>>
                        <option value="">-- Choose an Employee --</option>
                        <?php if (!empty($employees_list)): ?>
                            <?php foreach ($employees_list as $employee_item): ?>
                                <option value="<?php echo htmlspecialchars($employee_item['emp_id']); ?>">
                                    <?php echo htmlspecialchars(trim($employee_item['first_name'] . ' ' . $employee_item['last_name']) . ' (ID: ' . $employee_item['emp_id'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="month">Select Month:</label>
                    <select id="month" name="month" class="month-select form-control" required>
                        <?php $currentMonth = date('n'); for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo $m; ?>" <?php echo ($currentMonth == $m) ? 'selected' : ''; ?>>
                                <?php echo date('F', mktime(0, 0, 0, $m, 10)); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="year">Enter Year:</label>
                    <input type="number" id="year" name="year" class="form-control" value="<?php echo date('Y'); ?>" min="2000" max="<?php echo date('Y') + 5; ?>" required>
                </div>
            </div>
            <div class="form-actions">
                <button type="submit" class="btn-submit-calc" <?php echo empty($employees_list) ? 'disabled' : ''; ?>>
                    <i class="fas fa-calculator"></i> Calculate & Save Salary
                </button>
            </div>
        </form>

        <div id="error-message-box" class="error-message-box"></div>

        <div id="salaryResult" class="result-container">
            <!-- Header for Print -->
            <div class="payslip-header-print">
                <img src="images/epms(logo).jpg" alt="Company Logo" class="print-logo" id="printCompanyLogo"> <!-- Assuming you have a logo -->
                <div class="company-details-print" id="printCompanyDetails">
                    EPMS Solutions Inc. <br> <!-- Replace with actual company name -->
                    123 Innovation Drive, Tech City, PH 12345 <br>
                    (02) 8888-EPMS | info@epms.solutions
                </div>
                <h3 class="payslip-title-print">Payslip</h3>
            </div>

            <!-- Employee Info for Print -->
            <div class="employee-info-print" style="display:none;"> <!-- Initially hidden, shown by JS -->
                <div><strong>Employee Name:</strong> <span id="print-emp-name"></span></div>
                <div><strong>Employee ID:</strong> <span id="print-emp-id"></span></div>
                <div><strong>Pay Period:</strong> <span id="print-pay-period"></span></div>
            </div>
            
            <h3 class="result-title">Calculated Salary Details
                <button id="printPayslipBtn" class="btn-action btn-print" style="display:none; float:right; margin-bottom:0; margin-top:-5px;">
                    <i class="fas fa-print"></i> Print Payslip
                </button>
            </h3>
            <div class="result-grid">
                <div class="result-item"><div class="result-label">Employee ID:</div><div id="result-emp-id" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Employee Name:</div><div id="result-emp-name" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Pay Period:</div><div id="result-period" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Pay Frequency:</div><div id="result-pay-frequency" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Working Days (Present):</div><div id="result-days-present" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Total Hours Worked (Present):</div><div id="result-total-hours" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Base Salary Component:</div><div id="result-base-salary" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Hourly Rate Used:</div><div id="result-hourly-rate" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Regular Hours Component:</div><div id="result-regular-hours" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Regular Earnings:</div><div id="result-regular-earnings" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Overtime Hours Component:</div><div id="result-overtime-hours" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Overtime Earnings:</div><div id="result-overtime-earnings" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Total Allowances:</div><div id="result-total-allowances" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Gross Earnings:</div><div id="result-gross-earnings" class="result-value"></div></div>
                <div class="result-item"><div class="result-label">Total Deductions:</div><div id="result-total-deductions" class="result-value"></div></div>
            </div>
            <div class="total-salary-display">
                <span>Net Salary Payable</span> <div id="result-net-salary"></div>
            </div>
             <p style="font-size:0.8em; text-align:center; margin-top:15px; color:var(--accent-color);">This calculation has been saved. You can view payslips or make adjustments in the respective sections.</p>
             <p class="print-footer-note">This is a computer-generated payslip and does not require a signature.</p>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const salaryForm = document.getElementById('salaryForm');
        const errorMsgEl = document.getElementById('error-message-box');
        const generalMsgEl = document.getElementById('general-message-box');
        const resultContainerEl = document.getElementById('salaryResult');
        const employeeSelect = document.getElementById('emp_id');
        const submitButton = salaryForm.querySelector('button[type="submit"]');
        const printButton = document.getElementById('printPayslipBtn');
        const printEmployeeInfoDiv = document.querySelector('.employee-info-print');

        function showGeneralMessage(message, isError = false) {
            generalMsgEl.textContent = message;
            generalMsgEl.className = isError ? 'error-message-box' : 'info-message-box';
            generalMsgEl.style.display = 'block';
            if (isError) errorMsgEl.style.display = 'none';
        }
        
        if (employeeSelect.options.length <= 1 && employeeSelect.disabled) {
            // Message handled by PHP if $user_facing_error_for_page or list is empty
        } else if (employeeSelect.disabled || employeeSelect.options.length <=1) {
            showGeneralMessage('No employees are currently eligible for salary calculation. Please check employee data or system configuration.', true);
        }

        printButton.addEventListener('click', function() {
            window.print();
        });

        salaryForm.addEventListener('submit', function(e) {
            e.preventDefault();
            errorMsgEl.style.display = 'none'; errorMsgEl.textContent = '';
            generalMsgEl.style.display = 'none'; resultContainerEl.classList.remove('show');
            printButton.style.display = 'none'; printEmployeeInfoDiv.style.display = 'none';
            
            let formData = new FormData(this);
            const originalButtonText = submitButton.innerHTML;
            submitButton.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Calculating...';
            submitButton.disabled = true;
            
            fetch('<?php echo basename($_SERVER["PHP_SELF"]); ?>', { method: 'POST', body: formData })
            .then(response => {
                submitButton.innerHTML = originalButtonText; submitButton.disabled = false;
                const contentType = response.headers.get("content-type");
                if (contentType && contentType.indexOf("application/json") !== -1) return response.json();
                return response.text().then(text => { throw new Error("Server returned non-JSON response: " + text.substring(0, 200) + "..."); });
            })
            .then(data => {
                if (data.error) {
                    errorMsgEl.textContent = data.error; errorMsgEl.style.display = 'block';
                } else if (data.success && data.data) {
                    const salary = data.data;
                    const monthNames = ["", "January", "February", "March", "April", "May", "June",
                                       "July", "August", "September", "October", "November", "December"];
                    const payPeriodText = `${monthNames[parseInt(salary.month)]} ${salary.year}`;
                    
                    document.getElementById('result-emp-id').textContent = salary.emp_id;
                    document.getElementById('result-emp-name').textContent = salary.employee_name || 'N/A'; // Added employee name display
                    document.getElementById('result-period').textContent = payPeriodText;
                    document.getElementById('result-pay-frequency').textContent = salary.pay_frequency || 'N/A';
                    document.getElementById('result-days-present').textContent = salary.working_days_present;
                    document.getElementById('result-total-hours').textContent = `${parseFloat(salary.total_hours_worked || 0).toFixed(2)} hours`;
                    document.getElementById('result-base-salary').textContent = salary.base_salary_monthly_component_formatted !== undefined ? salary.base_salary_monthly_component_formatted : 'N/A';
                    document.getElementById('result-hourly-rate').textContent = salary.hourly_rate_used_formatted !== undefined ? salary.hourly_rate_used_formatted : 'N/A';
                    document.getElementById('result-regular-hours').textContent = `${parseFloat(salary.regular_hours_component || 0).toFixed(2)} hours`;
                    document.getElementById('result-regular-earnings').textContent = salary.regular_earnings_display_formatted !== undefined ? salary.regular_earnings_display_formatted : 'N/A';
                    document.getElementById('result-overtime-hours').textContent = `${parseFloat(salary.overtime_hours_component || 0).toFixed(2)} hours`;
                    document.getElementById('result-overtime-earnings').textContent = salary.overtime_earnings_display_formatted !== undefined ? salary.overtime_earnings_display_formatted : 'N/A';
                    document.getElementById('result-total-allowances').textContent = salary.total_allowances_display_formatted !== undefined ? salary.total_allowances_display_formatted : 'N/A';
                    document.getElementById('result-gross-earnings').textContent = salary.gross_earnings_display_formatted !== undefined ? salary.gross_earnings_display_formatted : 'N/A';
                    document.getElementById('result-total-deductions').textContent = salary.total_deductions_display_formatted !== undefined ? salary.total_deductions_display_formatted : 'N/A';
                    document.getElementById('result-net-salary').textContent = salary.net_salary_display_formatted !== undefined ? salary.net_salary_display_formatted : 'N/A';
                    
                    // Populate dedicated print employee info
                    document.getElementById('print-emp-name').textContent = salary.employee_name || 'N/A';
                    document.getElementById('print-emp-id').textContent = salary.emp_id;
                    document.getElementById('print-pay-period').textContent = payPeriodText;
                    printEmployeeInfoDiv.style.display = 'block';


                    resultContainerEl.classList.add('show');
                    printButton.style.display = 'inline-flex';
                    resultContainerEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    if(data.message) showGeneralMessage(data.message, false);
                } else {
                    errorMsgEl.textContent = (data && data.message) ? data.message : 'An unexpected response format was received.';
                    errorMsgEl.style.display = 'block';
                }
            })
            .catch(error => {
                console.error('Fetch Error:', error);
                submitButton.innerHTML = originalButtonText; submitButton.disabled = false;
                errorMsgEl.textContent = 'Client-side Error: ' + error.message;
                errorMsgEl.style.display = 'block';
            });
        });
    });
    </script>
</body>
</html>