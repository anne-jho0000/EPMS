<?php
// config.php

// Define constants used across the application

// Guest Employee ID for contact forms and other system-generated requests
if (!defined('CONTACT_FORM_GUEST_EMP_ID')) {
    define('CONTACT_FORM_GUEST_EMP_ID', 0);
}

// Request Type definitions for the public contact form
if (!defined('CONTACT_FORM_REQUEST_TYPE_NAME')) {
    define('CONTACT_FORM_REQUEST_TYPE_NAME', 'Contact Form Submission');
}
if (!defined('CONTACT_FORM_REQUEST_TYPE_CODE')) {
    define('CONTACT_FORM_REQUEST_TYPE_CODE', 'CONTACT_GUEST'); // A unique code for this type
}


// You can add other global configurations here in the future, for example:
// define('SITE_NAME', 'My EPMS');
// define('DEBUG_MODE', true); // Be careful with this in production

?>