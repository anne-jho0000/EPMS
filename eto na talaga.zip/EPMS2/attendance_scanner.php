<?php
session_start();
require_once 'database.php'; 
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Database connection failed in attendance_scanner.php");
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Database connection error.']);
        exit;
    } else {
        die("A critical database error occurred. Please try again later or contact support.");
    }
}

date_default_timezone_set('Asia/Manila'); 

// --- AttendanceScanner Class Definition ---
// (Your class definition from the previous response goes here - no changes needed inside the class for this specific warning)
class AttendanceScanner {
    private $conn;
    
    public function __construct($db_connection) {
        $this->conn = $db_connection;
    }
    
    public function scanQRCode($emp_qr_data_raw, $action) { 
        error_log("----- QR SCAN START -----");
        error_log("QR Scan - Raw input from POST['emp_id_qr']: " . var_export($emp_qr_data_raw, true));
        error_log("QR Scan - Action: " . var_export($action, true));
        
        if (empty($emp_qr_data_raw)) {
            error_log("QR Scan - ERROR: Employee identifier from QR code is empty.");
            return ['status' => 'error', 'message' => 'Employee identifier from QR code is required'];
        }
        
        $parsed_identifier = null;
        if (preg_match('/Code:\s*([A-Za-z0-9]+)/', $emp_qr_data_raw, $matches_code)) {
            $parsed_identifier = trim($matches_code[1]);
            error_log("QR Scan - Parsed emp_code: [" . $parsed_identifier . "]");
        } 
        elseif (preg_match('/Employee ID:\s*([0-9]+)/', $emp_qr_data_raw, $matches_id)) {
            $parsed_identifier = trim($matches_id[1]);
            error_log("QR Scan - Parsed emp_id: [" . $parsed_identifier . "]");
        } else {
            $parsed_identifier = trim($emp_qr_data_raw);
            error_log("QR Scan - Could not parse specific fields, using trimmed raw data as identifier: [" . $parsed_identifier . "]");
        }

        if (empty($parsed_identifier)) {
            error_log("QR Scan - ERROR: Could not extract a valid identifier from QR data: [" . $emp_qr_data_raw . "]");
            return ['status' => 'error', 'message' => 'Invalid QR code format. Could not read employee identifier. Scanned: ' . htmlspecialchars($emp_qr_data_raw)];
        }
        
        $sql_employee_check = "SELECT e.emp_id, e.emp_code, e.first_name, e.last_name, e.is_active, 
                                      d.dept_name, jt.title_name 
                               FROM employees e
                               LEFT JOIN departments d ON e.dept_id = d.dept_id
                               LEFT JOIN job_titles jt ON e.job_title_id = jt.job_title_id
                               WHERE e.emp_code = ? OR e.emp_id = ?"; 
        
        $stmt_employee_check = $this->conn->prepare($sql_employee_check);
        if ($stmt_employee_check === false) {
            error_log("QR Scan - Prepare failed: " . $this->conn->error);
            return ['status' => 'error', 'message' => 'Database error (prepare employee check): ' . $this->conn->error];
        }
        $stmt_employee_check->bind_param("ss", $parsed_identifier, $parsed_identifier); 
        if (!$stmt_employee_check->execute()) {
            error_log("QR Scan - Execute employee check failed: " . $stmt_employee_check->error);
            return ['status' => 'error', 'message' => 'Failed to execute employee check: ' . $stmt_employee_check->error];
        }
        $result_employee_check = $stmt_employee_check->get_result();
        if ($result_employee_check->num_rows === 0) {
            $stmt_employee_check->close();
            error_log("QR Scan - ERROR: Employee not found for parsed identifier [" . $parsed_identifier . "]. Original scan: [" . $emp_qr_data_raw . "]");
            return ['status' => 'error', 'message' => 'Invalid Employee Identifier - Employee not found (Processed scan: ' . htmlspecialchars($parsed_identifier) . ')'];
        }
        $employee = $result_employee_check->fetch_assoc();
        $stmt_employee_check->close();
        $emp_id_db = (int)$employee['emp_id']; 
        if (!$employee['is_active']) {
            return [
                'status' => 'error', 'message' => 'Employee account (' . htmlspecialchars($employee['first_name'] . ' ' . $employee['last_name']) . ') is inactive.',
                'employee_name' => trim($employee['first_name'] . ' ' . $employee['last_name'])
            ];
        }
        
        $today = date('Y-m-d');
        $now_datetime = date('Y-m-d H:i:s');
        $now_time = date('H:i:s');
        $expected_check_in_time = '09:00:00';
        $expected_check_out_time = '17:00:00'; 
        $employeeNameDisplay = trim($employee['first_name'] . ' ' . $employee['last_name']);
        $departmentNameDisplay = $employee['dept_name'] ?? 'N/A';
        $jobTitleDisplay = $employee['title_name'] ?? 'N/A';
        
        if ($action == 'check_in') {
            $checkSql = "SELECT attendance_id FROM attendance WHERE emp_id = ? AND attendance_date = ? AND check_in IS NOT NULL";
            $stmtCheck = $this->conn->prepare($checkSql);
            if ($stmtCheck === false) { return ['status' => 'error', 'message' => 'DB error (check existing check-in): ' . $this->conn->error]; }
            $stmtCheck->bind_param("is", $emp_id_db, $today);
            $stmtCheck->execute();
            $checkResult = $stmtCheck->get_result();
            if ($checkResult->num_rows > 0) {
                $stmtCheck->close();
                return [
                    'status' => 'warning', 'message' => htmlspecialchars($employeeNameDisplay) . ' already checked in today.',
                    'employee_name' => $employeeNameDisplay, 'employee_code' => $employee['emp_code'],
                    'department' => $departmentNameDisplay, 'position' => $jobTitleDisplay
                ];
            }
            $stmtCheck->close();
            $tardiness_minutes = 0;
            if ($now_time > $expected_check_in_time) {
                $time_check_in_obj = new DateTime($now_datetime); 
                $time_expected_in_obj = new DateTime($today . ' ' . $expected_check_in_time);
                if($time_check_in_obj > $time_expected_in_obj){
                    $interval = $time_check_in_obj->diff($time_expected_in_obj);
                    $tardiness_minutes = ($interval->h * 60) + $interval->i;
                }
            }
            $insertSql = "INSERT INTO attendance (emp_id, attendance_date, check_in, expected_check_in, status, tardiness_minutes, ip_address, device_info) VALUES (?, ?, ?, ?, 'Present', ?, ?, ?)";
            $stmtInsert = $this->conn->prepare($insertSql);
            if ($stmtInsert === false) { return ['status' => 'error', 'message' => 'DB error (insert attendance): ' . $this->conn->error];}
            $ip_address_att = $_SERVER['REMOTE_ADDR'] ?? null;
            $device_info_att = $_SERVER['HTTP_USER_AGENT'] ?? null;
            $stmtInsert->bind_param("isssiss", $emp_id_db, $today, $now_datetime, $expected_check_in_time, $tardiness_minutes, $ip_address_att, $device_info_att);
            if ($stmtInsert->execute()) {
                $stmtInsert->close();
                $response = [
                    'status' => 'success', 'message' => 'Check-in successful for ' . htmlspecialchars($employeeNameDisplay) . '!',
                    'employee_name' => $employeeNameDisplay, 'employee_code' => $employee['emp_code'],
                    'department' => $departmentNameDisplay, 'position' => $jobTitleDisplay,
                    'action' => 'check_in', 'time' => date('g:i A', strtotime($now_time)), 'date' => date('M d, Y', strtotime($today))
                ];
                if ($tardiness_minutes > 0) {
                    $response['tardiness'] = $tardiness_minutes . ' minutes late';
                    $response['message'] = 'Check-in successful for ' . htmlspecialchars($employeeNameDisplay) . '! (Late by ' . $tardiness_minutes . ' minutes)';
                }
                return $response;
            } else {
                 $error_details = $stmtInsert->error; $stmtInsert->close();
                 return ['status' => 'error', 'message' => 'Failed to record check-in: ' . $error_details];
            }
        } elseif ($action == 'check_out') {
            $findSql = "SELECT attendance_id, check_in FROM attendance WHERE emp_id = ? AND attendance_date = ? AND check_out IS NULL ORDER BY check_in DESC LIMIT 1";
            $stmtFind = $this->conn->prepare($findSql);
            if ($stmtFind === false) { return ['status' => 'error', 'message' => 'DB error (find check-in for checkout): ' . $this->conn->error]; }
            $stmtFind->bind_param("is", $emp_id_db, $today);
            $stmtFind->execute();
            $findResult = $stmtFind->get_result();
            if ($findResult->num_rows === 0) {
                $stmtFind->close();
                return [
                    'status' => 'error', 'message' => 'No active check-in record found for ' . htmlspecialchars($employeeNameDisplay) . ' today, or already checked out.',
                    'employee_name' => $employeeNameDisplay, 'employee_code' => $employee['emp_code']
                ];
            }
            $attendance_record = $findResult->fetch_assoc(); $stmtFind->close();
            $time_check_in_obj = new DateTime($attendance_record['check_in']);
            $time_check_out_obj = new DateTime($now_datetime);
            $worked_interval = $time_check_out_obj->diff($time_check_in_obj);
            $total_worked_minutes = ($worked_interval->days * 24 * 60) + ($worked_interval->h * 60) + $worked_interval->i;
            $worked_hours_decimal = round($total_worked_minutes / 60, 2);
            $expected_work_duration_hours = (strtotime($expected_check_out_time) - strtotime($expected_check_in_time)) / 3600; 
            $overtime_hours_calc = max(0, $worked_hours_decimal - $expected_work_duration_hours);
            $overtime_minutes_calc = round($overtime_hours_calc * 60);
            $updateSql = "UPDATE attendance SET check_out = ?, expected_check_out = ?, worked_hours = ?, overtime_minutes = ? WHERE attendance_id = ?";
            $stmtUpdate = $this->conn->prepare($updateSql);
            if ($stmtUpdate === false) { return ['status' => 'error', 'message' => 'DB error (update check-out): ' . $this->conn->error]; }
            $stmtUpdate->bind_param("ssddi", $now_datetime, $expected_check_out_time, $worked_hours_decimal, $overtime_minutes_calc, $attendance_record['attendance_id']);
            if ($stmtUpdate->execute()) {
                $stmtUpdate->close();
                $response = [
                    'status' => 'success', 'message' => 'Check-out successful for ' . htmlspecialchars($employeeNameDisplay) . '!',
                    'employee_name' => $employeeNameDisplay, 'employee_code' => $employee['emp_code'],
                    'department' => $departmentNameDisplay, 'position' => $jobTitleDisplay,
                    'action' => 'check_out', 'time' => date('g:i A', strtotime($now_time)), 'date' => date('M d, Y', strtotime($today)),
                    'worked_hours' => number_format($worked_hours_decimal, 2) . ' hours'
                ];
                if ($overtime_minutes_calc > 0) { $response['overtime'] = number_format($overtime_hours_calc, 2) . ' hours overtime'; }
                return $response;
            } else {
                $error_details_update = $stmtUpdate->error; $stmtUpdate->close();
                return ['status' => 'error', 'message' => 'Failed to record check-out: ' . $error_details_update];
            }
        } else {
            return ['status' => 'error', 'message' => 'Invalid action specified.'];
        }
    }
} 
// End of class AttendanceScanner

// Initialize the variable that will hold the result for display
$manual_form_result_display = null; // <--- FIX: INITIALIZE HERE

// Handle QR Code AJAX POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['emp_id_qr'])) {
    error_log("QR Scan - AJAX POST received: " . json_encode($_POST));
    $scanner_ajax = new AttendanceScanner($conn);
    $emp_qr_data_post_ajax = $_POST['emp_id_qr']; 
    $action_post_ajax = $_POST['action'] ?? 'check_in';
    $result_ajax = $scanner_ajax->scanQRCode($emp_qr_data_post_ajax, $action_post_ajax);
    error_log("QR Scan - AJAX response: " . json_encode($result_ajax));
    header('Content-Type: application/json');
    echo json_encode($result_ajax);
    exit;
}

// Handle Manual Form Submission
// $manual_form_result_display is ALREADY INITIALIZED TO NULL above
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_emp_id'])) {
    error_log("Manual Entry - POST request received: " . json_encode($_POST));
    $scanner_manual_form = new AttendanceScanner($conn);
    $manual_emp_id_post_form = $_POST['manual_emp_id'];
    $manual_action_post_form = $_POST['manual_action'] ?? 'check_in';
    $manual_form_result_display = $scanner_manual_form->scanQRCode($manual_emp_id_post_form, $manual_action_post_form);
    
    if (empty($_SERVER['HTTP_X_REQUESTED_WITH'])) { // Only redirect for non-AJAX form submissions
        $_SESSION['scan_result_manual_sess'] = $manual_form_result_display;
        header('Location: ' . $_SERVER['PHP_SELF']); 
        exit;
    }
    // If somehow this was AJAX, we'd output JSON, but manual form usually isn't.
    // else {
    //    header('Content-Type: application/json');
    //    echo json_encode($manual_form_result_display);
    //    exit;
    // }
}

// Get result from session if it exists from manual form submission redirect
if (isset($_SESSION['scan_result_manual_sess'])) {
    $manual_form_result_display = $_SESSION['scan_result_manual_sess'];
    unset($_SESSION['scan_result_manual_sess']); 
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Attendance Scanner - EPMS</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/js/all.min.js"></script>
    <script src="https://unpkg.com/html5-qrcode"></script>
    <style>
        /* Your CSS from previous response - no changes needed for this specific warning */
        :root { /* CSS Variables */
            --primary-color: #f0c14b; /* EPMS Yellow */
            --secondary-color: #3a3a3a; /* Dark Gray */
            --light-gray: #f4f6f9;
            --white: #ffffff;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --text-dark: #34495e;
        }
        body { font-family: 'Arial', sans-serif; margin: 0; background-color: var(--light-gray); color:var(--text-dark); line-height:1.6; }
        .top-header { background-color: var(--secondary-color); color: white; padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .logo-area { display: flex; align-items: center; }
        .logo-img-header { width: 50px; height: 50px; border-radius: 50%; border: 2px solid var(--primary-color); margin-right: 15px; }
        .system-brand h1 { font-size: 1.1em; margin:0; color: var(--primary-color); text-transform:uppercase; letter-spacing:1px;}
        .system-brand p { font-size: 0.8em; margin:0; color: #ccc; }
        .nav-link-back { background-color: var(--primary-color); color: var(--secondary-color); padding: 8px 15px; border-radius: 5px; text-decoration: none; font-weight: bold; display:inline-flex; align-items:center; }
        .nav-link-back i { margin-right: 5px; }
        .nav-link-back:hover { background-color: #e0b030; }

        .main-container { max-width: 700px; margin: 30px auto; padding: 25px; background-color: var(--white); border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .page-heading { text-align: center; font-size: 2rem; color: var(--text-dark); margin-bottom: 15px; }
        .time-display { text-align: center; font-size: 1.3rem; margin-bottom: 25px; font-weight: 600; color: var(--secondary-color); }
        
        .message-display { padding: 15px; margin-bottom: 20px; border-radius: 5px; border-left-width: 5px; border-left-style: solid; font-size:0.95rem; }
        .message-display.success { background-color: #e8f5e9; color: #2e7d32; border-color: var(--success-color); }
        .message-display.error { background-color: #ffebee; color: #c62828; border-color: var(--danger-color); }
        .message-display.warning { background-color: #fff8e1; color: #e65100; border-color: var(--warning-color); }
        .message-display strong {font-weight:bold;}
        .message-details p { margin: 5px 0; font-size:0.9em;}


        .scanner-controls { display: flex; justify-content: center; gap: 15px; margin-bottom: 25px; }
        .btn-scanner { padding: 12px 25px; border: none; border-radius: 5px; cursor: pointer; font-size: 1rem; font-weight: 600; display:inline-flex; align-items:center; transition: background-color 0.2s; }
        .btn-scanner i { margin-right: 8px; }
        .btn-scanner-start { background-color: var(--primary-color); color: var(--secondary-color); }
        .btn-scanner-start:hover { background-color: #e0b030;}
        .btn-scanner-start:disabled { background-color: #ccc; cursor:not-allowed; }
        .btn-scanner-stop { background-color: var(--text-dark); color: white; } 
        .btn-scanner-stop:hover { background-color: #626262;}
        .btn-scanner-stop:disabled { background-color: #ccc; cursor:not-allowed;}
        
        #qr-reader-section { width: 100%; max-width: 400px; margin: 0 auto 20px auto; border: 3px dashed var(--primary-color); border-radius: 8px; overflow: hidden; aspect-ratio: 1 / 1; position:relative; background:#efefef;}
        #qr-reader-section video { width:100%; height:100%; object-fit:cover;}
        #qr-scan-results { text-align: center; margin-top: 10px; font-weight: bold; min-height:24px; color: var(--info-color); }
        .visual-aid-line { width: 80%; height: 3px; background: linear-gradient(90deg, transparent, rgba(220,53,69,0.8), transparent); margin: 10px auto; animation: scan 2s infinite linear; position:absolute; top:50%; left:10%; transform:translateY(-50%); z-index:10; display:none; border-radius:2px;}
        @keyframes scan { 0% { transform: translateY(-50px) scaleY(1); } 50% { transform: translateY(50px) scaleY(1.5); } 100% { transform: translateY(-50px) scaleY(1); } }
        #qr-reader-section.scanning .visual-aid-line { display:block; }


        .manual-entry-section { margin-top: 30px; padding-top:20px; border-top:1px solid #eee;}
        .manual-entry-section h3 { text-align: center; font-size: 1.5rem; color: var(--text-dark); margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: var(--secondary-color); }
        .form-control { width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size:1rem; }
        .form-control:focus { border-color: var(--primary-color); outline: none; box-shadow: 0 0 0 2px rgba(240,193,75,0.2); }
        .btn-submit-manual { background-color: var(--success-color); color:white; width:100%; padding:12px; }
        .btn-submit-manual:hover { background-color: #1e7e34; }
    </style>
</head>
<body>
    <div class="top-header">
        <div class="logo-area">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img-header">
            <div class="system-brand">
                <h1>EPMS</h1>
                <p>QR Attendance Scanner</p>
            </div>
        </div>
        <a href="employeeHome.php" class="nav-link-back"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </div>
    
    <div class="main-container">
        <h1 class="page-heading">Scan QR Code for Attendance</h1>
        <div class="time-display">Current Time: <span id="live-time">Loading...</span></div>
        
        <div id="scan-message-area">
            <?php if ($manual_form_result_display): // This check is now safe ?>
                <div class="message-display <?php echo htmlspecialchars($manual_form_result_display['status']); ?>">
                    <strong><?php echo htmlspecialchars(ucfirst($manual_form_result_display['status'])); ?>:</strong> <?php echo htmlspecialchars($manual_form_result_display['message']); ?>
                    <?php if ($manual_form_result_display['status'] === 'success' || $manual_form_result_display['status'] === 'warning'): ?>
                        <div class="message-details">
                            <p><strong>Name:</strong> <?php echo htmlspecialchars($manual_form_result_display['employee_name'] ?? 'N/A'); ?></p>
                            <p><strong>ID Code:</strong> <?php echo htmlspecialchars($manual_form_result_display['employee_code'] ?? 'N/A'); ?></p>
                            <p><strong>Department:</strong> <?php echo htmlspecialchars($manual_form_result_display['department'] ?? 'N/A'); ?></p>
                            <p><strong>Position:</strong> <?php echo htmlspecialchars($manual_form_result_display['position'] ?? 'N/A'); ?></p>
                            <?php if(isset($manual_form_result_display['time'])): ?><p><strong>Time:</strong> <?php echo htmlspecialchars($manual_form_result_display['time']); ?></p><?php endif; ?>
                            <?php if(isset($manual_form_result_display['tardiness'])): ?><p style="color:var(--danger-color);"><strong>Note:</strong> <?php echo htmlspecialchars($manual_form_result_display['tardiness']); ?></p><?php endif; ?>
                            <?php if(isset($manual_form_result_display['worked_hours'])): ?><p><strong>Worked:</strong> <?php echo htmlspecialchars($manual_form_result_display['worked_hours']); ?></p><?php endif; ?>
                            <?php if(isset($manual_form_result_display['overtime'])): ?><p><strong>Overtime:</strong> <?php echo htmlspecialchars($manual_form_result_display['overtime']); ?></p><?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="scanner-controls">
            <button class="btn-scanner btn-scanner-start" id="startButton"><i class="fas fa-camera"></i> Start Scanner</button>
            <button class="btn-scanner btn-scanner-stop" id="stopButton" disabled><i class="fas fa-stop"></i> Stop Scanner</button>
        </div>
        
        <div id="qr-reader-section">
             <div class="visual-aid-line"></div>
        </div>
        <div id="qr-scan-results"></div>
        
        <div class="manual-entry-section">
            <h3>Manual Entry</h3>
            <form id="manualAttendanceForm" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="manual_emp_id">Employee Identifier (ID or Code):</label>
                    <input type="text" id="manual_emp_id" name="manual_emp_id" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="manual_action">Action:</label>
                    <select id="manual_action" name="manual_action" class="form-control" required>
                        <option value="check_in">Check In</option>
                        <option value="check_out">Check Out</option>
                    </select>
                </div>
                <button type="submit" class="btn-scanner btn-submit-manual"><i class="fas fa-check"></i> Submit Manual Entry</button>
            </form>
        </div>
    </div>

    <script>
        // JavaScript from the previous response - no changes needed for this specific warning
        document.addEventListener('DOMContentLoaded', function() {
            const html5QrCode = new Html5Qrcode("qr-reader-section");
            const qrResultContainer = document.getElementById('qr-scan-results');
            const scanMessageArea = document.getElementById('scan-message-area');
            const startButton = document.getElementById('startButton');
            const stopButton = document.getElementById('stopButton');
            const qrReaderSectionDiv = document.getElementById('qr-reader-section');

            function updateLiveTime() {
                const now = new Date();
                document.getElementById('live-time').textContent = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', second: '2-digit', hour12: true });
            }
            setInterval(updateLiveTime, 1000);
            updateLiveTime();

            function displayScanResultMessage(result) {
                scanMessageArea.innerHTML = ''; 
                if (!result || typeof result.status === 'undefined' || typeof result.message === 'undefined') {
                    scanMessageArea.innerHTML = `<div class="message-display error"><strong>Error:</strong> Received an invalid or incomplete response from the server.</div>`;
                    console.error("Invalid server response structure:", result);
                    return;
                }
                let alertClass = result.status; 
                let messageHTML = `<div class="message-display ${alertClass}">
                                    <strong>${result.status.charAt(0).toUpperCase() + result.status.slice(1)}:</strong> ${result.message}`;
                if (result.status === 'success' || result.status === 'warning') {
                    messageHTML += `<div class="message-details">
                                        <p><strong>Name:</strong> ${result.employee_name || 'N/A'}</p>
                                        <p><strong>ID Code:</strong> ${result.employee_code || 'N/A'}</p>
                                        <p><strong>Department:</strong> ${result.department || 'N/A'}</p>
                                        <p><strong>Position:</strong> ${result.position || 'N/A'}</p>
                                        ${result.time ? `<p><strong>Time:</strong> ${result.time}</p>` : ''}
                                        ${result.tardiness ? `<p style="color:var(--danger-color);"><strong>Note:</strong> ${result.tardiness}</p>` : ''}
                                        ${result.worked_hours ? `<p><strong>Worked:</strong> ${result.worked_hours}</p>` : ''}
                                        ${result.overtime ? `<p><strong>Overtime:</strong> ${result.overtime}</p>` : ''}
                                    </div>`;
                }
                messageHTML += `</div>`;
                scanMessageArea.innerHTML = messageHTML;
            }

            function onScanSuccess(decodedText, decodedResult) {
                console.log(`Raw Decoded Text from QR: "${decodedText}"`, decodedResult); 
                qrResultContainer.textContent = `Processing scan: "${decodedText}"...`;
                
                const formData = new FormData();
                formData.append('emp_id_qr', decodedText); 
                const manualActionSelect = document.getElementById('manual_action');
                formData.append('action', manualActionSelect ? manualActionSelect.value : 'check_in'); 

                fetch('<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>', {
                    method: 'POST',
                    body: formData
                })
                .then(response => {
                    if (!response.ok) { 
                        return response.text().then(text => { 
                            throw new Error('Network response was not ok: ' + response.status + ' ' + response.statusText + '. Server said: ' + text); 
                        });
                    }
                    return response.json();
                })
                .then(data => {
                    console.log('Server AJAX response:', data);
                    displayScanResultMessage(data); 
                })
                .catch(error => {
                    console.error('Error submitting scan via AJAX:', error);
                    displayScanResultMessage({status: 'error', message: 'Error processing scan: ' + error.message});
                });
            }

            function onScanFailure(error) { /* console.warn(`QR scan error = ${error}`); */ }

            function startQrScanning() {
                 const config = { 
                    fps: 10, 
                    qrbox: (viewportWidth, viewportHeight) => {
                        const minEdge = Math.min(viewportWidth, viewportHeight);
                        const qrboxSize = Math.floor(minEdge * 0.65); 
                        return { width: qrboxSize, height: qrboxSize };
                    },
                    rememberLastUsedCamera: true,
                    supportedScanTypes: [Html5QrcodeScanType.SCAN_TYPE_CAMERA] 
                };
                
                html5QrCode.start({ facingMode: "environment" }, config, onScanSuccess, onScanFailure)
                .then(() => {
                    qrReaderSectionDiv.classList.add('scanning');
                    startButton.disabled = true;
                    stopButton.disabled = false;
                    qrResultContainer.textContent = "Aim QR Code at Camera";
                    scanMessageArea.innerHTML = ''; 
                })
                .catch(err => {
                    qrResultContainer.textContent = `Scanner Start Error: ${err}`;
                    console.error("Scanner start error:", err);
                    startButton.disabled = false;
                });
            }

            function stopQrScanning() {
                if (html5QrCode && typeof html5QrCode.isScanning !== 'undefined' && html5QrCode.isScanning) {
                    html5QrCode.stop()
                    .then(() => {
                        qrReaderSectionDiv.classList.remove('scanning');
                        startButton.disabled = false;
                        stopButton.disabled = true;
                        qrResultContainer.textContent = "Scanner stopped.";
                    })
                    .catch(err => {
                        qrResultContainer.textContent = `Error stopping scanner: ${err}`;
                        console.error("Scanner stop error:", err);
                        startButton.disabled = false;
                        stopButton.disabled = true;
                         qrReaderSectionDiv.classList.remove('scanning');
                    });
                } else { 
                        startButton.disabled = false;
                        stopButton.disabled = true;
                        qrReaderSectionDiv.classList.remove('scanning');
                        if(qrResultContainer.textContent.includes("Scanning") || qrResultContainer.textContent.includes("Error starting scanner")) {
                           qrResultContainer.textContent = "Scanner is not active.";
                        }
                }
            }

            startButton.addEventListener('click', startQrScanning);
            stopButton.addEventListener('click', stopQrScanning);

            // Display result from session after manual form redirect
            <?php if ($manual_form_result_display): ?>
                displayScanResultMessage(<?php echo json_encode($manual_form_result_display); ?>);
            <?php endif; ?>

        });
    </script>
</body>
</html>