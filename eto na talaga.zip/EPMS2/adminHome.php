<?php
// Start session for user authentication
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}

// Include database connection and admin functions
require_once 'database.php'; // Ensures $conn is set
if (!$conn) {
    // Critical error: database connection failed.
    // You might want to display a user-friendly error page or die.
    die("Fatal Error: Could not connect to the database. Please check server logs or contact support.");
}

// admin_functions.php is optional for some stats, but required for recent activities if its function is used.
if (file_exists('admin_functions.php')) {
    require_once 'admin_functions.php';
}


// Fetch admin information from the normalized admins table
$admin_id_session = $_SESSION['admin_id'];
$admin = null;

$query_admin = "SELECT admin_id, full_name, role FROM admins WHERE admin_id = ? AND is_active = TRUE";
$stmt_admin = mysqli_prepare($conn, $query_admin);

if (!$stmt_admin) {
    error_log("Admin info prepare failed: " . mysqli_error($conn));
} else {
    mysqli_stmt_bind_param($stmt_admin, "i", $admin_id_session);
    if (!mysqli_stmt_execute($stmt_admin)) {
        error_log("Admin info execute failed: " . mysqli_stmt_error($stmt_admin));
    } else {
        $result_admin = mysqli_stmt_get_result($stmt_admin);
        if (!$result_admin) {
            error_log("Admin info get result failed: " . mysqli_stmt_error($stmt_admin));
        } else {
            $admin = mysqli_fetch_assoc($result_admin);
            mysqli_free_result($result_admin); 
        }
    }
    mysqli_stmt_close($stmt_admin);
}
// Default admin info if fetch fails
if (!$admin) {
    $admin = ['full_name' => 'Admin User (Error)', 'role' => 'System'];
}


// Get total active employee count
$total_employees_query = "SELECT COUNT(*) as total FROM employees WHERE is_active = TRUE";
$total_employees_result = mysqli_query($conn, $total_employees_query);
$total_employees = 0;
if ($total_employees_result) {
    $row = mysqli_fetch_assoc($total_employees_result);
    $total_employees = $row['total'] ?? 0; // Use null coalescing
    mysqli_free_result($total_employees_result);
} else {
    error_log("Total employees query failed: " . mysqli_error($conn));
}

// Get new employees this month
$new_employees_query = "SELECT COUNT(*) as new_employees FROM employees 
                       WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) 
                       AND YEAR(created_at) = YEAR(CURRENT_DATE()) 
                       AND is_active = TRUE";
$new_employees_result = mysqli_query($conn, $new_employees_query);
$new_employees = 0;
if ($new_employees_result) {
    $row = mysqli_fetch_assoc($new_employees_result);
    $new_employees = $row['new_employees'] ?? 0;
    mysqli_free_result($new_employees_result);
} else {
    error_log("New employees query failed: " . mysqli_error($conn));
}

// Get present employees today
$today = date('Y-m-d');
$present_today = 0;
$check_table_attendance = mysqli_query($conn, "SHOW TABLES LIKE 'attendance'");
if ($check_table_attendance) {
    if (mysqli_num_rows($check_table_attendance) > 0) {
        mysqli_free_result($check_table_attendance); 
        $present_today_query = "SELECT COUNT(DISTINCT emp_id) as present FROM attendance 
                               WHERE attendance_date = ? AND status = 'Present'"; // COUNT DISTINCT emp_id
        $stmt_present = mysqli_prepare($conn, $present_today_query);
        if($stmt_present) {
            mysqli_stmt_bind_param($stmt_present, "s", $today);
            if (mysqli_stmt_execute($stmt_present)) {
                $present_today_result = mysqli_stmt_get_result($stmt_present);
                if ($present_today_result) {
                    $row = mysqli_fetch_assoc($present_today_result);
                    $present_today = $row['present'] ?? 0;
                    mysqli_free_result($present_today_result);
                } else {
                    error_log("Present employees get result failed: " . mysqli_stmt_error($stmt_present));
                }
            } else {
                 error_log("Present employees query execution failed: " . mysqli_stmt_error($stmt_present));
            }
            mysqli_stmt_close($stmt_present);
        } else {
             error_log("Present employees prepare statement failed: " . mysqli_error($conn));
        }
    } else {
         if($check_table_attendance) mysqli_free_result($check_table_attendance);
         error_log("Attendance table does not exist.");
    }
} else {
    error_log("Error checking for attendance table: " . mysqli_error($conn));
}

$attendance_percentage = ($total_employees > 0) ? round(($present_today / $total_employees) * 100) : 0;

// Get pending requests
$pending_requests_query = "SELECT COUNT(*) as pending FROM employee_requests WHERE status = 'Pending'";
$pending_requests_result = mysqli_query($conn, $pending_requests_query);
$pending_requests = 0;
if ($pending_requests_result) {
    $row = mysqli_fetch_assoc($pending_requests_result);
    $pending_requests = $row['pending'] ?? 0;
    mysqli_free_result($pending_requests_result);
} else {
    error_log("Pending requests query failed: " . mysqli_error($conn));
}

// Get new requests today
$new_today_query = "SELECT COUNT(*) as new_today FROM employee_requests 
                   WHERE DATE(created_at) = CURDATE() AND status = 'Pending'";
$new_today_result = mysqli_query($conn, $new_today_query);
$new_today = 0;
if ($new_today_result) {
    $row = mysqli_fetch_assoc($new_today_result);
    $new_today = $row['new_today'] ?? 0;
    mysqli_free_result($new_today_result);
} else {
    error_log("New requests today query failed: " . mysqli_error($conn));
}

// Get recent activities
$recent_activities_from_function = []; // Initialize as empty array
if (function_exists('getRecentAdminActivities')) {
    $activities_result = getRecentAdminActivities(5); // Get 5 activities
    if ($activities_result !== false && is_array($activities_result)) {
        $recent_activities_from_function = $activities_result;
    } elseif ($activities_result === false) {
        error_log("getRecentAdminActivities returned false. Fallback query will be used if defined.");
    }
}

$recent_activities_from_query_result = null;
$use_fallback_query = true;
if (!empty($recent_activities_from_function)) {
    $use_fallback_query = false;
}

if ($use_fallback_query) {
    // Fallback query (as previously defined, it's already good for the 3NF schema)
    $fallback_query = "
    SELECT * FROM (
        SELECT 
            'New Employee Added' as activity_type, 
            CONCAT(e.first_name, ' ', e.last_name) as full_name, 
            CONCAT(d.dept_name, ' - ', jt.title_name) as details, 
            e.created_at, 'employee' as source
        FROM employees e
        LEFT JOIN departments d ON e.dept_id = d.dept_id
        LEFT JOIN job_titles jt ON e.job_title_id = jt.job_title_id
        WHERE e.created_at IS NOT NULL AND e.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND e.is_active = TRUE
        UNION ALL
        SELECT 
            'Salary Processed' as activity_type, CONCAT(emp.first_name, ' ', emp.last_name) as full_name, 
            CONCAT('Period: ', DATE_FORMAT(sc.pay_period_start_date, '%b %Y'), ', Status: ', sc.payment_status, ', Net: ₱', FORMAT(sc.net_salary, 2)) as details,
            COALESCE(sc.payment_date, sc.calculated_at) as created_at, 'salary' as source
        FROM salary_calculations sc JOIN employees emp ON sc.emp_id = emp.emp_id
        WHERE COALESCE(sc.payment_date, sc.calculated_at) IS NOT NULL AND COALESCE(sc.payment_date, sc.calculated_at) >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND emp.is_active = TRUE
        UNION ALL
        SELECT 
            'Employee Request' as activity_type, CONCAT(emp.first_name, ' ', emp.last_name) as full_name, 
            CONCAT(rt.type_name, ': ', er.subject, ' (Priority: ', er.priority, ')') as details,
            er.created_at, 'request' as source
        FROM employee_requests er JOIN employees emp ON er.emp_id = emp.emp_id LEFT JOIN request_types rt ON er.request_type_id = rt.request_type_id
        WHERE er.created_at IS NOT NULL AND er.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        UNION ALL
        SELECT 
            'Leave Application' as activity_type, CONCAT(emp.first_name, ' ', emp.last_name) as full_name,
            CONCAT(lt.type_name, ': ', lm.number_of_days, ' days (', DATE_FORMAT(lm.start_date, '%M %d'), ' - ', DATE_FORMAT(lm.end_date, '%M %d'), ')') as details,
            lm.applied_on as created_at, 'leave' as source
        FROM leave_management lm JOIN employees emp ON lm.emp_id = emp.emp_id LEFT JOIN leave_types lt ON lm.leave_type_id = lt.leave_type_id
        WHERE lm.applied_on IS NOT NULL AND lm.applied_on >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND emp.is_active = TRUE
        UNION ALL
        SELECT 
            aal.activity_type as activity_type, a.full_name as full_name, 
            CONCAT(COALESCE(aal.target_entity_type, ''), IF(aal.target_entity_type IS NOT NULL AND aal.description IS NOT NULL, ': ', ''), COALESCE(aal.description, '')) as details,
            aal.created_at, 'admin' as source
        FROM admin_activities_log aal JOIN admins a ON aal.admin_id = a.admin_id
        WHERE aal.created_at IS NOT NULL AND aal.created_at >= DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND a.is_active = TRUE
    ) AS activities
    ORDER BY created_at DESC LIMIT 6";

    $recent_activities_from_query_result = mysqli_query($conn, $fallback_query);
    if ($recent_activities_from_query_result === false) {
        error_log("Recent activities fallback query failed: " . mysqli_error($conn));
    }
}


function formatActivityType($type) { return ucwords(str_replace(['_', '-'], ' ', $type)); }
function formatTimestamp($timestamp) {
    if (empty($timestamp)) return 'N/A';
    try {
        $date = new DateTime($timestamp, new DateTimeZone('UTC')); // Assuming DB stores in UTC
        $date->setTimezone(new DateTimeZone(date_default_timezone_get())); // Convert to server/PHP timezone
        $now = new DateTime();
        $interval = $now->diff($date);
        if ($interval->days == 0) {
            if ($interval->h == 0) { return $interval->i . " minute" . ($interval->i != 1 ? "s" : "") . " ago"; }
            return $interval->h . " hour" . ($interval->h != 1 ? "s" : "") . " ago";
        } elseif ($interval->days == 1 && $date < $now) { return "Yesterday at " . $date->format('g:i A');
        } elseif ($interval->days < 7 && $date < $now) { return $interval->days . " days ago"; }
        return $date->format('M j, Y g:i A');
    } catch (Exception $e) { return 'Invalid date'; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* --- Using the CSS from your original adminHome.php --- */
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Arial', sans-serif; }
        body { display: flex; min-height: 100vh; background-color: #f0f2f5; }
        .sidebar { width: 250px; background-color: #2c3e50; color: white; padding-top: 20px; display: flex; flex-direction: column; }
        .logo-container { text-align: center; padding: 10px; margin-bottom: 20px; }
        .logo-img { width: 80px; height: 80px; object-fit: contain; border-radius: 50%; border: 2px solid #f0c14b; }
        .system-name { text-align: center; font-size: 14px; margin-top: 10px; color: #f0c14b; line-height: 1.3; }
        .admin-profile { text-align: center; padding: 15px 0; border-top: 1px solid #34495e; border-bottom: 1px solid #34495e; margin: 15px 0; }
        .profile-img { display: inline-block; padding: 6px 12px; background-color: #f0c14b; border-radius: 15px; font-weight: bold; color: #2c3e50; border: none; cursor: default; }
        .admin-name { margin-top: 8px; font-weight: bold; font-size: 1.1em; }
        .admin-role { font-size: 0.9em; color: #bdc3c7; }
        .nav-menu { list-style: none; flex-grow: 1; padding-left:0; } /* Added padding-left:0 */
        .nav-item { transition: all 0.2s ease-in-out; }
        .nav-item:hover, .nav-item.active { background-color: #34495e; }
        .nav-item.active .nav-link { border-left: 4px solid #f0c14b; padding-left: 16px; }
        .nav-item .nav-link:hover { color: #f0c14b; }
        .nav-link { color: #ecf0f1; text-decoration: none; display: flex; align-items: center; padding: 15px 20px; }
        .nav-item i.fas { margin-right: 12px; color: #f0c14b; width: 20px; text-align: center; } /* Targeted FontAwesome icons */
        .content { flex: 1; background-color: #f4f6f9; }
        .header { background-color: white; padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 1px 3px rgba(0,0,0,0.1); border-bottom: 1px solid #e0e0e0; }
        .dashboard-title { font-size: 22px; color: #333; font-weight: 600; }
        .add-btn { background-color: #f0c14b; color: #333; border: none; padding: 10px 18px; border-radius: 5px; font-weight: bold; cursor: pointer; display: flex; align-items: center; text-decoration: none; transition: background-color 0.2s; }
        .add-btn:hover { background-color: #e0b13a; }
        .add-btn i.fas { margin-right: 8px; } /* Targeted FontAwesome icons */
        .dashboard-content { padding: 25px; }
        .stats-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; margin-bottom: 30px; }
        .stat-card { background-color: white; border-radius: 8px; padding: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); position: relative; transition: transform 0.2s, box-shadow 0.2s; }
        .stat-card:hover { transform: translateY(-3px); box-shadow: 0 4px 12px rgba(0,0,0,0.12); }
        .stat-icon { position: absolute; top: 25px; right: 25px; width: 45px; height: 45px; background-color: rgba(240, 193, 75, 0.15); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #f0c14b; font-size: 1.2em; }
        .stat-title { color: #6c757d; font-size: 15px; margin-bottom: 8px; }
        .stat-value { font-size: 26px; font-weight: 700; color: #343a40; margin-bottom: 5px; }
        .stat-detail { font-size: 13px; color: #28a745; }
        .stat-card:nth-child(3) .stat-detail { color: #ffc107; }
        .activities-container { background-color: white; border-radius: 8px; padding: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
        .activities-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px solid #eee; }
        .activities-title { font-size: 18px; color: #333; font-weight: 600; }
        .view-all { color: #007bff; text-decoration: none; font-size: 0.9em; }
        .view-all:hover { text-decoration: underline; }
        .activity-item { display: flex; align-items: center; padding: 12px 0; border-bottom: 1px solid #f1f1f1; }
        .activity-item:last-child { border-bottom: none; }
        .activity-icon { width: 38px; height: 38px; background-color: rgba(240, 193, 75, 0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #f0c14b; margin-right: 18px; flex-shrink: 0; }
        .activity-details { flex: 1; min-width: 0; }
        .activity-title { font-weight: 600; margin-bottom: 3px; color: #495057; font-size: 0.95em; }
        .activity-description { color: #6c757d; font-size: 0.85em; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
        .activity-time { color: #adb5bd; font-size: 0.8em; text-align: right; white-space: nowrap; padding-left: 15px; }
        .no-activities { padding: 20px; text-align: center; color: #777; }
        .activity-note { font-size: 12px; color: #777; margin-bottom: 15px; }
    </style>
</head>
<body>
    <div class="sidebar">
        <div class="logo-container">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img">
            <div class="system-name">Employment Payment<br>Management System</div>
        </div>
        <div class="admin-profile">
            <div class="profile-img">Admin</div>
            <div class="admin-name"><?php echo htmlspecialchars($admin['full_name'] ?? 'Admin User'); ?></div>
            <div class="admin-role"><?php echo htmlspecialchars($admin['role'] ?? 'Administrator'); ?></div>
        </div>
        <ul class="nav-menu">
            <li class="nav-item active"><a href="adminHome.php" class="nav-link"><i class="fas fa-home"></i> Admin Home</a></li>
            <li class="nav-item"><a href="employee_details.php" class="nav-link"><i class="fas fa-users"></i> Employee Details</a></li>
            <li class="nav-item"><a href="view_attendance.php" class="nav-link"><i class="fas fa-clipboard-user"></i> Attendance</a></li>
            <li class="nav-item"><a href="salary_calculation.php" class="nav-link"><i class="fas fa-calculator"></i> Salary & Payslips</a></li>
            <li class="nav-item"><a href="admin_requests.php" class="nav-link"><i class="fas fa-envelope-open-text"></i> Employee Requests</a></li>
            <li class="nav-item"><a href="admin_settings.php" class="nav-link"><i class="fas fa-cog"></i> Settings</a></li>
            <li class="nav-item" style="margin-top: auto; border-top: 1px solid #34495e;"><a href="adminLogin.php?logout=1" class="nav-link"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
        </ul>
    </div>
    
    <div class="content">
        <div class="header">
            <div class="dashboard-title">Admin Dashboard</div>
            <a href="add_employee.php" class="add-btn"><i class="fas fa-user-plus"></i> Add Employee</a>
        </div>
        <div class="dashboard-content">
            <div class="stats-container">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-title">Total Employees</div>
                    <div class="stat-value"><?php echo $total_employees; ?></div>
                    <div class="stat-detail">+<?php echo $new_employees; ?> this month</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-user-check"></i></div>
                    <div class="stat-title">Present Today</div>
                    <div class="stat-value"><?php echo $present_today; ?></div>
                    <div class="stat-detail"><?php echo $attendance_percentage; ?>% attendance</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-hourglass-half"></i></div>
                    <div class="stat-title">Pending Requests</div>
                    <div class="stat-value"><?php echo $pending_requests; ?></div>
                    <div class="stat-detail"><?php echo $new_today; ?> new today</div>
                </div>
            </div>
            <div class="activities-container">
                <div class="activities-header">
                    <div class="activities-title">Recent System Activity</div>
                    <a href="admin_activities.php" class="view-all">View All</a>
                </div>
                <div class="activity-note">Showing key system events from the past 7 days including employee management, salary processing, and requests.</div>
                <div class="activity-list">
                    <?php 
                    $activity_displayed = false;
                    if (!empty($recent_activities_from_function)):
                        foreach ($recent_activities_from_function as $activity): ?>
                            <div class="activity-item">
                                <div class="activity-icon"><i class="fas fa-user-shield"></i></div>
                                <div class="activity-details">
                                    <div class="activity-title"><?php echo htmlspecialchars(formatActivityType($activity['activity_type'] ?? 'Admin Action')); ?></div>
                                    <div class="activity-description">
                                        <?php echo htmlspecialchars($activity['admin_name'] ?? 'N/A'); ?>
                                        - <?php echo htmlspecialchars($activity['description'] ?? 'Details not available'); ?>
                                         <?php if(!empty($activity['target_entity_type'])) echo " (" . htmlspecialchars($activity['target_entity_type']) . (isset($activity['target_entity_id']) ? ": ".htmlspecialchars($activity['target_entity_id']) : '') . ")"; ?>
                                    </div>
                                </div>
                                <div class="activity-time"><?php echo formatTimestamp($activity['created_at'] ?? null); ?></div>
                            </div>
                        <?php $activity_displayed = true; endforeach; 
                    endif;

                    if (!$activity_displayed && isset($recent_activities_from_query_result) && $recent_activities_from_query_result && mysqli_num_rows($recent_activities_from_query_result) > 0):
                        while ($activity = mysqli_fetch_assoc($recent_activities_from_query_result)): 
                            $icon_class = 'fa-bell'; 
                            if (!empty($activity['source'])) {
                                if ($activity['source'] === 'employee') $icon_class = 'fa-user-plus';
                                if ($activity['source'] === 'salary') $icon_class = 'fa-file-invoice-dollar';
                                if ($activity['source'] === 'request') $icon_class = 'fa-bullhorn';
                                if ($activity['source'] === 'leave') $icon_class = 'fa-calendar-times';
                                if ($activity['source'] === 'admin') $icon_class = 'fa-user-shield';
                            }?>
                            <div class="activity-item">
                                <div class="activity-icon"><i class="fas <?php echo $icon_class; ?>"></i></div>
                                <div class="activity-details">
                                    <div class="activity-title"><?php echo htmlspecialchars(formatActivityType($activity['activity_type'])); ?></div>
                                    <div class="activity-description">
                                        <?php 
                                        $desc_parts = [];
                                        if (!empty($activity['full_name'])) $desc_parts[] = htmlspecialchars($activity['full_name']);
                                        if (!empty($activity['details'])) $desc_parts[] = htmlspecialchars($activity['details']);
                                        echo implode(' - ', $desc_parts);
                                        ?>
                                    </div>
                                </div>
                                <div class="activity-time"><?php echo formatTimestamp($activity['created_at']); ?></div>
                            </div>
                        <?php $activity_displayed = true; endwhile; 
                        mysqli_free_result($recent_activities_from_query_result);
                    endif;
                    
                    if (!$activity_displayed): ?>
                        <div class="no-activities">No recent activities found in the last 7 days.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const currentPage = window.location.pathname.split('/').pop() || 'adminHome.php'; // Default to adminHome.php if path is empty
            const navLinks = document.querySelectorAll('.sidebar .nav-menu .nav-link');
            
            let activeLinkFound = false;
            navLinks.forEach(link => {
                const linkPage = link.getAttribute('href').split('/').pop();
                if (linkPage === currentPage) {
                    link.closest('.nav-item').classList.add('active');
                    activeLinkFound = true;
                } else {
                    link.closest('.nav-item').classList.remove('active');
                }
            });
            // If no specific link matches, but we are on adminHome.php (e.g. index redirect)
            if (!activeLinkFound && currentPage === 'adminHome.php') {
                 const homeLink = document.querySelector('.sidebar .nav-menu .nav-link[href="adminHome.php"]');
                 if (homeLink) {
                     homeLink.closest('.nav-item').classList.add('active');
                 }
            }
        });
    </script>
</body>
</html>