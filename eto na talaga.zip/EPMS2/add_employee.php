<?php
// Start session for user authentication (if not already started)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}

// Include database connection
require_once 'database.php'; 
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Critical: Database connection failed or $conn is not a mysqli object in add_employee.php.");
    die("A critical database error occurred. Please contact support or check server logs.");
}

// Include admin functions
if (file_exists('admin_functions.php')) {
    require_once 'admin_functions.php';
}

// Initialize variables and arrays
$firstName = $lastName = $email = $phone = $hireDate = $jobTitleName = $departmentId = $password = ""; // Changed $jobTitleId to $jobTitleName
$errors = [];
$successMessage = "";

// Helper Functions
function validatePassword($password) {
    $local_errors = [];
    if (strlen($password) < 8) $local_errors[] = "Password must be at least 8 characters long";
    if (!preg_match("/[A-Z]/", $password)) $local_errors[] = "Password must contain at least one uppercase letter";
    if (!preg_match("/[a-z]/", $password)) $local_errors[] = "Password must contain at least one lowercase letter";
    if (!preg_match("/[0-9]/", $password)) $local_errors[] = "Password must contain at least one number";
    if (!preg_match("/[!@#$%^&*()_+\-=\[\]{};':\"\\|,.<>\/?]/", $password)) $local_errors[] = "Password must contain at least one special character";
    return $local_errors;
}

/** @param mysqli $db_conn */
function getActiveDepartments($db_conn) {
    $departments = [];
    if (!$db_conn) return $departments;
    $sql = "SELECT dept_id, dept_name FROM departments WHERE is_active = TRUE ORDER BY dept_name ASC";
    $result = mysqli_query($db_conn, $sql);
    if ($result) {
        while ($row = mysqli_fetch_assoc($result)) $departments[] = $row;
        mysqli_free_result($result);
    } else {
        error_log("Error fetching departments: " . mysqli_error($db_conn));
    }
    return $departments;
}

// We no longer fetch job titles for a dropdown, but we need a function to get/create job title ID
/**
 * Gets the ID of a job title. If it doesn't exist, creates it.
 * @param mysqli $db_conn
 * @param string $titleName
 * @return int|false The job_title_id or false on error
 */
function getOrCreateJobTitleId($db_conn, $titleName) {
    if (!$db_conn || empty($titleName)) return false;

    // Check if job title exists
    $checkSql = "SELECT job_title_id FROM job_titles WHERE title_name = ?";
    $stmtCheck = mysqli_prepare($db_conn, $checkSql);
    if (!$stmtCheck) {
        error_log("getOrCreateJobTitleId - Prepare check failed: " . mysqli_error($db_conn));
        return false;
    }
    mysqli_stmt_bind_param($stmtCheck, "s", $titleName);
    mysqli_stmt_execute($stmtCheck);
    $resultCheck = mysqli_stmt_get_result($stmtCheck);
    $existingTitle = mysqli_fetch_assoc($resultCheck);
    mysqli_stmt_close($stmtCheck);

    if ($existingTitle) {
        return $existingTitle['job_title_id'];
    } else {
        // Job title does not exist, create it
        // Assuming new job titles are associated with a default/null department or this needs more logic
        $deptIdForNewTitle = null; // Or a default, or pass it as a parameter if relevant
        $insertSql = "INSERT INTO job_titles (title_name, dept_id, is_active, created_at) VALUES (?, ?, TRUE, NOW())";
        $stmtInsert = mysqli_prepare($db_conn, $insertSql);
        if (!$stmtInsert) {
            error_log("getOrCreateJobTitleId - Prepare insert failed: " . mysqli_error($db_conn));
            return false;
        }
        mysqli_stmt_bind_param($stmtInsert, "si", $titleName, $deptIdForNewTitle); // dept_id can be NULL
        if (mysqli_stmt_execute($stmtInsert)) {
            $newId = mysqli_insert_id($db_conn);
            mysqli_stmt_close($stmtInsert);
            return $newId;
        } else {
            error_log("getOrCreateJobTitleId - Execute insert failed: " . mysqli_stmt_error($stmtInsert));
            mysqli_stmt_close($stmtInsert);
            return false;
        }
    }
}

$departmentsList = getActiveDepartments($conn);
// $jobTitlesList = getActiveJobTitles($conn); // No longer needed for dropdown

// Form Processing
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    /** @var mysqli $conn */

    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone'] ?? '');
    $hireDate = trim($_POST['hire_date']);
    $jobTitleName = trim($_POST['job_title_name']); // New: getting job title name from text input
    $departmentId = trim($_POST['department_id']);
    $password = trim($_POST['password']);

    if (empty($firstName)) $errors[] = "First name is required";
    if (empty($lastName)) $errors[] = "Last name is required";
    if (empty($email)) $errors[] = "Email is required";
    else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Invalid email format";
    if (empty($hireDate)) $errors[] = "Hire date is required";
    if (empty($jobTitleName)) $errors[] = "Job title is required"; // Now checking $jobTitleName
    if (empty($departmentId)) $errors[] = "Department is required";
    
    $passwordValidationErrors = validatePassword($password);
    if (!empty($passwordValidationErrors)) {
        $errors = array_merge($errors, $passwordValidationErrors);
    }

    if (empty($errors)) {
        $checkEmailSql = "SELECT emp_id FROM employees WHERE email = ?";
        $stmtCheckEmail = mysqli_prepare($conn, $checkEmailSql);
        if ($stmtCheckEmail) {
            mysqli_stmt_bind_param($stmtCheckEmail, "s", $email);
            mysqli_stmt_execute($stmtCheckEmail);
            mysqli_stmt_store_result($stmtCheckEmail);
            if (mysqli_stmt_num_rows($stmtCheckEmail) > 0) {
                $errors[] = "Email address already exists. Please use a different email.";
            }
            mysqli_stmt_close($stmtCheckEmail);
        } else {
            $errors[] = "Error checking email: " . mysqli_error($conn);
        }

        // Get or create Job Title ID
        $actualJobTitleId = false;
        if (empty($errors) && !empty($jobTitleName)) {
            $actualJobTitleId = getOrCreateJobTitleId($conn, $jobTitleName);
            if ($actualJobTitleId === false) {
                $errors[] = "Error processing job title. Please try again.";
            }
        }


        if (empty($errors)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            
            $username_base = strtolower(explode('@', $email)[0]);
            $username_base = preg_replace("/[^a-z0-9_]/", "", $username_base);
            $username = $username_base;
            $counter = 1;
            
            do { // Username generation loop
                $checkUsernameSql = "SELECT emp_id FROM employees WHERE username = ?";
                $stmtCheckUser = mysqli_prepare($conn, $checkUsernameSql);
                if (!$stmtCheckUser) { $errors[] = "Error preparing username check: ".mysqli_error($conn); break; }
                mysqli_stmt_bind_param($stmtCheckUser, "s", $username);
                mysqli_stmt_execute($stmtCheckUser);
                mysqli_stmt_store_result($stmtCheckUser);
                $userExists = mysqli_stmt_num_rows($stmtCheckUser) > 0;
                mysqli_stmt_close($stmtCheckUser);
                if ($userExists) { $username = $username_base . $counter++; } else { break; }
            } while (true);

            $emp_code = strtoupper(substr($firstName, 0, 1) . substr($lastName, 0, 1)) . time() . rand(10,99);

            if (empty($errors)) { 
                $insertQuery = "INSERT INTO employees (emp_code, username, first_name, last_name, email, phone, hire_date, dept_id, job_title_id, password, is_active, created_at, updated_at) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, TRUE, NOW(), NOW())";
                
                $stmtInsert = mysqli_prepare($conn, $insertQuery);
                
                if ($stmtInsert) {
                    mysqli_stmt_bind_param(
                        $stmtInsert, 
                        "sssssssiis", 
                        $emp_code, $username, $firstName, $lastName, $email, 
                        $phone, $hireDate, $departmentId, $actualJobTitleId, $hashedPassword // Using $actualJobTitleId
                    );
            
                    if (mysqli_stmt_execute($stmtInsert)) {
                        $employeeId = mysqli_insert_id($conn);
                        $successMessage = "Employee added successfully! Employee ID: " . $employeeId . ", Username: " . $username . ", Code: " . $emp_code;
                        
                        if (function_exists('logAdminActivity') && isset($_SESSION['admin_id'])) {
                            $activityDescription = "Added new employee: $firstName $lastName (ID: $employeeId, Job: $jobTitleName)";
                            logAdminActivity($_SESSION['admin_id'], 'Employee Added', $activityDescription, 'Employee', $employeeId);
                        }
                        
                        $firstName = $lastName = $email = $phone = $hireDate = $jobTitleName = $departmentId = $password = ""; // Clear $jobTitleName
                    } else {
                        if(mysqli_errno($conn) == 1062) { 
                             $errors[] = "Error adding employee: A unique field (like Employee Code, Username, or Email) might already exist.";
                        } else {
                             $errors[] = "Error adding employee: " . mysqli_stmt_error($stmtInsert);
                        }
                    }
                    mysqli_stmt_close($stmtInsert);
                } else {
                    $errors[] = "Error preparing statement: " . mysqli_error($conn);
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Employee - EPMS</title>
    <style>
        :root {
            --primary-color: #ffde59; /* Yellow from logo */
            --secondary-color: #5e5e5e; /* Dark gray from logo */
            --lighter-gray: #f0f0f0;
            --white: #ffffff;
            --error: #d32f2f;
            --success: #388e3c;
        }
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: var(--lighter-gray); }
        .container { max-width: 800px; margin: 0 auto; background-color: var(--white); border-radius: 8px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1); padding: 20px; position: relative; }
        .back-button { position: absolute; top: 20px; right: 20px; background-color: var(--secondary-color); color: var(--white); border: none; padding: 8px 15px; border-radius: 4px; font-weight: bold; cursor: pointer; text-decoration: none; font-size: 14px; transition: all 0.3s; }
        .back-button:hover { background-color: var(--primary-color); color: var(--secondary-color); }
        .header { text-align: center; margin-bottom: 30px; padding-top: 20px; }
        .logo { max-width: 100px; height: auto; margin-bottom: 15px; }
        h1 { color: var(--secondary-color); margin-top: 0; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; color: var(--secondary-color); font-weight: bold; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; font-size: 16px; }
        .required:after { content: " *"; color: var(--error); }
        .btn-submit { background-color: var(--secondary-color); color: var(--white); border: none; padding: 12px 20px; border-radius: 4px; cursor: pointer; font-size: 16px; font-weight: bold; transition: all 0.3s; }
        .btn-submit:hover { background-color: var(--primary-color); color: var(--secondary-color); }
        .error-message, .success-message { padding: 15px; margin-bottom: 20px; border-radius: 4px; border: 1px solid transparent; }
        .error-message { color: var(--error); background-color: #fdecea; border-color: var(--error); }
        .error-message ul { margin: 0; padding-left: 20px; }
        .success-message { color: var(--success); background-color: #e6f4e7; border-color: var(--success); }
    </style>
</head>
<body>
    <div class="container">
        <a href="adminHome.php" class="back-button">Back to Admin Home</a>
        <div class="header">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo">
            <h1>Add New Employee</h1>
        </div>
        <?php if (!empty($errors)): ?>
            <div class="error-message">
                <strong>Please correct the following errors:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?php echo htmlspecialchars($error); ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if (!empty($successMessage)): ?>
            <div class="success-message">
                <?php echo htmlspecialchars($successMessage); ?>
            </div>
        <?php endif; ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="first_name" class="required">First Name</label>
                <input type="text" id="first_name" name="first_name" value="<?php echo htmlspecialchars($firstName); ?>" required>
            </div>
            <div class="form-group">
                <label for="last_name" class="required">Last Name</label>
                <input type="text" id="last_name" name="last_name" value="<?php echo htmlspecialchars($lastName); ?>" required>
            </div>
            <div class="form-group">
                <label for="email" class="required">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone Number</label>
                <input type="tel" id="phone" name="phone" value="<?php echo htmlspecialchars($phone); ?>" placeholder="e.g., +1-555-123-4567">
            </div>
            <div class="form-group">
                <label for="hire_date" class="required">Hire Date</label>
                <input type="date" id="hire_date" name="hire_date" value="<?php echo htmlspecialchars($hireDate); ?>" required>
            </div>
            <div class="form-group">
                <label for="department_id" class="required">Department</label>
                <select id="department_id" name="department_id" required>
                    <option value="">-- Select Department --</option>
                    <?php foreach ($departmentsList as $dept): ?>
                        <option value="<?php echo htmlspecialchars($dept['dept_id']); ?>" 
                                <?php echo ($departmentId !== "" && $departmentId == $dept['dept_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($dept['dept_name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="job_title_name" class="required">Job Title</label> <!-- Changed from job_title_id to job_title_name -->
                 <input type="text" id="job_title_name" name="job_title_name" value="<?php echo htmlspecialchars($jobTitleName); ?>" required> <!-- Changed to text input -->
            </div>
            <div class="form-group">
                <label for="password" class="required">Password</label>
                <input type="password" id="password" name="password" required>
                <small class="form-text text-muted">Password must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.</small>
            </div>
            <div class="form-group">
                <button type="submit" class="btn-submit">Add Employee</button>
            </div>
        </form>
    </div>
</body>
</html>