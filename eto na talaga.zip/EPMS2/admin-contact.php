<?php
// No session_start() typically needed for a public contact form unless using session-based CSRF, etc.

// --- INCLUDE CONFIG FILE ---
require_once __DIR__ . '/config.php'; // For CONTACT_FORM_GUEST_EMP_ID, TYPE_NAME, TYPE_CODE

require_once __DIR__ . '/database.php'; // Ensures $conn is initialized
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Critical: Database connection failed in admin-contact.php.");
    // For a public page, avoid die() with raw errors. Show a user-friendly message.
    // The HTML part can display a generic error message.
    $submission_error_message = "Our system is temporarily unavailable. Please try again later.";
}

// Initialize variables for form data and error messages
$name_form = $email_form = $message_form = '';
$nameErr_form = $emailErr_form = $messageErr_form = '';
$formSubmitted_message = false;
if (!isset($submission_error_message)) { // Only initialize if not set by DB connection failure
    $submission_error_message = '';
}

// The constants CONTACT_FORM_REQUEST_TYPE_NAME, CONTACT_FORM_REQUEST_TYPE_CODE,
// and CONTACT_FORM_GUEST_EMP_ID are now defined in config.php.
// No need for the define() calls below anymore:
// define('CONTACT_FORM_REQUEST_TYPE_NAME', 'Contact Form Submission');
// define('CONTACT_FORM_REQUEST_TYPE_CODE', 'CONTACT_GUEST');
// define('CONTACT_FORM_GUEST_EMP_ID', 0); 

// Function to get request_type_id (or create if not exists - for robustness)
function getOrCreateContactRequestTypeId($db_conn) {
    // Constants are now globally available from config.php
    $typeName = CONTACT_FORM_REQUEST_TYPE_NAME;
    $typeCode = CONTACT_FORM_REQUEST_TYPE_CODE;

    $stmt_check = $db_conn->prepare("SELECT request_type_id FROM request_types WHERE type_name = ? OR type_code = ?");
    if(!$stmt_check) { 
        error_log("getOrCreateContactRequestTypeId - Prepare failed (check type): ".$db_conn->error); 
        return false; 
    }
    $stmt_check->bind_param("ss", $typeName, $typeCode);
    if(!$stmt_check->execute()){
        error_log("getOrCreateContactRequestTypeId - Execute failed (check type): ".$stmt_check->error);
        $stmt_check->close();
        return false;
    }
    $result = $stmt_check->get_result();
    if($row = $result->fetch_assoc()) {
        $stmt_check->close();
        return (int)$row['request_type_id'];
    }
    $stmt_check->close();

    // Type not found, create it
    $stmt_insert = $db_conn->prepare("INSERT INTO request_types (type_name, type_code, description, requires_approval, is_active) VALUES (?, ?, ?, FALSE, TRUE)");
    if(!$stmt_insert) { 
        error_log("getOrCreateContactRequestTypeId - Prepare failed (insert type): ".$db_conn->error); 
        return false; 
    }
    $description = "Requests submitted via the public contact form by non-employees.";
    $stmt_insert->bind_param("sss", $typeName, $typeCode, $description);
    if($stmt_insert->execute()){
        $new_id = $stmt_insert->insert_id;
        $stmt_insert->close();
        return (int)$new_id;
    } else {
        error_log("getOrCreateContactRequestTypeId - Execute failed (insert type): ".$stmt_insert->error);
        $stmt_insert->close();
        return false;
    }
}


// Process form submission only if DB connection is okay
if ($conn && $_SERVER['REQUEST_METHOD'] == 'POST') {
    $name_form = trim($_POST['name'] ?? '');
    $email_form = trim($_POST['email'] ?? '');
    $message_form = trim($_POST['message'] ?? '');

    if (empty($name_form)) $nameErr_form = 'Name is required';
    if (empty($email_form)) $emailErr_form = 'Email is required';
    else if (!filter_var($email_form, FILTER_VALIDATE_EMAIL)) $emailErr_form = 'Invalid email format';
    if (empty($message_form)) $messageErr_form = 'Message is required';
    
    if (empty($nameErr_form) && empty($emailErr_form) && empty($messageErr_form)) {
        $contact_request_type_id = getOrCreateContactRequestTypeId($conn);

        if ($contact_request_type_id === false) {
            $submission_error_message = "System error: Could not process request type. Please try again later.";
            error_log("admin-contact.php: Failed to get or create contact request type ID.");
        } else {
            $subject_line = "Contact Form: " . substr($name_form, 0, 100); // Truncate subject
            $description_full = "Contact Form Submission Details:\n";
            $description_full .= "Submitted By: " . htmlspecialchars($name_form) . "\n";
            $description_full .= "Email: " . htmlspecialchars($email_form) . "\n";
            $description_full .= "Date Submitted: " . date('Y-m-d H:i:s') . "\n\n";
            $description_full .= "Message:\n" . htmlspecialchars($message_form);
            
            $status_default = 'Pending';
            $priority_default = 'Medium'; 

            $stmt_insert_request = $conn->prepare(
                "INSERT INTO employee_requests (emp_id, request_type_id, subject, description, status, priority, created_at, updated_at) 
                 VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())"
            );
            
            if ($stmt_insert_request) {
                $guest_emp_id_val = CONTACT_FORM_GUEST_EMP_ID; // From config.php
                mysqli_stmt_bind_param($stmt_insert_request, "iissss", 
                    $guest_emp_id_val, 
                    $contact_request_type_id, 
                    $subject_line, 
                    $description_full, 
                    $status_default,
                    $priority_default
                );
                
                if (mysqli_stmt_execute($stmt_insert_request)) {
                    $formSubmitted_message = true;
                    $name_form = $email_form = $message_form = ''; // Clear form fields
                } else {
                    // Check for foreign key constraint error specifically
                    if (mysqli_errno($conn) == 1452) { // Error code for FK constraint violation
                        $submission_error_message = "Error submitting your request: The system could not associate this request with a valid user. Please ensure guest user (ID: ".CONTACT_FORM_GUEST_EMP_ID.") exists if this is a contact form.";
                        error_log("admin-contact.php - FK Constraint Violation (emp_id=".CONTACT_FORM_GUEST_EMP_ID."): " . mysqli_stmt_error($stmt_insert_request));
                    } else {
                        $submission_error_message = "Error submitting your request. Please try again. (Code: DBX01)";
                        error_log("admin-contact.php - Execute failed (insert employee_requests): " . mysqli_stmt_error($stmt_insert_request));
                    }
                }
                mysqli_stmt_close($stmt_insert_request);
            } else {
                $submission_error_message = "System error: Could not prepare your request. Please try again. (Code: DBP01)";
                error_log("admin-contact.php - Prepare failed (insert employee_requests): " . mysqli_error($conn));
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Admin - EPMS</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #121828; color: #e0e0e0; margin: 0; padding: 20px; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
        .container { background-color: #1f2a40; padding: 30px 40px; border-radius: 12px; box-shadow: 0 8px 25px rgba(0,0,0,0.3); width: 100%; max-width: 550px; }
        h1 { font-size: 2rem; margin-bottom: 25px; text-align: center; color: #f0c14b; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: 500; font-size: 0.95rem; color: #a0aec0; }
        input[type="text"], input[type="email"], textarea { width: 100%; padding: 12px 15px; border-radius: 6px; border: 1px solid #2d3748; background-color: #2d3748; color: #e0e0e0; font-size: 1rem; transition: border-color 0.3s, box-shadow 0.3s; }
        input[type="text"]::placeholder, input[type="email"]::placeholder, textarea::placeholder { color: #718096; }
        input[type="text"]:focus, input[type="email"]:focus, textarea:focus { border-color: #f0c14b; outline: none; box-shadow: 0 0 0 3px rgba(240, 193, 75, 0.2); }
        textarea { min-height: 140px; resize: vertical; }
        .error { color: #ffc107; font-size: 0.85rem; margin-top: 6px; display: block; }
        .btn-submit-request { background-color: #f0c14b; color: #121828; border: none; padding: 12px 20px; font-size: 1.05rem; font-weight: bold; border-radius: 6px; cursor: pointer; width: 100%; transition: background-color 0.3s, transform 0.2s; }
        .btn-submit-request:hover { background-color: #e0b030; transform: translateY(-2px); }
        .message-banner { padding: 15px; border-radius: 6px; margin-bottom: 25px; text-align: center; font-size: 0.95rem; }
        .message-banner.success { background-color: rgba(40, 167, 69, 0.15); border: 1px solid #28a745; color: #a3d9a5; }
        .message-banner.error-submit { background-color: rgba(220, 53, 69, 0.15); border: 1px solid #dc3545; color: #f8d7da; }
        .back-link { display: block; margin-top: 25px; color: #f0c14b; text-decoration: none; text-align: center; font-size: 0.9rem; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Contact Admin</h1>
        
        <?php if ($formSubmitted_message): ?>
            <div class="message-banner success">
                <p>Your request has been submitted successfully. An administrator will review it shortly.</p>
            </div>
        <?php endif; ?>
        <?php if (!empty($submission_error_message)): ?>
            <div class="message-banner error-submit">
                <p><?php echo htmlspecialchars($submission_error_message); ?></p>
            </div>
        <?php endif; ?>
        
        <?php if (!$formSubmitted_message): // Only show form if not successfully submitted ?>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
            <div class="form-group">
                <label for="name">Full Name</label>
                <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name_form); ?>" placeholder="Enter your full name">
                <?php if($nameErr_form): ?><span class="error"><?php echo $nameErr_form; ?></span><?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email_form); ?>" placeholder="Enter your email address">
                <?php if($emailErr_form): ?><span class="error"><?php echo $emailErr_form; ?></span><?php endif; ?>
            </div>
            
            <div class="form-group">
                <label for="message">Message</label>
                <textarea id="message" name="message" placeholder="Please explain your issue or query."><?php echo htmlspecialchars($message_form); ?></textarea>
                <?php if($messageErr_form): ?><span class="error"><?php echo $messageErr_form; ?></span><?php endif; ?>
            </div>
            
            <button type="submit" class="btn-submit-request">Submit Request</button>
        </form>
        <?php endif; ?>
        
        <a href="index.php" class="back-link">← Back to Login Options</a>
    </div>
</body>
</html>