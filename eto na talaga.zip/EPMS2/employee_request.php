<?php
// Start session
session_start();

// Check if employee is logged in
if (!isset($_SESSION['employee_id'])) {
    header("Location: index.php"); // Or your employee login page
    exit();
}

// Include database connection
require_once 'database.php';
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Critical: Database connection failed in employee_request.php.");
    die("A critical database error occurred. Please contact support.");
}

$success_message = '';
$error_message = '';
$emp_id = (int)$_SESSION['employee_id']; // Ensure emp_id is integer

// Fetch employee data (optional, if needed for display like name)
$employee_query = "SELECT first_name, last_name FROM employees WHERE emp_id = ?";
$stmt_emp_data = mysqli_prepare($conn, $employee_query);
$employee_name_display = "Employee"; // Default
if ($stmt_emp_data) {
    mysqli_stmt_bind_param($stmt_emp_data, "i", $emp_id);
    mysqli_stmt_execute($stmt_emp_data);
    $result_emp_data = mysqli_stmt_get_result($stmt_emp_data);
    if ($emp_row_data = mysqli_fetch_assoc($result_emp_data)) {
        $employee_name_display = trim($emp_row_data['first_name'] . ' ' . $emp_row_data['last_name']);
    }
    mysqli_stmt_close($stmt_emp_data);
}


// Fetch available request types for the dropdown
$available_request_types = [];
$sql_fetch_types = "SELECT request_type_id, type_name FROM request_types WHERE is_active = TRUE ORDER BY type_name ASC";
$result_types = mysqli_query($conn, $sql_fetch_types);
if ($result_types) {
    while ($type_row = mysqli_fetch_assoc($result_types)) {
        $available_request_types[] = $type_row;
    }
    mysqli_free_result($result_types);
} else {
    error_log("Failed to fetch request types: " . mysqli_error($conn));
    // Handle error, maybe disable form if types can't be fetched
}


// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_request'])) {
    // Use request_type_id from form
    $request_type_id_form = filter_input(INPUT_POST, 'request_type_id', FILTER_VALIDATE_INT);
    $subject_form = trim($_POST['subject']);
    $description_form = trim($_POST['description']);
    $priority_form = $_POST['priority'] ?? 'Medium'; // Default priority if not submitted

    // Basic Validation
    if (empty($request_type_id_form)) {
        $error_message .= "Please select a request type.<br>";
    }
    if (empty($subject_form)) {
        $error_message .= "Subject is required.<br>";
    }
    if (empty($description_form)) {
        $error_message .= "Description is required.<br>";
    }
    // Validate priority if needed
    $valid_priorities = ['Low', 'Medium', 'High', 'Urgent'];
    if (!in_array($priority_form, $valid_priorities)) {
        $priority_form = 'Medium'; // Default if invalid
    }


    if (empty($error_message)) {
        // Insert request into database using request_type_id
        $sql_insert = "INSERT INTO employee_requests 
                       (emp_id, request_type_id, subject, description, status, priority, created_at, updated_at) 
                       VALUES (?, ?, ?, ?, 'Pending', ?, NOW(), NOW())";
        
        $stmt_insert_req = mysqli_prepare($conn, $sql_insert);
        if ($stmt_insert_req) {
            mysqli_stmt_bind_param($stmt_insert_req, "iisss", 
                $emp_id, 
                $request_type_id_form, 
                $subject_form, 
                $description_form,
                $priority_form
            );
            
            if (mysqli_stmt_execute($stmt_insert_req)) {
                $success_message = "Your request has been submitted successfully!";
            } else {
                $error_message = "Error submitting request: " . mysqli_stmt_error($stmt_insert_req);
                error_log("Error submitting employee request: " . mysqli_stmt_error($stmt_insert_req));
            }
            mysqli_stmt_close($stmt_insert_req);
        } else {
            $error_message = "Database error (prepare insert): " . mysqli_error($conn);
            error_log("Database error (prepare insert employee request): " . mysqli_error($conn));
        }
    }
}

// Get employee's previous requests (joining with request_types)
// This is where your line 55 error occurred because $stmt was from the INSERT block if it failed
$requests_list = []; // Initialize
$sql_fetch_requests = "SELECT er.*, rt.type_name as request_type_name, adm.full_name as resolved_by_admin_name 
                       FROM employee_requests er
                       JOIN request_types rt ON er.request_type_id = rt.request_type_id
                       LEFT JOIN admins adm ON er.resolved_by_admin_id = adm.admin_id
                       WHERE er.emp_id = ? 
                       ORDER BY er.created_at DESC"; // Changed request_date to created_at
$stmt_fetch_list = mysqli_prepare($conn, $sql_fetch_requests); // Use a new statement variable

if ($stmt_fetch_list) { // Check if prepare was successful
    mysqli_stmt_bind_param($stmt_fetch_list, "i", $emp_id);
    mysqli_stmt_execute($stmt_fetch_list);
    $result_requests_list = mysqli_stmt_get_result($stmt_fetch_list);
    if ($result_requests_list) {
        while($row_req = mysqli_fetch_assoc($result_requests_list)){
            $requests_list[] = $row_req;
        }
        mysqli_free_result($result_requests_list);
    } else {
        error_log("Error fetching previous requests (get_result): " . mysqli_stmt_error($stmt_fetch_list));
    }
    mysqli_stmt_close($stmt_fetch_list);
} else {
    // This means mysqli_prepare failed for fetching the list
    $error_message .= " Error preparing to fetch previous requests: " . mysqli_error($conn);
    error_log("Error preparing to fetch previous requests: " . mysqli_error($conn));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Requests - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root { /* CSS Variables */
            --primary-color: #f0c14b; /* EPMS Yellow */
            --secondary-color: #3a3a3a; /* Dark Gray */
            --light-gray: #f4f6f9;
            --white: #ffffff;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --text-dark: #34495e;
        }
        body { font-family: 'Arial', sans-serif; margin: 0; background-color: var(--light-gray); color:var(--text-dark); line-height:1.6; }
        .top-header { background-color: var(--secondary-color); color: white; padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .logo-area { display: flex; align-items: center; }
        .logo-img-header { width: 50px; height: 50px; border-radius: 50%; border: 2px solid var(--primary-color); margin-right: 15px; }
        .system-brand h1 { font-size: 1.1em; margin:0; color: var(--primary-color); text-transform:uppercase; letter-spacing:1px;}
        .system-brand p { font-size: 0.8em; margin:0; color: #ccc; }
        .nav-link-back { background-color: var(--primary-color); color: var(--secondary-color); padding: 8px 15px; border-radius: 5px; text-decoration: none; font-weight: bold; display:inline-flex; align-items:center; }
        .nav-link-back i { margin-right: 5px; }
        .nav-link-back:hover { background-color: #e0b030; }

        .main-container { max-width: 900px; margin: 30px auto; padding: 25px; background-color: var(--white); border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .page-heading { text-align: center; font-size: 2rem; color: var(--text-dark); margin-bottom: 25px; }
        
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; border-left-width: 5px; border-left-style: solid; font-size:0.95rem; }
        .alert-success { background-color: #e8f5e9; color: #2e7d32; border-color: var(--success-color); }
        .alert-danger { background-color: #ffebee; color: #c62828; border-color: var(--danger-color); }
        .alert-danger ul { margin:0; padding-left:20px;}
        
        .form-section { margin-bottom: 40px; padding: 25px; background-color: #fdfdfd; border: 1px solid #eee; border-radius: 8px; }
        .form-section h3 { text-align:center; margin-top:0; margin-bottom:25px; color:var(--text-dark); font-size:1.5rem; padding-bottom:10px; border-bottom:2px solid var(--primary-color); }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-weight: 600; color: var(--secondary-color); }
        .form-control { width: 100%; padding: 12px; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; font-size:1rem; }
        .form-control:focus { border-color: var(--primary-color); outline: none; box-shadow: 0 0 0 2px rgba(240,193,75,0.2); }
        textarea.form-control { min-height: 100px; resize: vertical; }
        .btn-submit-request { background-color: var(--primary-color); color: var(--secondary-color); width:100%; padding:12px; border:none; border-radius:5px; font-weight:bold; font-size:1.1rem;}
        .btn-submit-request:hover { background-color: #e0b030; }

        .requests-history h3 { text-align:center; margin-top:0; margin-bottom:25px; color:var(--text-dark); font-size:1.5rem; padding-bottom:10px; border-bottom:2px solid var(--primary-color); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size:0.9rem; }
        th, td { border: 1px solid #ddd; padding: 10px 12px; text-align: left; }
        th { background-color: #e9ecef; color: var(--text-dark); font-weight: 600; }
        tr:nth-child(even) { background-color: #f8f9fa; }
        .status-badge { padding: .3em .6em; font-size: 0.8em; font-weight: 700; line-height: 1; text-align: center; white-space: nowrap; vertical-align: baseline; border-radius: .25rem; color:#fff; }
        .status-Pending { background-color: var(--warning-color); color:var(--text-dark); }
        .status-Resolved, .status-Approved { background-color: var(--success-color); }
        .status-InProgress { background-color: var(--info-color); }
        .status-Rejected, .status-Closed { background-color: var(--danger-color); }
        .btn-view-details { background-color:var(--info-color); color:white; padding:5px 10px; font-size:0.8em; border:none; border-radius:3px; cursor:pointer;}
        .details-content { display:none; padding:10px; background-color:#f9f9f9; margin-top:5px; border-radius:4px; border:1px solid #eee;}
        .details-content p {margin:5px 0;}
        .details-content strong {color:#555;}
        .response-text { padding:8px; background-color:#e6f7ff; border-left:3px solid var(--info-color); margin-top:8px; border-radius:3px;}
        .no-requests { text-align:center; padding:20px; color:#777;}
    </style>
</head>
<body>
    <div class="top-header">
        <div class="logo-area">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img-header">
            <div class="system-brand">
                <h1>EPMS</h1>
                <p>Employee Self-Service</p>
            </div>
        </div>
        <a href="employeeHome.php" class="nav-link-back"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </div>

    <div class="main-container">
        <h1 class="page-heading">My Requests</h1>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger"><?php echo $error_message; /* May contain HTML list */ ?></div>
        <?php endif; ?>
        
        <div class="form-section">
            <h3>Submit a New Request</h3>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="form-group">
                    <label for="request_type_id">Request Type:</label>
                    <select id="request_type_id" name="request_type_id" class="form-control" required>
                        <option value="">-- Select Request Type --</option>
                        <?php foreach ($available_request_types as $type): ?>
                            <option value="<?php echo htmlspecialchars($type['request_type_id']); ?>">
                                <?php echo htmlspecialchars($type['type_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="subject">Subject:</label>
                    <input type="text" id="subject" name="subject" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="priority">Priority:</label>
                    <select id="priority" name="priority" class="form-control">
                        <option value="Medium">Medium</option>
                        <option value="Low">Low</option>
                        <option value="High">High</option>
                        <option value="Urgent">Urgent</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" class="form-control" rows="5" required></textarea>
                </div>
                <button type="submit" name="submit_request" class="btn-submit-request">
                    <i class="fas fa-paper-plane"></i> Submit Request
                </button>
            </form>
        </div>
        
        <div class="requests-history">
            <h3>Your Previous Requests</h3>
            <?php if (!empty($requests_list)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Type</th>
                            <th>Subject</th>
                            <th>Submitted</th>
                            <th>Status</th>
                            <th>Priority</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($requests_list as $request_item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($request_item['request_id']); ?></td>
                                <td><?php echo htmlspecialchars($request_item['request_type_name']); ?></td>
                                <td><?php echo htmlspecialchars($request_item['subject']); ?></td>
                                <td><?php echo date('M d, Y h:i A', strtotime($request_item['created_at'])); ?></td>
                                <td><span class="status-badge status-<?php echo str_replace(' ', '',htmlspecialchars($request_item['status'])); ?>"><?php echo htmlspecialchars($request_item['status']); ?></span></td>
                                <td><?php echo htmlspecialchars($request_item['priority']); ?></td>
                                <td>
                                    <button class="btn-view-details" data-requestid="<?php echo $request_item['request_id']; ?>">
                                        <i class="fas fa-eye"></i> View
                                    </button>
                                </td>
                            </tr>
                            <tr class="details-row" id="details-row-<?php echo $request_item['request_id']; ?>" style="display:none;">
                                <td colspan="7">
                                    <div class="details-content">
                                        <p><strong>Description:</strong><br><?php echo nl2br(htmlspecialchars($request_item['description'])); ?></p>
                                        <?php if (!empty($request_item['resolution_details'])): ?>
                                            <div class="response-text">
                                                <p><strong>Admin Response (<?php echo htmlspecialchars($request_item['resolved_by_admin_name'] ?? 'Admin'); ?>):</strong><br>
                                                <?php echo nl2br(htmlspecialchars($request_item['resolution_details'])); ?></p>
                                                <p><small>Responded on: <?php echo date('M d, Y h:i A', strtotime($request_item['resolved_at'])); ?></small></p>
                                            </div>
                                        <?php elseif ($request_item['status'] == 'Pending' || $request_item['status'] == 'In Progress'):?>
                                            <p><em>This request is currently being processed.</em></p>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-requests">You haven't submitted any requests yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.btn-view-details').forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.dataset.requestid;
                const detailsRow = document.getElementById('details-row-' + requestId);
                if (detailsRow) {
                    if (detailsRow.style.display === 'none' || detailsRow.style.display === '') {
                        detailsRow.style.display = 'table-row';
                        this.innerHTML = '<i class="fas fa-eye-slash"></i> Hide';
                    } else {
                        detailsRow.style.display = 'none';
                        this.innerHTML = '<i class="fas fa-eye"></i> View';
                    }
                }
            });
        });
    });
    </script>
</body>
</html>

<?php
if (isset($conn) && $conn instanceof mysqli) {
    mysqli_close($conn);
}
?>