<?php
session_start();
require_once 'database.php';
if (!$conn || !($conn instanceof mysqli)) {
    // If $conn is not a valid mysqli object, something went wrong in database.php
    // Log this critical error and stop execution or show a friendly error page.
    error_log("Critical: Database connection failed or $conn is not a mysqli object in add_employee.php.");
    die("A critical database error occurred. Please contact support or check server logs.");
}

// Initialize variables
$message = '';
$message_type = '';

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $emp_id = trim($_POST['emp_id']);
    $email = trim($_POST['email']);
    
    // Validate input
    if (empty($emp_id) || empty($email)) {
        $message = "Please enter both Employee ID and Email address.";
        $message_type = "error";
    } else {
        // Check if employee exists with the provided ID and email
        $query = "SELECT emp_id, email, first_name FROM employees WHERE emp_id = ? AND email = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "is", $emp_id, $email);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);
            
            // Generate a random password
            $new_password = generateRandomPassword();
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            
            // Update the password in the database
            $update_query = "UPDATE employees SET password = ? WHERE emp_id = ?";
            $update_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($update_stmt, "si", $hashed_password, $emp_id);
            
            if (mysqli_stmt_execute($update_stmt)) {
                // Password reset successful
                $message = "Password has been reset. Your new password is: <strong>{$new_password}</strong><br>Please login with this password and change it immediately.";
                $message_type = "success";
                
                // In a production environment, you would send this password via email instead of displaying it
                // sendPasswordResetEmail($row['email'], $row['first_name'], $new_password);
            } else {
                $message = "Error resetting password. Please try again later.";
                $message_type = "error";
            }
            
            mysqli_stmt_close($update_stmt);
        } else {
            $message = "No account found with the provided Employee ID and Email.";
            $message_type = "error";
        }
        
        mysqli_stmt_close($stmt);
    }
}

// Function to generate a random password
function generateRandomPassword($length = 10) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()';
    $password = '';
    $max = strlen($characters) - 1;
    
    for ($i = 0; $i < $length; $i++) {
        $password .= $characters[random_int(0, $max)];
    }
    
    return $password;
}

// Function to send password reset email (commented out for now)
/*
function sendPasswordResetEmail($email, $name, $password) {
    $subject = "EPMS Password Reset";
    $message = "Hello {$name},\n\nYour password has been reset. Your new password is: {$password}\n\nPlease login with this password and change it immediately.\n\nRegards,\nEPMS Team";
    $headers = "From: noreply@epms.com";
    
    mail($email, $subject, $message, $headers);
}
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - EPMS</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background-color: #1e2633;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        
        .reset-container {
            background-color: #0e1521;
            border-radius: 10px;
            box-shadow: 0 0 30px rgba(255, 216, 77, 0.2);
            width: 100%;
            max-width: 500px;
            overflow: hidden;
            padding: 40px;
            color: white;
            position: relative;
        }
        
        .reset-container::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(255, 216, 77, 0.4);
            pointer-events: none;
        }
        
        .logo img {
            width: 100px;
            margin-bottom: 30px;
        }
        
        h1 {
            font-size: 2rem;
            margin-bottom: 20px;
            color: white;
        }
        
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }
        
        label {
            display: block;
            color: #fff;
            margin-bottom: 8px;
            font-weight: bold;
        }
        
        .input-icon {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #ccc;
        }
        
        input[type="text"],
        input[type="email"] {
            width: 100%;
            padding: 15px;
            background-color: rgba(255, 255, 255, 0.1);
            border: none;
            border-radius: 25px;
            color: #fff;
            font-size: 16px;
            padding-left: 45px;
        }
        
        input[type="text"]::placeholder,
        input[type="email"]::placeholder {
            color: rgba(255, 255, 255, 0.5);
        }
        
        input:focus {
            border-color: #ffd84d;
            outline: none;
            box-shadow: 0 0 0 2px rgba(255, 216, 77, 0.3);
        }
        
        .input-icon {
            position: absolute;
            left: 20px;
            top: 53px;
            color: #f0c14b;
        }
        
        .reset-btn {
            width: 100%;
            padding: 15px;
            background-color: #f0c14b;
            border: none;
            border-radius: 25px;
            color: #333;
            font-size: 18px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
            margin-bottom: 20px;
        }
        
        .reset-btn:hover {
            background-color: #e0b346;
        }
        
        .back-to-login {
            text-align: center;
            margin-top: 20px;
        }
        
        .back-to-login a {
            color: #f0c14b;
            text-decoration: none;
            font-weight: bold;
        }
        
        .message {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        
        .message.error {
            background-color: rgba(255, 0, 0, 0.1);
            color: #ff6b6b;
            border-left: 4px solid #ff6b6b;
        }
        
        .message.success {
            background-color: rgba(0, 255, 0, 0.1);
            color: #6bff6b;
            border-left: 4px solid #6bff6b;
        }
        
        .system-name {
            text-align: center;
            margin-top: 25px;
            color: rgba(255, 255, 255, 0.7);
            font-size: 14px;
        }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="reset-container">
        <div class="logo">
            <img src="images/logo2.png" alt="EPMS Logo">
        </div>
        
        <h1>Forgot Password</h1>
        
        <?php if (!empty($message)): ?>
            <div class="message <?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
        <?php endif; ?>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="emp_id">Employee ID</label>
                <div class="input-container">
                    <span class="input-icon">👤</span>
                    <input type="text" id="emp_id" name="emp_id" placeholder="Enter your employee ID" required>
                </div>
            </div>
            
            <div class="form-group">
                <label for="email">Email Address</label>
                <div class="input-container">
                    <span class="input-icon">✉️</span>
                    <input type="email" id="email" name="email" placeholder="Enter your email address" required>
                </div>
            </div>
            
            <button type="submit" class="reset-btn">Reset Password</button>
            
            <div class="back-to-login">
                <a href="employeeLogin.php">Back to Login</a>
            </div>
            
            <div class="system-name">
                Employment Payment Management System (EPMS)
            </div>
        </form>
    </div>
</body>
</html>