<?php
// setup_database.php

// Set error reporting at the very top
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start output buffering for better control of progress display
ob_start();

// Set content type and charset (best to do this before any HTML)
header('Content-Type: text/html; charset=utf-8');

// Initialize the global status variable that create_tables.php will set
// Doing this here ensures it's available in the global scope for create_tables.php
global $epms_setup_status_from_create_tables;
$epms_setup_status_from_create_tables = false; // Default to false

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EPMS Database Setup</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            margin: 0;
            padding: 20px;
            min-height: 100vh;
            color: #333;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 40px rgba(0,0,0,0.15);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #f0c14b 0%, #e6b800 100%);
            padding: 30px 20px;
            text-align: center;
            color: #333;
        }
        .header h1 { margin: 0; font-size: 2.2em; font-weight: 400; }
        .header p { margin: 10px 0 0 0; opacity: 0.9; font-size: 0.95em; }
        .content { padding: 25px 30px; }
        .progress-bar { width: 100%; height: 20px; background-color: #e9ecef; border-radius: 10px; overflow: hidden; margin: 25px 0; }
        .progress-fill { height: 100%; background: linear-gradient(90deg, #5cb85c, #4cae4c); width: 0%; transition: width 0.4s ease-in-out; border-radius: 10px; }
        .step { margin: 15px 0; padding: 12px 15px; border-left: 4px solid #ced4da; background: #f8f9fa; border-radius: 0 8px 8px 0; font-size: 0.9em; transition: all 0.3s ease; }
        .step.success { border-left-color: #28a745; background: #e9f7ef; color: #155724; }
        .step.error { border-left-color: #dc3545; background: #f8d7da; color: #721c24; }
        .step.processing { border-left-color: #007bff; background: #e7f3ff; color: #004085; }
        .status-message { color: white; padding: 20px; border-radius: 10px; margin: 25px 0; text-align: center; box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .status-message h3 { margin-top:0; margin-bottom:10px; font-size:1.5em;}
        .success-message { background: linear-gradient(135deg, #28a745, #218838); }
        .error-message { background: linear-gradient(135deg, #dc3545, #c82333); }
        .action-buttons { text-align: center; margin-top: 30px; padding-bottom: 10px; }
        .btn { display: inline-block; padding: 12px 25px; margin: 5px 10px; background: linear-gradient(135deg, #f0c14b, #e6b800); color: #333; text-decoration: none; border-radius: 25px; font-weight: 500; transition: all 0.3s ease; border: none; cursor: pointer; font-size: 0.95em; }
        .btn:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }
        .btn-secondary { background: linear-gradient(135deg, #6c757d, #5a6268); color: white; }
        .info-box { background: #e3f2fd; border: 1px solid #007bff; border-radius: 8px; padding: 15px; margin: 20px 0; font-size: 0.9em; }
        .info-box ul { margin: 10px 0 0 0; padding-left: 20px;}
        .detailed-log-container details { margin: 20px 0; border: 1px solid #ddd; border-radius: 5px;}
        .detailed-log-container summary { cursor: pointer; font-weight: bold; padding: 10px; background-color: #f0f0f0; border-radius: 5px 5px 0 0;}
        .detailed-log-container summary:hover { background-color: #e9e9e9;}
        .detailed-log-output { background: #f9f9f9; padding: 15px; margin-top: 0; font-family: monospace; font-size: 12px; max-height: 400px; overflow-y: auto; border-top: 1px solid #ddd; border-radius: 0 0 5px 5px; word-wrap: break-word; white-space: pre-wrap;}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🏢 EPMS Database Setup</h1>
            <p>Employee Payroll Management System - Database Initialization</p>
        </div>
        
        <div class="content">
            <div class="info-box">
                <strong>📋 Setup Process:</strong> This script will attempt to connect to your database, create the necessary 3NF tables if they don't exist, and insert initial lookup data.
            </div>
            
            <div class="progress-bar">
                <div class="progress-fill" id="progressFill"></div>
            </div>
            
            <div id="setupSteps">
                <?php
                $steps = [
                    'Checking database connection...',        // Step 0
                    'Creating database schema (tables)...',   // Step 1
                    'Inserting initial lookup data...',       // Step 2
                    'Inserting guest employee record...',     // Step 3
                    'Verifying table structure...',           // Step 4
                    'Finalizing setup...'                     // Step 5
                ];
                
                foreach ($steps as $index => $step) {
                    echo "<div class='step' id='step{$index}'>{$step}</div>";
                }
                ?>
            </div>
            
            <?php
            ob_flush(); flush(); 
            
            $setupSuccessOverall = true; 
            $errorMessagesFromSetup = []; 
            $detailed_log_output = ''; 
            
            try {
                // Step 0: Check database connection
                echo "<script>document.getElementById('step0').classList.add('processing'); document.getElementById('progressFill').style.width = '5%';</script>";
                ob_flush(); flush();
                
                // THIS IS WHERE database.php IS INCLUDED
                require_once __DIR__ . '/database.php'; 
                
                if (!$conn || !($conn instanceof mysqli)) { 
                    throw new Exception("Database connection failed. Please check your database.php configuration and that your database server is running.");
                }
                if (!function_exists('getDatabaseStatus')) { // Make sure function from database.php is available
                    throw new Exception("getDatabaseStatus() function not found. Ensure database.php is correctly included and defines it.");
                }
                $db_status = getDatabaseStatus(); 
                if (!$db_status['database_selected'] || !$db_status['database_exists_on_server']) {
                    throw new Exception("Connected to MySQL server, but database '" . DB_NAME . "' not found or not selected. The database.php script should create it if it doesn't exist.");
                }
                
                echo "<script>document.getElementById('step0').classList.remove('processing'); document.getElementById('step0').classList.add('success'); document.getElementById('progressFill').style.width = '16%';</script>";
                ob_flush(); flush();
                
                // Steps 1-3: Handled by create_epms_tables.php
                echo "<script>document.getElementById('step1').classList.add('processing');</script>"; 
                echo "<script>document.getElementById('step2').classList.add('processing');</script>"; 
                echo "<script>document.getElementById('step3').classList.add('processing');</script>"; 
                ob_flush(); flush();
                
                // --- START OF CORRECTED SECTION ---
                // Define possible filenames for the table creation script
                $possible_files = [
                    'create_epms_tables.php'
                    // Add other potential filenames here if your setup might use them
                    // e.g., 'create_tables.php', 'epms_schema.php'
                ];
                $create_tables_path = null; // Initialize

                // Try to find the script file
                foreach ($possible_files as $filename) {
                    $path_to_check = __DIR__ . '/' . $filename;
                    if (file_exists($path_to_check)) {
                        $create_tables_path = $path_to_check;
                        break; // Found the file, exit the loop
                    }
                }
                
                // Check if the table creation script was found
                if (!$create_tables_path) {
                    // $possible_files is defined above, so it can be used here
                    $searched_files_list = implode(', ', $possible_files);
                    throw new Exception("FATAL: None of the expected table creation files were found. Searched for: " . htmlspecialchars($searched_files_list) . " in directory: " . htmlspecialchars(__DIR__) . ". Please ensure one of these files exists in the same directory as setup_database.php.");
                }
                // --- END OF CORRECTED SECTION ---
                
                ob_start(); 
                require_once $create_tables_path; // Use the verified path
                $detailed_log_output = ob_get_clean(); 
                
                // This global variable is set by the table creation script
                global $epms_setup_status_from_create_tables; 
                if ($epms_setup_status_from_create_tables === true) {
                    echo "<script>
                            document.getElementById('step1').classList.remove('processing'); document.getElementById('step1').classList.add('success'); 
                            document.getElementById('step2').classList.remove('processing'); document.getElementById('step2').classList.add('success'); 
                            document.getElementById('step3').classList.remove('processing'); document.getElementById('step3').classList.add('success'); 
                            document.getElementById('progressFill').style.width = '60%';
                          </script>";
                } else {
                    throw new Exception("Core table creation or initial data insertion failed within the table creation script. Review the detailed log. Message: " . ($detailed_log_output ? htmlspecialchars(substr($detailed_log_output, 0, 200)).(strlen($detailed_log_output)>200?'...':'') : "No specific output from table creation script"));
                }
                ob_flush(); flush();

                // Step 4: Verifying table structure
                echo "<script>document.getElementById('step4').classList.add('processing');</script>";
                ob_flush(); flush();
                if (!function_exists('tablesExist')) {
                     throw new Exception("Helper function tablesExist() is not defined. Ensure it's in database.php or included functions file.");
                }
                if (!tablesExist()) { 
                    throw new Exception("Verification failed: Not all required tables exist in the database after setup attempt. Check detailed log from table creation script and the tablesExist() function in database.php.");
                }
                echo "<script>document.getElementById('step4').classList.remove('processing'); document.getElementById('step4').classList.add('success'); document.getElementById('progressFill').style.width = '80%';</script>";
                ob_flush(); flush();

                // Step 5: Finalizing setup
                echo "<script>document.getElementById('step5').classList.add('processing');</script>";
                ob_flush(); flush();
                echo "<script>document.getElementById('step5').classList.remove('processing'); document.getElementById('step5').classList.add('success'); document.getElementById('progressFill').style.width = '100%';</script>";
                ob_flush(); flush();

                echo "<div class='status-message success-message'>";
                echo "<h3>🎉 Database Setup Completed Successfully!</h3>";
                echo "<p>All tables have been created/verified and initial data has been inserted.</p>";
                echo "<p>Your EPMS system is now ready to use!</p>";
                echo "</div>";
                
            } catch (Exception $e) {
                $setupSuccessOverall = false;
                $errorMessagesFromSetup[] = $e->getMessage();
                
                echo "<script>
                        let progressFillElem = document.getElementById('progressFill');
                        if (progressFillElem) progressFillElem.style.backgroundColor = '#dc3545'; // Change progress bar to red
                        // Mark current or all steps as error
                        for(let i=0; i < " . count($steps) . "; i++) {
                            let stepElem = document.getElementById('step' + i);
                            if(stepElem && !stepElem.classList.contains('success')) {
                                stepElem.classList.remove('processing');
                                stepElem.classList.add('error');
                            }
                        }
                      </script>";
                ob_flush(); flush();

                echo "<div class='status-message error-message'>";
                echo "<h3>❌ Setup Failed</h3>";
                foreach ($errorMessagesFromSetup as $msg) {
                    // The message from the exception is already HTML escaped if it came from our custom throw.
                    // If it's a generic PHP exception, htmlspecialchars is good.
                    // To be safe, always escape unless you are sure it's safe or already escaped.
                    // The Exception message for file not found now uses htmlspecialchars.
                    echo "<p>" . $msg . "</p>"; // Assuming $msg is already safe or needs to be output as is from Exception
                }
                echo "</div>";
            }

            if (!empty($detailed_log_output)) {
                echo "<div class='detailed-log-container'><details" . (!$setupSuccessOverall ? " open" : "") .">"; // Open details if error
                echo "<summary>📊 View Detailed Setup Log from Table Creation Script</summary>";
                echo "<div class='detailed-log-output'>";
                echo nl2br(htmlspecialchars($detailed_log_output));
                echo "</div>";
                echo "</details></div>";
            } elseif (empty($detailed_log_output) && !$setupSuccessOverall && !empty($errorMessagesFromSetup)) {
                 $foundCreateTablesError = false;
                 foreach($errorMessagesFromSetup as $msg) {
                     if (strpos(strtolower($msg), "create") !== false && strpos(strtolower($msg), "tables") !== false) {
                         $foundCreateTablesError = true;
                         break;
                     }
                 }
                 if ($foundCreateTablesError) {
                    echo "<p style='color:red; font-weight:bold; padding:10px; background-color:#fff0f0; border-radius:5px;'>Note: The table creation script seems to have failed very early or produced no output before the error. Check its direct execution or PHP error logs for syntax errors.</p>";
                 }
            }
            ?>
            
            <div class="action-buttons">
                <?php if ($setupSuccessOverall): ?>
                    <a href="index.php" class="btn">🚀 Go to Login Page</a>
                    <a href="adminLogin.php" class="btn btn-secondary">👨‍💼 Admin Login</a>
                <?php else: ?>
                    <button onclick="window.location.href='<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>'" class="btn">🔄 Retry Setup</button>
                    <a href="database.php?check_status=1" target="_blank" class="btn btn-secondary">🔧 Check DB Status</a>
                <?php endif; ?>
            </div>
            
            <div class="info-box" style="margin-top: 30px;">
                <strong>📝 Next Steps (if setup was successful):</strong>
                <ul style="margin: 10px 0 0 0; padding-left: 20px;">
                    <li>Access the admin panel (you might need to register the first admin if the table creation script doesn't automatically create one).</li>
                    <li>Review and customize default lookup data (departments, job titles, etc.) via the admin interface if needed.</li>
                    <li>Start adding employees to the system.</li>
                </ul>
            </div>
        </div>
    </div>
    
    <script>
        // Simple scroll to bottom, you might not need this if the page isn't too long
        // window.scrollTo(0, document.body.scrollHeight);
    </script>
</body>
</html>
<?php
ob_end_flush(); // Send the final buffered output
?>