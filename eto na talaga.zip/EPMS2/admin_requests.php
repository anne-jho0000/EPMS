<?php
// Start session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: adminLogin.php");
    exit();
}

// --- INCLUDE CONFIG FILE ---
require_once __DIR__ . '/config.php'; // For CONTACT_FORM_GUEST_EMP_ID

// Include database connection
require_once __DIR__ . '/database.php';
if (!$conn || !($conn instanceof mysqli)) {
    error_log("Critical: Database connection failed in admin_requests.php.");
    die("A critical database error occurred. Please contact support.");
}

// Include admin functions if it exists for logging
if (file_exists(__DIR__ . '/admin_functions.php')) {
    require_once __DIR__ . '/admin_functions.php';
}

$success_message = '';
$error_message = '';
$admin_id_session = (int)$_SESSION['admin_id']; // Current logged-in admin

// Handle response submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['respond_request'])) {
    $request_id_form = filter_input(INPUT_POST, 'request_id', FILTER_VALIDATE_INT);
    $resolution_details_form = trim($_POST['resolution_details'] ?? '');
    $status_form = trim($_POST['status'] ?? '');

    $valid_statuses = ['Pending', 'In Progress', 'Resolved', 'Rejected', 'Closed'];
    if (!$request_id_form) {
        $error_message = "Invalid request ID.";
    } elseif (empty($resolution_details_form)) {
        $error_message = "Response details cannot be empty.";
    } elseif (empty($status_form) || !in_array($status_form, $valid_statuses)) {
        $error_message = "Invalid status selected.";
    } else {
        $sql_update = "UPDATE employee_requests SET 
                        resolution_details = ?, 
                        status = ?, 
                        resolved_at = NOW(),
                        resolved_by_admin_id = ?,
                        updated_at = NOW()
                       WHERE request_id = ?";
        
        $stmt_update = mysqli_prepare($conn, $sql_update);
        if ($stmt_update) {
            mysqli_stmt_bind_param($stmt_update, "ssii", 
                $resolution_details_form, 
                $status_form, 
                $admin_id_session, 
                $request_id_form
            );
            
            if (mysqli_stmt_execute($stmt_update)) {
                $success_message = "Response submitted successfully for Request ID: " . htmlspecialchars($request_id_form);
                if (function_exists('logAdminActivity')) {
                    logAdminActivity($admin_id_session, 'Request Responded', "Responded to request ID $request_id_form with status $status_form.", 'Employee Request', $request_id_form);
                }
            } else {
                $error_message = "Error updating request: " . mysqli_stmt_error($stmt_update);
                error_log("Error updating request ID $request_id_form: " . mysqli_stmt_error($stmt_update));
            }
            mysqli_stmt_close($stmt_update);
        } else {
            $error_message = "Database error (prepare update): " . mysqli_error($conn);
            error_log("Database error (prepare update employee_requests): " . mysqli_error($conn));
        }
    }
}

// Get all employee requests
$requests_list_data = [];

// Get the value of the constant to use in the SQL query
$guest_id_value = CONTACT_FORM_GUEST_EMP_ID;

$sql_select = "SELECT r.request_id, r.subject, r.description, r.status, r.priority, r.created_at, 
                      r.resolution_details, r.resolved_at, r.emp_id as request_emp_id,
                      e.first_name, e.last_name, e.email as employee_email_db,
                      rt.type_name as request_type_name,
                      admin_res.full_name as resolved_by_admin_name
               FROM employee_requests r
               LEFT JOIN employees e ON r.emp_id = e.emp_id AND r.emp_id != " . $guest_id_value . "
               JOIN request_types rt ON r.request_type_id = rt.request_type_id
               LEFT JOIN admins admin_res ON r.resolved_by_admin_id = admin_res.admin_id
               ORDER BY r.status = 'Pending' DESC, r.priority = 'Urgent' DESC, r.priority = 'High' DESC, r.created_at DESC";

$result_requests = mysqli_query($conn, $sql_select);

if (!$result_requests) {
    // Display the specific MySQL error for debugging
    $error_message = "Error fetching requests: " . mysqli_error($conn);
    error_log("Error fetching employee_requests: " . mysqli_error($conn));
} else {
    while($row = mysqli_fetch_assoc($result_requests)) {
        if ($row['request_emp_id'] == CONTACT_FORM_GUEST_EMP_ID) { 
            $parsed_name = 'Guest Contact'; 
            $parsed_email = 'N/A'; 
            if (preg_match('/(?:Submitted By|Name):\s*(.+?)\n/i', $row['description'], $name_matches)) {
                $parsed_name = trim($name_matches[1]);
            }
            if (preg_match('/Email:\s*(.+?)\n/i', $row['description'], $email_matches)) {
                $parsed_email = trim($email_matches[1]);
            }
            $row['display_employee_name'] = $parsed_name;
            $row['display_employee_email'] = $parsed_email;
        } else {
            $row['display_employee_name'] = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? 'Unknown Employee'));
            $row['display_employee_email'] = $row['employee_email_db'] ?? 'N/A';
        }
        $requests_list_data[] = $row;
    }
    mysqli_free_result($result_requests);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Employee Requests - EPMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        :root { /* CSS Variables */
            --primary-color: #f0c14b; /* EPMS Yellow */
            --secondary-color: #3a3a3a; /* Dark Gray */
            --light-gray: #f4f6f9;
            --white: #ffffff;
            --success-color: #28a745;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --text-dark: #34495e;
            --border-color: #dee2e6;
        }
        body { font-family: 'Arial', sans-serif; margin: 0; background-color: var(--light-gray); color:var(--text-dark); line-height:1.6; }
        .top-header { background-color: var(--secondary-color); color: white; padding: 15px 25px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .logo-area { display: flex; align-items: center; }
        .logo-img-header { width: 50px; height: 50px; border-radius: 50%; border: 2px solid var(--primary-color); margin-right: 15px; }
        .system-brand h1 { font-size: 1.1em; margin:0; color: var(--primary-color); text-transform:uppercase; letter-spacing:1px;}
        .system-brand p { font-size: 0.8em; margin:0; color: #ccc; }
        .nav-link-back { background-color: var(--primary-color); color: var(--secondary-color); padding: 8px 15px; border-radius: 5px; text-decoration: none; font-weight: bold; display:inline-flex; align-items:center; }
        .nav-link-back i { margin-right: 5px; }
        .nav-link-back:hover { background-color: #e0b030; }
        
        .main-container { max-width: 1300px; /* Wider for more columns */ margin: 30px auto; padding: 25px; background-color: var(--white); border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .page-heading { text-align: center; font-size: 2rem; color: var(--text-dark); margin-bottom: 25px; }
        
        .alert { padding: 15px; margin-bottom: 20px; border-radius: 5px; border-left-width: 5px; border-left-style: solid; font-size:0.95rem; }
        .alert-success { background-color: #e8f5e9; color: #2e7d32; border-color: var(--success-color); }
        .alert-danger { background-color: #ffebee; color: #c62828; border-color: var(--danger-color); }
        
        .table-responsive-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; font-size:0.9rem; }
        th, td { border: 1px solid var(--border-color); padding: 10px 12px; text-align: left; vertical-align:top;}
        th { background-color: #e9ecef; color: var(--text-dark); font-weight: 600; white-space:nowrap;}
        tr:nth-child(even) { background-color: #f8f9fa; }
        
        .status-badge { padding: .3em .6em; font-size: 0.8em; font-weight: 700; line-height: 1; text-align: center; white-space: nowrap; vertical-align: baseline; border-radius: .25rem; color:#fff; }
        .status-Pending { background-color: var(--warning-color); color:var(--text-dark); }
        .status-Resolved, .status-Approved { background-color: var(--success-color); }
        .status-InProgress { background-color: var(--info-color); }
        .status-Rejected, .status-Closed { background-color: var(--danger-color); }

        .btn-action { padding: 6px 12px; border: none; border-radius: 4px; cursor: pointer; font-weight: 500; transition: all 0.2s; font-size: 0.85rem; margin-right:5px; }
        .btn-action i { margin-right: 5px; }
        .btn-view-respond { background-color: var(--info-color); color:white; }
        .btn-view-respond:hover { background-color: #138496; }

        .details-row td { background-color: #fdfdfd; padding:0;} /* For the expand row */
        .request-details-content { padding: 15px; border: 1px solid #eee; border-top:2px solid var(--info-color); }
        .request-details-content p { margin: 5px 0 10px 0; line-height:1.5;}
        .request-details-content strong { color: #555; }
        .response-text-display { margin-top:15px; padding: 10px; background-color: #e6f7ff; border-left: 3px solid var(--info-color); border-radius: 4px;}
        .response-text-display small { font-size:0.8em; color:#777; display:block; margin-top:5px;}
        
        .response-form-wrapper { margin-top: 15px; padding: 20px; background-color: #f0f2f5; border-radius: 5px; display: none; }
        .response-form-wrapper h4 { margin-top:0; margin-bottom:15px; color:var(--text-dark); font-size:1.1rem;}
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; margin-bottom: 6px; font-weight: 500; }
        .form-control { width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px; box-sizing:border-box; font-size: 0.9rem; }
        textarea.form-control { min-height: 80px; resize: vertical; }
        .response-actions { text-align: right; margin-top: 15px;}
        .btn-submit-response { background-color: var(--success-color); color:white; }
        .btn-cancel-response { background-color: var(--secondary-color); color:white; }
        .no-requests { text-align:center; padding:30px; color:#777; font-style:italic;}
    </style>
</head>
<body>
    <div class="top-header">
        <div class="logo-area">
            <img src="images/epms(logo).jpg" alt="EPMS Logo" class="logo-img-header">
            <div class="system-brand">
                <h1>EPMS</h1>
                <p>Admin Panel</p>
            </div>
        </div>
        <a href="adminHome.php" class="nav-link-back"><i class="fas fa-arrow-left"></i> Dashboard</a>
    </div>

    <div class="main-container">
        <h1 class="page-heading">Manage Employee & Guest Requests</h1>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success"><i class="fas fa-check-circle"></i> <?php echo htmlspecialchars($success_message); ?></div>
        <?php endif; ?>
        <?php if (!empty($error_message)): ?>
             <div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> <?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
        
        <div class="table-responsive-wrapper">
        <?php if (!empty($requests_list_data)): ?>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Submitted By</th>
                        <th>Contact Email</th>
                        <th>Type</th>
                        <th>Subject</th>
                        <th>Date Submitted</th>
                        <th>Priority</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requests_list_data as $request): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($request['request_id']); ?></td>
                            <td><?php echo htmlspecialchars($request['display_employee_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['display_employee_email']); ?></td>
                            <td><?php echo htmlspecialchars($request['request_type_name']); ?></td>
                            <td><?php echo htmlspecialchars($request['subject']); ?></td>
                            <td><?php echo date('M d, Y h:i A', strtotime($request['created_at'])); ?></td>
                            <td><?php echo htmlspecialchars($request['priority']); ?></td>
                            <td><span class="status-badge status-<?php echo str_replace(' ', '',htmlspecialchars($request['status'])); ?>"><?php echo htmlspecialchars($request['status']); ?></span></td>
                            <td>
                                <button class="btn-action btn-view-respond" data-requestid="<?php echo $request['request_id']; ?>">
                                    <i class="fas fa-eye"></i> View/Respond
                                </button>
                            </td>
                        </tr>
                        <tr class="details-row" id="details-row-<?php echo $request['request_id']; ?>" style="display:none;">
                            <td colspan="9">
                                <div class="request-details-content" id="content-<?php echo $request['request_id']; ?>">
                                    <p><strong>Full Description:</strong><br><?php echo nl2br(htmlspecialchars($request['description'])); ?></p>
                                    
                                    <?php if (!empty($request['resolution_details'])): ?>
                                        <div class="response-text-display">
                                            <p><strong>Response by <?php echo htmlspecialchars($request['resolved_by_admin_name'] ?? 'Admin'); ?>:</strong><br>
                                                <?php echo nl2br(htmlspecialchars($request['resolution_details'])); ?></p>
                                            <small>Responded on: <?php echo date('M d, Y h:i A', strtotime($request['resolved_at'])); ?></small>
                                        </div>
                                    <?php elseif (!in_array($request['status'], ['Resolved', 'Rejected', 'Closed'])): ?>
                                        <button class="btn-action btn-primary respond-form-toggle-btn mt-2" data-requestid="<?php echo $request['request_id']; ?>" style="background-color:var(--primary-color); color:var(--text-dark);">
                                            <i class="fas fa-reply"></i> Respond Now
                                        </button>
                                        <div id="response-form-<?php echo $request['request_id']; ?>" class="response-form-wrapper">
                                            <h4>Submit Response</h4>
                                            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                                                <input type="hidden" name="request_id" value="<?php echo $request['request_id']; ?>">
                                                <div class="form-group">
                                                    <label for="resolution_details_<?php echo $request['request_id']; ?>">Response:</label>
                                                    <textarea id="resolution_details_<?php echo $request['request_id']; ?>" name="resolution_details" class="form-control" rows="4" required></textarea>
                                                </div>
                                                <div class="form-group">
                                                    <label for="status_<?php echo $request['request_id']; ?>">Update Status:</label>
                                                    <select id="status_<?php echo $request['request_id']; ?>" name="status" class="form-control" required>
                                                        <option value="In Progress" <?php if($request['status'] == 'In Progress') echo 'selected';?>>In Progress</option>
                                                        <option value="Resolved" <?php if($request['status'] == 'Resolved') echo 'selected';?>>Resolved</option>
                                                        <option value="Rejected" <?php if($request['status'] == 'Rejected') echo 'selected';?>>Rejected</option>
                                                        <option value="Closed" <?php if($request['status'] == 'Closed') echo 'selected';?>>Closed</option>
                                                        <option value="Pending" <?php if($request['status'] == 'Pending') echo 'selected';?>>Keep Pending</option>
                                                    </select>
                                                </div>
                                                <div class="response-actions">
                                                    <button type="button" class="btn-action btn-cancel-response" data-requestid="<?php echo $request['request_id']; ?>">Cancel</button>
                                                    <button type="submit" name="respond_request" class="btn-action btn-submit-response"><i class="fas fa-paper-plane"></i> Submit</button>
                                                </div>
                                            </form>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php elseif (empty($error_message) && mysqli_ping($conn)): // Only show "no requests" if there wasn't a general query error and DB connection is still alive ?>
            <p class="no-requests">No employee or guest requests found at this time.</p>
        <?php endif; ?>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        document.querySelectorAll('.btn-view-respond').forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.dataset.requestid;
                const detailsRow = document.getElementById('details-row-' + requestId);
                if (detailsRow) {
                    if (detailsRow.style.display === 'none' || detailsRow.style.display === '') {
                        detailsRow.style.display = 'table-row';
                        this.innerHTML = '<i class="fas fa-eye-slash"></i> Hide Details';
                    } else {
                        detailsRow.style.display = 'none';
                        this.innerHTML = '<i class="fas fa-eye"></i> View/Respond';
                        const responseForm = document.getElementById('response-form-' + requestId);
                        if (responseForm) responseForm.style.display = 'none';
                        const respondBtn = document.querySelector(`.respond-form-toggle-btn[data-requestid="${requestId}"]`);
                        if (respondBtn) respondBtn.style.display = 'inline-block'; 
                    }
                }
            });
        });

        document.querySelectorAll('.respond-form-toggle-btn').forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.dataset.requestid;
                const responseForm = document.getElementById('response-form-' + requestId);
                if (responseForm) responseForm.style.display = 'block';
                this.style.display = 'none'; 
            });
        });

        document.querySelectorAll('.btn-cancel-response').forEach(button => {
            button.addEventListener('click', function() {
                const requestId = this.dataset.requestid;
                const responseForm = document.getElementById('response-form-' + requestId);
                if (responseForm) responseForm.style.display = 'none';
                const respondBtn = document.querySelector(`.respond-form-toggle-btn[data-requestid="${requestId}"]`);
                if (respondBtn) respondBtn.style.display = 'inline-block'; 
            });
        });
    });
    </script>
</body>
</html>
<?php
if (isset($conn) && $conn instanceof mysqli) {
    mysqli_close($conn);
}
?>